#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/package-benchmark-20261010
case_name=$1
kind=$2
cd "$root/$case_name"
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
binary=/home/mozztcad/geo3d/build/sinterconnect_run
extra=()
if [ "$kind" = vendor ]; then
 binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
 extra=(--noSyntaxCheck)
fi
sha256sum "$binary" case.cmd ../mesh-package-final/package_msh.tdr > identities.sha256
date -Is > start.txt
cat /proc/sys/vm/swappiness > swappiness.txt
for attempt in 1 2 3 4 5 6; do
 vmstat 1 6 > "load-before-$attempt.txt"
 cp "load-before-$attempt.txt" load-before.txt
 if awk 'NF>=17 && $1 ~ /^[0-9]+$/ {n++; if (n>1 && ($7 != 0 || $8 != 0 || $15 < 95)) bad=1} END {exit bad || n<2}' load-before.txt; then break; fi
 if [ "$attempt" = 6 ]; then echo 'VM load did not settle; run not started' > rejected-load.txt; exit 75; fi
done
vmstat 1 > load-during.txt & monitor=$!
grep -E '^pswpin |^pswpout ' /proc/vmstat > swap-before.txt
trap 'kill "$monitor" 2>/dev/null || true' EXIT
set +e
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$binary" "${extra[@]}" case.cmd > stdout.log 2> stderr.log
rc=$?
set -e
kill "$monitor" 2>/dev/null || true
wait "$monitor" 2>/dev/null || true
grep -E '^pswpin |^pswpout ' /proc/vmstat > swap-after.txt
trap - EXIT
if cmp -s swap-before.txt swap-after.txt && awk 'NF>=17 && $1 ~ /^[0-9]+$/ {n++; if (n>1 && ($7 != 0 || $8 != 0)) bad=1} END {exit bad || n<2}' load-during.txt; then
 echo VALID_NO_VM_SWAP > timing-valid.txt
else
 echo INVALID_VM_SWAP > timing-valid.txt
fi
echo "$rc" > exit.txt
grep -E 'BENCH_|Points:|Nodes:|Volumes:|Elapsed time for solve|Total elapsed|CPU Time:' stdout.log | tail -12 || true
grep -E 'Exception|Error|Maximum resident|Elapsed \(wall|Exit status' stderr.log | tail -6 || true
exit "$rc"
