(sde:clear)

; Set SDE in the UCS coordinate system
; ---------------------------------------------------------------

(sde:set-process-up-direction "-x")

; Define meshing parameters for SDE
; ---------------------------------------------------------------

(sdesnmesh:delaunizer  
      "maxPoints" 60000 
      "delaunayTolerance" 0.6
)

; Define the dimensions of the Silicon die
; ---------------------------------------------------------------

(define X0 0)
(define XDie 2500)
(define Y0 0)
(define YDie 3500)

; Define the vertical dimensions of the Silicon die and BEOL
; ---------------------------------------------------------------

(define Z0  0)
(define ZDie 200.0)
(define Zbeol1 180.0)
(define Zbeol2 200.0)

; Define the source and gate mask
; ---------------------------------------------------------------

(sdepe:generate-mask "8"  (list                            
( list 50 1950 50 2450 350 2450 350 1950 )
( list 50 50 50 1900 3450 1900 3450 50 )
( list 400 1900 400 2450 3450 2450 3450 1900 )
) )

; Process emulation commands to generate the die structure
; ---------------------------------------------------------------

; Define the simulation domain
; ---------------------------------------------------------------

; Silicon depth is 200 microns

(sdepe:define-pe-domain (list Y0 X0 YDie XDie))
(sdepe:add-substrate "material" "Silicon" "thickness" ZDie)

; Create BEOL on top of the silicon die and save the structure 
; with the BEOL layer
; ---------------------------------------------------------------

(sdegeo:set-default-boolean "ABA")

(sdepe:depo "material" "SmearBeol" "thickness" 25.0)

(sdeio:save-3d-tdr-bnd (get-body-list) "npkg_sib_bnd.tdr")

; Create the simplified top aluminum layer and save the structure
; with the aluminum layer. Aluminum is 1.0 um thick. 
; ---------------------------------------------------------------

(sdepe:depo "material" "Aluminum" "thickness" 1.0)

; Metal mask for Die surface
; ---------------------------------------------------------------

(sdepe:pattern "mask" "8" "polarity" "light" "material" "Resist" "thickness" 1.0)
(sdepe:etch-material "material" "Aluminum"   "depth" 2.0   "type" "aniso")
(sdepe:remove "material" "Resist")

(sdeio:save-3d-tdr-bnd (get-body-list) "npkg_siba_bnd.tdr")

; Add preform of 35um thickness at the bottom of Si Die
; ---------------------------------------------------------------

(define PreX0 (- X0 200) )
(define PreY0 (- Y0 200) )
(define XPre  (+ (+ PreX0 400) XDie) ) 
(define YPre  (+ (+ PreY0 400) YDie) ) 
(define ZPre  35)

(sdegeo:create-cuboid 
        (position (* -1.0 Z0) PreY0 PreX0    )  
(position (* -1.0 (- Z0 ZPre)) YPre XPre    ) "Solder" "preform" )

; (sdepe:fill-device "material" "SmearBeol" "height" -225 "region" "SmearBeol")

; Add Frame of 800um thickness at the bottom of Preform
; Save the structure with the preform and frame
; ---------------------------------------------------------------

(define FrameX0 (+ XDie 900) )
(define FrameY0 (- Y0   700) )
(define XFrame  (- FrameX0 5100) ) 
(define YFrame  (+ YDie 700) )
(define ZFrame  800)

(define Zcurrent (- Z0 ZPre) )

(sdegeo:create-cuboid 
        (position (* -1.0 (- Z0 ZPre)) FrameY0  FrameX0  )  
(position (* -1.00 (- Zcurrent ZFrame)) YFrame XFrame  ) "Copper" "frame" )

(sdeio:save-3d-tdr-bnd (get-body-list) "npkg_sibashs_bnd.tdr")

; Create contact wires and enclose the structure in resin material
; The contact wires are 0.25 mm thick
; ---------------------------------------------------------------

(define ResinX0 (+ FrameX0 1700) )
(define ResinY0 (- FrameY0 850) )
(define XResin  (- ResinX0 6000) ) 
(define YResin  (+ YFrame 850) )
(define ZResin  (+ ZDie (+ ZPre (+ ZFrame 1360))) )

(define LeadX0 (- ResinX0 1000) )
(define LeadY0 (- YFrame 400) )
(define XLead0 (+ LeadX0 1000) )
(define YLead0 (+ LeadY0  400) )

(define LeadX1 (- ResinX0 1000) )
(define LeadY1 (+ FrameY0  0) )
(define XLead1 (+ LeadX1 1000) )
(define YLead1 (+ LeadY1  400) )

(define Zlength (- (/ ZResin 2) 225) )
(define Zlead0 (- (+ Zcurrent Zlength) 550.0) )
(define Zlead1 (- (+ Zlead0 250) 550.0) ) 

(sdegeo:create-cuboid 
         (position (* -1.0 Zlead0) LeadY0 LeadX0)  
(position (* -1.0 Zlead1) YLead0 XLead0) "Copper" "lead1" )

(sdegeo:create-cuboid 
        (position (* -1.0 Zlead0) LeadY1  LeadX1)  
(position (* -1.0 Zlead1) YLead1 XLead1 ) "Copper" "lead2" )

(define Lead1Wire (sdegeo:create-polyline-wire (list
        (position (* -1.0 Zlead0) LeadY0 LeadX0)
        (position (* -1.0 Zlead0) LeadY0 (+ LeadX0 2200))
        (position (* -1.0 (- Zcurrent 500)) LeadY0 (+ LeadX0 2800))
(position (* -1.0 (- Zcurrent 500)) LeadY0 (+ LeadX0 3800)))) )

(define Lead2Wire (sdegeo:create-polyline-wire (list
        (position (* -1.0 Zlead0) LeadY1 LeadX1)
        (position (* -1.0 Zlead0) LeadY1 (+ LeadX1 2200) )
        (position (* -1.0 (- Zcurrent 500)) LeadY1 (+ LeadX1 2800))
(position (* -1.0 (- Zcurrent 500)) LeadY1 (+ LeadX1 3800)))) )
	
(sdegeo:sweep (list
        (car (find-face-id (position -237.5 3850 5100))) )
        Lead1Wire (sweep:options "solid" #t "rigid" #f "miter_type" "default") )	

(sdegeo:sweep (list
       (car (find-face-id (position -237.5 -500 5100))) )
        Lead2Wire (sweep:options "solid" #t "rigid" #f "miter_type" "default") )
        
(entity:delete Lead1Wire)
(entity:delete Lead2Wire)
	
(define XGate (- XDie 275) )
(define YGate (+ Y0 (/ 400 2)) )
(define ZGate ZDie)

(define XGate1 XPre )
(define YGate1 PreY0 )
(define ZGate1 (+ Zlead1 500) )

(define XGateF (- ResinX0 800) )
(define YGateF (+ ResinY0 1000) )
(define ZGateF Zlead1)

(define XSource (+ X0 (/ XDie 2)) )
(define YSource (+ (+ Y0 (/ YDie 2)) 500) )
(define ZSource ZDie)

(define XSource1 XPre )
(define YSource1 YPre )
(define ZSource1 (+ Zlead1 500) )

(define XSourceF (- ResinX0 800) )
(define YSourceF (- YResin 1000) )
(define ZSourceF Zlead1)

(sdegeo:create-cuboid 
	(position -341.75 3975 1225 ) 
	(position -437.5 4125 4300  ) 
	"Copperline" "DrainWire" 
)

(sdegeo:create-cuboid 
	(position -341.75 2125 1225 ) 
	(position -201 2275 1375) 
	"Copperline" "DrainWire" 
)

(sdegeo:create-cuboid 
	(position -341.75 2125  1225) 
	(position -437.5 4125 1375 ) 
	"Copperline" "DrainWire" 
)

(sdegeo:create-cuboid 
	(position -341.75 -625 2125   ) 
	(position -437.5 -475 4300 ) 
	"Copperline" "GateWire" 
)

(sdegeo:create-cuboid 
	(position -341.75 125  2125) 
	(position -201 275  2275) 
	"Copperline" "GateWire" 
)

(sdegeo:create-cuboid 
	(position -341.75 -625 2125 ) 
	(position -437.5 275 2275 ) 
	"Copperline" "GateWire" 
)

; Save the structure with the contact wires
; ---------------------------------------------------------------

(sdeio:save-3d-tdr-bnd (get-body-list) "npkg_sibashsl_bnd.tdr")

; Extract geometry infomation to use in mesh generation
; ---------------------------------------------------------------

(define Xmin (position:x (car (bbox (get-body-list)))))
(define Xmax (position:x (cdr (bbox (get-body-list)))))
(define Ymin (position:y (car (bbox (get-body-list)))))
(define Ymax (position:y (cdr (bbox (get-body-list)))))
(define Zmin (position:z (car (bbox (get-body-list)))))
(define Zmax (position:z (cdr (bbox (get-body-list)))))

(display "; Xmin = ") (display Xmin) (newline)
(display "; Xmax = ") (display Xmax) (newline)
(display "; Ymin = ") (display Ymin) (newline)
(display "; Ymax = ") (display Ymax) (newline)
(display "; Zmin = ") (display Zmin) (newline)
(display "; Zmax = ") (display Zmax) (newline)


; (sdegeo:set-default-boolean "ABiB")
(sdegeo:set-default-boolean "BAB")
(sdegeo:create-cuboid 
        (position (* -1.0 1560) ResinY0 ResinX0)  
(position (* -1.00 (- Zcurrent ZFrame)) YResin XResin ) "Resin" "Resin" )

; Save the structure with the resin encapsulation
; ---------------------------------------------------------------

; (sdeio:save-3d-tdr-bnd (get-body-list) "npkg_sibashslr_bnd.tdr")

; Define refinement placements for the entire package strucutre
; ---------------------------------------------------------------

(define xMaxSize (/ Xmax 10))
(define yMaxSize (/ Ymax 15))
(define zMaxSize (/ Zmax 20))
(define MostMin  (max Xmax Ymax Zmax))
(define minSize  (/ MostMin 80))
(define Size1    (/ MostMin 50))
(define Size2    (/ MostMin 5)) 
(define Size3    (/ MostMin 5))

(define zSize3 (/ ZDie 100))
(define zSize2 (/ ZDie 5))
(define zSize1 (/ Zmax 25))
(define ySize1 (/ Ymax 30))

; Solder refinement definitions
; ---------------------------------------------------------------

(sdedr:define-refeval-window "SolderWin1" "Cuboid" (position 0 (- Y0 50) (- X0 50)) (position 35 (+ Y0 50) (+ XDie 50)) )
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "SolderWin2" "Cuboid" (position 0 (- YDie 50) (- X0 50)) (position 35 (+ YDie 50) (+ XDie 50)) )
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "SolderWin3" "Cuboid" (position 0 (+ Y0 50) (- X0 50)) (position 35 (+ YDie 50) (+ X0 50)) )
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "SolderWin4" "Cuboid" (position 0 (+ Y0 50) (- XDie 50)) (position 35 (+ YDie 50) (+ XDie 50)) )
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "SolderWin5" "Cuboid" (position 0 (- YDie 50) (- X0 50)) (position 35 (+ YDie 50) (+ XDie 50)) )
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "SolderWin6" "Cuboid" (position 0 (- YDie 350) (- X0 50)) (position 35 (+ YDie 50) (+ X0 50)) )
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

; Crack refinement definitions
; ---------------------------------------------------------------

(define maxlt (+ (* 2.0 50) 50))

(sdedr:define-refeval-window "CrkWin2" "Cuboid" (position -40 (- 3500 (* 2.0 maxlt)) (- 0 (* 0.5 maxlt)) ) (position 40 (+ 3500 (* 0.5 maxlt)) (* 2.0 maxlt)) ) 
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "CrkWin3" "Cuboid" (position -25 (- 3500 maxlt) 0) (position 25 (- 3500 0) maxlt) ) 
; thermal benchmark: omitted crack/solder-specific refinement
; thermal benchmark: omitted crack/solder-specific refinement

(sdedr:define-refeval-window "GlobalWin" "Cuboid" (position Xmin Ymin Zmin) (position Xmax Ymax Zmax) ) 
(sdedr:define-refinement-size "GlobalSize" 600 600 600 300 300 300 )
(sdedr:define-refinement-placement "GlobalPlace" "GlobalSize" "GlobalWin" )

; Save the mesh command file 
; ---------------------------------------------------------------

; (sdedr:write-cmd-file "npkg_sibashslr_msh.cmd")

; Build the mesh for the entire package
; ---------------------------------------------------------------


(define gaslo (car (bbox (get-body-list))))
(define gashi (cdr (bbox (get-body-list))))
(sdegeo:set-default-boolean "BAB")
(sdegeo:create-cuboid (position (- (position:x gaslo) 50) (position:y gaslo) (position:z gaslo)) (position (position:x gaslo) (position:y gashi) (position:z gashi)) "Gas" "Gas_ambient")
(sdeio:save-3d-tdr-bnd (get-body-list) "package_bnd.tdr")
