Definitions { Refinement "global" { MaxElementSize=(150 150 150) MinElementSize=(75 75 75) } }
Placements { Refinement "global" { Reference="global" RefineWindow=Cuboid [(-2000 -2000 -2500) (1500 6000 10000)] } }
Delaunizer { maxPoints=200000 delaunayTolerance=0.6 }
