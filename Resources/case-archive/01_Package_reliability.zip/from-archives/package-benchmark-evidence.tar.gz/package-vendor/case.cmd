math numThreads=1
pdbSet Grid AddGasMesh 0
mater add name=Copperline new.like=Copper
mater add name=SmearBeol new.like=Nitride
mater add name=Resin new.like=Copper
init tdr=../mesh-package-final/package_msh.tdr !load.commands !pdb
SetTemp 26.844
pdbSet Env.Temp 26.844
pdbSet Gas AttachThermalResistor 0
pdbSet Gas RadiationHeatTransfer 1
pdbSet Gas ConvectiveHeatTransfer 0
# Radiation on Gas interfaces; convection on exterior side boundaries.
# Conductivities in W/(cm K). Package sdevice.par supplies Cu/Solder/Resin.
foreach {mat k} {Silicon 1.48 Copper 4.01 Copperline 4.01 Solder 0.41 Resin 0.00168 SmearBeol 0.015 Aluminum 2.37} {
 pdbSet $mat Temperature Conductivity $k
 pdbSet $mat Temperature JouleHeating 0
 pdbSet $mat AttachThermalResistor 0
 pdbSet $mat HeatSinkTransfer 0.0
 pdbSet $mat SideHeatTransfer 0.0025
 pdbSet $mat Emissivity 0.8
}
# Copper package base coupled to a heat sink: 1000 W/(m2 K).
pdbSet Copper HeatSinkTransfer 0.1
supply region.name=region_1 power.density=2857.142857142857
mode thermal
solve info=2
puts "BENCH_TMAX [select max name=Temperature]"
puts "BENCH_TMIN [select min name=Temperature]"
struct tdr=result
