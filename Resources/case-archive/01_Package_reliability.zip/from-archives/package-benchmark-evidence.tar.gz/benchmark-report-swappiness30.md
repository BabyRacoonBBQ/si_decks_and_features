# Package heat-transfer benchmark — StressThermal vs vendor

The repaired Release `sinterconnect_run` completes the selected package heat-transfer case. Performance is reported for this steady thermal deck only; it is not a general product speedup claim. See the run-environment table before interpreting elapsed-time ratios.

## VM and execution boundary

All machine information was collected inside `192.168.43.128`. Rocky Linux 8.10, kernel `4.18.0-553.el8_10.x86_64`, VMware guest, 10 vCPUs, approximately 12.4 GiB RAM. The guest-reported CPU model is Intel Core i7-13700F. No host-machine inventory was collected.

Both binaries run sequentially on guest CPU 4 with `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, a 6 GiB virtual-memory limit, and a 300 s timeout. Measured repetitions alternate execution order: odd-numbered rounds vendor/local, even-numbered rounds local/vendor. Selected round numbers appear in the environment table. Each starts after five 1 s samples with at least 95% guest idle and no swapping. No GDB, Frida, or preload instrumentation is present.

The local binary is CMake Release (`-O3 -DNDEBUG`), built from `4140959ce963437b066e36dcc47703ac609881a1` plus the uncommitted thermal-entry patch. Native timer labels are retained. Vendor runs use `--noSyntaxCheck`; the local runner has no corresponding option. End-to-end startup work is therefore product-specific.

## Deck and mesh

Adapted from `Applications_Library/Backend/Package_ThermomechanicalReliability`. The original thermal stage uses SDevice; this benchmark expresses its package geometry and material context in a SInterconnect thermal deck. It is an adapted engineering example, not an unchanged vendor reference deck.

- 107,792 spatial vertices; 129,399 material nodes reported by both binaries.
- 593,869 tetrahedral volume elements: 568,909 solid and 24,960 ambient Gas.
- 15 solid regions, 1 Gas region, 7 distinct solid materials.
- External mesh retained by `Grid AddGasMesh=0`; mesh generation is excluded from executable timings.
- Steady 5 W die power, ambient 300 K, conduction in all solids.
- Top Gas-interface radiation, emissivity 0.8; side convection 25 W/(m² K); Copper bottom heat-sink convection 1000 W/(m² K). Radiation and convection act on separate boundary sets.

| Material | Conductivity W/(m K) | Basis |
|---|---:|---|
| Silicon | 148 | Benchmark assumption |
| Copper / Copperline | 401 | Package parameter file |
| Solder | 41 | Package parameter file |
| Resin | 0.168 | Package parameter file |
| SmearBeol | 1.5 | Effective BEOL assumption |
| Aluminum | 237 | Benchmark assumption |

The mesh and inputs are identical across each vendor/local pair. The measured exchange files are TDR16 because that is the vendor comparison boundary; this does not validate a GFR export path.

## Native total and inclusive solve timers

Values are medians of three runs. Parenthesized ranges are min–max.

| Metric | Vendor | Release local |
|---|---:|---:|
| Native Elapsed Time (s) | 63.00 | 26.00 |
| Native User Time (s) | 27.00 | 25.00 |
| Native CPU Time (s) | 26.00 | 24.00 |
| Native inclusive solve (s) | 14.95 (14.82–15.72) | 14.07 (14.04–14.17) |
| External wall clock (s) | 63.71 (63.62–65.18) | 27.39 (27.34–27.67) |
| Peak RSS (KiB) | 1757976.00 (1757496.00–1758360.00) | 1661488.00 (1661456.00–1665780.00) |

The observed inclusive-solve ratio is 1.063× (vendor/local). End-to-end elapsed time also contains startup/waiting and I/O; its ratio must not be described as a solver acceleration.

## Every reported native module

A final `select max name=Temperature info=3` enables the full native timer report after the simulation and output finish. Both decks contain this same command. Values below are medians in seconds. `0.00` means rounded to native timer resolution, not absent work. Names such as “Mechanics step” are native timer labels; this deck solves thermal physics only.

| Native timer | Vendor CPU | Local CPU | Vendor elapsed | Local elapsed | Calls V / L |
|---|---:|---:|---:|---:|---|
| BoxMethod by Region | 9.99 | 9.68 | 10.26 | 9.94 | 1 / 1 |
| init command | 6.14 | 4.98 | 6.31 | 5.12 | 1 / 1 |
| struct command | 5.13 | 5.38 | 5.27 | 5.54 | 1 / 1 |
| Solver(PDE). | 3.83 | 3.27 | 3.94 | 3.37 | 3 / 3 |
| Other Program Parts | 1.17 | 1.31 | 1.22 | 1.37 | 1 / 1 |
| solve command | 0.29 | 0.27 | 0.30 | 0.28 | 1 / 1 |
| Solve step time. | 0.26 | 0.26 | 0.27 | 0.26 | 1 / 1 |
| sel command | 0.25 | 0.36 | 0.26 | 0.37 | 71 / 71 |
| Serial mode assembly. | 0.10 | 0.13 | 0.11 | 0.13 | 5 / 5 |
| mater command | 0.05 | 0.05 | 0.05 | 0.05 | 95 / 95 |
| Total time spent in Symbolic. | 0.05 | 0.02 | 0.05 | 0.02 | 1 / 1 |
| TS4Geom | 0.02 | 0.02 | 0.02 | 0.02 | 1 / 1 |
| SetTemp command | 0.00 | 0.08 | 0.01 | 0.08 | 1 / 1 |
| select command | 0.01 | 0.01 | 0.01 | 0.01 | 6 / 6 |
| region command | 0.01 | 0.01 | 0.01 | 0.01 | 68 / 68 |
| term command | 0.01 | 0.02 | 0.01 | 0.02 | 87 / 87 |
| Store nodal values: Serial. | 0.01 | 0.01 | 0.01 | 0.01 | 80 / 80 |
| supply command | 0.00 | 0.00 | 0.00 | 0.00 | 9 / 9 |
| contact command | 0.00 | 0.00 | 0.00 | 0.00 | 5 / 5 |
| mgoals command | 0.00 | 0.01 | 0.00 | 0.01 | 1 / 1 |
| mode command | 0.00 | 0.00 | 0.00 | 0.00 | 2 / 2 |
| Prepare structure | 0.00 | 0.00 | 0.00 | 0.00 | 1 / 1 |
| Mechanics step | 0.00 | 0.00 | 0.00 | 0.00 | 1 / 1 |
| solution command | 0.00 | 0.01 | 0.00 | 0.01 | 89 / 89 |
| math command | 0.00 | 0.00 | 0.00 | 0.00 | 9 / 9 |
| circuit command | 0.00 | not reported | 0.00 | not reported | 1 / not reported |
| equation command | 0.00 | 0.00 | 0.00 | 0.00 | 14 / 14 |

The detailed stopwatch categories and inclusive `Elapsed time for solve` have different accounting boundaries. Do not add the inclusive timer to its submodules. Native total elapsed time also includes time outside the detailed stopwatch categories.

## Environment for every measured run

`vmstat` is sampled each second; its first cumulative-since-boot row and repeated headers are excluded. Swap amounts below are sums of the 1 s samples in KiB. A strict zero-swap criterion is reported independently rather than silently relaxed.

| Run | Pre-run mean idle % | During mean idle % | Swap in / out KiB | Strict zero-swap |
|---|---:|---:|---:|---|
| 1 vendor | 100.00 | 94.95 | 16 / 0 | INVALID_VM_SWAP |
| 1 local | 100.00 | 89.44 | 0 / 0 | VALID_NO_VM_SWAP |
| 2 vendor | 100.00 | 95.37 | 0 / 0 | VALID_NO_VM_SWAP |
| 2 local | 100.00 | 89.15 | 0 / 0 | VALID_NO_VM_SWAP |
| 3 vendor | 100.00 | 95.24 | 48 / 0 | INVALID_VM_SWAP |
| 3 local | 100.00 | 89.41 | 8 / 0 | INVALID_VM_SWAP |

**Environmental qualification:** Some runs contain guest-wide swap activity, as listed above. These are observational measurements, not a clean zero-swap performance certification. The logs cannot attribute those pages to the solver versus unrelated guest processes. Small performance differences should not be over-interpreted.

Earlier warm-up, mesh-calibration, GDB, boundary-control, and cache-pressure runs are excluded. The earlier `bench-*`, `clean-*`, and `noswap-*` measurements remain as diagnostic evidence. Read-only eviction of the completed backup archive’s page cache freed approximately 5 GiB; no archive content or VM sysctl was changed.

## Correctness and physical controls

Each of the three measured fine-mesh pairs has 354 exactly matching numeric field groups, including Temperature, TemperatureGradient and HeatFlux, matching compared topology arrays and field attributes, and no missing/extra fields. Full TDR byte identity is not established: global metadata/provenance and HDF5 storage differ or remain unclassified.

Peak temperature is 489.518175350140 K. The log’s global minimum of 0 K belongs to inactive Gas and must not be interpreted as a physical package temperature.

Vendor-only mechanism controls on the same fine mesh: emissivity zero raises the peak to 491.680426556492 K; removing side and bottom convection raises it to 2484.634597281299 K. The latter is a numerical mechanism check far outside a credible package operating regime. These controls are excluded from timing.

## Thermomechanical continuation and regressions

See `continuation-results.md` for the thermal-field transfer, displacement/stress comparison, mesh-size distinction, and repository regression results. The fine-grid mechanical solve exceeded the 6 GiB virtual-memory cap in the vendor and is not presented as successful.

## Reproduction and evidence

VM evidence root: `/home/mozztcad/tmp/package-benchmark-20261010`. Local report folder: `C:/Users/Yuanyuan/Desktop/si/architecture-overview/StressThermal/performance-benchmark/`.

- `benchmark-results.json`: every repetition, timer, load statistic, and binary/deck/mesh SHA256.
- `detailed-r{1,2,3}-{vendor,local}/`: stdout, stderr, native timers, exit status and load samples.
- `package-vendor/case.cmd`, `mesh-package-final/`: deck, material definitions, geometry and measured mesh.
- `formal-detailed.py`, `run-final-case.sh`: sequential measurement procedure.
- `thermal-recovery/`: binary-probing evidence, Release build/regression logs and uncommitted repair patch.
- `thermal-repair-report.md`: repair scope and unverified branches.
