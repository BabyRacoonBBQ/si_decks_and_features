#!/bin/bash
set -uo pipefail
source /home/mozztcad/geo3d/.env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP FRIDA_AGENT FRIDA_OPTIONS GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
cd /home/mozztcad/tmp/package-benchmark-20261010/mesh-coarse
ulimit -v 6291456
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9 || exit 75
/usr/bin/time -v timeout -k 10 300 taskset -c 4 /home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sde -e -l mesh.scm > mesh.stdout 2> mesh.stderr
rc=$?
echo "$rc" > exit.txt
tail -20 mesh.stdout
tail -15 mesh.stderr
exit "$rc"
