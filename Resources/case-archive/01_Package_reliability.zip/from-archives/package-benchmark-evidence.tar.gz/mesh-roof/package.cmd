Definitions { Refinement "global" { MaxElementSize=(300 300 300) MinElementSize=(150 150 150) } }
Placements { Refinement "global" { Reference="global" RefineWindow=Cuboid [(-2000 -2000 -2500) (1500 6000 10000)] } }
Delaunizer { maxPoints=100000 delaunayTolerance=0.6 }
