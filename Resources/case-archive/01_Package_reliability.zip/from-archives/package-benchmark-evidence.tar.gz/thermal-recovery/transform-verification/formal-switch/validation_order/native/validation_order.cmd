# Invalid arguments must be diagnosed before unrecovered formal dimension guards.
proc check {tag script} {
    set rc [catch {uplevel 1 $script} value]
    binary scan $value H* encoded
    puts "HANDLER_CHECK|$tag|$rc|$encoded"
}
proc invalid_transforms {prefix} {
    check ${prefix}_directions {transform reflect left right}
    check ${prefix}_false {transform reflect left right=false}
    check ${prefix}_number {transform reflect left right angle=bad}
    check ${prefix}_min_count {transform min= {0 0} max= {1}}
    check ${prefix}_degenerate {transform min= {0 0} max= {1 0}}
    check ${prefix}_angle {transform angle=45}
    check ${prefix}_axis {transform axis=q}
    check ${prefix}_axis_angle {transform rotate angle=90 axis=z}
    check ${prefix}_stretch {transform stretch length=-1}
    check ${prefix}_min_priority {transform min= {0} angle=45}
}
invalid_transforms noinit
line x location=0 spacing=0.1 tag=top
line x location=1 spacing=0.1 tag=bottom
line y location=0 spacing=0.1 tag=left
line y location=1 spacing=0.1 tag=right
region Silicon xlo=top xhi=bottom ylo=left yhi=right
init
invalid_transforms delayed
