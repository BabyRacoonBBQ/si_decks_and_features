# Force real 2D so the formal transform wrapper enters the shared parser.
line x location=0 spacing=0.1 tag=top
line x location=1 spacing=0.1 tag=bottom
line y location=0 spacing=0.1 tag=left
line y location=1 spacing=0.1 tag=right
region Silicon xlo=top xhi=bottom ylo=left yhi=right
init !DelayFullD
proc check {tag script} {
    set rc [catch {uplevel 1 $script} value]
    binary scan $value H* encoded
    puts "HANDLER_CHECK|$tag|$rc|$encoded"
}
check directions {transform reflect left right}
check false_is_specified {transform reflect left right=false}
check angle_priority {transform reflect left right angle=45}
check value_error_priority {transform reflect left right angle=bad}
check mesh_group {grid get.nodes get.elements}
check two_groups {grid get.brep.faces get.brep.vertices get.nodes get.elements}
