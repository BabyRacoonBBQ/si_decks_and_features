# Parser post-validation applies before the SyntaxCheck execution gate.
proc check {tag script} {
    set rc [catch {uplevel 1 $script} value]
    binary scan $value H* encoded
    puts "HANDLER_CHECK|$tag|$rc|$encoded"
}
check two_directions {transform reflect left right}
check false_still_specified {transform reflect left right=false}
check both_false {transform reflect left=false right=false}
check negation {transform reflect left !right}
check repeated_same {transform reflect left left}
check repeated_overwrite {transform reflect left left=false}
check direction_aliases {transform reflect left ymin}
check retry_single {transform reflect left}
check retry_empty {transform}
check parse_error_first {transform reflect left right angle=bad}
check group_before_angle {transform reflect left right angle=45}
check grid_quality {grid get.nodes get.elements}
check grid_two_groups {grid get.nodes get.elements get.brep.faces get.brep.vertices}
check grid_two_groups_reversed {grid get.brep.faces get.brep.vertices get.nodes get.elements}
check grid_false {grid get.nodes=false get.elements=false}
check grid_repeat {grid get.nodes get.nodes}
check grid_separate_groups {grid get.nodes get.brep.vertices}
check grid_parse_first {grid get.nodes get.elements set.max.points=bad}
check grid_retry {grid get.nodes}
