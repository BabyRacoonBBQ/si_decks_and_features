# Exact explicit SyntaxCheck observations; all individual Tcl errors are caught.
proc check {tag script} {
    set rc [catch {uplevel 1 $script} value]
    binary scan $value H* encoded
    puts "HANDLER_CHECK|$tag|$rc|$encoded"
}
check empty {transform}
check translate2 {transform translate= {0.1 0}}
check translate3 {transform translate= {0.1 0 0}}
check translate4 {transform translate= {1 2 3 4}}
check bad_number {transform translate= {x 0}}
check unknown {transform no.such.option}
check flip {transform flip}
check reflect {transform reflect left}
check conflicting_directions {transform reflect left right}
check rotate_default {transform rotate}
check rotate90 {transform rotate angle=90 axis=z}
check rotate0 {transform rotate angle=0 axis=z}
check rotate90x {transform rotate angle=90 axis=x}
check rotate180y {transform rotate angle=180 axis=y}
check rotate270x {transform rotate angle=270 axis=x}
check angle_negative {transform angle=-90}
check angle45 {transform angle=45}
check angle360 {transform angle=360}
check axis_unknown {transform axis=q}
check axis_upper {transform axis=Y}
check axis_prefix {transform axis=xyz}
check axis_empty {transform axis= {}}
check cut {transform cut min= {0 0} max= {1 1}}
check min_only {transform min= {0 0}}
check min_max_count {transform min= {0 0} max= {1}}
check min_max_equal {transform min= {0 0} max= {1 0}}
check min_max_reversed {transform min= {2 2} max= {1 1}}
check min_max4 {transform min= {0 0 0 0} max= {1 1 1 1}}
check stretch_default {transform stretch}
check stretch_zero {transform stretch length=0}
check stretch_negative {transform stretch length=-1}
check negative_without_stretch {transform length=-1}
check stretch_false {transform stretch=false length=-1}
check formal_only_options {transform reflect up run.only save remesh}
check adaptive {transform Adaptive}
check priority_min_angle {transform min= {0} angle=45}
check priority_angle_axis {transform angle=45 axis=q}
check back_save {pdbGetString Grid Back.Material}
set saved_back [pdbGetString Grid Back.Material]
pdbSetString Grid Back.Material NoSuchBackMaterial
check unknown_back {transform}
pdbSetString Grid Back.Material $saved_back
check repeat {transform translate= {0.1 0}}
