#!/bin/bash
set -uo pipefail
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP FRIDA_AGENT FRIDA_OPTIONS GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/package-benchmark-20261010
case=$1
kind=$2
binary=/home/mozztcad/geo3d/build/sinterconnect_run
if [ "$kind" = vendor ]; then binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect; fi
cd "$root/$case"
ulimit -v 6291456
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9 || exit 75
vmstat 1 > vmstat.log & monitor=$!
date -Is > start.txt
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$binary" --noSyntaxCheck case.cmd > stdout.log 2> stderr.log
rc=$?
kill "$monitor" 2>/dev/null || true
echo "$rc" > exit.txt
tail -25 stdout.log
tail -5 stderr.log
exit "$rc"
