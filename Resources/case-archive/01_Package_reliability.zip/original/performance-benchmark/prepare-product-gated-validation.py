from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
for label in ['package','multistep','implicit','uniform','catch','missing','conflict','no-time']:
 d=r/('certified-v3-'+label+'-local');d.mkdir()
 for name in ['case.cmd','settings.cmd','mp.cmd','datexcodes.txt']:shutil.copyfile(r/('certified-v2-'+label+'-local')/name,d/name)
for name in ['run-certified-v2-profile-matrix.sh','compare-certified-v2-matrix.py','assert-certified-v2-matrix.py','run-certified-e2e-v2.sh','run-profile-strain-v2.sh']:
 (r/name.replace('v2','v3')).write_text((r/name).read_text().replace('v2','v3'))
s=(r/'run-e2e-final-regressions.sh').read_text().replace('/e2e-final-regressions','/product-gated-regressions');(r/'run-product-gated-regressions.sh').write_text(s)
d=r.parent/'settemp-unit-v3-local';d.mkdir()
for name in ['case.cmd','datexcodes.txt']:shutil.copyfile(r.parent/'settemp-unit-local'/name,d/name)
s=(r/'run-settemp-unit.sh').read_text().replace('for kind in vendor local','for kind in local').replace('settemp-unit-$kind','settemp-unit-v3-$kind').replace('settemp-unit-local/result','settemp-unit-v3-local/result').replace('settemp-unit-comparison.json','settemp-unit-v3-comparison.json');(r/'run-settemp-unit-v3.sh').write_text(s)
s=(r/'summarize-e2e-final.py').read_text().replace('v2','v3').replace('e2e-verification-summary.json','product-gated-verification-summary.json');(r/'summarize-product-gated.py').write_text(s)
s=(r/'finalize-e2e-summary.py').read_text().replace('e2e-verification-summary.json','product-gated-verification-summary.json').replace('e2e-final-regressions','product-gated-regressions').replace('settemp-unit-comparison.json','settemp-unit-v3-comparison.json').replace("d=r.parent/('settemp-unit-'+kind)","d=r.parent/('settemp-unit-'+('v3-local' if kind=='local' else kind))");(r/'finalize-product-gated.py').write_text(s)
