import re,json
from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
out={}
for label in ['missing','conflict','no-time']:
 row={}
 for kind,folder in [('vendor',label+'-vendor'),('local','final-'+label+'-local')]:
  d=r/folder;s=re.sub(r'\x1b\[[0-9;]*m','',(d/'stderr.log').read_text())
  begin=s.find('** Error **');end=s.find('Command exited')
  text=s[begin:end].strip() if begin>=0 else s[:500]
  row[kind]={'exit':int((d/'exit.txt').read_text()),'diagnostic':text}
 out[label]=row
(r/'final-error-comparison.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
