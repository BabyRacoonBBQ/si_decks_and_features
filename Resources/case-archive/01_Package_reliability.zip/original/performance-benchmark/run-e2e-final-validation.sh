#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
bash "$r/run-certified-v2-profile-matrix.sh"
PYTHONNOUSERSITE=1 python3 "$r/compare-certified-v2-matrix.py" > "$r/certified-v2-comparison-console.log"
python3 "$r/assert-certified-v2-matrix.py"
bash "$r/run-profile-strain-v2.sh"
bash "$r/run-e2e-final-regressions.sh"
bash "$r/record-recovery-identity.sh"
