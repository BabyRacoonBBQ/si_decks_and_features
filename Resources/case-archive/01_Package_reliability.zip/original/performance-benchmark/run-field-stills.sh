#!/bin/bash
set -euo pipefail
root=/home/mozztcad/tmp/package-benchmark-20261010/demo-thermal-vendor
vendorbin=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin
mkdir -p "$root/mesh-visualization"
cd "$root/mesh-visualization"
export PYTHONNOUSERSITE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 LP_NUM_THREADS=1
unset LD_PRELOAD
display_file=$(mktemp "$PWD/display.XXXXXX")
"$vendorbin/Xvfb" -displayfd 3 -screen 0 1000x680x24 -nolisten tcp 3>"$display_file" > xvfb.log 2>&1 &
xvfb_pid=$!
trap 'kill "$xvfb_pid" 2>/dev/null || true; rm -f -- "$display_file"' EXIT
for i in $(seq 1 50); do test -s "$display_file" && break; sleep 0.1; done
test -s "$display_file"
export DISPLAY=:$(cat "$display_file")
nice -n 10 taskset -c 9 "$vendorbin/python3" "$root/render-field-stills.py" "$@"
