import h5py,json
from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
def tags(p):
 with h5py.File(p) as f:
  g=f['collection/tag_group_0/tag_group_0'];out={}
  for v in g.values():
   k=v.attrs['key'].decode();x=v.attrs.get('value')
   out[k]=x.decode() if isinstance(x,bytes) else str(x)
  return out
a=tags(r/'demo-coupled-vendor/result_sis.tdr');b=tags(r/'thermomechanical-recovery/pdb-gate-local/result_sis.tdr')
j={'missing':{k:a[k] for k in sorted(a.keys()-b.keys())},'extra':{k:b[k] for k in sorted(b.keys()-a.keys())},'changed':{k:[a[k],b[k]] for k in sorted(a.keys()&b.keys()) if a[k]!=b[k]}}
(r/'thermomechanical-recovery/pdb-gate-parameter-tags.json').write_text(json.dumps(j,indent=2))
for key in j:
 print(key,len(j[key]));print(json.dumps(dict(list(j[key].items())[:28]),indent=2))


