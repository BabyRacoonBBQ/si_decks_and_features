from pathlib import Path
import subprocess,json,re,os
w=Path('/home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2')
b=Path('/home/mozztcad/tmp/paused-info2-20261010');b.mkdir(exist_ok=True)
def git(*args):
 p=subprocess.run(['git','-C',str(w),*args],text=True,capture_output=True)
 if p.returncode:
  msg=re.sub(r'https?://\S+','[remote URL redacted]',p.stdout+p.stderr)
  raise RuntimeError(msg)
 return p.stdout.strip()
assert git('branch','--show-current')=='codex/recover-3d-interconnect-info2'
assert git('rev-parse','HEAD')=='d59825863a70d8940a17b2325de0dda3a43fb6a3'
(b/'status-before.txt').write_text(git('status','--porcelain=v1','--untracked-files=all'))
(b/'tracked.patch').write_text(git('diff','HEAD','--binary'))
note=w/'doc/sinterconnect/paused-info2-20261010.md'
note.write_text('''# Paused recovery checkpoint

Paused by user request to free the VM for benchmarking. This is a WIP backup, not a completed integration or a claim that all validation passed.

Original HEAD: d59825863a70d8940a17b2325de0dda3a43fb6a3.
Thread: codex://threads/01a0b261-ba0c-7df3-9253-532c450388ea
Original worktree: /home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2

User-reported checkpoint results: mesh 37/37 and 3D 12/12; minimal regression 6/6; contact 7/7; transform formal checks passed; main grid-merge matrix passed. Doping passed its first five cases and was stopped at 186_8_aniso_dep. verify_region remains blocked by fixture/configuration gaps. These results were not rerun for this backup.

The unified gate process group was stopped and its lock released. The thread goal is paused. Do not resume automatically. Unrelated PID 1151116 must not be terminated as part of cleanup.

All remaining untracked/ignored evidence and build files are retained in a separately verified full worktree archive before local checkout removal. The remote checkpoint branch preserves code and this handoff; restoring artifacts requires that archive.
''')
git('add','-u')
git('add','--','doc/sinterconnect/paused-info2-20261010.md','doc/sinterconnect/3d_interconnect_info2_audit.md','inverter_fv_mixed_mode.patch','inverter_gmres_breakdown.gdb','run_inverter_gmres_breakdown.sh')
check=subprocess.run(['git','-C',str(w),'diff','--cached','--check'],text=True,capture_output=True)
(b/'checkpoint-whitespace-check.txt').write_text(check.stdout+check.stderr)
# Preserve existing audit/patch whitespace in this WIP backup; do not rewrite evidence.
git('commit','-m','wip: checkpoint paused info2 recovery before VM cleanup')
head=git('rev-parse','HEAD')
remote_branch='backup/paused-info2-20261010-'+head[:8]
assert not git('ls-remote','--heads','origin','refs/heads/'+remote_branch)
git('push','origin','HEAD:refs/heads/'+remote_branch)
remote=git('ls-remote','--heads','origin','refs/heads/'+remote_branch).split()[0]
assert remote==head
info={'worktree':str(w),'local_branch':'codex/recover-3d-interconnect-info2','head':head,'remote_branch':remote_branch,'remote_verified':remote,'original_remote_branch_untouched':True}
(b/'checkpoint.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2))
