# Full CTest results — unresolved failures

The complete Release build succeeded. The subsequent full suite passed **24/34** tests; **10 failed**. This is not an all-green repository validation. The successful SI, minimum-deck, transform and init/struct gates are separate results.

| Test | Observed failure |
|---|---|
| `ts4_standalone_mesh_lifecycle_smoke` | Aborts: canonical TS4 tables were not reset. |
| `delayfulld_brick_to_tet_smoke` | Segmentation fault in `collectBoundaryFaces` → `Mesh::BuildBoundary` → `exerciseSplit`. |
| `floops_doping_smoke` | Aborts: `free(): invalid pointer`. |
| `depetch_license_unit_smoke` | Expected trapezoidal algorithm values for `horizontal` and `unknown` do not match. |
| `icwb_stage1_driver_coverage` | Missing expected `polygon_segments_unit: createPolygonFromPoints(2, values, valueCount)` coverage text. |
| `icwb_stage2_mac_reader` | Same prerequisite coverage check fails. |
| `icwb_stage3_bbox_query` | Same prerequisite coverage check fails. |
| `icwb_stage4_layout_queries` | Same prerequisite coverage check fails. |
| `icwb_stage5_stretch_queries` | Same prerequisite coverage check fails. |
| `icwb_stage13_writeall` | Initially fails compiling because the test's ad-hoc compiler command cannot find TBB headers. A command-local `CPLUS_INCLUDE_PATH` retry resolves compilation but then fails the minimal-layout `writeAll` output comparison. |

The mesh-lifecycle, doping and depetch unit executables' link commands do not include the four changed thermal-repair translation units. Those failures therefore are not validation of the repaired thermal path. The ICWB checks and code are also outside the changed files. However, a complete pristine-HEAD rebuild/comparison was **not** performed, so the entire failure set is not certified as a pre-existing baseline.

The `delayfulld` test links the shared runtime archives. A bounded GDB run reproduced its geometry-boundary crash. Breakpoints requested for the four modified functions did not resolve in this test executable; their hit-count coverage is **unverified**, not a claim of four verified zero counts. The crash stack and linker inputs are retained. No geometry/doping/ICWB source was changed to suppress these failures.

VM evidence: `/home/mozztcad/tmp/package-benchmark-20261010/thermal-recovery/`.

- `build-all.log`, `ctest.log`, `ctest-exits.txt`
- `ctest-link-dependencies.txt`
- `ctest-delayfulld-probe.log`
- `ctest-icwb-include-retry.log`

Product changes remain uncommitted. Benchmark numerical parity is established for the tested steady thermal cases; repository-wide correctness is not claimed.
