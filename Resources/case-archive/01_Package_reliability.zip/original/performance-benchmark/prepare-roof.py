from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
d=r/'mesh-roof';d.mkdir(exist_ok=True)
s=(r/'mesh-medium/geometry.scm').read_text()
old='(sdegeo:create-cuboid (position (- (position:x gaslo) 50) (- (position:y gaslo) 50) (- (position:z gaslo) 50)) (position (+ (position:x gashi) 50) (+ (position:y gashi) 50) (+ (position:z gashi) 50)) "Gas" "ambient")'
new='(sdegeo:create-cuboid (position (- (position:x gaslo) 50) (position:y gaslo) (position:z gaslo)) (position (position:x gaslo) (position:y gashi) (position:z gashi)) "Gas" "ambient")'
assert old in s
(d/'geometry.scm').write_text(s.replace(old,new))
shutil.copy2(r/'mesh-medium/datexcodes.txt',d/'datexcodes.txt')
shutil.copy2(r/'mesh-medium/package.cmd',d/'package.cmd')
(r/'roof.sh').write_text((r/'medium.sh').read_text().replace('/mesh-medium','/mesh-roof'))
for kind in ['vendor','local','no-radiation','no-convection']:
 out=r/('roof-'+kind);out.mkdir(exist_ok=True)
 deck=(r/'thermal-recovery/vendor-entry/case.cmd').read_text().replace('../../mesh-coarse/npkg_sibashslr_msh.tdr','../mesh-roof/package_msh.tdr')
 deck=deck.replace('pdbSet Grid AddGasMesh 1','pdbSet Grid AddGasMesh 0')
 # Explicit ambient on the upper face; sides/bottom remain solid boundaries.
 deck=deck.replace('pdbSet Copper HeatSinkTransfer 0.1','pdbSet Copper HeatSinkTransfer 0.0')
 deck=deck.replace('5714.2857142857','571.42857142857')
 if kind=='no-radiation':deck=deck.replace('Emissivity 0.8','Emissivity 0.0')
 if kind=='no-convection':deck=deck.replace('SideHeatTransfer 0.0025','SideHeatTransfer 0.0')
 (out/'case.cmd').write_text(deck)
 shutil.copy2(d/'datexcodes.txt',out/'datexcodes.txt')
