#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
kind=${1:-local}
label=${2:-initial}
dir=$root/thermomechanical-recovery/$label-$kind
mkdir -p "$dir"
if [ ! -f "$dir/case.cmd" ]; then
 cp "$root/demo-coupled-$kind/"{case.cmd,settings.cmd,mp.cmd,datexcodes.txt} "$dir/"
 sed -i 's@../demo-thermal-vendor/@../../demo-thermal-vendor/@' "$dir/case.cmd"
fi
cd "$dir"
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
binary=/home/mozztcad/geo3d/build/sinterconnect_run
extra=()
if [ "$kind" = vendor ]; then
 binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
 extra=(--noSyntaxCheck)
fi
sha256sum "$binary" case.cmd settings.cmd mp.cmd ../../demo-thermal-vendor/result_sis.tdr > identities.sha256
set +e
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$binary" "${extra[@]}" case.cmd > stdout.log 2> stderr.log
rc=$?
set -e
echo "$rc" > exit.txt
tail -8 stdout.log
tail -24 stderr.log
exit "$rc"
