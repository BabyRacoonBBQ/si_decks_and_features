import h5py
from pathlib import Path
root=Path('/home/mozztcad/tmp/package-benchmark-20261010')
for path in [root/'thermal-recovery/vendor-entry/result_sis.tdr',root/'mesh-medium/package_msh.tdr']:
 print('FILE',path)
 with h5py.File(path) as f:
  seen=set()
  def visit(name,obj):
   if not isinstance(obj,h5py.Group): return
   attrs=dict(obj.attrs)
   if name in ['collection/geometry_0/region_'+str(i) for i in (4,21,31,32,33)]:print('REGION',name,attrs)
   unit=attrs.get('unit:name')
   if unit is not None and unit not in seen:
    print(name,attrs)
    seen.add(unit)
   if name.count('/') < 2: print(name,attrs)
  f.visititems(visit)
