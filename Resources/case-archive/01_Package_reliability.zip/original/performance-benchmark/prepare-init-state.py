from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(r/'solve-flags-local/case.cmd').read_text().split('math numThreads=1')[0]
s+='''flagState startup
math numThreads=1
pdbSet Grid AddGasMesh 0
source settings.cmd
flagState before-init
proc traceMaterial {cmd args} {puts "MATERIAL_CALL $cmd"}
trace add execution pdbNewMaterialandInterfaces enter traceMaterial
trace add execution pdbNewMaterial enter traceMaterial
init tdr=../../demo-thermal-vendor/result_sis.tdr !load.commands !pdb
flagState after-init
'''
for kind in ['vendor','local']:
 d=r/('init-state-'+kind);d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(s)
 for f in ['settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((r/'initial-local'/f).read_bytes())
