#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
bash "$r/run-certified-profile-matrix.sh"
PYTHONNOUSERSITE=1 python3 "$r/compare-certified-matrix.py" > "$r/certified-comparison-console.log"
bash "$r/run-final-regressions.sh"
bash "$r/record-recovery-identity.sh"
