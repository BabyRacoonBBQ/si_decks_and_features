# Define the linear elasticmaterial properties of the 
# materials that constitute the package structure
# ----------------------------------------------------------

# Silicon
# ----------------------------------------------------------

pdbSet Silicon Mechanics BulkModulus [Enu2K 162.0e10 0.28]
pdbSet Silicon Mechanics ShearModulus [Enu2G 162.0e10 0.28]
pdbSet Silicon Mechanics ThExpCoeff 3.05e-6
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
pdbSetBoolean Silicon Mechanics Anisotropic 1

# Copper
# ----------------------------------------------------------

pdbSet Copper Mechanics BulkModulus [Enu2K 111.5e10 0.343]
pdbSet Copper Mechanics ShearModulus [Enu2G 111.5e10 0.343]
pdbSet Copper Mechanics ThExpCoeff 17.75e-6
pdbSetBoolean Copper Mechanics IsPlastic 0

# Contact wire
# ----------------------------------------------------------

mater add name= Copperline new.like= Copper
pdbSet Copperline Mechanics BulkModulus [Enu2K 111.5e10 0.343]
pdbSet Copperline Mechanics ShearModulus [Enu2G 111.5e10 0.343]
pdbSet Copperline Mechanics ThExpCoeff 17.15e-6
pdbSetBoolean Copperline Mechanics IsPlastic 0

# Solder
# ----------------------------------------------------------

pdbSet Solder Mechanics BulkModulus 5.4952e11
pdbSet Solder Mechanics ShearModulus 1.7399e11
pdbSet Solder Mechanics ThExpCoeff 2.15e-5
pdbSetBoolean Solder Mechanics IsCreep 0
pdbSetBoolean Solder Mechanics IsViscoPlastic 0
pdbSetBoolean Solder Mechanics PlaneStress 0

# Aluminum
# ----------------------------------------------------------

pdbSet Aluminum Mechanics BulkModulus [Enu2K 86.0e10 0.3]
pdbSet Aluminum Mechanics ShearModulus [Enu2G 86.0e10 0.3]
pdbSet Aluminum Mechanics ThExpCoeff 24.4e-6
pdbSetDouble Aluminum   Mechanics Vcrit0 1e-30
pdbSetDouble Aluminum   Mechanics VcritW 0.0
pdbSetDouble Aluminum   Mechanics Viscosity0 1e40
pdbSetDouble Aluminum   Mechanics ViscosityW 0.0
pdbSet Aluminum Mechanics YoungsModulusRate 0
pdbSetBoolean Aluminum Mechanics PlaneStress 0

# BEOL
# ----------------------------------------------------------

mater add name= SmearBeol new.like= Nitride
pdbSetDouble SmearBeol   Mechanics BulkModulus  [Enu2K 66.5e10 0.29]
pdbSetDouble SmearBeol   Mechanics ShearModulus [Enu2G 66.5e10 0.29]
pdbSetDouble SmearBeol   Mechanics ThExpCoeff   15.3e-6
pdbSetDouble SmearBeol   Mechanics Vcrit0 1e-30
pdbSetDouble SmearBeol   Mechanics VcritW 0.0
pdbSetDouble SmearBeol   Mechanics Viscosity0 1e40
pdbSetDouble SmearBeol   Mechanics ViscosityW 0.0

# Lead
# ----------------------------------------------------------

mater add name= Lead new.like= Copper
pdbSetDouble Lead Mechanics BulkModulus [Enu2K 16.0e10 0.44]
pdbSetDouble Lead Mechanics ShearModulus [Enu2G 16.0e10 0.44]
pdbSetDouble Lead Mechanics ThExpCoeff 28.9e-6

# Resin
# ----------------------------------------------------------

pdbSetDouble Resin Mechanics BulkModulus [Enu2K 13.0e10 0.25]
pdbSetDouble Resin Mechanics ShearModulus [Enu2G 13.0e10 0.25]
pdbSetDouble Resin Mechanics ThExpCoeff 34.0e-6
pdbSetDouble Resin   Mechanics Vcrit0 1e-30
pdbSetDouble Resin   Mechanics VcritW 0.0
pdbSetDouble Resin   Mechanics Viscosity0 1e40
pdbSetDouble Resin   Mechanics ViscosityW 0.0
