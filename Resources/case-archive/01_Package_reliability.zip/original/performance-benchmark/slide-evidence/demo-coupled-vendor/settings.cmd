# Define mechanics settings
# ------------------------------------------------

pdbSet InfoDefault 1

pdbSet Mechanics FiniteElementOrder 1

pdbSet Mechanics EtchDepoRelax 0
pdbSet Mechanics StressHistory 0

pdbSetDouble Mechanics RefThExpCoeff 0.0
pdbSet Mechanics Calculate.Principal.Stress 1

pdbSet Mechanics SaveMaxStress 1
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
pdbSet Mechanics Save.Step.Displacement 1

pdbSet Mechanics MaxIterations 50

math coord.ucs
mode mechanics

# Define solver settings
# ------------------------------------------------

math ils
pdbSet Math Flow 3D ILS.method sts3
pdbSet Math Flow 3D ILS.tolrel 1e-3
pdbSetDouble Math Flow ILS.refine.residual 1e-3
pdbSet Math Flow 3D ILS.ilut.tau 1e-14
pdbSet Math Flow 3D ILS.scaling diagsym
pdbSet Math Flow 3D ILS.nonsymmOrdering none
pdbSet Math Flow 3D ILS.refine.sts 1
pdbSet Math Flow 3D ILS.leftPreconditioner 1

# Define Convergence settings
# ------------------------------------------------

pdbSet Mechanics Convergence.Info 1
pdbSet Mechanics Use.FE.Library 1

pdbSet Mechanics Convergence.Force.Tolerance 0.999
pdbSet Mechanics Convergence.Energy.Tolerance 0.1

# Add new materials
# ------------------------------------------------

mater add name= Copperline new.like= Copper
mater add name= SmearBeol new.like= Nitride
mater add name= Leadcu new.like= Copper
mater add name= Resin new.like= Copper
mater add name= Silicon2 new.like= Silicon

# Select material properties
# ------------------------------------------------

#if @mpnonlinear@ == 0
	source mp.cmd
#elif @mpnonlinear@ == 1
	# Linear-elastic benchmark: mp.cmd selected
#elif @mpnonlinear@ == 2
	# Linear-elastic benchmark: mp.cmd selected
#endif

# Grid settings
# ------------------------------------------------

pdbSetBoolean Grid No3DMerge 1
pdbSetBoolean Grid No3DSwap 1
pdbSetBoolean Grid Adaptive 0
pdbSet Mechanics Merge.Vertices 0

pdbSet Grid SnMesh Parallel 0

pdbSet Grid MGoals Keep3DBrep 0

