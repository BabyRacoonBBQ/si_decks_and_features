# Package thermal field -> mechanical thermal strain, one-way sequential coupling.
# Both binaries read the SAME validated vendor thermal field on the SAME mesh.
math numThreads=1
pdbSet Grid AddGasMesh 0
source settings.cmd
init tdr=../demo-thermal-vendor/result_sis.tdr !load.commands !pdb
select z=Temperature name=FinalTemp store
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
mode mechanics
solve temperature=26.844<C> time=1.0<s> init=1.0<s> maxstep=1.0<s> t.final.profile=FinalTemp info=2
puts "COUPLED_TMAX [select max name=FinalTemp]"
select name=DisplacementMagnitude z="sqrt(Displacement_x^2+Displacement_y^2+Displacement_z^2)" store
puts "COUPLED_UMAX [select max name=DisplacementMagnitude]"
struct tdr=result
