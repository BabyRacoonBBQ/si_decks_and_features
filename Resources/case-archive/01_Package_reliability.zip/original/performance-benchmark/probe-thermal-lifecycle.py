import gdb,json,struct
from pathlib import Path
events=[];inside=False
def reg(x):return int(gdb.parse_and_eval('$'+x))
def s(x):return gdb.Value(x).cast(gdb.lookup_type('char').pointer()).string() if x else None
def q(x):return struct.unpack('<Q',bytes(gdb.selected_inferior().read_memory(x,8)))[0]
class End(gdb.FinishBreakpoint):
 def __init__(self,e,scope=False):super().__init__(gdb.newest_frame(),internal=True);self.e=e;self.scope=scope
 def stop(self):
  global inside
  if self.scope:inside=False
  else:self.e['return']=float(gdb.parse_and_eval('$xmm0.v2_double[0]'))
  return False
class Probe(gdb.Breakpoint):
 def __init__(self,expr,kind):super().__init__(expr);self.kind=kind
 def stop(self):
  global inside
  k=self.kind
  if k=='settemp':inside=True
  if k in ['global','float'] and not inside:return False
  e={'kind':k};events.append(e)
  if k=='settemp':e['args']=[s(q(reg('rsi')+8*i)) for i in range(reg('edi'))];End(e,True)
  if k in ['global','float']:e['name']=s(reg('rsi'));End(e)
  if k=='copy':e.update(source=s(reg('rsi')),target=s(reg('rdx')),stack=gdb.execute('bt 5',to_string=True))
  if k=='command':e['args']=[s(q(reg('rdx')+8*i)) for i in range(reg('esi'))]
  return False
for spec,kind in [('SetTemp_tcl(int, char**, pdblib::ParamParse&)','settemp'),('pdblib::getGlobalDouble(Tcl_Interp*, ...)','global'),('pdblib::ParamParse::FloatLookup(char const*)','float'),('floops::FieldServer::copyTempFields(std::shared_ptr<floops::FieldServer> const&, char const*, char const*, double, double)','copy'),('pdblib::pdbsetCommand(Tcl_Interp*, int, char**, pdblib::ParamParse&, char const*, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >)','command')]:Probe(spec,kind)
for bp in gdb.breakpoints():
 if bp.pending:raise RuntimeError('unresolved '+bp.location)
vendor='sinterconnect_run' not in gdb.current_progspace().filename
gdb.execute('run '+('--noSyntaxCheck ' if vendor else '')+'case.cmd > product.stdout 2> product.stderr')
if gdb.selected_inferior().pid:raise RuntimeError('premature stop')
Path('lifecycle.json').write_text(json.dumps(events,indent=2))
print('EVENTS',len(events))
