from pathlib import Path
import shutil,re,json,subprocess
root=Path('/home/mozztcad/tmp/package-benchmark-20261010')
source=Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/Applications_Library/Backend/Package_ThermomechanicalReliability')
case=root/'mesh-coarse';case.mkdir(parents=True,exist_ok=True)
for name in ('datexcodes.txt','mp.cmd','mpnonlinear.cmd','sdevice.par','settings.cmd'):
 shutil.copy2(source/name,case/name)
s=(source/'dpack_struct_sis.cmd').read_text()
s=s[s.index('(sde:clear)'):s.index('; This is the end of the SDE commands')]
s=s.replace('@node@','pkg').replace('@Crksize@','50').replace('"maxPoints" 250000','"maxPoints" 60000')
s=re.sub(r'^\(sdedr:define-refinement-(?:size|placement).*$',lambda m:'; thermal benchmark: omitted crack/solder-specific refinement' if any(k in m[0] for k in ('Solder','Crk')) else m[0],s,flags=re.M)
s=s.replace('"GlobalSize" 250 250 250 200 200 200','"GlobalSize" 600 600 600 300 300 300')
(case/'mesh.scm').write_text(s)
run='''#!/bin/bash
set -uo pipefail
source /home/mozztcad/geo3d/.env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP FRIDA_AGENT FRIDA_OPTIONS GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
cd /home/mozztcad/tmp/package-benchmark-20261010/mesh-coarse
ulimit -v 6291456
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9 || exit 75
/usr/bin/time -v timeout -k 10 300 taskset -c 4 /home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sde -e -l mesh.scm > mesh.stdout 2> mesh.stderr
rc=$?
echo "$rc" > exit.txt
tail -20 mesh.stdout
tail -15 mesh.stderr
exit "$rc"
'''
(root/'mesh.sh').write_text(run)
info={}
for key,cmd in {'cpu':['lscpu'],'memory':['free','-h'],'os':['uname','-a'],'load':['uptime'],'disk':['df','-h','/home'],'revision':['git','-C','/home/mozztcad/geo3d','rev-parse','HEAD']}.items():
 info[key]=subprocess.check_output(cmd,text=True)
(root/'vm-environment.json').write_text(json.dumps(info,indent=2))
print(case)
