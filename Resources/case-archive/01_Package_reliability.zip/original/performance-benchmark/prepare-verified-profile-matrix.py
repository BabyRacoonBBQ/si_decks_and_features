from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
for label,source in [('package','pdb-gate-local'),('multistep','multistep-vendor'),('implicit','implicit-vendor'),('uniform','uniform-vendor'),('catch','catch-recovery-vendor'),('missing','missing-vendor'),('conflict','conflict-vendor'),('no-time','no-time-vendor')]:
 d=r/('verified-'+label+'-local');d.mkdir(exist_ok=True)
 for f in ['case.cmd','settings.cmd','mp.cmd','datexcodes.txt']:shutil.copy2(r/source/f,d/f)
