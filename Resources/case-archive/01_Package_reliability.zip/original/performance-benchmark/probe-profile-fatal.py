import gdb,json,struct
from pathlib import Path
records=[];interp=None;active=False

def q(p):return struct.unpack('<Q',bytes(gdb.selected_inferior().read_memory(p,8)))[0]
def reg(n):return int(gdb.parse_and_eval('$'+n))
def s(p):return gdb.Value(p).cast(gdb.lookup_type('char').pointer()).string() if p else None
def result():
 if not interp:return None
 return s(q(interp)) or s(q(q(interp+0x2a8)+8))
class BP(gdb.Breakpoint):
 def __init__(self,sym,k):super().__init__(sym);self.k=k
 def stop(self):
  global interp,active
  if self.k=='check':interp=q(reg('rsi'));active=True;return False
  if not active:return False
  e={'kind':self.k,'stack':gdb.execute('bt 8',to_string=True)}
  if self.k=='panic':e.update(code=reg('edi'),message=s(reg('rsi')),tcl_result=result())
  if self.k=='throw':
   name=s(q(reg('rsi')+8));e['exception_type']=name
   if name=='St13runtime_error':e['what']=s(q(reg('rdi')+8))
  records.append(e);return False
BP('sinterconnect::SolveCmd::solveErrorCheck(pdblib::ParamParse&, pdblib::TclInterp_cl&)','check')
BP('panicproc(int)','signal_handler')
BP('FLPS_panic(FLPS_ErrorCode, char*)','panic')
BP('__cxa_throw','throw')
for bp in gdb.breakpoints():
 if bp.pending:raise RuntimeError('unresolved '+bp.location)
gdb.execute('handle SIGSEGV nostop noprint pass')
vendor='sinterconnect_run' not in gdb.current_progspace().filename
gdb.execute('run '+('--noSyntaxCheck ' if vendor else '')+'case.cmd > product.stdout 2> product.stderr')
if gdb.selected_inferior().pid:raise RuntimeError('inferior still alive')
Path('fatal-boundary.json').write_text(json.dumps(records,indent=2))
print('FATAL_EVENTS '+json.dumps([{k:v for k,v in e.items() if k!='stack'} for e in records]))
