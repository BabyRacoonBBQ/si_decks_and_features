from pathlib import Path
import json,re,statistics,os
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
def seconds(s):
 parts=list(map(float,s.split(':')));return sum(x*60**i for i,x in enumerate(reversed(parts)))
def load(path):
 rows=[]
 for line in path.read_text().splitlines():
  values=line.split()
  if len(values)>=17 and all(v.lstrip('-').isdigit() for v in values):rows.append(list(map(int,values)))
 rows=rows[1:]
 return {'samples':len(rows),'idle_min':min((x[14] for x in rows),default=None),'idle_mean':statistics.mean(x[14] for x in rows) if rows else None,'swap_in_max':max((x[6] for x in rows),default=None),'swap_out_max':max((x[7] for x in rows),default=None),'swap_in_kib':sum(x[6] for x in rows),'swap_out_kib':sum(x[7] for x in rows)}
runs=[]
first=int(os.environ.get('BENCH_FIRST_REP','1'))
for rep in range(first,first+3):
 for kind in ['vendor','local']:
  d=r/f'{os.environ.get("BENCH_PREFIX","bench")}-r{rep}-{kind}'
  text=(d/'stdout.log').read_text(errors='replace');err=(d/'stderr.log').read_text(errors='replace')
  row={'rep':rep,'kind':kind,'directory':str(d),'exit':int((d/'exit.txt').read_text()),'native_timers':{},'native_cpu':{},'native_elapsed':{}}
  for name in ['Elapsed Time','User Time','CPU Time']:
   m=re.search(r'^'+name+r':\s*([0-9:]+)',text,re.M)
   row['native_timers'][name]=seconds(m.group(1)) if m else None
  section=None
  for line in text.splitlines():
   if line.strip()=='Detailed CPU time report:':section='native_cpu'
   if line.strip()=='Detailed elapsed time report:':section='native_elapsed'
   m=re.match(r'([0-9.]+) sec \(([0-9.]+)%\) (.+) \((\d+) calls\)\.',line)
   if m and section:row[section][m[3]]={'seconds':float(m[1]),'percent':float(m[2]),'calls':int(m[4])}
  row['solve_elapsed']=float(re.search(r'Elapsed time for solve ([0-9.]+)s',text)[1])
  row['max_temperature']=float(re.search(r'BENCH_TMAX ([0-9.eE+-]+)',text)[1])
  row['max_rss_kib']=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',err)[1])
  row['external_wall']=seconds(re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): ([0-9:.]+)',err)[1])
  row['before_load']=load(d/'load-before.txt');row['during_load']=load(d/'load-during.txt')
  row['environment_verdict']=(d/'timing-valid.txt').read_text().strip() if (d/'timing-valid.txt').exists() else 'UNCLASSIFIED'
  if (d/'swappiness.txt').exists():row['swappiness']=int((d/'swappiness.txt').read_text())
  if (d/'swap-before.txt').exists():
   before=dict(line.split() for line in (d/'swap-before.txt').read_text().splitlines())
   after=dict(line.split() for line in (d/'swap-after.txt').read_text().splitlines())
   row['kernel_swap_delta_pages']={key:int(after[key])-int(value) for key,value in before.items()}
  row['identities']=(d/'identities.sha256').read_text().splitlines()
  runs.append(row)
summary={}
for kind in ['vendor','local']:
 group=[x for x in runs if x['kind']==kind]
 stats={}
 for key in ['solve_elapsed','external_wall','max_rss_kib']:
  vals=[x[key] for x in group];stats[key]={'median':statistics.median(vals),'min':min(vals),'max':max(vals)}
 stats['native_timers']={key:statistics.median(x['native_timers'][key] for x in group) for key in group[0]['native_timers']}
 for section in ['native_cpu','native_elapsed']:
  stats[section]={}
  names=sorted(set.union(*(set(x[section]) for x in group)))
  for name in names:
   vals=[x[section][name]['seconds'] for x in group if name in x[section]]
   stats[section][name]={'reported_runs':len(vals),'median':statistics.median(vals),'min':min(vals),'max':max(vals),'calls':[x[section].get(name,{}).get('calls') for x in group]}
 summary[kind]=stats
out={'runs':runs,'summary':summary}
(r/'benchmark-results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(summary,indent=2))
