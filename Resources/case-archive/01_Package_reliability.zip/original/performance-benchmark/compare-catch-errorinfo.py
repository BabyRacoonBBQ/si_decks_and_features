from pathlib import Path
import re,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
data={}
for kind in ['vendor','local']:
 s=(r/('catch-recovery-'+kind)/'stdout.log').read_text(errors='replace')
 data[kind]=dict(re.findall(r'PROBE_ERRORINFO (\w+) <(.*?)>\n',s,re.S))
data['equal']=data['vendor']==data['local'];data['two_errors_observed']=len(data['vendor'])==len(data['local'])==2
(r/'catch-errorinfo-comparison.json').write_text(json.dumps(data,indent=2))
print(json.dumps(data,indent=2))
