#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
# Only wait for our already-started minimum regression, never run concurrently.
while kill -0 1381982 2>/dev/null; do
 state=$(ps -o stat= -p 1381982 || true)
 case "$state" in Z*) break;; esac
 sleep 5
done
test "$(cat /proc/sys/vm/swappiness)" = 0
python3 "$root/prepare-fine.py"
BENCH_PREFIX=sw0 python3 "$root/formal-detailed.py"
BENCH_PREFIX=sw0 python3 "$root/summarize-benchmark.py" > "$root/benchmark-summary-sw0.txt"
