import h5py,json
from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
for label,p in [('vendor',r/'demo-coupled-vendor/result_sis.tdr'),('local',r/'thermomechanical-recovery/initial-local/result_sis.tdr')]:
 with h5py.File(p) as f:
  for path in ['collection/tag_group_0','collection/tag_group_0/tag_group_0','collection/tag_group_0/tag_group_0/tag_0','collection/tag_group_0/tag_group_0/tag_209']:
   g=f[path];print(label,path,dict(g.attrs))
  if label=='vendor':
   for i in [210,211,220,300,450]:print(label,i,dict(f['collection/tag_group_0/tag_group_0/tag_'+str(i)].attrs))
j=json.loads((r/'thermomechanical-recovery/initial-metadata.json').read_text())
print('COUNTS', {k:len(v) for k,v in j.items()})
print('FIRSTATTRS',j['attributes'][:10]);print('DATASETS',j['datasets'][:10])
