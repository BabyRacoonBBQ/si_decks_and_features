from pathlib import Path
import json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
for p in sorted(r.glob('*-r*-*/load-during.txt')):
    rows=[list(map(int,s.split())) for s in p.read_text().splitlines() if len(s.split())>=17 and all(v.lstrip('-').isdigit() for v in s.split())][1:]
    print(p.parent.name, json.dumps({'samples':len(rows),'swap_in_kib':sum(x[6] for x in rows),'swap_out_kib':sum(x[7] for x in rows),'idle_min':min(x[14] for x in rows)}))
