"""Only delete superseded files produced by this visualization task."""
from pathlib import Path
import re,json,shutil
root=Path('/home/mozztcad/tmp/package-benchmark-20261010/demo-thermal-vendor').resolve()
out=root/'mesh-visualization'
assert (root/'package-mesh-rotation-section.gif').is_file()
assert json.loads((out/'manifest.json').read_text())['rendered_frames']==180
poster=out/'mesh-poster.png'
shutil.copy2(out/'frame-000.png',poster)
deleted=[]
for p in out.iterdir():
    if p.is_file() and re.fullmatch(r'frame-\d{3}\.png',p.name):
        assert p.resolve().parent==out.resolve()
        deleted.append({'name':p.name,'bytes':p.stat().st_size});p.unlink()
(out/'cleanup.json').write_text(json.dumps({'deleted':deleted,'freed_bytes':sum(x['bytes'] for x in deleted),'kept':'Original TDR, latest GIF, poster, renderer, manifests, log and current field images'},indent=2))
print((out/'cleanup.json').read_text())
