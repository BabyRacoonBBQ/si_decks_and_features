"""Render the locally recovered StressThermal result on the VM evidence mesh."""
from pathlib import Path
src = Path(__file__).with_name('render-package-animation.py').read_text()
src = src.replace("ROOT=Path('/home/mozztcad/tmp/package-benchmark-20261010/demo-thermal-vendor')", "ROOT=Path(__file__).resolve().parent/'slide-evidence'/'thermal-local'")
src = src.replace("OUT=ROOT/'mesh-visualization';OUT.mkdir(exist_ok=True)", "OUT=Path(__file__).resolve().parent/'reliability-figures-local'/'mesh-visualization';OUT.mkdir(parents=True,exist_ok=True)")
exec(compile(src, str(Path(__file__).with_name('render-package-animation.py')), 'exec'), globals(), globals())
