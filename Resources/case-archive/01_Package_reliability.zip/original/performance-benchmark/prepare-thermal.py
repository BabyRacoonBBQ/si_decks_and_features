from pathlib import Path
import h5py,json,shutil,hashlib
root=Path('/home/mozztcad/tmp/package-benchmark-20261010')
mesh=root/'mesh-coarse/npkg_sibashslr_msh.tdr'
with h5py.File(mesh) as f:
 g=f['collection/geometry_0']; regs=[]
 for n,o in g.items():
  if n.startswith('region_') and 'material' in o.attrs:
   regs.append({'name':o.attrs['name'].decode(),'material':o.attrs['material'].decode()})
 npoints=int(g.attrs['number of vertices'])
metadata={'vertices':npoints,'regions':regs,'mesh_sha256':hashlib.sha256(mesh.read_bytes()).hexdigest()}
(root/'mesh-coarse/mesh-summary.json').write_text(json.dumps(metadata,indent=2))
deck='''math numThreads=1
pdbSet Grid AddGasMesh 1
mater add name=Copperline new.like=Copper
mater add name=SmearBeol new.like=Nitride
mater add name=Resin new.like=Copper
init tdr=../mesh-coarse/npkg_sibashslr_msh.tdr !load.commands !pdb
SetTemp 26.844
pdbSet Env.Temp 26.844
pdbSet Gas AttachThermalResistor 0
pdbSet Gas RadiationHeatTransfer 1
pdbSet Gas ConvectiveHeatTransfer 0
# Radiation on Gas interfaces; convection on exterior side boundaries.
# Conductivities in W/(cm K). Package sdevice.par supplies Cu/Solder/Resin.
foreach {mat k} {Silicon 1.48 Copper 4.01 Copperline 4.01 Solder 0.41 Resin 0.00168 SmearBeol 0.015 Aluminum 2.37} {
 pdbSet $mat Temperature Conductivity $k
 pdbSet $mat Temperature JouleHeating 0
 pdbSet $mat AttachThermalResistor 0
 pdbSet $mat HeatSinkTransfer 0.0
 pdbSet $mat SideHeatTransfer 0.0025
 pdbSet $mat Emissivity 0.8
}
# Copper package base coupled to a heat sink: 1000 W/(m2 K).
pdbSet Copper HeatSinkTransfer 0.1
'''
for r in regs:
 if r['material']=='Silicon': deck+=f'supply region.name={r["name"]} power.density=57142.857142857<W/cm3>\n'
deck+='''mode thermal
solve info=2
puts "BENCH_TMAX [select max name=Temperature]"
puts "BENCH_TMIN [select min name=Temperature]"
struct tdr=result
'''
for case in ('vendor-smoke','local-smoke'):
 d=root/case;d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(deck)
 shutil.copy2(root/'mesh-coarse/datexcodes.txt',d/'datexcodes.txt')
runner='''#!/bin/bash
set -uo pipefail
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP FRIDA_AGENT FRIDA_OPTIONS GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/package-benchmark-20261010
case=$1
kind=$2
binary=/home/mozztcad/geo3d/build/sinterconnect_run
if [ "$kind" = vendor ]; then binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect; fi
cd "$root/$case"
ulimit -v 6291456
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9 || exit 75
vmstat 1 > vmstat.log & monitor=$!
date -Is > start.txt
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$binary" --noSyntaxCheck case.cmd > stdout.log 2> stderr.log
rc=$?
kill "$monitor" 2>/dev/null || true
echo "$rc" > exit.txt
tail -25 stdout.log
tail -5 stderr.log
exit "$rc"
'''
(root/'thermal.sh').write_text(runner)
print(json.dumps(metadata,indent=2))
