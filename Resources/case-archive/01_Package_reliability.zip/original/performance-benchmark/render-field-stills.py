"""Render text-free scientific field images directly from vendor TDR on VM."""
from pathlib import Path
p=Path(__file__).with_name('render-package-animation.py')
exec(p.read_text().split('start=time.time();samples=')[0])
manifest={}
for key,field,source,scale in [('temp','Temperature',INPUT,1),('u','Displacement',ROOT.parent/'demo-coupled-vendor/result_sis.tdr',1e4),('stress','MisesStressMax',ROOT.parent/'demo-coupled-vendor/result_sis.tdr',1e-10)]:
    with h5py.File(source) as f:
        g=f['collection/geometry_0']
        data={(int(o.attrs['region']),name(o.attrs['name'])):o['values'][:] for o in g['state_0'].values() if 'values' in o and 'region' in o.attrs}
        arrays=[]
        for region,grid in zip(regions,grids):
            ids=np.unique(vtk_to_numpy(grid.GetCells().GetConnectivityArray()))
            a=data[int(region['region'][7:]),field]
            if key=='u':a=np.linalg.norm(a.reshape(-1,3),axis=1)
            a=a.reshape(-1)*scale
            assert len(a)==len(ids)
            values=np.zeros(len(pts));values[ids]=a
            arrays.append((values,a))
        lo=min(float(a.min()) for _,a in arrays);hi=max(float(a.max()) for _,a in arrays)
        lut=vtk.vtkLookupTable();lut.SetHueRange(.667,0);lut.SetRange(lo,hi);lut.Build()
        for region,grid,actor,(values,a) in zip(regions,grids,actors,arrays):
            grid.GetPointData().SetScalars(numpy_to_vtk(values,deep=True))
            mapper=actor.GetMapper();mapper.SetInputData(grid);mapper.SetScalarModeToUsePointData();mapper.ScalarVisibilityOn();mapper.SetLookupTable(lut);mapper.SetScalarRange(lo,hi)
            actor.SetVisibility(region['material']!='Resin');actor.GetProperty().EdgeVisibilityOff()
        im=render_frame(0);dest=OUT/(key+'-vm.png');im.save(dest)
        manifest[key]={'input':str(source),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'field':field,'maximum':hi,'image':str(dest),'image_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'text_overlays':False}
(OUT/'field-stills.json').write_text(json.dumps(manifest,indent=2))
win.Finalize()
