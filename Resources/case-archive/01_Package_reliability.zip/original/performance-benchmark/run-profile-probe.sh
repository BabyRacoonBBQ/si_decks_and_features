#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
for kind in vendor local; do
 dir=$root/thermomechanical-recovery/probe-$kind
 mkdir -p "$dir"
 cp "$root/demo-coupled-$kind/"{case.cmd,settings.cmd,mp.cmd,datexcodes.txt} "$dir/"
 sed -i 's@../demo-thermal-vendor/@../../demo-thermal-vendor/@' "$dir/case.cmd"
 cd "$dir"
 binary=/home/mozztcad/geo3d/build/sinterconnect_run
 extra=()
 if [ "$kind" = vendor ]; then
 binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
 extra=(--noSyntaxCheck)
 fi
 sha256sum "$binary" case.cmd settings.cmd mp.cmd > identities.sha256
 timeout -k 10 150 taskset -c 4 gdb -q -batch -ex 'set pagination off' -ex 'set confirm off' -ex 'set breakpoint pending off' -ex "source $root/thermomechanical-recovery/profile-probe.py" --args "$binary" "${extra[@]}" case.cmd > probe.log 2>&1
 grep 'PROBE' probe.log
 done
