from pathlib import Path
r=Path('/home/mozztcad/geo3d')
p=r/'src/abi/sprocess/sprocess/SProcessCmdUtil.h';s=p.read_text();s=s.replace('void installCsseMechanicsCommands();','void installCsseMechanicsCommands(bool interconnect = false);');p.write_text(s)
p=r/'src/abi/sprocess/sprocess/SProcessCmdUtil.cpp';s=p.read_text();old='''void SProcessCmdUtil::installCsseMechanicsCommands() {
    commands_[VOF_STATIC_STR("SetTemp")] = &sinterconnect::SetTempT_tcl;
    commands_[VOF_STATIC_STR("settemp")] = &sinterconnect::SetTempT_tcl;''';assert old in s
s=s.replace(old,'''void SProcessCmdUtil::installCsseMechanicsCommands(bool interconnect) {
    // geo_run also installs the shared CSSE commands. Its process SetTemp
    // handler must remain unchanged; only SI initializes spatial history here.
    if (interconnect) {
        commands_[VOF_STATIC_STR("SetTemp")] = &sinterconnect::SetTempT_tcl;
        commands_[VOF_STATIC_STR("settemp")] = &sinterconnect::SetTempT_tcl;
    }''');p.write_text(s)
p=r/'src/abi/sinterconnect/SInterconnectMain.cpp';s=p.read_text();assert 'commandUtility->installCsseMechanicsCommands();' in s;s=s.replace('commandUtility->installCsseMechanicsCommands();','commandUtility->installCsseMechanicsCommands(true);');p.write_text(s)
