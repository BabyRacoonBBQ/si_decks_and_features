from pathlib import Path
import os,time,json,subprocess
root=Path('/home/mozztcad/.cache/vscode-cpptools').resolve()
assert str(root)=='/home/mozztcad/.cache/vscode-cpptools'
opened=set(); unreadable=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit(): continue
 try:
  if proc.stat().st_uid!=os.getuid(): continue
  for fd in (proc/'fd').iterdir():
   try: opened.add(os.readlink(fd).replace(' (deleted)',''))
   except OSError: pass
  for line in (proc/'maps').read_text().splitlines():
   parts=line.split(None,5)
   if len(parts)==6: opened.add(parts[5].replace(' (deleted)',''))
 except (PermissionError,FileNotFoundError,ProcessLookupError):
  try:
   comm=(proc/'comm').read_text().strip()
   # Login/session daemons do not own C/C++ IntelliSense cache files.
   if comm not in ('(sd-pam)','gnome-keyring-d','vmtoolsd','sshd'):
    unreadable.append(proc.name+':'+comm)
  except (FileNotFoundError,ProcessLookupError): pass
report={'scope':str(root),'removed':[],'skipped':[],'unreadable_user_processes':unreadable}
if unreadable:
 report['status']='Skipped cleanup because some user processes could not be inspected'
else:
 for f in root.rglob('*'):
  if f.is_symlink() or not f.is_file(): continue
  resolved=f.resolve()
  if root not in resolved.parents: raise RuntimeError('Outside cache root')
  st=f.stat()
  if time.time()-st.st_mtime<7*86400: continue
  if str(resolved) in opened:
   report['skipped'].append(str(resolved));continue
  f.unlink()
  report['removed'].append({'path':str(resolved),'bytes':st.st_size})
 report['status']='Removed only unused cache files older than seven days'
report['bytes_reclaimed']=sum(x['bytes'] for x in report['removed'])
report['vm_memory_after']=subprocess.check_output(['free','-h'],text=True)
report['vm_disk_after']=subprocess.check_output(['df','-h','/home'],text=True)
out=Path('/home/mozztcad/tmp/package-benchmark-20261010/cleanup-report.json')
out.write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('removed','skipped')},indent=2))
print('Removed files:',len(report['removed']),'Skipped open files:',len(report['skipped']))
