from pathlib import Path
import json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
a=json.loads((r/'execution-vendor/execution.json').read_text());b=json.loads((r/'execution-local/execution.json').read_text())
for x in (a,b):
 for e in x['events']:e.pop('stack',None)
print('vendor nonmapping', [e for e in a['events'] if e['kind']!='mapping'])
print('local nonmapping', [e for e in b['events'] if e['kind']!='mapping'])
va=[e for e in a['events'] if e['kind']=='mapping'];vb=[e for e in b['events'] if e['kind']=='mapping']
print('raw sampled mapping equality',va==vb)
for aa,bb in zip(va,vb):
 print(aa['ordinal'],[k for k in aa if aa.get(k)!=bb.get(k)])
