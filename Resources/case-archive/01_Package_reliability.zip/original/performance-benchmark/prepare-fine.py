from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
d=r/'mesh-package-final';d.mkdir(exist_ok=True)
(d/'geometry.scm').write_text((r/'mesh-roof/geometry.scm').read_text().replace('"Gas" "ambient"','"Gas" "Gas_ambient"'))
(d/'package.cmd').write_text((r/'mesh-roof/package.cmd').read_text().replace('(300 300 300)','(150 150 150)').replace('(150 150 150) }','(75 75 75) }').replace('maxPoints=100000','maxPoints=200000'))
shutil.copy2(r/'mesh-roof/datexcodes.txt',d/'datexcodes.txt')
(r/'final-mesh.sh').write_text((r/'roof.sh').read_text().replace('/mesh-roof','/mesh-package-final'))
for kind in ['vendor','local','no-radiation','no-convection']:
 out=r/('package-'+kind);out.mkdir(exist_ok=True)
 deck=(r/'roof-vendor/case.cmd').read_text().replace('../mesh-roof/package_msh.tdr','../mesh-package-final/package_msh.tdr')
 deck=deck.replace('571.42857142857','2857.142857142857')
 deck=deck.replace('pdbSet Copper HeatSinkTransfer 0.0','pdbSet Copper HeatSinkTransfer 0.1')
 if kind=='no-radiation':deck=deck.replace('Emissivity 0.8','Emissivity 0.0')
 if kind=='no-convection':
  deck=deck.replace('SideHeatTransfer 0.0025','SideHeatTransfer 0.0')
  deck=deck.replace('pdbSet Copper HeatSinkTransfer 0.1','pdbSet Copper HeatSinkTransfer 0.0')
 (out/'case.cmd').write_text(deck)
 shutil.copy2(d/'datexcodes.txt',out/'datexcodes.txt')
(r/'run-final-case.sh').write_text((r/'run-package-case.sh').read_text().replace('../mesh-roof/package_msh.tdr','../mesh-package-final/package_msh.tdr'))
