# Missing-profile fatal-path diagnosis

Execution parity: DIFF at diagnostic/exception handling; the faulting physics path agrees within the observed stack. Both binaries enter `FieldServer::setTempKField`, then `RealData::operator=` and `BaseData::operator=` with a missing target field, receive SIGSEGV, and invoke `panicproc`.

At `FLPS_panic(FLPS_ErrorCode,char*)`, both have error code 1, message `Internal error`, and Tcl result `s`. The vendor then throws `std::runtime_error("1")`; local throws `std::runtime_error("ERR 1")`. Vendor prints its PID and live Tcl result and catches the exception in floopsCmd, reporting the failed command and calling the Tcl `exit 1` path. Local reports only from the main exception barrier, omitting command context and the ordinary failure footer.

Evidence: `fatal-boundary-{vendor,local}/{fatal-boundary.json,probe.log,product.stderr,identities.sha256}`. The observer passes SIGSEGV to the installed product handler, records handler/throw boundaries and lets the product terminate. The first attempted probe never started because the shared lock wait expired; the retained runs are the subsequent successful probe executions.

Static confirmation, bound to vendor SHA256 6b5f30b801b08012dd846b339c4e4275502c5d1ee526420c4be315623d178464:
- FLPS_panic @0x12e2530: WarningKeeper, PID flag +0x199, getpid, Tcl result and error-code exception.
- throw construction @0xf25127: formats the error code, constructs runtime_error and throws.
- floopsCmd cold path @0xf25fb7..0xf261c2: stop command timer, exception text, argv (excluding run.only), cleanSyntaxCheckFiles, Tcl_Eval("exit 1"), fallback FLPS_exit.

Diagnosis source edits: none. Recommendation: restore SI diagnostic/exception/exit boundaries, preserving other product branches. A separately authorized repair follows. Do not turn the missing profile into a successful zero-temperature or no-op path, and do not copy a recorded PID into output.
