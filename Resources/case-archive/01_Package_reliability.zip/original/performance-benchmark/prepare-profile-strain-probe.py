from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(r/'probe-profile-execution-v2.py').read_text()
s=s.replace("assignment.enabled=bool(active)","assignment.enabled=bool(active);thermal.enabled=True")
marker="for bp in gdb.breakpoints():"
insert='''class ThermalEnd(gdb.FinishBreakpoint):
 def __init__(self,e,p):super().__init__(gdb.newest_frame(),internal=True);self.e=e;self.p=p
 def stop(self):
  self.e['strain_output']=struct.unpack('<6d',bytes(gdb.selected_inferior().read_memory(self.p,48)))
  self.e['returned']=True;return False
class Thermal(gdb.Breakpoint):
 def stop(self):
  obj=reg('rdi');element=reg('rsi');output=reg('rdx')
  if not element:return False
  self.enabled=False
  mesh=q(element+0x10);mat=q(mesh+0x98);params=q(obj+0x108)
  e={'kind':'thermal_strain','mapping_epoch':counts.get('mapping',0),'material':textptr(q(mat+8)), 'data_index':i(element+0x1c),'element_kind':i(element+0x20),'component':reg('ecx'),'use_old':bool(reg('r8')&255),'mode':reg('r9d'),'alpha_base':d(params+0x5f0),'previous_temperature':d(params+0x6e8),'current_temperature':d(params+0x6f0),'strain_input':struct.unpack('<6d',bytes(gdb.selected_inferior().read_memory(output,48)))}
  if not any(x['kind']=='thermal_strain' for x in events):e['stack']=gdb.execute('bt 7',to_string=True)
  events.append(e);ThermalEnd(e,output);return False
thermal=Thermal('floops::MechPDE::computeThermalStrain(floops::Element*, double*, int, bool, int)')
'''
assert s.count(marker)==1;s=s.replace(marker,insert+marker)
(r/'probe-profile-strain.py').write_text(s)
s=(r/'run-profile-execution-v2.sh').read_text().replace('execution-v2-$kind','strain-$kind').replace('probe-profile-execution-v2.py','probe-profile-strain.py').replace('flock -w 600','flock -w 3600')
(r/'run-profile-strain.sh').write_text(s)
