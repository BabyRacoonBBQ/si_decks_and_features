"""VM-only scientific rendering of the selected TDR; no solver invocation."""
from pathlib import Path
import os, sys, math, json, hashlib, time, socket
import numpy as np
import h5py
import vtk
from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray, vtk_to_numpy
from PIL import Image

ROOT=Path('/home/mozztcad/tmp/package-benchmark-20261010/certified-e2e-v2-thermal-local')
INPUT=ROOT/'result_sis.tdr'
OUT=Path('/home/mozztcad/tmp/package-benchmark-20261010/reliability-local/mesh-visualization');OUT.mkdir(parents=True,exist_ok=True)
W,H=1000,680
PREVIEW='--preview' in sys.argv
FRAME_COUNT=180
COLORS={'Silicon':'#287E8B','Copper':'#C99450','Copperline':'#A56942',
        'Solder':'#97A9BD','SmearBeol':'#6C72AE','Aluminum':'#CCD6DE','Resin':'#C7D6D7'}
LABELS={'Silicon':'Silicon die','Copper':'Cu leadframe','Copperline':'Cu wires',
        'Solder':'Solder','SmearBeol':'BEOL','Aluminum':'Aluminum','Resin':'Resin'}
def rgb(c):return tuple(int(c[i:i+2],16)/255 for i in (1,3,5))
def name(a):return a.decode() if isinstance(a,bytes) else str(a)
vtk.vtkMultiThreader.SetGlobalMaximumNumberOfThreads(1)
vtk.vtkMultiThreader.SetGlobalDefaultNumberOfThreads(1)
ren=vtk.vtkRenderer();ren.SetBackground(1,1,1);ren.SetViewport(0,.04,1,1)
win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(W,H)
win.SetMultiSamples(4);win.SetNumberOfLayers(2);win.AddRenderer(ren)
back=vtk.vtkRenderer();back.SetBackground(1,1,1);back.SetLayer(0);win.AddRenderer(back)
# Render the model after the full-canvas background, then render text on layer 1.
win.RemoveRenderer(ren);win.AddRenderer(ren)
overlay=vtk.vtkRenderer();overlay.SetLayer(1);overlay.InteractiveOff();win.AddRenderer(overlay)
def add_text(value,x,y,size=18,col='#172D43',bold=False):
    actor=vtk.vtkTextActor();actor.SetInput(value);actor.SetPosition(x,H-y-size)
    prop=actor.GetTextProperty();prop.SetFontFamilyToArial();prop.SetFontSize(size)
    prop.SetColor(rgb(col));prop.SetBold(bold);overlay.AddActor2D(actor);return actor
# No text overlays inside the mesh animation.
plane=vtk.vtkPlane();plane.SetNormal(0,1,0)
grids=[];actors=[];clippers=[];regions=[];total=0;gas=0
with h5py.File(INPUT,'r') as f:
    g=f['collection/geometry_0']; v=g['vertex'][:]
    pts=np.column_stack((v['z'],v['y'],-v['x']))*10.0 # cm -> mm, rigid rotation
    pmin,pmax=pts.min(0),pts.max(0);center=(pmin+pmax)*0.5
    pts-=center
    vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(pts,deep=True))
    for key,r in g.items():
        if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0:continue
        mat=name(r.attrs['material']);a=r['elements_0'][:].reshape(-1,5)
        assert np.all(a[:,0]==5),'Only tetrahedral cell type expected'
        total+=len(a)
        if mat=='Gas':gas+=len(a);continue
        cells=np.array(a,dtype=np.int64);cells[:,0]=4
        ca=vtk.vtkCellArray();ca.SetCells(len(a),numpy_to_vtkIdTypeArray(cells.ravel(),deep=True))
        ug=vtk.vtkUnstructuredGrid();ug.SetPoints(vp);ug.SetCells(vtk.VTK_TETRA,ca)
        clip=vtk.vtkTableBasedClipDataSet();clip.SetInputData(ug);clip.SetClipFunction(plane);clip.InsideOutOn()
        mapper=vtk.vtkDataSetMapper()
        mapper.SetInputConnection(clip.GetOutputPort())
        mapper.ScalarVisibilityOff()
        actor=vtk.vtkActor();actor.SetMapper(mapper)
        prop=actor.GetProperty();prop.SetColor(rgb(COLORS[mat]));prop.SetAmbient(.55);prop.SetDiffuse(.45)
        prop.SetSpecular(.18);prop.SetSpecularPower(28)
        prop.EdgeVisibilityOn();prop.SetEdgeColor(tuple(.68*c+.12 for c in rgb(COLORS[mat])));prop.SetLineWidth(.3)
        ren.AddActor(actor);grids.append(ug);actors.append(actor);clippers.append(clip)
        regions.append({'region':key,'name':name(r.attrs['name']),'material':mat,'tetrahedra':len(a)})

solid_ids=np.unique(np.concatenate([vtk_to_numpy(grid.GetCells().GetConnectivityArray()) for grid in grids]))
solid=pts[solid_ids];low,high=solid.min(0),solid.max(0)
focus=(low+high)*.5
plane.SetOrigin(0,high[1]+.05,0)
camera=ren.GetActiveCamera();camera.SetViewUp(0,0,1);camera.SetViewAngle(29)
radius=np.linalg.norm(high-low)*1.48
ren.SetAmbient(1,1,1)
light=vtk.vtkLight();light.SetLightTypeToCameraLight();light.SetPosition(1,-1,2);light.SetIntensity(.8);ren.AddLight(light)
window_image=vtk.vtkWindowToImageFilter();window_image.SetInput(win);window_image.SetInputBufferTypeToRGB();window_image.ReadFrontBufferOff()

def smooth(t):return (1-math.cos(math.pi*t))*.5
def render_frame(i):
    # Only ONE shared clipping plane exists in the pipeline. Restore completely
    # before changing its normal. Camera is stationary during each section sweep.
    theta=395;axis=1;cut=0.;stage=''
    if i<36:
        theta=35+360*i/36
    elif i<66:
        cut=smooth((i-36)/29);stage='Section A'
    elif i<74:
        cut=1.;stage='Section A'
    elif i<104:
        cut=1-smooth((i-74)/29);stage='Restoring'
    elif i<112:
        cut=0.
    elif i<140:
        axis=2;cut=smooth((i-112)/27);stage='Section B'
    elif i<148:
        axis=2;cut=1.;stage='Section B'
    elif i<176:
        axis=2;cut=1-smooth((i-148)/27);stage='Restoring'
    else:
        axis=2;cut=0.
    normal=[0,0,0];normal[axis]=1;origin=[0,0,0]
    target=low[axis]-.05  # Sweep beyond the far face, through the entire model.
    origin[axis]=(high[axis]+.05)*(1-cut)+target*cut
    plane.SetNormal(*normal);plane.SetOrigin(*origin)
    for actor,region in zip(actors,regions):
        if region['material']=='Resin':actor.GetProperty().SetEdgeVisibility(cut<.01)
    rad=math.radians(theta);elev=math.radians(32)
    camera.SetPosition(focus[0]+radius*math.cos(rad)*math.cos(elev),focus[1]+radius*math.sin(rad)*math.cos(elev),focus[2]+radius*math.sin(elev))
    camera.SetFocalPoint(*focus);camera.SetViewUp(0,0,1);ren.ResetCameraClippingRange()
    win.Render();window_image.Modified();window_image.Update()
    raw=vtk_to_numpy(window_image.GetOutput().GetPointData().GetScalars()).reshape(H,W,3)
    return Image.fromarray(np.flipud(raw).copy())

start=time.time();samples=[0,65,103,139,175,179] if PREVIEW else range(FRAME_COUNT)
frames=[]
for i in samples:
    im=render_frame(i)
    if i in [0,65,103,139,175,179]:im.save(OUT/f'frame-{i:03}.png')
    if not PREVIEW:frames.append(im)
    if i%12==0: print(json.dumps({'frame':i,'elapsed_seconds':round(time.time()-start,2)}),flush=True)
if not PREVIEW:
    # Shared palette avoids per-frame color flicker; no temporal field interpolation.
    atlas=Image.new('RGB',(500,340*6))
    for j,i in enumerate([0,36,65,103,139,175]):atlas.paste(frames[i].resize((500,340)),(0,j*340))
    palette=atlas.quantize(colors=256,method=Image.Quantize.MEDIANCUT)
    quant=[f.quantize(palette=palette,dither=Image.Dither.NONE) for f in frames]
    output=ROOT/'package-mesh-rotation-section.gif'
    temporary=output.with_suffix('.pending.gif')
    quant[0].save(temporary,save_all=True,append_images=quant[1:],duration=80,loop=0,optimize=False,disposal=2)
    temporary.replace(output)
    with Image.open(output) as encoded:
        encoded_frames=encoded.n_frames
        encoded_duration=sum((encoded.seek(i) or encoded.info.get('duration',0)) for i in range(encoded_frames))
    manifest={'input':str(INPUT),'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        'output':str(output),'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'render_host':socket.gethostname(),'renderer':'VTK '+vtk.vtkVersion.GetVTKVersion(),
        'render_location':'VM; no frames rendered on Windows','rendered_frames':FRAME_COUNT,'encoded_frames':encoded_frames,'encoded_duration_ms':encoded_duration,'frame_duration_ms':80,
        'size':[W,H],'vertices':len(pts),'tetrahedra_including_gas':total,'gas_tetrahedra':gas,
        'solid_tetrahedra':total-gas,'regions':regions,'seconds':time.time()-start,
        'semantics':'Original TDR tetrahedra; Gas hidden; material colors; perspective orbit; exactly one clipping plane clips every solid region; full-depth Y sweep and full restoration, then full-depth Z sweep and full restoration. No numerical simulation or physical deformation in animation.'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest),flush=True)
win.Finalize()

