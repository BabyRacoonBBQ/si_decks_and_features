import os,json
from pathlib import Path
archive=Path('/home/mozztcad/tmp/paused-info2-20261010/worktree.tar.gz')
def memory():
 wanted={'MemFree','MemAvailable','Cached','SwapFree'}
 return {k:int(v.strip().split()[0]) for k,v in (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines()) if k in wanted}
result={'archive':str(archive),'before_kib':memory()}
assert archive.is_file() and archive.stat().st_size==7294572067
with archive.open('rb') as stream:
 os.posix_fadvise(stream.fileno(),0,0,os.POSIX_FADV_DONTNEED)
result['after_kib']=memory()
result['file_size_after']=archive.stat().st_size
Path('/home/mozztcad/tmp/package-benchmark-20261010/archive-cache-release.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
