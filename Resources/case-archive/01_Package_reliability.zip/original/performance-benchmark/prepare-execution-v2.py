from pathlib import Path
p=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(p/'probe-profile-execution.py').read_text()
s=s.replace("if values:out[name]=d(values)","""if values:
   nodes=q(mesh+0x20); ncount=i(mesh+0x2c)
   chosen=None
   for j in range(ncount):
    node=q(nodes+8*j)
    if node:
     index=i(node+0x1c)
     if not 0<=index<1000000:raise RuntimeError('invalid node data index')
     chosen={'data_index':index,'value':d(values+8*index)};break
   if chosen:out[name]=chosen""")
s=s.replace("def __init__(self,e,kind):super().__init__(gdb.newest_frame(),internal=True);self.e=e;self.kind=kind", "def __init__(self,e,kind):super().__init__(gdb.newest_frame(),internal=True);self.e=e;self.kind=kind;self.obj=reg('rdi')")
s=s.replace("self.e['returned']=True", """if self.kind=='setParams':
   count=i(self.obj+0x24);table=q(self.obj+0x18)
   if count!=1:raise RuntimeError('unexpected ramp count '+str(count))
   step=q(table)
   self.e['created_ramp']=struct.unpack('<5d',bytes(gdb.selected_inferior().read_memory(step+8,40)))
  self.e['returned']=True""")
(p/'probe-profile-execution-v2.py').write_text(s)
s=(p/'run-profile-execution.sh').read_text().replace('execution-$kind','execution-v2-$kind').replace('probe-profile-execution.py','probe-profile-execution-v2.py')
(p/'run-profile-execution-v2.sh').write_text(s)
