from pathlib import Path
import subprocess,sys,json,os
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
prefix=os.environ.get('BENCH_PREFIX','detailed')
pairs=[(f'{prefix}-r{i}-vendor',f'{prefix}-r{i}-local',f'{prefix}-fields-r{i}.json') for i in range(1,4)]
pairs += [('demo-thermal-vendor','demo-thermal-local','demo-thermal-fields.json'),('demo-coupled-vendor','demo-coupled-local','demo-coupled-fields.json')]
summary=[]
for a,b,out in pairs:
    if not (r/a/'result_sis.tdr').exists() or not (r/b/'result_sis.tdr').exists():
        summary.append({'pair':[a,b],'status':'OUTPUT_MISSING'});continue
    with (r/(out+'.log')).open('w') as log:
        subprocess.run([sys.executable,str(r/'compare-thermal.py'),str(r/a/'result_sis.tdr'),str(r/b/'result_sis.tdr'),str(r/out)],stdout=log,stderr=subprocess.STDOUT,check=True)
    d=json.loads((r/out).read_text())
    summary.append({'pair':[a,b],'field_groups':len(d['fields']),'exact_groups':sum(x.get('exact',False) for x in d['fields'].values()),'missing_fields':d['missing_fields'],'extra_fields':d['extra_fields'],'topology_differences':d['topology_differences'],'field_attribute_differences':d['metadata_differences'],'raw_identical':d['raw']['identical'],'max_field_abs':d['max_field_abs']})
(r/'field-audit-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
