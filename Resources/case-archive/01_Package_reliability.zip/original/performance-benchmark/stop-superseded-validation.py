from pathlib import Path
import subprocess,os,signal,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
root=1613208
raw=subprocess.check_output(['ps','-eo','pid=,ppid=,args='],text=True)
rows={int(x[0]):(int(x[1]),x[2]) for line in raw.splitlines() if len(x:=line.split(None,2))==3}
assert root in rows and 'run-e2e-final-validation.sh' in rows[root][1]
owned=[root]
for pid in owned:
 owned.extend(k for k,v in rows.items() if v[0]==pid and k not in owned)
(r/'e2e-final-regressions/stopped-owned-processes.json').write_text(json.dumps({str(k):rows[k] for k in owned},indent=2))
for pid in reversed(owned):
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:pass
print('Stopped own superseded validation chain',owned)
