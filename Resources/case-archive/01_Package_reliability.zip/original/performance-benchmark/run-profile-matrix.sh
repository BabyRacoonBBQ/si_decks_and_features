#!/bin/bash
set -u
root=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
for label in multistep implicit uniform missing conflict no-time; do
 for kind in vendor local; do
  bash "$root/run-profile-case.sh" "$kind" "$label" > "$root/$label-$kind-run.log" 2>&1
  echo "$label $kind exit=$?"
 done
 done
