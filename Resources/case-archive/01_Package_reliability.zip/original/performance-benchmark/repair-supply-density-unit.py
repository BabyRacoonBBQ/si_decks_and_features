from pathlib import Path
p=Path('/home/mozztcad/geo3d/src/abi/sinterconnect/SupplyCmd.cpp');s=p.read_text();old='auto* const powerDensityParam = newFloat(VOF_STATIC_STR("power.density"));';assert old in s
s=s.replace(old,'// SI @0x11f8725: PowerDensity (0x1a), with default W/cm3.\n    auto* const powerDensityParam = new pdblib::UserParamFloat(\n        VOF_STATIC_STR("power.density"), 0.0, pdblib::Unit::PowerDensity,\n        VOF_STATIC_STR("W/cm3"));');p.write_text(s)
