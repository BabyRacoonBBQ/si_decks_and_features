import gdb,json,struct
from pathlib import Path
counts={};events=[];active=[]
def q(p):return struct.unpack('<Q',bytes(gdb.selected_inferior().read_memory(p,8)))[0]
def i(p):return struct.unpack('<i',bytes(gdb.selected_inferior().read_memory(p,4)))[0]
def d(p):return struct.unpack('<d',bytes(gdb.selected_inferior().read_memory(p,8)))[0]
def textptr(p):return gdb.Value(p).cast(gdb.lookup_type('char').pointer()).string() if p else None
def fieldname(p):return textptr(q(p+0x18)) if p else None
def reg(s):return int(gdb.parse_and_eval('$'+s))
def xmm(n):return float(gdb.parse_and_eval('$xmm'+str(n)+'.v2_double[0]'))
def snapshot(fs,f):
 if not f:return None
 table=q(fs+0xa8);count=i(fs+0xb4)
 if not 0<count<1000:raise RuntimeError('invalid mesh count '+str(count))
 nodefields=q(f+0x60);out={}
 for n in range(count):
  mesh=q(table+8*n)
  if not mesh or i(mesh+0x2c)<=0:continue
  mat=q(mesh+0x98);idx=i(mat+0x34);name=textptr(q(mat+8))
  if not 0<=idx<1000:raise RuntimeError('invalid material index')
  md=q(nodefields+8*idx) if nodefields else 0
  values=q(md) if md else 0
  if values:out[name]=d(values)
 return out
class Finish(gdb.FinishBreakpoint):
 def __init__(self,e,kind):super().__init__(gdb.newest_frame(),internal=True);self.e=e;self.kind=kind
 def stop(self):
  if self.kind=='mapping':
   ctx=active.pop();self.e['output_sample']=snapshot(ctx['fs'],ctx.get('output',0));assignment.enabled=bool(active)
  else:self.e['return_eax']=reg('eax')
  self.e['returned']=True
  return False
class Probe(gdb.Breakpoint):
 def __init__(self,s,kind):super().__init__(s);self.kind=kind
 def stop(self):
  k=self.kind;counts[k]=counts.get(k,0)+1
  e={'kind':k,'ordinal':counts[k]};events.append(e)
  if counts[k]==1:e['stack']=gdb.execute('bt 6',to_string=True)
  if k=='mapping':
   fs=reg('rdi');final=reg('rsi');initial=reg('rdx')
   e.update(final=fieldname(final),initial=fieldname(initial),duration=xmm(0),time=xmm(1),dt=xmm(2),final_sample=snapshot(fs,final),initial_sample=snapshot(fs,initial))
   active.append({'fs':fs});assignment.enabled=True
  if k=='setParams':e['implicit']=reg('edx')
  if k=='AddStep':
   p=reg('rsi');e['ramp']=struct.unpack('<5d',bytes(gdb.selected_inferior().read_memory(p+8,40)))
  Finish(e,k)
  return False
class Assignment(gdb.Breakpoint):
 def stop(self):
  if active and fieldname(reg('rdi'))=='Temperature':active[-1]['output']=reg('rdi')
  return False
assignment=Assignment('floops::RealData::operator=(floops::RealData const&)');assignment.enabled=False
Probe('floops::FieldServer::setTempKField(floops::RealData*, floops::RealData*, double, double, double)','mapping')
Probe('floops::Temp_Ramp::setParams(pdblib::ParamParse&, bool, floops::AnnealStep* (*)())','setParams')
Probe('floops::Temp_Ramp::AddStep(floops::AnnealStep&)','AddStep')
Probe('floops::Tdr_reader::read(bool, bool)','read')
Probe('floops::TDRInterfaceHelper::ReadModifiedParams(Tdr_tag_group*)','readParameters')
for bp in gdb.breakpoints():
 if bp.pending:raise RuntimeError('unresolved breakpoint '+bp.location)
vendor='sinterconnect_run' not in gdb.current_progspace().filename
gdb.execute('run '+('--noSyntaxCheck ' if vendor else '')+'case.cmd > product.stdout 2> product.stderr')
if gdb.selected_inferior().pid:raise RuntimeError('probe stopped before normal exit')
if any(not e.get('returned') for e in events):raise RuntimeError('missing return observation')
Path('execution.json').write_text(json.dumps({'counts':counts,'events':events},indent=2))
print('PROBE_COUNTS '+str(counts))

