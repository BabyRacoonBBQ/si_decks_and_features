"""Render local Release fields with the fixed-camera section sweep."""
from pathlib import Path
src = Path(__file__).with_name('render-field-sections.py').read_text()
src = src.replace("with_name('render-package-animation.py')", "with_name('render-package-animation-local.py')")
src = src.replace("OUT=ROOT/'field-sections';OUT.mkdir(exist_ok=True)", "OUT=Path(__file__).resolve().parent/'reliability-figures-local';OUT.mkdir(parents=True,exist_ok=True)")
src = src.replace("ROOT.parent/'demo-coupled-vendor/result_sis.tdr'", "Path(__file__).resolve().parent/'slide-evidence'/'package-local'/'coupled-result_sis.tdr'")
exec(compile(src, str(Path(__file__).with_name('render-field-sections.py')), 'exec'), globals(), globals())
