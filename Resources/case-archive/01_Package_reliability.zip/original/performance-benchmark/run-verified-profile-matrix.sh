#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 3600 9
ulimit -v 6291456
binary=/home/mozztcad/geo3d/build/sinterconnect_run
for label in package multistep implicit uniform catch missing conflict no-time; do
 dir=$r/verified-$label-local
 cd "$dir"
 sha256sum "$binary" case.cmd settings.cmd mp.cmd ../../demo-thermal-vendor/result_sis.tdr > identities.sha256
 set +e
 /usr/bin/time -v timeout -k 10 300 taskset -c 4 "$binary" case.cmd > stdout.log 2> stderr.log
 rc=$?
 set -e
 echo "$rc" > exit.txt
 echo "$label=$rc"
 case "$label" in missing|conflict|no-time) expected=1;; *) expected=0;; esac
 if [ "$rc" != "$expected" ]; then tail -35 stderr.log;exit 1;fi
done
