from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s='''foreach p {saveModifiedParameters saveModifiedParameter pdbNewMaterialandInterfaces pdbNewMaterial pdbNewInterface} {
 if {[llength [info procs $p]]} {puts "PROCEDURE $p [info args $p]"; puts [info body $p]}
}
mater add name=ProbeCopper new.like=Copper
foreach n [lsort [info globals Params*]] {
 if {[array exists $n]} {
  foreach k {Like Modify} {
   if {[info exists ${n}($k)]} {puts "STATE $n $k [set ${n}($k)]"}
  }
 }
}
'''
for kind in ['vendor','local']:
 d=r/('material-tags-'+kind);d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(s)
 for f in ['settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((r/'initial-local'/f).read_bytes())
