from pathlib import Path
r=Path('/home/mozztcad/geo3d')
p=r/'src/abi/sinterconnect/SolveCmd.cpp'
s=p.read_text()
old='''        if (!hadConverged_) {
            pdblib::pdbunsetBoolean('''
new='''        // Cleanup evaluates Tcl PDB commands. Preserve the solve result and
        // error state: native solveErrorCheck leaves its diagnostic intact
        // when solve_tcl returns TCL_ERROR (profile-conflict probe).
        Tcl_InterpState const savedState = Tcl_SaveInterpState(interpreter_, TCL_OK);
        if (!hadConverged_) {
            pdblib::pdbunsetBoolean('''
assert s.count(old)==1;s=s.replace(old,new)
old='''                pdblib::PDB0);
        }
    }

private:
    Tcl_Interp* interpreter_;'''
new='''                pdblib::PDB0);
        }
        (void)Tcl_RestoreInterpState(interpreter_, savedState);
    }

private:
    Tcl_Interp* interpreter_;'''
assert s.count(old)==1;s=s.replace(old,new)
assert s.count('temp.ramp parameters parameter and ')==1
s=s.replace('temp.ramp parameters parameter and ','temp.ramp parameters  parameter and ')
p.write_text(s)
e=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
(e/'solve-error-diagnosis.md').write_text('''# Profile error diagnostic diagnosis

Execution parity: DIFF. First proven divergence: solveErrorCheck returns an error with one space missing in the local message; solve_tcl subsequently returns the same error code but an empty Tcl result. Vendor preserves its diagnostic.

Read-only GDB result observations use the actual linked Tcl_GetObjResult layout (+0x2a8 object, +8 bytes, legacy result first). No inferior calls or mutations. Both runs use conflict-vendor/case.cmd and the established single-thread boundary. Evidence: error-boundary-{vendor,local}/{error-boundary.json,probe.log,identities.sha256}.

Local SolveTemporaryPdbCleanup executes PDB Tcl commands on scope exit without preserving interpreter state. The named destructor probe did not hit (optimized inline cleanup); source and the solve entry/check return/solve return observations establish result loss within the wrapper, not a validator rejection difference.

Recommendation: preserve complete Tcl interpreter state around cleanup; match vendor diagnostic spacing. Diagnosis itself did not edit product source. A separately authorized repair follows this report.
''')
