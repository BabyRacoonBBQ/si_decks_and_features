from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
for kind in ['vendor','local']:
    t=r/f'demo-thermal-{kind}';t.mkdir(exist_ok=True)
    (t/'case.cmd').write_text((r/'package-vendor/case.cmd').read_text().replace('../mesh-package-final/','../mesh-roof/'))
    shutil.copy2(r/'package-vendor/datexcodes.txt',t/'datexcodes.txt')
    m=r/f'demo-coupled-{kind}';m.mkdir(exist_ok=True)
    for name in ['settings.cmd','mp.cmd','datexcodes.txt']:
        shutil.copy2(r/f'coupled-{kind}'/name,m/name)
    (m/'case.cmd').write_text((r/f'coupled-{kind}/case.cmd').read_text().replace('../package-vendor/result_sis.tdr','../demo-thermal-vendor/result_sis.tdr'))
(r/'run-demo-coupling.sh').write_text((r/'run-coupling.sh').read_text().replace('/coupled-$kind','/demo-coupled-$kind').replace('../package-vendor/result_sis.tdr','../demo-thermal-vendor/result_sis.tdr'))
