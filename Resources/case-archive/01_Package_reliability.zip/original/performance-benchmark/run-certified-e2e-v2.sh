#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
rec=$root/thermomechanical-recovery
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 3600 9
ulimit -v 6291456
bin=/home/mozztcad/geo3d/build/sinterconnect_run
py=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3
mkdir "$root/certified-e2e-v2-thermal-local"
cp "$root/demo-thermal-local/"{case.cmd,datexcodes.txt} "$root/certified-e2e-v2-thermal-local/"
cd "$root/certified-e2e-v2-thermal-local"
sha256sum "$bin" case.cmd datexcodes.txt ../mesh-roof/package_msh.tdr > identities.sha256
set +e
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$bin" case.cmd > stdout.log 2> stderr.log
rc=$?
set -e
echo "$rc" > exit.txt
[ "$rc" = 0 ]
"$py" "$rec/verify-profile-timestamps.py" "$root/demo-thermal-vendor/result_sis.tdr" result_sis.tdr "$rec/e2e-v2-thermal-comparison.json"
mkdir "$rec/certified-e2e-v2-mechanics-local"
cp "$rec/certified-package-local/"{case.cmd,settings.cmd,mp.cmd,datexcodes.txt} "$rec/certified-e2e-v2-mechanics-local/"
cd "$rec/certified-e2e-v2-mechanics-local"
sed -i 's@../../demo-thermal-vendor/@../../certified-e2e-v2-thermal-local/@' case.cmd
sha256sum "$bin" case.cmd settings.cmd mp.cmd datexcodes.txt ../../certified-e2e-v2-thermal-local/result_sis.tdr > identities.sha256
set +e
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$bin" case.cmd > stdout.log 2> stderr.log
rc=$?
set -e
echo "$rc" > exit.txt
[ "$rc" = 0 ]
"$py" "$rec/verify-profile-timestamps.py" "$root/demo-coupled-vendor/result_sis.tdr" result_sis.tdr "$rec/e2e-v2-mechanics-comparison.json"

