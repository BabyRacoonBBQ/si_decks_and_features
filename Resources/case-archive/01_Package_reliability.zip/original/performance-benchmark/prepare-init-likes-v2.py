from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s='''math numThreads=1
pdbSet Grid AddGasMesh 0
source settings.cmd
proc dumpLikes {phase} {
 puts "PHASE $phase"
 foreach n [lsort [info globals Params*]] {
  set n ::$n
  if {[array exists $n] && [info exists ${n}(Like)]} {
   set m {};if {[info exists ${n}(Modify)]} {set m [set ${n}(Modify)]}
   puts "LIKE $n VALUE [set ${n}(Like)] MODIFY $m"
  }
 }
}
dumpLikes before
init tdr=../../demo-thermal-vendor/result_sis.tdr !load.commands !pdb
dumpLikes after
'''
for kind in ['vendor','local']:
 d=r/('init-likes-v2-'+kind);d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(s)
 for f in ['settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((r/'initial-local'/f).read_bytes())

