from pathlib import Path
import base64, hashlib, json, zipfile, io
from PIL import Image

root=Path(__file__).resolve().parents[1]
assets=root/'performance-benchmark/reliability-figures'
old_path=assets/'package-mesh-rotation-section.gif'
new_path=assets/'package-mesh-rotation-section.new.gif'
old=old_path.read_bytes();new=new_path.read_bytes()
manifest=json.loads((assets/'vm-gif-manifest.json').read_text())
assert hashlib.sha256(new).hexdigest()==manifest['output_sha256']
with Image.open(new_path) as image: assert image.n_frames>100 and image.size==(1000,680)
old64=base64.b64encode(old).decode();new64=base64.b64encode(new).decode()
phrases={
 'A plane sections the solid mesh and a second plane cuts back the upper resin; these are display operations, not a changed analysis mesh.':'A single plane sections the solid mesh in direction A, then fully restores it before sectioning in direction B; these are display operations, not a changed analysis mesh.',
 'Rotation, a section through the solid mesh, a resin cutaway, and restoration of the complete package.':'Rotation, section A, full restoration, section B, and full restoration of the complete package.',
 'Rotating TDR mesh with a progressive section and resin cutaway':'Rotating TDR mesh with sequential single-plane sections',
}
def revise(text):
    text=text.replace(old64,new64)
    for a,b in phrases.items():text=text.replace(a,b)
    return text
files=[]
for base in ['StressThermal-physics','StressThermal-with-reliability']:
    files.extend(root/(base+suffix) for suffix in ['.html','.drawio'])
files.extend(root/name for name in ['scene.json','scene-with-reliability.json'])
files.extend(root.glob('svg*/03-reliability.svg'))
records=[]
for p in files:
    original=p.read_bytes();text=original.decode('utf-8');updated=revise(text)
    assert p.read_bytes()==original,'Concurrent edit detected'
    p.write_text(updated,encoding='utf-8')
    records.append({'file':p.name,'GIF_replacements':text.count(old64)})
for base in ['StressThermal-physics','StressThermal-with-reliability']:
    p=root/(base+'.pptx');original=p.read_bytes();mem=io.BytesIO();replaced=0
    with zipfile.ZipFile(io.BytesIO(original)) as zin,zipfile.ZipFile(mem,'w',compression=zipfile.ZIP_DEFLATED) as zout:
        for entry in zin.infolist():
            content=zin.read(entry.filename)
            if content==old:content=new;replaced+=1
            elif entry.filename.endswith('.xml'):content=revise(content.decode('utf-8')).encode('utf-8')
            zout.writestr(entry,content)
    assert replaced==1,(p,replaced)
    assert p.read_bytes()==original,'Concurrent edit detected'
    p.write_bytes(mem.getvalue());records.append({'file':p.name,'GIF_replacements':replaced})
module=root.parent/'reliability-slide.cjs'
module.write_text(revise(module.read_text(encoding='utf-8')),encoding='utf-8')
new_path.replace(old_path)
(root/'performance-benchmark/animation-replacement.json').write_text(json.dumps({'manifest':manifest,'updated':records},indent=2))
print(json.dumps(records,indent=2))
