from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
s=(r/'demo-thermal-vendor/case.cmd').read_text()
s=s.replace('SetTemp 26.844','''foreach {label args} {none {} extra {300 400} parameters {parameters} editor {editor.syntax} run_only {run.only} invalid {not_a_number}} {
 set code [catch {SetTemp {*}$args} message]
 puts "SETTEMP_CHECK $label <$code> <$message>"
}
SetTemp 400
SetTemp 26.844
puts "SETTEMP_HISTORY [select max name=Temperature] [select max name=PrevTemperature] [select max name=InitTemperature]"''')
s=s.replace('power.density=2857.142857142857','power.density=2857142.857142857<mW/cm3>')
for kind in ['vendor','local']:
 d=r/('settemp-unit-'+kind);d.mkdir();(d/'case.cmd').write_text(s);(d/'datexcodes.txt').write_bytes((r/'demo-thermal-vendor/datexcodes.txt').read_bytes())
