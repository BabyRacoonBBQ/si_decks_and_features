from pathlib import Path
import json,hashlib,re
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
expected=(r/'final-build.sha256').read_text().splitlines()[0].split()[0]
checks={}
for label in ['package','multistep','implicit','uniform','catch','missing','conflict','no-time']:
 d=r/('certified-'+label+'-local')
 actual=(d/'identities.sha256').read_text().splitlines()[0].split()[0]
 checks[label]={'binary_sha256':actual,'matches_final_build':actual==expected,'exit_code':int((d/'exit.txt').read_text())}
 assert actual==expected
summary={'final_binary_sha256':expected,'cases':checks,'matrix':json.loads((r/'certified-matrix-comparison.json').read_text()),'mapping':json.loads((r/'execution-v2-comparison.json').read_text())}
for x in summary['matrix'].values():assert x.get('timestamp_excluded_byte_exact',x.get('equal',False))
summary['mapping_build_note']='Execution-v2 observes the recovered coupling core; the subsequent changes only restore SI diagnostic/exit handling. The final executable is independently checked by all eight certified cases.'
(r/'verification-summary.json').write_text(json.dumps(summary,indent=2))
print('All eight case runs used final binary',expected)
