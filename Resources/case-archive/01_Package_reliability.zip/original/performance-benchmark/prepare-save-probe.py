from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s='''mater add name=ProbeCopper new.like=Copper
proc captureSave {cmd op} {puts "SAVED $cmd"}
proc captureGet {cmd code result op} {
 if {[string match *ProbeCopper* $cmd]} {puts "GET $cmd CODE $code RESULT $result"}
}
trace add execution saveModifiedParameter enter captureSave
trace add execution __pdbGet leave captureGet
saveModifiedParameters
'''
for kind in ['vendor','local']:
 d=r/('material-save-'+kind);d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(s)
 for f in ['settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((r/'initial-local'/f).read_bytes())
