# Thermomechanical recovery verification

## Result and scope

The approved adapted **Backend Package_ThermomechanicalReliability** case now runs locally through thermal analysis and temperature-driven mechanics. Both stages match the retained vendor outputs byte for byte after excluding only structurally identified HDF5 timestamps. The discriminating mechanics cases, error behavior, mapped temperature evolution and sampled thermal-strain calculations are verified separately.

This is scoped behavioral equivalence, not a claim that every feature of the two programs is identical. Full startup warning streams and dynamic timers remain outside the exact-output claim. The broader CTest suite is not entirely passing; see the regression section.

- Repository: `/home/mozztcad/geo3d`, branch `main`, base `4140959ce963437b066e36dcc47703ac609881a1`.
- Mesh: **17,171 vertices; 24,389 material nodes; 88,813 tetrahedra including Gas**.
- Solid materials: Silicon, Copper, Copperline, Solder, Resin, SmearBeol and Aluminum.
- Thermal loading: 5 W die, 300 K ambient, conduction, radiation with emissivity 0.8, side convection 25 W/(m2 K), Copper base heat transfer 1000 W/(m2 K).
- Mechanics: first-order 3D solid elements, linear material models, bottom displacement clamp, mapped temperature profile; four-step and one-step variants are distinct cases.
- Evidence: `/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery`.
- No commit, push, reset, vendor modification, injected vendor solver or output rewriting was performed. The supplied recovery prompt was used for working methods only.

## Repairs and first-divergence evidence

| Area | Restored behavior |
|---|---|
| Temperature ramp | Accept `t.final.profile`; preserve the vendor implicit initial-temperature behavior when `temperature` is omitted |
| Field mapping | Pass final and initial fields to `setTempKField` in the vendor argument order |
| Structure initialization | Honor SI `init !pdb` at the reader boundary, preserving live parameter state and material inheritance |
| Tcl errors | Preserve interpreter result/errorInfo during temporary PDB cleanup; restore SI exception, command traceback and failure-exit behavior |
| SI `SetTemp` entry | Dispatch to the spatial-temperature handler; update the field server, copy current Temperature into PrevTemperature then InitTemperature, then set current temperature. Do not persist a generic process SetTemp command |
| Heat-source units | Restore `power.density` as PowerDensity with default `W/cm3`, including unit conversion |

The earlier authorized thermal repairs remain: pure-thermal controller preparation, inactive-solution handling in `needPDESolve`, steady thermal integration and thermal output units. The complete patch contains 16 modified source files.

A shared regression caught an intermediate registration error: geo_run also installs the common CSSE commands. The final installer receives an explicit Interconnect flag only from the SI entry point; geo_run keeps its existing SetTemp handler. The previously failing 9_101_insert_min case passes after this correction. Evidence is retained in product-gated-insert.log and the superseded e2e-final-regressions/ logs.

The last end-to-end check initially exposed an additional difference despite exact physical fields: local SetTemp used the generic process entry, changing field allocation order and saved command history. A bounded vendor/local GDB trace identified the first differing entry. The corrected execution produces the original vendor file layout without sorting or rewriting outputs. Native constructor evidence independently identified the missing power-density unit. Details are in `si-settemp-diagnosis.md`.

## Final executable and output checks

Release flags: `-O3 -DNDEBUG`. The build cache has `RECON_BISECT=ON`; these executions are standalone with preload, Frida and replacement-library variables unset. Binary identity, dependencies and link commands are retained in `latest-build-identity.txt`.

- Vendor SHA256: `6b5f30b801b08012dd846b339c4e4275502c5d1ee526420c4be315623d178464`.
- Final local SHA256: `d223681b488443d6361471cd22a621f4be94827ee6d8798e665fa73c1e115ebc`.

| Check | Observed result |
|---|---|
| Local thermal stage vs vendor thermal | Timestamp-excluded byte-exact; 5,397,818 bytes |
| Local thermal output mapped into local mechanics vs vendor chain | Timestamp-excluded byte-exact; 39,221,879 bytes |
| Same-input one-step mechanics | Timestamp-excluded byte-exact; 1,012 field groups, topology, attributes and all 459 saved PDB keys/values match |
| Four 0.25 s steps | Timestamp-excluded byte-exact |
| Omitted starting temperature | Timestamp-excluded byte-exact |
| Uniform 400 K target | Timestamp-excluded byte-exact |
| Catch two parameter errors, then valid four-step solve | Exact catch code/message/errorInfo and timestamp-excluded byte-exact result |
| Conflicting `t.final` and `t.final.profile` | Exact diagnostic, exit 1 |
| Profile without `time` | Exact diagnostic, exit 1 |
| Missing target field | Exit 1; fatal diagnostic exact after normalizing only its actual PID; failure footer exact |
| SI SetTemp and power-density unit probes | Six argument probes, repeated setting/history fields and `mW/cm3` conversion match; final file timestamp-excluded byte-exact |

Raw file hashes differ. The comparator parses HDF5 v1 object headers and excludes only the four-byte seconds values of object-time messages: 463 fields in the thermal file and 1,086 in the coupled file. It verifies matching timestamp locations, file size and every remaining byte. No tolerance was widened and no output file was changed.

For the original package case, maximum temperature is **489.456443930281 K**; one-step maximum displacement is **0.0023671581775702812 cm** (23.6715817757 micrometres); maximum von Mises stress is **1.1055737403071117e10 dyn/cm2** (1.105573740 GPa). Four-step maximum displacement is **0.002368891480417139 cm** in both programs.

The same-input mechanics tests use the validated vendor thermal field to isolate coupling behavior. The separate final end-to-end test uses the **local** thermal field; both comparisons are retained.

## Mapping and thermal strain

The final local executable and vendor perform four matching temperature mappings, with identical field names, duration, time steps and sampled values across seven solid materials:

`T = T_initial + (T_final - T_initial) * (time + dt) / duration`.

For one active Copper node, the mapped temperatures are 336.3137249201055, 372.62744984021106, 408.9411747603166 and 445.2548996804221 K, starting from 300 K.

A bounded probe captures one Copper volume element after each mapping. Temperature, expansion coefficient, function arguments and all six strain components match exactly. In the exercised small-deformation path, the thermal contribution is **input strain minus returned strain**, because the function subtracts thermal eigenstrain:

`Delta epsilon_thermal = alpha * (T_current - T_previous)`

in each of the three normal components, with zero shear. With `alpha = 1.775e-5`, each sampled increment is approximately `6.857237672692e-4`, and the exact floating-point calculation agrees in all four steps. This is a representative-element trace, not an all-integration-point proof. The probe output also matches the unprobed vendor output after timestamp exclusion.

Both programs read the structure once and prepare one ramp. `ReadModifiedParams` is unhit on the valid `!pdb` path. Vendor AddStep has an out-of-line call; local appends inline, verified through disassembly and completed ramp state. Unused storage-slot observations from the first probe were superseded by actual active-node/dataIndex sampling.

## Regression status

The final all-target Release build succeeded. Final regression results are recorded in `product-gated-regressions/` and the machine-readable `product-gated-verification-summary.json`.

| Gate | Result |
|---|---|
| SI cantilever and inverter | PASS |
| Minimum regression | 6/6 PASS |
| Transform | Syntax/parameter checks and 18 formal outputs PASS |
| Structure import | 8/8 PASS |
| Full CTest | 24/34 PASS |
| `git diff --check` | PASS |

CTest has the same ten failing test names and failure classes as the earlier thermal and coupling checkpoints: mesh lifecycle, brick-to-tetra boundary collection, doping invalid free, deposition license values, five ICWB prerequisite failures, and ICWB write-all build/fixture issues. No pristine-HEAD baseline was rebuilt, so the report does not assert that every failure predates all changes. These broader failures are not presented as passes.

## Reproduction and evidence

Runs were serialized under `/tmp/geo3d-sinterconnect-heavy.lock`; product/GDB runs used CPU 4 and one OpenMP/MKL thread, a 6 GiB virtual-memory limit and bounded timeouts. Builds used CPUs 2-3 and two jobs. VM swappiness remains restored to 30. This recovery validation does not supersede the separately recorded performance benchmark.

Key evidence under the VM recovery directory:

- `product-gated-verification-summary.json`, `latest-build-identity.txt`, `recovery.patch`.
- `certified-v3-matrix-comparison.json`, `certified-v3-catch-diagnostics.json`, `certified-v3-*-timestamp-proof.json`.
- `e2e-v3-thermal-comparison.json`, `e2e-v3-mechanics-comparison.json`, `settemp-unit-v3-comparison.json`.
- `strain-vendor/execution.json`, `strain-v3-local/execution.json`, `strain-v3-timestamp-proof.json`.
- `si-settemp-diagnosis.md`, `pdb-gate-diagnosis.md`, `solve-error-diagnosis.md`, `fatal-profile-diagnosis.md`.
- `build-si-settemp-gate.log`, `product-gated-regressions/`.

Fresh-run recipes are in `run-certified-e2e-v3.sh`, `run-certified-v3-profile-matrix.sh`, `run-profile-strain-v3.sh`, and `run-settemp-unit-v3.sh`. Use new evidence-directory names for reruns to preserve the retained results. Compare with the structural timestamp comparator and assert its JSON result; that comparator alone does not signal a mismatch through its process exit code.

Unverified scope includes transient heat solving, nonlinear materials, contact, shells, electrical coupling, parallel solves, other package parameter nodes and complete stdout/stderr identity.



