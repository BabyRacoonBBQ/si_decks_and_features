from pathlib import Path
r=Path('/home/mozztcad/geo3d')
p=r/'src/abi/floops/floops/SetTemp_tcl.cpp';s=p.read_text();assert 'namespace sinterconnect' not in s
s=s.replace('#include "abi/floops/floops/FieldServer.h"','#include "abi/floops/floops/FieldServer.h"\n#include "abi/floops/floops/FLPS.h"\n#include "abi/floops/floops/StructureManagerParams.h"')
s+='''

namespace sinterconnect {

// SI W-2024.09-SP1 SetTempT_tcl @0x12087e0. This command initializes
// spatial temperature history and does not persist a process SetTemp command.
int SetTempT_tcl(int argc, char** argv, pdblib::ParamParse& parser)
{
    floops::_globalPool->globalSteps->pushCommand();
    for (int index = 1; index < argc; ++index) {
        if (std::strcmp(argv[index], VOF_STR("parameters")) == 0 ||
            std::strcmp(argv[index], VOF_STR("editor.syntax")) == 0 ||
            std::strcmp(argv[index], VOF_STR("run.only")) == 0) {
            return TCL_OK;
        }
    }
    if (argc != 2) {
        parser.Interpreter()->AppendResult(
            VOF_STR("SetTemp requires 1 arguments"), nullptr);
        return TCL_ERROR;
    }
    auto* const temperature = new pdblib::UserParamFloat(
        VOF_STATIC_STR("temperature"), 26.844, pdblib::Unit::Temperature, "C");
    parser.Append(temperature);
    std::string argument = VOF_STR("temperature=");
    argument += argv[1];
    char* arguments[] = {argv[0], argument.data()};
    parser.Clear();
    const int result = parser.Parser(2, arguments, false, pdblib::UserParam::Float);
    if (result != TCL_OK || pdblib::TclExecution::executionOff()) {
        return result;
    }
    auto& simulation = floops::globalSimObject();
    if (simulation.fieldServer->MaxNodes() == 0) {
        FLPS_warning(VOF_STR("Warning: No grid defined, SetTemp command cannot set local temperatures"));
    }
    const double temperatureK = temperature->FloatValue();
    const double temperatureC = temperatureK - 273.156;
    floops::StructureManagerParams update(
        pdblib::pdbgetBoolean(simulation.interpreter->interpreter,
            VOF_STR("Grid"), VOF_STR("Adaptive"), pdblib::PDB0));
    update.setUpdateName(VOF_STR("Setting temperature"));
    floops::_globalPool->structureManager->updateFieldServer(update);
    floops::FieldServer::copyTempFields(simulation.fieldServer,
        VOF_STATIC_STR("Temperature"), VOF_STATIC_STR("PrevTemperature"),
        temperatureK, temperatureK);
    floops::FieldServer::copyTempFields(simulation.fieldServer,
        VOF_STATIC_STR("Temperature"), VOF_STATIC_STR("InitTemperature"),
        temperatureK, temperatureK);
    floops::FieldServer::setGlobalTempC(simulation.fieldServer, temperatureC);
    return result;
}

}  // namespace sinterconnect
'''
p.write_text(s)
p=r/'src/abi/sprocess/sprocess/SProcessCmdUtil.cpp';s=p.read_text();s=s.replace('int SetTemp_tcl(int argc, char** argv, pdblib::ParamParse& parser);','int SetTemp_tcl(int argc, char** argv, pdblib::ParamParse& parser);\nnamespace sinterconnect {\nint SetTempT_tcl(int argc, char** argv, pdblib::ParamParse& parser);\n}')
s=s.replace('void SProcessCmdUtil::installCsseMechanicsCommands() {','void SProcessCmdUtil::installCsseMechanicsCommands() {\n    commands_[VOF_STATIC_STR("SetTemp")] = &sinterconnect::SetTempT_tcl;\n    commands_[VOF_STATIC_STR("settemp")] = &sinterconnect::SetTempT_tcl;')
p.write_text(s)
