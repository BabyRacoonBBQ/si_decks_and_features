from pathlib import Path
import json,re,subprocess
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
py='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3'
summary={}
refs={'package':r.parent/'demo-coupled-vendor','multistep':r/'multistep-vendor','implicit':r/'implicit-vendor','uniform':r/'uniform-vendor','catch':r/'catch-recovery-vendor'}
for label,a in refs.items():
 b=r/('verified-'+label+'-local')
 if not (b/'exit.txt').exists():summary[label]={'pending':True};continue
 out=r/('verified-'+label+'-timestamp-proof.json')
 subprocess.run([py,str(r/'verify-profile-timestamps.py'),str(a/'result_sis.tdr'),str(b/'result_sis.tdr'),str(out)],check=True,stdout=subprocess.DEVNULL)
 x=json.loads(out.read_text());summary[label]={k:x[k] for k in ['reference_sha256','candidate_sha256','sizes','raw_differences','remaining_differences','timestamp_excluded_byte_exact']}
for label in ['missing','conflict','no-time']:
 pair={}
 for kind,d in [('vendor',r/(label+'-vendor')),('local',r/('verified-'+label+'-local'))]:
  if not (d/'exit.txt').exists():pair[kind]={'pending':True};continue
  s=(d/'stderr.log').read_text(errors='replace')
  if label=='missing':
   start=s.index('\x1b[1m\n** Error **');end=s.index('Command exited',start)
   body=s[start:end];body=re.sub(r'Internal error \d+ !','Internal error <PID> !',body)
  else:
   marker='temp.ramp parameters ' if label=='conflict' else '"t.final.profile" requires time.'
   start=s.index(marker);end=s.index('Command exited',start);body=s[start:end]
  pair[kind]={'exit':(d/'exit.txt').read_text().strip(),'diagnostic':body}
 pair['equal']=pair.get('vendor')==pair.get('local')
 summary[label]=pair
(r/'verified-matrix-comparison.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
