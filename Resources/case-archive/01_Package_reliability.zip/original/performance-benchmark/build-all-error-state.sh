#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
cd /home/mozztcad/geo3d
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 600 9
env -u LD_LIBRARY_PATH taskset -c 2,3 cmake --build build -j2 > "$r/build-all-error-state.log" 2>&1
sha256sum build/sinterconnect_run build/geo_run build/libbrep_recon.so > "$r/post-error-build.sha256"
git diff --check
printf 'BUILD_ALL_OK\n'
