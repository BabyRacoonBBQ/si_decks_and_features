# Thermomechanical continuation and recovery limits

The vendor completes the package thermomechanical continuation. The local Release executable reproduces its input thermal fields exactly, but **does not yet complete the temperature-profile-to-mechanics path**.

## Demonstration model

The demonstration uses the same package geometry, seven solid materials, 5 W heat input, conduction, convection and radiation as the performance case, with a smaller mesh to fit the VM:

| Item | Heat-transfer benchmark | Thermomechanical demonstration |
|---|---:|---:|
| Spatial vertices | 107,792 | 17,171 |
| Material nodes | 129,399 | 24,389 |
| Tetrahedral volume elements, including Gas | 593,869 | 88,813 |
| Thermal peak temperature | 489.518175350140 K | 489.456443930281 K |

The coarse thermal outputs match exactly in all 354 compared field groups, compared topology arrays and field attributes. The peak differs from the finer mesh by approximately 0.062 K; this single comparison is not a formal mesh-convergence study.

The mechanical continuation uses the package example's linear-elastic material parameter file `mp.cmd`, first-order elements and a clamped bottom (`dx=dy=dz=0`). Its temperature reference is 300 K. One quasi-static loading increment applies the spatially varying final thermal field. Temperature-dependent material behavior and thermal strain follow the selected vendor material models; this demonstration does not enable the example's optional nonlinear material or crack branches.

```tcl
init tdr=../demo-thermal-vendor/result_sis.tdr !load.commands !pdb
select z=Temperature name=FinalTemp store
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
mode mechanics
solve temperature=26.844<C> time=1.0<s> init=1.0<s> maxstep=1.0<s> t.final.profile=FinalTemp info=2
```

This is one-way sequential coupling: the solved temperature field is supplied to mechanics; the thermal equation is not solved again in the mechanical step. Both candidate binaries receive the same vendor thermal result to isolate the mechanics/profile-transfer comparison.

## Vendor result

- Completed with exit status 0.
- Native inclusive mechanical solve: 6.91 s; this is a demonstration run, not a repeated mechanics performance benchmark.
- Maximum displacement magnitude: **23.6715817757 µm**. The native `Displacement` field stores cm; the derived scalar is `sqrt(Displacement_x^2+Displacement_y^2+Displacement_z^2)`. Its generic scalar metadata has no length unit, so the conversion is taken from the original displacement components.
- Peak `MisesStressMax`: approximately **1.10557 GPa**, using native `dyn*cm^-2` units. This is the idealized clamped, linear-material model's computed value, not a package qualification result.
- Peak RSS: 1,371,064 KiB.

The finer mesh was tried first. The vendor requested an allocation beyond the imposed 6 GiB virtual-memory limit and exited with `Cannot allocate memory for integer array, size = 164102144`. That failed attempt is retained in `coupled-vendor/` and excluded from successful results.

## Local limitation

The matching local continuation exits before mechanics with `Syntax error in temp_ramp` and no result file. The source has both a process-specific ramp command path and an explicit `TCL_ERROR` for `t.final.profile` in `floops::Temp_Ramp::setParams`. This requires separate recovery of temperature-profile handling; removing the guard alone would not implement the missing behavior.

Execution parity for this continuation: **DIFF at the command/ramp preparation boundary; detailed call-tree parity unverified**. Mechanical field parity: **not verified** because no local result is produced. No additional source change was made to pretend this path succeeds.

The completed source repair covers the steady thermal benchmark, not this temperature-profile continuation, transient thermal ramps, or simultaneous multiphysics modes.

## Regression status

The existing SInterconnect regression (`scripts/verify_si.sh`, cantilever and inverter) passed. The repository's `scripts/verify.sh --min` passed **6/6** with freshly generated vendor baselines. `scripts/verify_transform.sh --no-build` passed its SyntaxCheck probes, formal parameter probes and **18/18** TDR16 cases (ignoring only HDF5 object timestamps). `scripts/verify_init_struct.sh --no-build` passed **8/8**, including its two CSSE cases. `git diff --check` passed.

The full Release build succeeded. Full CTest passed **24/34**, with **10 unresolved failures**; see [ctest-failures.md](ctest-failures.md) for each failure and its diagnostic limits. This work is not presented as an all-green repository validation. Raw logs are in `thermal-recovery/`.

## Artifacts

VM root: `/home/mozztcad/tmp/package-benchmark-20261010/`.

- `demo-thermal-{vendor,local}/`: thermal decks, logs and output fields.
- `demo-coupled-vendor/`: working vendor mechanical deck, `settings.cmd`, `mp.cmd`, result and logs.
- `demo-coupled-local/`: identical input deck and retained failure logs.
- `field-audit-summary.json`: every measured thermal pair and the missing local mechanical output.
- `demo-mechanics-fields.json`: native stress/displacement field ranges and unit attributes.
- `thermal-recovery/`: repair patch and regression logs.
