from pathlib import Path
import tarfile,hashlib,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
files=set()
for pattern in ['*.md','*.json','*.py','*.sh','*.gdb','*.txt']:
    files.update(r.glob(pattern))
for dirname in ['mesh-package-final','mesh-roof','package-vendor','demo-thermal-vendor','demo-thermal-local','demo-coupled-vendor','demo-coupled-local']:
    d=r/dirname
    files.update(p for p in d.iterdir() if p.is_file() and p.suffix in ['.cmd','.scm','.tdr','.json','.txt','.log','.sha256'])
for prefix in ['detailed','sw0']:
    for rep in range(1,4):
        for kind in ['vendor','local']:
            d=r/f'{prefix}-r{rep}-{kind}'
            if d.exists():files.update(p for p in d.iterdir() if p.is_file() and (p.suffix!='.tdr' or (rep==3 and prefix=='sw0')))
for p in (r/'thermal-recovery').rglob('*'):
    if p.is_file() and p.suffix in ['.log','.txt','.sha256','.patch','.asm','.gdb','.json','.cmd']:files.add(p)
out=r/'package-benchmark-evidence.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=3) as archive:
    for p in sorted(files):archive.add(p,arcname=str(p.relative_to(r)),recursive=False)
manifest={'archive':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'files':len(files)}
(r/'package-benchmark-evidence.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
