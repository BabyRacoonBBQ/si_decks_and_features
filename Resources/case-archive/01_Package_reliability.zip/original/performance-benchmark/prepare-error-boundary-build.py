from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(r/'build-all-error-state.sh').read_text().replace('build-all-error-state.log','build-all-error-boundaries.log').replace('post-error-build.sha256','post-error-boundaries-build.sha256')
(r/'build-all-error-boundaries.sh').write_text(s)
