#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
bash "$r/run-profile-execution-v2.sh"
bash "$r/run-profile-case-queued.sh" vendor catch-recovery > "$r/catch-vendor-run.log" 2>&1
bash "$r/run-profile-case-queued.sh" local catch-recovery > "$r/catch-local-run.log" 2>&1
bash "$r/run-thermomechanical-regressions.sh"
