#!/bin/bash
set -u
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
python=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3
for label in multistep implicit uniform missing conflict no-time init-state; do
 bash "$r/run-profile-case.sh" local "final-$label" > "$r/final-$label-run.log" 2>&1
 echo "$label local exit=$?"
 if [ -f "$r/final-$label-local/result_sis.tdr" ]; then
  PYTHONNOUSERSITE=1 "$python" "$r/verify-profile-timestamps.py" "$r/$label-vendor/result_sis.tdr" "$r/final-$label-local/result_sis.tdr" "$r/final-$label-timestamp-proof.json" > "$r/final-$label-byte-check.log" 2>&1
  echo "$label byte_checker_exit=$?"
 fi
 done
