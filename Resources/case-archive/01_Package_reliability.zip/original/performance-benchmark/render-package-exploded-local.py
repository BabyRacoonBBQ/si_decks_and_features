"""Exploded display of the local sinterconnect_run package result."""
from pathlib import Path
src = Path(__file__).with_name('render-package-exploded.py').read_text()
src = src.replace("with_name('render-package-animation.py')", "with_name('render-package-animation-local.py')")
src = src.replace("OUT=ROOT/'exploded-visualization';OUT.mkdir(exist_ok=True)", "OUT=Path(__file__).resolve().parent/'reliability-figures-local';OUT.mkdir(parents=True,exist_ok=True)")
exec(compile(src, str(Path(__file__).with_name('render-package-exploded.py')), 'exec'), globals(), globals())
