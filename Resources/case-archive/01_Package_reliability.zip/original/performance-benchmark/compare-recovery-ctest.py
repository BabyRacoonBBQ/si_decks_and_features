from pathlib import Path
import re,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
data={}
for label,path in [('thermal_checkpoint',r/'thermal-recovery/ctest.log'),('thermomechanical',r/'thermomechanical-recovery/regressions/ctest.log')]:
 s=path.read_text(errors='replace')
 failed=s.split('The following tests FAILED:')[-1]
 data[label]=re.findall(r'^\s*(\d+) - ([^\n]+)',failed,re.M)
data['same_failure_set']=data['thermal_checkpoint']==data['thermomechanical']
data['qualification']='Earlier thermal-recovery checkpoint, not pristine HEAD; unchanged failure set does not certify baseline causality.'
(r/'thermomechanical-recovery/regressions/ctest-comparison.json').write_text(json.dumps(data,indent=2))
print(json.dumps(data,indent=2))
