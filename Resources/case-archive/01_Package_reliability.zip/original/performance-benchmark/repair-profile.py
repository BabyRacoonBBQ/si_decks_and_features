from pathlib import Path
root=Path('/home/mozztcad/geo3d')
e=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
(e/'diagnosis_report.md').write_text('''# Temperature-profile diagnosis before repair
Execution parity: DIFF within Temp_Ramp::setParams / AddStep scope.
First proven divergence: local setParams returns TCL_ERROR (1) for the approved profile deck; vendor returns TCL_OK (0) and appends a one-second AnnealStep.
TDR parity: unverified for this diagnostic run, which intentionally stops after parsing.
Repair performed: NO during diagnosis. Product source modified: NO during diagnosis (four earlier thermal repair files were already dirty).

Scope: /home/mozztcad/geo3d main at 4140959ce963437b066e36dcc47703ac609881a1; sinterconnect vendor and Release sinterconnect_run. Input/executable SHA256: probe-vendor/identities.sha256 and probe-local/identities.sha256. Matched package mesh and vendor thermal field; 1 thread, CPU 4, shared heavy lock, no preload. GDB scripts stop deliberately on parser return, before solving.

Vendor parser 0x17608e0 appends rate=0, duration=1, start=0, start/end temperature=26.843999999999994 C; options temperature=1 and t.final.profile=1. Local rejects before AddStep. Stacks in both probe.log files show SolveCmd -> setAnnealStep -> setParams. All declared breakpoints resolve; the optional vendor temperature-rewrite branch is not hit with explicit temperature. Two initial observer attempts omitted deck arguments and were terminated; corrected script explicitly passes case.cmd. These attempts are not product failures.

Static evidence: setParams.asm profile option storage at 0x1760ce7..0x1760e4e. When initial temperature is omitted, branch 0x1762728..0x1762b18 obtains global temperature C, formats scientific precision 20, invokes UserParam SetValue, and clears specified flag. With explicit temperature, branch 0x1761860 bypasses this rewrite.
SetTemp.asm at 0x17494b4..0x17494cc passes final field (+0x6e0) as first RealData argument and initial field (+0x6d8) second; local source reverses these. FieldServer computes initial+(final-initial)*(time+dt)/duration.

Recommendation: restore profile parsing semantics and correct DiffSolver interpolation operand order; then probe repaired parsing and compare full package solution and discriminating time histories. Global profile rewrite and full solver behavior remain unverified dynamically.

Artifacts: this diagnosis_report.md; setParams.asm; SetTemp.asm; profile-probe.py; run-profile-probe.sh; probe-{vendor,local}/probe.log, probe-stdout.log, probe-stderr.log, identities.sha256.
Mutation ledger: only temporary evidence created; no build, repository mutation, or vendor mutation during diagnosis.
''')
p=root/'src/abi/floops/floops/Temp_Ramp.cpp'
s=p.read_text()
old='''    if (parser.isSpecified(VOF_STR("t.final.profile"))) {
        return TCL_ERROR;
    }

'''
assert s.count(old)==1
s=s.replace(old,'    const bool profileSpecified = parser.isSpecified(VOF_STR("t.final.profile"));\n\n',1)
anchor='''    const double parsedTemperatureC =
        parser.FloatLookup(VOF_STR("temperature")) - 273.156;'''
replacement='''    // SI W-2024.09-SP1 setParams @0x1762728..0x1762b18: an
    // omitted initial temperature uses the current global temperature.
    // Keep it implicit after SetValue, so the existing initial field is
    // preserved rather than replaced by an explicitly prescribed scalar.
    if (profileSpecified && !temperatureSpecified) {
        pdblib::UserParam* const temperatureParam =
            parser.GetParam(VOF_STR("temperature"));
        std::stringstream value;
        value << std::scientific << std::setprecision(20)
              << _globalPool->globalSim->fieldServer->getGlobalTempC();
        temperatureParam->SetValue(*parser.Interpreter(), value.str().c_str());
        temperatureParam->ClearSpecified();
    }

'''+anchor
assert s.count(anchor)==1
s=s.replace(anchor,replacement,1)
s=s.replace('step->options_[VOF_STATIC_STR("t.final.profile")] = false;', 'step->options_[VOF_STATIC_STR("t.final.profile")] = profileSpecified;',1)
p.write_text(s)
p=root/'src/abi/floops/floops/DiffSolver.cpp'
s=p.read_text()
old='fieldServer->setTempKField(initialTemperatureData_, finalTemperatureData_, step->timeSeconds_, time, dt);'
new='''// SI W-2024.09-SP1 @0x17494b4: final (+0x6e0), then
            // initial (+0x6d8), for initial + (final-initial)*fraction.
            fieldServer->setTempKField(finalTemperatureData_, initialTemperatureData_, step->timeSeconds_, time, dt);'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
