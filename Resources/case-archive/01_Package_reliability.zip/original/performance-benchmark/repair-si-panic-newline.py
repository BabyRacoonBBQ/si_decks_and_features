from pathlib import Path
r=Path('/home/mozztcad/geo3d')
p=r/'src/abi/floops/floops/FLPS.cpp';s=p.read_text()
a='VOF_STATIC_STR(" ... aborting\\n\\n"), true);'
b='VOF_STATIC_STR(" ... aborting\\n"), true);'
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
e=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(e/'build-all-error-boundaries-v2.sh').read_text().replace('build-all-error-boundaries-v2.log','build-final.log').replace('post-error-boundaries-build.sha256','final-build.sha256')
(e/'build-final.sh').write_text(s)
