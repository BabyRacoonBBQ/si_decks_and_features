from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
for label in ['package','multistep','implicit','uniform','catch','missing','conflict','no-time']:
 d=r/('certified-'+label+'-local');d.mkdir(exist_ok=True)
 for f in ['case.cmd','settings.cmd','mp.cmd','datexcodes.txt']:shutil.copy2(r/('verified-'+label+'-local')/f,d/f)
for src,dst in [('run-verified-profile-matrix.sh','run-certified-profile-matrix.sh'),('compare-verified-matrix.py','compare-certified-matrix.py')]:
 s=(r/src).read_text().replace('verified-','certified-');(r/dst).write_text(s)
s=(r/'run-thermomechanical-regressions.sh').read_text().replace('/thermomechanical-recovery/regressions','/thermomechanical-recovery/final-regressions')
(r/'run-final-regressions.sh').write_text(s)
