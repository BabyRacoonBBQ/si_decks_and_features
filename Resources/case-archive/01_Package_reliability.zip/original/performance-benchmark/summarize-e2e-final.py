from pathlib import Path
import json,subprocess,math,hashlib
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
py='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3'
sha=hashlib.sha256(Path('/home/mozztcad/geo3d/build/sinterconnect_run').read_bytes()).hexdigest()
s={'local_release_sha256':sha,'vendor_sha256':'6b5f30b801b08012dd846b339c4e4275502c5d1ee526420c4be315623d178464','scope':'Approved adapted package, eight discriminating mechanics scenarios, and local thermal-to-mechanics end-to-end chain. Not whole-program equivalence.'}
s['matrix']=json.loads((r/'certified-v2-matrix-comparison.json').read_text())
assert len(s['matrix'])==8
for label,v in s['matrix'].items():
 assert v.get('timestamp_excluded_byte_exact',v.get('equal',False))
 assert (r/('certified-v2-'+label+'-local')/'identities.sha256').read_text().split()[0]==sha
s['end_to_end']={}
for label,d in [('thermal',r.parent/'certified-e2e-v2-thermal-local'),('mechanics',r/'certified-e2e-v2-mechanics-local')]:
 z=json.loads((r/('e2e-v2-'+label+'-comparison.json')).read_text());assert z['timestamp_excluded_byte_exact'];assert (d/'identities.sha256').read_text().split()[0]==sha
 s['end_to_end'][label]={k:v for k,v in z.items() if not k.endswith('_timestamps')}
a=json.loads((r/'strain-vendor/execution.json').read_text());b=json.loads((r/'strain-v2-local/execution.json').read_text());assert (r/'strain-v2-local/identities.sha256').read_text().split()[0]==sha
keys=['final','initial','duration','time','dt','final_sample','initial_sample','output_sample','returned']
am=[e for e in a['events'] if e['kind']=='mapping'];bm=[e for e in b['events'] if e['kind']=='mapping'];assert len(am)==len(bm)==4;assert all(all(u.get(k)==v.get(k) for k in keys) for u,v in zip(am,bm))
def strains(raw):
 out=[]
 for e in raw['events']:
  if e['kind']!='thermal_strain':continue
  e={k:v for k,v in e.items() if k!='stack'};e['thermal_strain_contribution']=[x-y for x,y in zip(e['strain_input'],e['strain_output'])]
  expected=e['alpha_base']*(e['current_temperature']-e['previous_temperature']);assert e['thermal_strain_contribution']==[expected]*3+[0.0]*3;out.append(e)
 return out
at,bt=strains(a),strains(b);assert at==bt and [e['mapping_epoch'] for e in at]==[1,2,3,4]
s['mapping_exact_four_steps']=True;s['thermal_strain']={'exact':True,'coverage':'One Copper volume element after each of four mapped-temperature updates; no pre-mapping hit. Not every integration point.','formula':'thermal strain increment = input minus output = alpha * (T_current - T_previous) in each normal component; zero shear','observations':bt}
out=r/'strain-v2-timestamp-proof.json';subprocess.run([py,str(r/'verify-profile-timestamps.py'),str(r/'multistep-vendor/result_sis.tdr'),str(r/'strain-v2-local/result_sis.tdr'),str(out)],check=True,stdout=subprocess.DEVNULL);z=json.loads(out.read_text());assert z['timestamp_excluded_byte_exact'];s['probe_output_timestamp_excluded_byte_exact']=True
p=r/'e2e-verification-summary.json';p.write_text(json.dumps(s,indent=2));print('Eight scenarios, both end-to-end stages, final-build mapping and strain: PASS',sha)
