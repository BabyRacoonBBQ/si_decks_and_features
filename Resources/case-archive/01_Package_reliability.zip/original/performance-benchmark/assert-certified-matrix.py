import json
from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
x=json.loads((r/'certified-matrix-comparison.json').read_text())
for k,v in x.items():
 ok=v.get('timestamp_excluded_byte_exact',v.get('equal',False));print(k,ok)
 assert ok
assert len(x)==8
# Check the fatal warning footer separately from dynamic timing text.
a=(r/'missing-vendor/stdout.log').read_text(errors='replace');b=(r/'certified-missing-local/stdout.log').read_text(errors='replace')
marker='Simulation failed!'
assert a[a.index(marker):]==b[b.index(marker):]
print('fatal failure footer exact')
# Preserve complete catch diagnostics and errorInfo on the final executable.
import re
p={}
for kind,d in [('vendor','catch-recovery-vendor'),('local','certified-catch-local')]:
 s=(r/d/'stdout.log').read_text(errors='replace')
 p[kind]={'messages':[line for line in s.splitlines() if line.startswith('PROBE_ERROR ')], 'error_info':dict(re.findall(r'PROBE_ERRORINFO (\w+) <(.*?)>\n',s,re.S))}
assert p['vendor']==p['local'] and len(p['vendor']['messages'])==2
(r/'certified-catch-diagnostics.json').write_text(json.dumps(p,indent=2))
print('catch code, message, errorInfo exact')
