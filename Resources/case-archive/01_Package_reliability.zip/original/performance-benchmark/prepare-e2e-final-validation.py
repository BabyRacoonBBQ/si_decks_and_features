from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
for label in ['package','multistep','implicit','uniform','catch','missing','conflict','no-time']:
 d=r/('certified-v2-'+label+'-local');d.mkdir()
 for name in ['case.cmd','settings.cmd','mp.cmd','datexcodes.txt']:shutil.copyfile(r/('certified-'+label+'-local')/name,d/name)
for name in ['run-certified-profile-matrix.sh','compare-certified-matrix.py','assert-certified-matrix.py']:
 s=(r/name).read_text().replace('certified-','certified-v2-')
 (r/name.replace('certified-','certified-v2-')).write_text(s)
s=(r/'run-final-regressions.sh').read_text().replace('/final-regressions','/e2e-final-regressions')
(r/'run-e2e-final-regressions.sh').write_text(s)
s=(r/'run-profile-strain.sh').read_text().replace('for kind in vendor local','for kind in local').replace('dir=$r/strain-$kind','dir=$r/strain-v2-$kind')
(r/'run-profile-strain-v2.sh').write_text(s)
