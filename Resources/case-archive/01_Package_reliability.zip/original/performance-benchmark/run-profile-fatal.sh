#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 600 9
ulimit -v 6291456
for kind in vendor local; do
 dir=$r/fatal-boundary-$kind
 mkdir -p "$dir"
 cp "$r/missing-vendor/"{case.cmd,settings.cmd,mp.cmd,datexcodes.txt} "$dir/"
 cd "$dir"
 binary=/home/mozztcad/geo3d/build/sinterconnect_run
 if [ "$kind" = vendor ]; then binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect;fi
 sha256sum "$binary" case.cmd "$r/probe-profile-fatal.py" > identities.sha256
 timeout -k 10 200 taskset -c 4 gdb -q -batch -ex 'set pagination off' -ex 'set confirm off' -ex 'set breakpoint pending off' -ex "source $r/probe-profile-fatal.py" --args "$binary" > probe.log 2>&1
 test -f fatal-boundary.json
 cat fatal-boundary.json
 done

