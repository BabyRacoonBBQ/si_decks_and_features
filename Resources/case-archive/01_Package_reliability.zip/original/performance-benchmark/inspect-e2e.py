import json,h5py
from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010');rec=r/'thermomechanical-recovery'
for mode,ref,loc in [('thermal',r/'demo-thermal-vendor/result_sis.tdr',r/'certified-e2e-thermal-local/result_sis.tdr'),('mechanics',r/'demo-coupled-vendor/result_sis.tdr',rec/'certified-e2e-mechanics-local/result_sis.tdr')]:
 def tags(p):
  with h5py.File(p) as f:
   return {str(v.attrs['key']):str(v.attrs.get('value')) for v in f['collection/tag_group_0/tag_group_0'].values()}
 a,b=tags(ref),tags(loc)
 j={'missing':{k:a[k] for k in a.keys()-b.keys()},'extra':{k:b[k] for k in b.keys()-a.keys()},'changed':{k:[a[k],b[k]] for k in a.keys()&b.keys() if a[k]!=b[k]}}
 print(mode,json.dumps(j,indent=2));(rec/('e2e-'+mode+'-tags.json')).write_text(json.dumps(j,indent=2))
 m=json.loads((rec/('e2e-'+mode+'-metadata.json')).read_text());print('attrs without name/quantity', [x for x in m['attributes'] if x['attribute'] not in ['name','quantity']][:15]);print('datasets',len(m['datasets']),m['datasets'][:5])
