from pathlib import Path
import json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
a=json.loads((r/'execution-v2-vendor/execution.json').read_text());b=json.loads((r/'execution-v2-local/execution.json').read_text())
ma=[x for x in a['events'] if x['kind']=='mapping'];mb=[x for x in b['events'] if x['kind']=='mapping']
keys=['final','initial','duration','time','dt','final_sample','initial_sample','output_sample','returned']
report={'vendor_counts':a['counts'],'local_counts':b['counts'],'mapping_count_equal':len(ma)==len(mb)==4,'mapping_events':[],'ramp_state_equal':next(e['created_ramp'] for e in a['events'] if e['kind']=='setParams')==next(e['created_ramp'] for e in b['events'] if e['kind']=='setParams'),'pdb_not_imported':a['counts'].get('readParameters',0)==b['counts'].get('readParameters',0)==0}
for x,y in zip(ma,mb):
 row={'step':x['ordinal'],'equal':all(x.get(k)==y.get(k) for k in keys),'differences':[k for k in keys if x.get(k)!=y.get(k)],'time':x['time'],'dt':x['dt'],'bulk_samples':{}}
 for name in ['Silicon','Copper','Copperline','Solder','Resin','SmearBeol','Aluminum']:
  vi=x['initial_sample'][name]['value'];vf=x['final_sample'][name]['value'];vo=x['output_sample'][name]['value'];fraction=(x['time']+x['dt'])/x['duration']
  row['bulk_samples'][name]={'initial':vi,'final':vf,'mapped':vo,'formula_abs_error':abs(vo-(vi+(vf-vi)*fraction))}
 report['mapping_events'].append(row)
report['covered_mapping_match']=report['mapping_count_equal'] and report['ramp_state_equal'] and report['pdb_not_imported'] and all(row['equal'] for row in report['mapping_events'])
report['AddStep_note']='Native out-of-line hit 1; local inlined append proved by setParams disassembly (count increment and pointer store), and the created ramp state is compared at setParams return. The out-of-line zero count is not a missing behavior.'
(r/'execution-v2-comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='mapping_events'},indent=2))
for row in report['mapping_events']:print('STEP',row['step'],row['equal'],'Copper',row['bulk_samples']['Copper'],'max_formula_error',max(z['formula_abs_error'] for z in row['bulk_samples'].values()))
