#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
for rep in 1 2 3; do
 order='vendor local'
 if [ "$rep" = 2 ]; then order='local vendor'; fi
 for kind in $order; do
  name=${BENCH_PREFIX:-bench}-r${rep}-${kind}
  mkdir -p "$root/$name"
  cp "$root/package-vendor/case.cmd" "$root/package-vendor/datexcodes.txt" "$root/$name/"
  echo "BENCH BEGIN $name"
  bash "$root/run-final-case.sh" "$name" "$kind"
  test "$(cat "$root/$name/timing-valid.txt")" = VALID_NO_VM_SWAP
  echo "BENCH COMPLETE $name"
 done
done
