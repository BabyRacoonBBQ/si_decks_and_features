from pathlib import Path
import json,math,subprocess
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
raw={k:json.loads((r/('strain-'+k)/'execution.json').read_text()) for k in ['vendor','local']}
records={k:[{key:v for key,v in e.items() if key!='stack'} for e in raw[k]['events'] if e['kind']=='thermal_strain'] for k in raw}
for k in records:
 assert records[k], 'no thermal strain observations '+k
 for e in records[k]:
  assert e['returned'] and all(math.isfinite(v) for v in e['strain_input']+e['strain_output'])
  e['thermal_strain_contribution']=[a-b for a,b in zip(e['strain_input'],e['strain_output'])]
x={'vendor':records['vendor'],'local':records['local'],'exact_equal':records['vendor']==records['local'],'nonzero_observed':any(any(v!=0 for v in e['thermal_strain_contribution']) for e in records['vendor']),'coverage':'First eligible computeThermalStrain call before mapping and after each mapped-field update; not every integration point. Strain contribution is input minus output in the exercised small-deformation path, not the full output buffer alone.'}
(r/'thermal-strain-comparison.json').write_text(json.dumps(x,indent=2));print(json.dumps(x,indent=2))
assert x['exact_equal'] and x['nonzero_observed']
keys=['final','initial','duration','time','dt','final_sample','initial_sample','output_sample','returned']
a=[e for e in raw['vendor']['events'] if e['kind']=='mapping'];b=[e for e in raw['local']['events'] if e['kind']=='mapping'];assert len(a)==len(b)==4
assert all(all(u.get(k)==v.get(k) for k in keys) for u,v in zip(a,b))
print('final-build four-step mapping: exact')
py='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3'
for label,ref in [('strain','strain-vendor'),('strain-observer-reference','multistep-vendor')]:
 out=r/(label+'-timestamp-proof.json')
 subprocess.run([py,str(r/'verify-profile-timestamps.py'),str(r/ref/'result_sis.tdr'),str(r/'strain-local/result_sis.tdr'),str(out)],check=True,stdout=subprocess.DEVNULL)
 z=json.loads(out.read_text());assert z['timestamp_excluded_byte_exact'];print(label,'timestamp-excluded byte-exact')
s=json.loads((r/'verification-summary.json').read_text());s['thermal_strain']=x;s['final_build_mapping_verified']=True
(r/'verification-summary.json').write_text(json.dumps(s,indent=2))
