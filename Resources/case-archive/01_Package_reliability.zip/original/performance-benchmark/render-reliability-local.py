"""Render archived reference fields; never runs or changes either solver."""
from pathlib import Path
import hashlib, json, html
import h5py
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'reliability-figures-local'
OUT.mkdir(exist_ok=True)
P = ROOT / 'slide-evidence/package-local/coupled-result_sis.tdr'
T = ROOT / 'slide-evidence/thermal-local/thermal-result_sis.tdr'
def decode(v): return v.decode() if isinstance(v, bytes) else str(v)
def fields(g):
    return {(int(o.attrs['region']),decode(o.attrs['name'])):o['values'][:]
            for o in g['state_0'].values() if 'values' in o and 'region' in o.attrs}
with h5py.File(P) as f, h5py.File(T) as tf:
    g=f['collection/geometry_0']; tg=tf['collection/geometry_0']
    raw=g['vertex'][:]; xyz=np.column_stack([raw[n] for n in ('x','y','z')])
    data=fields(g); thermal=fields(tg); regions=[]; shared={}; errors=[]
    volume=0; n_tets=0; n_nodes=0; profile_errors=[]
    for n,r in g.items():
        if not n.startswith('region_') or r.attrs.get('type')!=0: continue
        rid=int(n[7:]); mat=decode(r.attrs['material'])
        a=r['elements_0'][:].reshape(-1,5); assert np.all(a[:,0]==5)
        tet=a[:,1:]; ids=np.unique(tet); n_tets+=len(tet); n_nodes+=len(ids)
        temp=thermal[rid,'Temperature']; final=data[rid,'FinalTemp']; assert len(ids)==len(temp)
        profile_errors.append(float(np.max(np.abs(temp-final))))
        for i,t in zip(ids,temp) if mat!='Gas' else []:
            if int(i) in shared: errors.append(abs(t-shared[int(i)]))
            shared[int(i)]=t
        if mat=='Silicon':
            q=xyz[tet]; volume+=np.abs(np.linalg.det(q[:,1:]-q[:,0,None,:])).sum()/6
        if mat=='Gas': continue
        disp=data[rid,'Displacement'].reshape(-1,3)
        umag=np.linalg.norm(disp,axis=1)*1e4
        assert np.allclose(umag,data[rid,'DisplacementMagnitude']*1e4,rtol=1e-12,atol=1e-12)
        stress=data[rid,'MisesStressMax']*1e-10
        # Region surface triangles from exact tetrahedral connectivity.
        faces=np.sort(np.concatenate([tet[:,p] for p in ((0,1,2),(0,1,3),(0,2,3),(1,2,3))]),axis=1)
        faces,counts=np.unique(faces,axis=0,return_counts=True); faces=faces[counts==1]
        regions.append(dict(id=rid,name=decode(r.attrs['name']),material=mat,ids=ids,
                            faces=faces,temp=temp,u=umag,stress=stress))
    assert max(errors)<1e-8, 'Nodal indexing inconsistent across material interfaces'
    assert max(profile_errors)<1e-8, 'FinalTemp differs from thermal result'

# An orthographic isometric view of actual coordinates. Gas and resin are hidden
# for interior visibility; no geometry deformation or artificial field values.
def project(p):
    return np.column_stack((0.82*p[:,2]-0.58*p[:,1],
                            0.28*p[:,2]+0.39*p[:,1]+1.65*p[:,0]))
visible=[r for r in regions if r['material']!='Resin']
allids=np.unique(np.concatenate([r['ids'] for r in visible])); v=project(xyz[allids])
lo=v.min(0); hi=v.max(0); scale=min(640/(hi[0]-lo[0]),310/(hi[1]-lo[1]))
def screen(p):
    v=project(p); return (v-(lo+hi)/2)*scale+np.array([360,235])
palette=['#206d65','#b57741','#79529b','#6e8ca7','#ccae6b','#4876a2']
matcolors=dict(zip(['Silicon','Copper','Copperline','Solder','SmearBeol','Aluminum'],palette))
stops=np.array([[68,1,84],[59,82,139],[33,145,140],[94,201,98],[253,231,37]])
def color(t):
    q=np.clip(t,0,1)*4; i=min(int(q),3); c=stops[i]*(1-(q-i))+stops[i+1]*(q-i)
    return '#'+''.join(f'{int(x):02x}' for x in c)
def text(x,y,s,size=19,col='#172d43'):
    return f'<text x="{x}" y="{y}" font-family="Arial" font-size="{size}" fill="{col}">{html.escape(s)}</text>'
def marker(p,label,x,y):
    a=screen(np.array([p]))[0]
    return (f'<path d="M{x+12},{y+5} L{a[0]:.1f},{a[1]:.1f}" stroke="#172d43" stroke-width="2"/>'
            f'<circle cx="{x+12}" cy="{y}" r="15" fill="#172d43"/>'
            f'<text x="{x+12}" y="{y+6}" font-family="Arial" font-size="18" fill="white" text-anchor="middle">{label}</text>')
maxima={k:max(float(r[k].max()) for r in regions) for k in ('temp','u','stress')}
for mode,caption in [('mesh','Material interfaces · first-order tetrahedra'),('temp','Temperature T [K]'),('u','Displacement magnitude |u| [µm]'),('stress','Peak von Mises stress [GPa]')]:
    limit=(300,490) if mode=='temp' else ((0,24) if mode=='u' else (0,1.11))
    triangles=[]
    for r in visible:
        for face in r['faces']:
            pts=xyz[face]; xy=screen(pts)
            depth=np.mean(-pts[:,0]+0.22*pts[:,1]+0.15*pts[:,2])
            if mode=='mesh': fill=matcolors[r['material']]
            else:
                value=float(r[mode][np.searchsorted(r['ids'],face)].mean())
                fill=color((value-limit[0])/(limit[1]-limit[0]))
            poly=' '.join(f'{x:.2f},{y:.2f}' for x,y in xy)
            edge='#263d50' if mode=='mesh' else fill
            triangles.append((depth,f'<polygon points="{poly}" fill="{fill}" stroke="{edge}" stroke-width="{0.35 if mode=="mesh" else 0.4}"/>'))
    content=''.join(s for _,s in sorted(triangles,key=lambda t:t[0]))
    if mode=='mesh':
        for j,(mat,c) in enumerate(matcolors.items()):
            x=20+(j%3)*230;y=440+(j//3)*27
            content+=f'<rect x="{x}" y="{y-13}" width="14" height="14" fill="{c}"/>'+text(x+22,y,mat,18)
    else:
        for j in range(120): content+=f'<rect x="{130+j*3.8}" y="440" width="4" height="14" fill="{color(j/119)}"/>'
        content+=text(130,478,str(limit[0]),20)+text(560,478,str(limit[1]),20)
        content+=text(170,510,caption,21)
    if mode=='temp':
        si=next(r for r in visible if r['material']=='Silicon')
        content+=marker(xyz[si['ids']].mean(0),'1',280,90)
        resin=next(r for r in regions if r['material']=='Resin')
        a=xyz[resin['ids']].min(0); b=xyz[resin['ids']].max(0)
        roof=np.array([[a[0],a[1],a[2]],[a[0],b[1],a[2]],[a[0],b[1],b[2]],[a[0],a[1],b[2]]])
        points=' '.join(f'{x:.1f},{y:.1f}' for x,y in screen(roof))
        content+=f'<polygon points="{points}" fill="none" stroke="#a45b17" stroke-width="2" stroke-dasharray="7 5"/>'
        content+=marker(roof.mean(0),'2',80,80)
        side=(a+b)/2;side[1]=a[1]
        content+=marker(side,'3',615,350)
    if mode=='u':
        bottom=xyz[allids][np.argmax(xyz[allids,0])]
        content+=marker(bottom,'4',500,375)
    content+=text(20,35,'Gas + resin hidden to expose package interior',20,'#52677c')
    (OUT/f'{mode}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="720" height="435" viewBox="0 65 720 435"><rect width="720" height="530" fill="#ffffff"/>{content}</svg>',encoding='utf-8')

audit={'mechanics_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),
       'thermal_sha256':hashlib.sha256(T.read_bytes()).hexdigest(),
       'vertices':len(xyz),'region_nodes':n_nodes,'tetrahedra_including_gas':n_tets,
       'shared_node_temperature_max_delta':float(max(errors)),
       'thermal_to_FinalTemp_max_delta':max(profile_errors),
       'silicon_volume_cm3':volume,'power_W':volume*2857.142857142857,
       'maxima':maxima,'plot_notes':'Actual surface triangles; gas and resin hidden; undeformed geometry; nodal scalar triangle means; global maxima include resin.'}
(OUT/'field-render-audit.json').write_text(json.dumps(audit,indent=2))
print(json.dumps(audit,indent=2))

