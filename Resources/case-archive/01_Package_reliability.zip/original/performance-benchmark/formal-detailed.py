from pathlib import Path
import subprocess,json,os
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
first=int(os.environ.get('BENCH_FIRST_REP','1'))
count=int(os.environ.get('BENCH_REPS','3'))
for rep in range(first,first+count):
    for kind in (['vendor','local'] if rep%2 else ['local','vendor']):
        d=r/f'{os.environ.get("BENCH_PREFIX","detailed")}-r{rep}-{kind}'; d.mkdir(exist_ok=True)
        deck=(r/'package-vendor/case.cmd').read_text()
        (d/'case.cmd').write_text(deck+'\n# Enable complete native timer report only after simulation/output.\nselect max name=Temperature info=3\n')
        (d/'datexcodes.txt').write_bytes((r/'package-vendor/datexcodes.txt').read_bytes())
        print('BEGIN',d.name,flush=True)
        subprocess.run(['bash',str(r/'run-final-case.sh'),d.name,kind],check=True)
        # Preserve and report every sample; never silently classify swap as absent.
        print('ENVIRONMENT', (d/'timing-valid.txt').read_text().strip(),flush=True)
