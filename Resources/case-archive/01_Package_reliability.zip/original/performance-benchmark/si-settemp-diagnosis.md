# SI temperature-field initialization: first divergent entry

The fresh end-to-end check preserved exact numerical fields but failed the timestamp-only byte comparison. Field names were allocated in a different order, and the thermal file retained an extra process SetTemp command plus a unitless power-density command.

Vendor SHA256: 6b5f30b801b08012dd846b339c4e4275502c5d1ee526420c4be315623d178464.
Pre-repair local SHA256: add267dd89cc65b4d11d4a3b4c06ba581ee22c72e317239bd98a1ebffc81d279.

Evidence: ../e2e-lifecycle-{vendor,local}/lifecycle.json, probe-thermal-lifecycle.py, vendor-settempt.disasm, vendor-supply-params.disasm. The decks and mesh input SHA match the retained reference.

The scoped GDB probe proves that vendor SetTemp dispatches to SetTempT_tcl at 0x12087e0. Its copyTempFields calls create PrevTemperature and then InitTemperature, before updateStressHistory. The local dispatch instead reaches generic SetTemp_tcl, sets global process state, persists a command, and leaves the two history fields to later lifecycle stages. Generic SetTemp_tcl has zero vendor hits: this is an entry-point mismatch, not a missed breakpoint or field-value roundoff.

The complete SetTempT body was inspected. It pushes the command lifecycle, recognizes parameters/editor.syntax/run.only as early returns, requires one positional temperature argument, uses the Temperature unit with C as default, honors executionOff, updates the field server with Grid Adaptive and update name Setting temperature, copies current Temperature into PrevTemperature then InitTemperature, and calls setGlobalTempC. It does not persist a process SetTemp command or write Global Diffuse SetTemp. The initial repair registered this handler in installCsseMechanicsCommands. The shared regression subsequently proved that this installer also serves geo_run; the final product-specific gate is described below.

A separate native constructor at 0x11f8725 selects unit TYPE 0x1a (PowerDensity), with default W/cm3 at 0x6f80495 and parameter name power.density at 0x6f8049b. The local supply declaration used Unit::None. The repair restores this parameter's unit type and conversion rather than rewriting persisted output.

After both repairs, fresh standalone local thermal and local thermal-to-mechanics runs produce timestamp-excluded byte-exact files versus the original vendor thermal and coupled references (e2e-v2-thermal-comparison.json and e2e-v2-mechanics-comparison.json). Both raw files remain untouched. Intermediate build: c69a3c54c19993a4fe21e005faa8450656e609b5ca77c063e025dcfbba9c8be4.

## Product registration correction

An intermediate shared regression failed 9_101_insert_min: the candidate gained crystal material properties and changed the inserted material metadata. SProcessMain.cpp and SInterconnectMain.cpp both call installCsseMechanicsCommands, so changing that common installer unconditionally also changed geo_run's SetTemp dispatch. The final implementation uses an explicit interconnect flag (default false), supplied as true only by SInterconnectMain. This preserves geo_run's original command handler while installing SetTempT for SI.

The superseded validation chain was stopped after recording its own process tree; unrelated processes were untouched. Final build SHA256 is d223681b488443d6361471cd22a621f4be94827ee6d8798e665fa73c1e115ebc. The formerly failing insert case passes (product-gated-insert.log), and both thermal and thermomechanical end-to-end files again pass timestamp-only byte equality (e2e-v3-*-comparison.json). Remaining final validation is recorded separately under product-gated-regressions/ and certified-v3-*; earlier checkpoints are not overwritten.

