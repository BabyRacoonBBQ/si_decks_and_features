#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export GEO3D_PYTHON=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3
export PYTHONNOUSERSITE=1 GEO3D_BUILD_JOBS=2 GEO3D_VERIFY_BUILD_DONE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery/regressions
mkdir -p "$r"
# verify_si acquires the shared heavy lock internally; never double-acquire.
for attempt in $(seq 1 120); do
 set +e
 timeout -k 10 300 bash scripts/verify_si.sh > "$r/verify-si.log" 2>&1
 rc=$?
 set -e
 if [ "$rc" != 75 ]; then break; fi
 sleep 5
done
printf 'si=%s\n' "$rc" | tee "$r/exits.txt"
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 600 9
set +e
timeout -k 10 900 bash scripts/verify.sh --min > "$r/verify-min.log" 2>&1
printf 'min=%s\n' "$?" | tee -a "$r/exits.txt"
timeout -k 10 900 bash scripts/verify_transform.sh --no-build > "$r/verify-transform.log" 2>&1
printf 'transform=%s\n' "$?" | tee -a "$r/exits.txt"
timeout -k 10 900 bash scripts/verify_init_struct.sh --no-build > "$r/verify-init-struct.log" 2>&1
printf 'init_struct=%s\n' "$?" | tee -a "$r/exits.txt"
env -u LD_LIBRARY_PATH ctest --test-dir build --output-on-failure -j1 > "$r/ctest.log" 2>&1
printf 'ctest=%s\n' "$?" | tee -a "$r/exits.txt"
git diff --check > "$r/diff-check.txt" 2>&1
printf 'diff_check=%s\n' "$?" | tee -a "$r/exits.txt"
