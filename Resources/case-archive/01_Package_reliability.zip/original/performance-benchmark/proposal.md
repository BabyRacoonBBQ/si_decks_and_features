# Thermal benchmark proposal — awaiting deck confirmation

## Revised selection: prefer Backend

Found installed Backend library at `/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/Applications_Library/Backend`.

Recommended candidate: `Package_ThermomechanicalReliability`. Its structure contains a silicon die, solder preform, copper frame/leads and resin, with package-scale geometry and existing mechanical material definitions. Important: the original thermal stage `thermal_des.cmd` uses Sentaurus Device, not Interconnect. Reuse its geometry/material intent and adapt thermal loading/boundaries into a sinterconnect thermal-only deck; do not benchmark the SDevice stage. Require conduction, convection and radiation, then reuse the computed temperature for mechanics. User confirmation is pending.

Alternative: `SRAM_Backend/sinterconnect1_sis.cmd` already uses `mode current thermal mechanics`, but requires the preceding structure-generation stage and adaptation to thermal-only heating plus convection/radiation. It is a real backend topology, although its small length scale makes environmental convection/radiation less prominent relative to conduction.

The earlier 3D Interconnect draft below is retained only as a fallback, not the selected benchmark. No candidate has been run and no actual mesh counts are available yet.

VM filesystem: `/home` has 63 GiB free of 214 GiB; main worktree approximately 20 GiB. No disk-space need to push/delete worktrees has been established. No worktree was removed or pushed.

## Environment snapshot

VM: 192.168.43.128, Linux 4.18.0-553.el8_10.x86_64, VMware, 10 vCPUs, Intel i7-13700F, 12 GiB RAM, 8.9 GiB available, 15 GiB swap with 659 MiB used. Load averages 3.91 / 3.33 / 1.95; sample CPU idle 82–89%. A separate geo_run was active. These are snapshots, not benchmark acceptance evidence.


Worktree: /home/mozztcad/geo3d, main, 4140959ce963437b066e36dcc47703ac609881a1; clean at inspection. Existing build cache is Release, but the target still needs an explicit rebuild and identity verification.

## Proposed case

Derive a 3D BEOL thermal-loading example from vendor Applications_Library/GettingStarted/sinterconnect/3D_Interconnect/sinterconnect_sis.cmd and Model1.gds. Four solid materials: Silicon substrate, Oxide dielectric, Copper lower metal, Aluminum upper metal. Preserve the real mask-defined topology. Controlled upper contact temperature 125 C, environment/substrate sink 30 C, bulk conduction and exposed-surface radiation; emissivity 0.8 is an explicit benchmark assumption, not measured material data.

Draft: proposed-3d-interconnect-thermal.cmd. Geometry and syntax have not yet been run. Original script retained as vendor-original.cmd. No claim that this came from an unidentified backend directory; it comes from the installed vendor application library.

User confirmed all three mechanisms are mandatory: conduction, convection and radiation. Simultaneous convection/radiation behavior must be verified rather than assumed from setting two flags. Prefer a backend example; 3D Interconnect is a fallback pending user confirmation.

After thermal timing, reuse geometry, temperature fields and material regions for a thermomechanical demonstration with differential expansion and a documented mechanical support condition. No electrical-current solve is included in the thermal benchmark.

## Mesh/runtime calibration after confirmation

Start with the application mesh and bounded refinement trials. Proposed target: approximately 30–120 seconds of thermal solve time, rather than a toy dominated by startup/license latency. Initial search band 30,000–150,000 elements, subject to actual memory/time measurements. These are targets, not measured mesh counts. Report geometric points, material-associated nodes, element counts by type/region, thermal DOFs, peak RSS, physical time interval and actual time-step/Newton counts. Do not infer element counts from nominal spacing.

Prioritize memory safety: first establish baseline peak RSS and VM memory headroom, then refine. Set bounded timeout and memory limits after confirming current machine headroom. Avoid swapping; no unrelated process is stopped automatically. Existing occupied swap alone does not imply active paging, so monitor rates.

## Fair timing protocol

Compile sinterconnect_run Release with a low build parallelism after resource checks; record compiler, flags, source revision, executable SHA/build-id, linked libraries. Verify standalone execution, with no vendor delegation or profiling hooks.

Use matching input, initial mesh, material data, thread count (initially one), CPU affinity, solver controls, convergence criteria and output frequency. Prepare both end-to-end and premeshed solve comparisons so geometry/startup does not obscure thermal assembly/solve cost. Confirm numeric output equivalence before interpreting speed differences.

Use vendor-native total and detailed CPU/elapsed timers as the primary timing categories. First enumerate actual labels in both logs. Do not fabricate missing submodule times or sum overlapping nested timers. Existing vendor logs show Elapsed Time, User Time, CPU Time, Detailed CPU time report and Detailed elapsed time report, with categories such as Symbolic and struct command; emitted categories depend on the run. Distinguish process totals from accumulated module timers and explain unmatched time. External wall clock, RSS and OS load are supplementary observations.

Prefer at least three matched pairs after warm-up, alternating order to reduce drift. Record VM CPU, memory, paging and competing jobs before/during each run. Set acceptance thresholds from an idle baseline; reject contaminated pairs. No concurrent vendor/local runs or compilation. A shared lock prevents overlap with cooperating jobs, but does not control arbitrary VM workloads.

Deck selection must be confirmed by the user before trial solves or formal timing. Actual mesh size/runtime and module timer coverage remain pending.

