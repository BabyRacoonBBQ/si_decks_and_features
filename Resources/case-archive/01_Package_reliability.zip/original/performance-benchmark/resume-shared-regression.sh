#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export GEO3D_PYTHON=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3
export PYTHONNOUSERSITE=1 GEO3D_BUILD_JOBS=2 GEO3D_VERIFY_BUILD_DONE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
root=/home/mozztcad/tmp/package-benchmark-20261010/thermal-recovery
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
set +e
timeout -k 10 900 bash scripts/verify_transform.sh --no-build > "$root/verify-transform.log" 2>&1
echo "transform=$?" | tee "$root/shared-regression-exits.txt"
timeout -k 10 900 bash scripts/verify_init_struct.sh --no-build > "$root/verify-init-struct.log" 2>&1
echo "init_struct=$?" | tee -a "$root/shared-regression-exits.txt"
git diff --check > "$root/diff-check.txt" 2>&1
echo "diff_check=$?" | tee -a "$root/shared-regression-exits.txt"
