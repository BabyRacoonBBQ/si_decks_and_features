#!/bin/bash
set -eu
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export GEO3D_PYTHON=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3
export PYTHONNOUSERSITE=1 GEO3D_BUILD_JOBS=2 GEO3D_VERIFY_BUILD_DONE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
flock -w 3600 /tmp/geo3d-sinterconnect-heavy.lock timeout -k 10 600 bash scripts/verify.sh -s data/sfdram/single/9_101_insert_min.cmd > "$r/product-gated-insert.log" 2>&1
printf 'Previously failing insert: PASS\n'
bash "$r/run-certified-e2e-v3.sh"
bash "$r/run-certified-v3-profile-matrix.sh"
python3 "$r/compare-certified-v3-matrix.py" > "$r/certified-v3-comparison-console.log"
python3 "$r/assert-certified-v3-matrix.py"
bash "$r/run-profile-strain-v3.sh"
bash "$r/run-settemp-unit-v3.sh"
python3 "$r/summarize-product-gated.py"
bash "$r/run-product-gated-regressions.sh"
bash "$r/record-recovery-identity.sh"
python3 "$r/finalize-product-gated.py"
