from pathlib import Path
import json,re
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
p=r/'e2e-verification-summary.json';s=json.loads(p.read_text())
log=(r/'e2e-final-regressions/ctest.log').read_text(errors='replace');fails=re.findall(r'^\s*(\d+) - ([^\n]+)',log.split('The following tests FAILED:')[-1],re.M)
prior=json.loads((r/'regressions/ctest-comparison.json').read_text())
x={'failures':fails,'same_as_thermal_checkpoint':fails==[tuple(t) for t in prior['thermal_checkpoint']],'same_as_coupling_core_checkpoint':fails==[tuple(t) for t in prior['thermomechanical']],'qualification':'Observed checkpoints only; no pristine-HEAD baseline rebuild.'}
assert len(fails)==10 and x['same_as_thermal_checkpoint'] and x['same_as_coupling_core_checkpoint']
exits=dict(line.split('=') for line in (r/'e2e-final-regressions/exits.txt').read_text().splitlines());assert exits=={'si':'0','min':'0','transform':'0','init_struct':'0','ctest':'8','diff_check':'0'}
s['regressions']={'exits':exits,'ctest':x}
u=json.loads((r/'settemp-unit-comparison.json').read_text());assert u['timestamp_excluded_byte_exact']
v=[]
for kind in ['vendor','local']:
 d=r.parent/('settemp-unit-'+kind)
 log=(d/'stdout.log').read_text(); records=re.findall(r'SETTEMP_CHECK (\w+) <(\d+)> <(.*?)>\n',log,re.S); assert len(records)==6; records += re.findall(r'SETTEMP_HISTORY ([^\n]+)',log); v.append(records)
 assert (d/'exit.txt').read_text().strip()=='0'
 if kind=='local':assert (d/'identities.sha256').read_text().split()[0]==s['local_release_sha256']
assert v[0]==v[1] and len(v[0])==7
s['settemp_and_units']={'diagnostics_and_history_exact':True,'records':v[0],'output_timestamp_excluded_byte_exact':True,'notes':'Six SetTemp argument probes, repeated SetTemp calls, mW/cm3 power-density conversion.'}
p.write_text(json.dumps(s,indent=2));print('FINAL VALIDATION COMPLETE',s['local_release_sha256']);print(exits);print(v[0])

