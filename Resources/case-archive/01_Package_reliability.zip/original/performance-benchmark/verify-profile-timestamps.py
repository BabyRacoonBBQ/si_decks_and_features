import sys,struct,json,hashlib
from pathlib import Path
import h5py

def inspect(p):
 raw=p.read_bytes();objs={}
 with h5py.File(p) as f:
  objs[int(h5py.h5o.get_info(f['/'].id).addr)]='/'
  def add_object(n,o):
   objs.setdefault(int(h5py.h5o.get_info(o.id).addr),n)
  f.visititems(add_object)
 ranges=[];unsupported=[]
 for addr,name in sorted(objs.items()):
  if raw[addr]!=1:
   unsupported.append([addr,name,raw[addr]]);continue
  nmsg=struct.unpack_from('<H',raw,addr+2)[0];size=struct.unpack_from('<I',raw,addr+8)[0]
  blocks=[(addr+16,size)];seen=set();parsed=0
  while blocks:
   start,length=blocks.pop(0)
   if (start,length) in seen:raise RuntimeError('continuation cycle')
   seen.add((start,length));pos=start;end=start+length
   while pos+8<=end:
    typ,n,flags=struct.unpack_from('<HHB',raw,pos)
    if pos+8+n>end:raise RuntimeError('invalid message bounds '+name)
    if typ==18:
     assert n==8 and raw[pos+8:pos+12]==b'\x01\0\0\0'
     ranges.append({'offset':pos+12,'length':4,'object_header':addr,'object':name,'seconds':struct.unpack_from('<I',raw,pos+12)[0]})
    if typ==16:
     assert n>=16
     blocks.append(struct.unpack_from('<QQ',raw,pos+8))
    parsed+=1;pos+=8+n
   if pos!=end:raise RuntimeError('unaligned header '+name)
  if parsed!=nmsg:unsupported.append([addr,name,'message-count',nmsg,parsed])
 return raw,ranges,unsupported

a,b=map(Path,sys.argv[1:3]);x,rx,ux=inspect(a);y,ry,uy=inspect(b)
sx={(r['offset'],r['length']) for r in rx};sy={(r['offset'],r['length']) for r in ry}
shared=sx&sy
ignored={i for pos,n in shared for i in range(pos,pos+n)}
remaining=[i for i,(u,v) in enumerate(zip(x,y)) if u!=v and i not in ignored]
r={'reference':str(a),'candidate':str(b),'reference_sha256':hashlib.sha256(x).hexdigest(),'candidate_sha256':hashlib.sha256(y).hexdigest(),'sizes':[len(x),len(y)],'raw_differences':sum(u!=v for u,v in zip(x,y))+abs(len(x)-len(y)),'remaining_differences':len(remaining)+abs(len(x)-len(y)),'first_remaining':remaining[:12],'same_timestamp_ranges':sx==sy,'unparsed_reference':ux,'unparsed_candidate':uy,'reference_timestamps':rx,'candidate_timestamps':ry,'timestamp_excluded_byte_exact':len(x)==len(y) and not remaining and sx==sy and not ux and not uy}
Path(sys.argv[3]).write_text(json.dumps(r,indent=2))
print(json.dumps({k:v for k,v in r.items() if not k.endswith('_timestamps')},indent=2));print('timestamp_fields',len(rx),len(ry))

