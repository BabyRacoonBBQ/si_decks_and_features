#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
root=/home/mozztcad/tmp/package-benchmark-20261010/thermal-recovery
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
set +e
timeout -k 10 1200 env -u LD_LIBRARY_PATH cmake --build build -j2 > "$root/build-all.log" 2>&1
rc=$?
echo "build_all=$rc" | tee "$root/ctest-exits.txt"
if [ "$rc" != 0 ]; then exit "$rc"; fi
timeout -k 10 1200 ctest --test-dir build --output-on-failure -j1 --timeout 180 > "$root/ctest.log" 2>&1
rc=$?
echo "ctest=$rc" | tee -a "$root/ctest-exits.txt"
exit "$rc"
