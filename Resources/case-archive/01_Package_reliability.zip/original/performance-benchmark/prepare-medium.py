from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010');d=r/'mesh-medium';d.mkdir(exist_ok=True)
s=(r/'mesh-coarse/mesh.scm').read_text();s=s[:s.index('(sde:build-mesh')]
s+='''
(define gaslo (car (bbox (get-body-list))))
(define gashi (cdr (bbox (get-body-list))))
(sdegeo:set-default-boolean "BAB")
(sdegeo:create-cuboid (position (- (position:x gaslo) 50) (- (position:y gaslo) 50) (- (position:z gaslo) 50)) (position (+ (position:x gashi) 50) (+ (position:y gashi) 50) (+ (position:z gashi) 50)) "Gas" "ambient")
(sdeio:save-3d-tdr-bnd (get-body-list) "package_bnd.tdr")
'''
(d/'geometry.scm').write_text(s)
shutil.copy2(r/'mesh-coarse/datexcodes.txt',d/'datexcodes.txt')
(d/'package.cmd').write_text('''Definitions { Refinement "global" { MaxElementSize=(300 300 300) MinElementSize=(150 150 150) } }
Placements { Refinement "global" { Reference="global" RefineWindow=Cuboid [(-2000 -2000 -2500) (1500 6000 10000)] } }
Delaunizer { maxPoints=100000 delaunayTolerance=0.6 }
''')
(r/'medium.sh').write_text('''#!/bin/bash
set -uo pipefail
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP FRIDA_AGENT FRIDA_OPTIONS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
cd /home/mozztcad/tmp/package-benchmark-20261010/mesh-medium
ulimit -v 6291456
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9 || exit 75
bin=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin
timeout -k 10 180 taskset -c 4 "$bin/sde" -e -l geometry.scm > geometry.stdout 2> geometry.stderr || exit $?
/usr/bin/time -v timeout -k 10 300 taskset -c 4 "$bin/snmesh" package > mesh.stdout 2> mesh.stderr
rc=$?
echo "$rc" > exit.txt
tail -20 mesh.stdout
exit "$rc"
''')
print(d)
