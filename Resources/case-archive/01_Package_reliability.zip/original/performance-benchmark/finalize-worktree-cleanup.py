from pathlib import Path
import subprocess,json,os,re
root=Path('/home/mozztcad/geo3d')
b=Path('/home/mozztcad/tmp/paused-info2-20261010')
info=json.loads((b/'checkpoint.json').read_text())
w=Path(info['worktree']).resolve()
assert w==Path('/home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2')
assert (b/'archive.sha256').is_file() and (b/'archive.sha256').stat().st_size>64
def git(cwd,*args):
 p=subprocess.run(['git','-C',str(cwd),*args],text=True,capture_output=True)
 if p.returncode: raise RuntimeError(re.sub(r'https?://\S+','[remote URL redacted]',p.stdout+p.stderr))
 return p.stdout.strip()
assert git(w,'rev-parse','HEAD')==info['head']
assert not git(w,'diff','HEAD','--name-only')
assert git(w,'ls-remote','--heads','origin','refs/heads/'+info['remote_branch']).split()[0]==info['head']
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit(): continue
 for part in ('cwd','exe'):
  try:
   target=os.readlink(p/part)
   if target==str(w) or target.startswith(str(w)+'/'):active.append((p.name,part,target))
  except OSError:pass
 try:
  for fd in (p/'fd').iterdir():
   try:
    target=os.readlink(fd)
    if target==str(w) or target.startswith(str(w)+'/'):active.append((p.name,'fd',target))
   except OSError:pass
 except OSError:pass
assert not active,active
# The preceding tar --diff verified every archived entry against the live tree.
# Its successful completion is required before archive.sha256 is produced.
git(root,'worktree','remove','--force',str(w))
git(root,'branch','-D',info['local_branch'])
assert not w.exists()
assert not git(root,'branch','--list',info['local_branch'])
assert git(root,'ls-remote','--heads','origin','refs/heads/'+info['remote_branch']).split()[0]==info['head']
info['local_worktree_removed']=True
info['local_branch_removed']=True
info['archive']=str(b/'worktree.tar.gz')
info['archive_sha256']=(b/'archive.sha256').read_text().split()[0]
info['disk_after']=subprocess.check_output(['df','-h','/home'],text=True)
(b/'cleanup-complete.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2))
