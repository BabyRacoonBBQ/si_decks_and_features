import sys,json
from pathlib import Path
import h5py,numpy as np
a,b=map(Path,sys.argv[1:3]);result={'missing':[],'extra':[],'attributes':[],'datasets':[]}
def equal(x,y):
 try:return bool(np.array_equal(x,y))
 except:return repr(x)==repr(y)
def brief(x):
 s=repr(x);return s if len(s)<250 else s[:250]+'...'
with h5py.File(a) as fa,h5py.File(b) as fb:
 aa={};bb={};fa.visititems(lambda n,o:aa.__setitem__(n,o));fb.visititems(lambda n,o:bb.__setitem__(n,o))
 result['missing']=sorted(set(aa)-set(bb));result['extra']=sorted(set(bb)-set(aa))
 for k in sorted(set(aa)&set(bb)):
  x,y=aa[k],bb[k]
  for attr in set(x.attrs)|set(y.attrs):
   xv=x.attrs.get(attr);yv=y.attrs.get(attr)
   if not equal(xv,yv):result['attributes'].append({'object':k,'attribute':attr,'vendor':brief(xv),'local':brief(yv)})
  if isinstance(x,h5py.Dataset) and isinstance(y,h5py.Dataset) and not equal(x[()],y[()]):
   result['datasets'].append({'object':k,'vendor_shape':x.shape,'local_shape':y.shape,'vendor_dtype':str(x.dtype),'local_dtype':str(y.dtype)})
Path(sys.argv[3]).write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2)[:16000])
