#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 3600 9
ulimit -v 6291456
for kind in vendor local; do
 cd "$root/settemp-unit-$kind"
 bin=/home/mozztcad/geo3d/build/sinterconnect_run
 args=()
 if [ "$kind" = vendor ]; then bin=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect;args=(--noSyntaxCheck);fi
 sha256sum "$bin" case.cmd datexcodes.txt ../mesh-roof/package_msh.tdr > identities.sha256
 set +e
 /usr/bin/time -v timeout -k 10 300 taskset -c 4 "$bin" "${args[@]}" case.cmd > stdout.log 2> stderr.log
 rc=$?
 set -e
 echo "$rc" > exit.txt
 test "$rc" = 0
 grep SETTEMP_ stdout.log
 done
PYTHONNOUSERSITE=1 /home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3 "$root/thermomechanical-recovery/verify-profile-timestamps.py" "$root/settemp-unit-vendor/result_sis.tdr" "$root/settemp-unit-local/result_sis.tdr" "$root/thermomechanical-recovery/settemp-unit-comparison.json"
