from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
original=Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/Applications_Library/Backend/Package_ThermomechanicalReliability')
settings=(original/'settings.cmd').read_text()
settings=settings.replace('source mpnonlinear.cmd','# Linear-elastic benchmark: mp.cmd selected').replace('source cudefault.cmd','# Linear-elastic benchmark: mp.cmd selected')
for kind in ['vendor','local']:
 d=r/('coupled-'+kind);d.mkdir(exist_ok=True)
 shutil.copy2(original/'mp.cmd',d/'mp.cmd')
 shutil.copy2(r/'package-vendor/datexcodes.txt',d/'datexcodes.txt')
 (d/'settings.cmd').write_text(settings)
 (d/'case.cmd').write_text('''# Package thermal field -> mechanical thermal strain, one-way sequential coupling.
# Both binaries read the SAME validated vendor thermal field on the SAME mesh.
math numThreads=1
pdbSet Grid AddGasMesh 0
source settings.cmd
init tdr=../package-vendor/result_sis.tdr !load.commands !pdb
select z=Temperature name=FinalTemp store
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
mode mechanics
solve temperature=26.844<C> time=1.0<s> init=1.0<s> maxstep=1.0<s> t.final.profile=FinalTemp info=2
puts "COUPLED_TMAX [select max name=FinalTemp]"
select name=DisplacementMagnitude z="sqrt(Displacement_x^2+Displacement_y^2+Displacement_z^2)" store
puts "COUPLED_UMAX [select max name=DisplacementMagnitude]"
struct tdr=result
''')
