# VM local replay status

The thermal, reliability, and flip-chip example figures in this directory are generated from the VM Release binary `/home/mozztcad/geo3d/build/sinterconnect_run` on `mozztcad@192.168.43.128`. Host machine information is excluded from the evidence. Per the latest scope, the existing mechanics GIFs were left unchanged and were not rerendered against the final binary.

Completed local examples:

- package thermal field and package thermomechanical reliability: local TDR results and VM VTK/Pillow renders;
- mechanics quasistatic, linear buckling, post-buckling, and geometric comparison: existing mechanics GIFs remain embedded; no final-binary GIF refresh was requested;
- flip-chip global and unit-fine submodel replay: local Release TDRs and local VM renders are embedded in the application-cases slide.

The local and vendor flip-chip comparisons are recorded in `flipchip-array-verification/local-release/compare-summary.json`. Geometry and temperature fields are exact in both compared models. Global displacement, stress, elastic strain, and elastic energy fields are exact; unit-fine displacement, stress, elastic strain, and elastic energy differ only at machine precision (maximum relative difference below `1e-11`). The source TDR hashes and local binary SHA are retained in `local-release/compare-local.json` and `local-release/binary.sha256`.

Linear buckling is now recovered in the VM Release binary. The clean run reports the vendor critical loads 71.7609, 71.7609, and 609.8; the field comparison has no missing or extra fields, and all non-eigenmode fields match exactly or at machine precision. The existing mechanics GIFs remain unchanged by request.
