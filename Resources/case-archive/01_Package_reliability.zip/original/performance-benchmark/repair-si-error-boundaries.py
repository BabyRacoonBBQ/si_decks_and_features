from pathlib import Path
r=Path('/home/mozztcad/geo3d')
p=r/'src/abi/floops/floops/FLPS.cpp';s=p.read_text()
s=s.replace('''                     const char* continuation)
{''','''                     const char* continuation,
                     bool interconnectContext = false)
{''',1)
s=s.replace('''    TCAD_PRINT(stderr, VOF_STR(" !\\n"));
    if (continuation != nullptr)''','''    if (interconnectContext && params && params->unverifiedFlagAt199_) {
        TCAD_PRINT(stderr, VOF_STR(" %d"), static_cast<int>(::getpid()));
    }
    TCAD_PRINT(stderr, VOF_STR(" !\\n"));
    if (interconnectContext && floops::_globalPool) {
        const auto* simulation = floops::_globalPool->globalSim.get();
        if (simulation && simulation->interpreter) {
            TCAD_PRINT(stderr, VOF_STR("%s\\n"),
                       Tcl_GetStringResult(simulation->interpreter->interpreter));
        }
    }
    if (continuation != nullptr)''',1)
s=s.replace('''[[noreturn]] void FLPS_panic(FLPS_ErrorCode, char* message)
{
#if RECON_SPROCESS''','''[[noreturn]] void FLPS_panic(FLPS_ErrorCode errorCode, char* message)
{
    const bool interconnect = floops::_globalPool
        && floops::_globalPool->jobInfo.get()
        && floops::_globalPool->jobInfo->getToolName() == VOF_STR("SINTERCONNECT");
    if (interconnect) {
        // SI W-2024.09-SP1 FLPS_panic @0x12e2530: retain the warning,
        // PID flag and live Tcl result; the exception carries the error code.
        floops::_globalPool->warningKeeper->storeWarning(message, true);
        writeDiagnostic(VOF_STATIC_STR("\\n** Error **\\n"), message,
                        VOF_STATIC_STR(" ... aborting\\n\\n"), true);
        ++panicCount;
        if (panicCount == 1) {
            throw std::runtime_error(std::to_string(static_cast<int>(errorCode)));
        }
        FLPS_exit(EXIT_FAILURE);
    }
#if RECON_SPROCESS''',1)
assert s!=p.read_text();p.write_text(s)
p=r/'src/abi/floops/floops/FloopsCmd.cpp';s=p.read_text()
s=s.replace('#include "abi/floops/floops/GlobalSteps.h"','#include "abi/floops/floops/GlobalSteps.h"\n#include "abi/floops/floops/JobInfo.h"',1)
s=s.replace('namespace {\n//', 'extern "C" void cleanSyntaxCheckFiles();\n\nnamespace {\n//',1)
old='''    const int result = cmd->second(argc, const_cast<char**>(argv), parser);'''
new='''    int result;
    try {
        result = cmd->second(argc, const_cast<char**>(argv), parser);
    } catch (const std::exception& error) {
        auto* const pool = floops::_globalPool.get();
        if (!pool || !pool->jobInfo.get()
            || pool->jobInfo.get()->getToolName() != VOF_STR("SINTERCONNECT")) {
            throw;
        }
        // SI floopsCmd cold path @0xf25fb7..0xf261c2: report the
        // failed command and leave through the registered Tcl exit command.
        TbStopwatch::stop(watch->second);
        TCAD_PRINT(stderr, VOF_STR("\\nUnexpected Exception: %s\\n"), error.what());
        TCAD_PRINT(stderr, VOF_STR("While executing command:\\n\\n"));
        for (int index = 0; index != argc; ++index) {
            if (std::strcmp(argv[index], VOF_STR("run.only")) != 0) {
                TCAD_PRINT(stderr, VOF_STR("%s "), argv[index]);
            }
        }
        TCAD_PRINT(stderr, "\\n\\n");
        TCAD_FLUSH(stderr);
        cleanSyntaxCheckFiles();
        (void)Tcl_Eval(interp, VOF_STR("exit 1"));
        FLPS_exit(1);
    }'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=r/'src/abi/floops/floops/FloopsMain.cpp';s=p.read_text()
old='''    const char* message = Tcl_GetStringResult(interp);
    LOGE'''
new='''    const char* message = Tcl_GetStringResult(interp);
    if (toolName == VOF_STR("sinterconnect")) {
        // Match the Tcl_MainEx file-error boundary used by SI: preserve the
        // full Tcl traceback, including the source file and line number.
        Tcl_AddErrorInfo(interp, "");
        const char* const errorInfo = Tcl_GetVar(
            interp, VOF_STR("errorInfo"), TCL_GLOBAL_ONLY);
        TCAD_PRINT(stderr, VOF_STR("%s\\n"), errorInfo ? errorInfo : message);
        TCAD_FLUSH(stderr);
        return false;
    }
    LOGE'''
assert s.count(old)==1;s=s.replace(old,new)
old='''    if (errors > 0) {
        LOGE(VOF_STR("%s: %d command error(s)'''
new='''    if (errors > 0) {
        if (ip && currentToolName() == VOF_STR("sinterconnect")) {
            (void)Tcl_Eval(ip, VOF_STR("exit 1"));
            return 1;
        }
        LOGE(VOF_STR("%s: %d command error(s)'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
