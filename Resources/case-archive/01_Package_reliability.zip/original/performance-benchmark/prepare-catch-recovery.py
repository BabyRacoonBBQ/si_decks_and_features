from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(r/'multistep-vendor/case.cmd').read_text()
line=next(x for x in s.splitlines() if x.startswith('solve '))
conflict=line.replace(' info=2',' t.final=100<C> info=2')
no_time=line.replace(' time=1.0<s>','')
prefix=''
for label,cmd in [('conflict',conflict),('no_time',no_time)]:
 prefix+='set status [catch {'+cmd+'} message options]\n'
 prefix+='puts "PROBE_ERROR '+label+' code=$status message=<$message>"\n'
 prefix+='puts "PROBE_ERRORINFO '+label+' <[dict get $options -errorinfo]>"\n'
s=s.replace(line,prefix+line)
for kind in ['vendor','local']:
 d=r/('catch-recovery-'+kind);d.mkdir(exist_ok=True)
 for f in ['settings.cmd','mp.cmd','datexcodes.txt']:shutil.copy2(r/'multistep-vendor'/f,d/f)
 (d/'case.cmd').write_text(s)
