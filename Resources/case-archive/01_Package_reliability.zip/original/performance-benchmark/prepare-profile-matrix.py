from pathlib import Path
root=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
base=root/'initial-local'
variants={
 'multistep': lambda s:s.replace('init=1.0<s> maxstep=1.0<s>','init=0.25<s> maxstep=0.25<s>'),
 'implicit': lambda s:s.replace('temperature=26.844<C> ',''),
 'uniform': lambda s:s.replace('select z=Temperature name=FinalTemp store','select z=400 name=FinalTemp store'),
 'missing': lambda s:s.replace('t.final.profile=FinalTemp','t.final.profile=DoesNotExist'),
 'conflict': lambda s:s.replace('t.final.profile=FinalTemp','t.final.profile=FinalTemp t.final=100<C>'),
 'no-time': lambda s:s.replace(' time=1.0<s>',''),
}
for label,change in variants.items():
 for kind in ['vendor','local']:
  d=root/(label+'-'+kind);d.mkdir(exist_ok=True)
  for f in ['settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((base/f).read_bytes())
  (d/'case.cmd').write_text(change((base/'case.cmd').read_text()))
