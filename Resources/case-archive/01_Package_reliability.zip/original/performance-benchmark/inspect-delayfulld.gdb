set pagination off
set confirm off
set breakpoint pending on
break floops::Controller::needPDESolve
commands
silent
printf "PATCHED_FUNCTION_HIT needPDESolve\n"
continue
end
break floops::TdrWriterUtils::getTdrUnit
commands
silent
printf "PATCHED_FUNCTION_HIT getTdrUnit\n"
continue
end
break floops::Time_TRBDF::Solve
commands
silent
printf "PATCHED_FUNCTION_HIT Time_TRBDF_Solve\n"
continue
end
break sinterconnect::SolveController::prepareStructure
commands
silent
printf "PATCHED_FUNCTION_HIT prepareStructure\n"
continue
end
run
bt 15
quit
