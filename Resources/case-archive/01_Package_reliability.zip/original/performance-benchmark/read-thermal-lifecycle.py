import json
from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
for kind in ['vendor','local']:
 e=json.loads((r/('e2e-lifecycle-'+kind)/'lifecycle.json').read_text());print(kind)
 for x in e:
  if x['kind']!='command':print(x)
 print('commands',len([x for x in e if x['kind']=='command']))
