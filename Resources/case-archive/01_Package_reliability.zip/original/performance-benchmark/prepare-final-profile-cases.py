from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
for label in ['multistep','implicit','uniform','missing','conflict','no-time','init-state']:
 d=r/('final-'+label+'-local');d.mkdir(exist_ok=True)
 for f in ['case.cmd','settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((r/(label+'-local')/f).read_bytes())
