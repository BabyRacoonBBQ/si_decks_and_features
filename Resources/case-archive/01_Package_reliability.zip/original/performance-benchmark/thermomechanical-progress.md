# Final verified checkpoint

The scoped recovery is verified on final Release SHA256 d223681b488443d6361471cd22a621f4be94827ee6d8798e665fa73c1e115ebc. Eight mechanics/error cases, both local thermal-to-mechanics stages, four-step temperature/thermal-strain probes and SetTemp/unit-conversion probes pass. Outputs are byte-exact after structural timestamp exclusions; PID is normalized only in the scoped fatal diagnostic.

Final gates: SI PASS; minimum 6/6 PASS; transform PASS; init/struct 8/8 PASS; diff-check PASS. CTest is 24/34, with the same ten failures as the earlier checkpoints. The intermediate registration regression was repaired with the explicit SI-only flag; final full minimum regression confirms the correction.

Authoritative current documents: thermomechanical-recovery-report.md and product-gated-verification-summary.json. VM evidence: /home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery. Source changes remain uncommitted in /home/mozztcad/geo3d. The final evidence-recording script initially missed rg under the sourced PATH; it succeeded in a fresh SSH shell, and final summary reconciliation passed. Product checks were not rerun for that reporting-only environment issue.

## Historical progress (superseded by the checkpoint above)
# Thermomechanical recovery — current evidence

Worktree: `/home/mozztcad/geo3d`, main, base `4140959ce963437b066e36dcc47703ac609881a1`.
VM evidence: `/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery`.

## Verified progress

| Issue | Evidence | Repair / state |
|---|---|---|
| Profile rejected before mechanics | Matched GDB: vendor setParams returns 0 and appends AnnealStep; local returns 1 without AddStep | Temp_Ramp.cpp now implements profile option and implicit initial temperature handling; one Release incremental build completed |
| Reversed temperature interpolation inputs | Vendor DiffSolver::SetTemp instructions load final +0x6e0 first, initial +0x6d8 second; local did the reverse | DiffSolver.cpp corrected operand order |
| Package single-step output | 1,012 field groups, including temperature/displacement/stress | All numerical values exact; checked topology and field attributes exact |
| Four 0.25-second steps | Matched time-step logs and 1,012 final field groups | Final values exact; internal intermediate field snapshots still to verify |
| Implicit initial temperature | Vendor/local runs completed, 1,012 field groups compared | Exact numerical values, checked topology and field attributes |
| Uniform 400 K final profile | Vendor/local runs completed, 1,012 field groups compared | Exact numerical values, checked topology and field attributes |
| Missing profile, conflicting final temperature, omitted time | Six runs completed | Both binaries exit 1 in each case; exact diagnostics still under review |

## Open findings and remaining verification

- Raw output is **not byte-exact**. Do not call it timestamp-only.
- Keyed comparison of saved Floops Parameters: 251 missing `Like` material/interface inheritance tags, 2 extra tags (`Compute/Converged`, `Math/Internal.FTS.NegErrCntrl`), and zero changed values among common keys.
- Minimal material creation probes are prepared/running to locate the missing modification tracking. This is a diagnostic deck, not a replacement acceptance case.
- Post-repair parser/state probes, intermediate temperature mapping, error-message differences, lifecycle/side-effect scope, standalone linkage audit, and shared geo_run regressions remain required.
- Previously measured shared CTest baseline was 24/34; those failures are retained separately, not assumed fixed or automatically pre-existing for new code.
- No commit, push, vendor modification, or relaxation of comparison tolerance.

## Reproduction

`run-profile-case.sh <vendor|local> <label>` runs one existing deck under the shared heavy lock, CPU 4, one thread, 6 GiB virtual-memory limit, 300-second timeout. `run-profile-matrix.sh` runs the six discriminator pairs sequentially. Identities, exit codes, full stdout/stderr and resource measurements are retained in each case directory.

Comparison reports: `initial-comparison.json`, `multistep-comparison.json`, `implicit-comparison.json`, `uniform-comparison.json`, `initial-metadata.json`, `parameter-tags.json`. Pre-repair diagnosis: `diagnosis_report.md`; vendor static evidence: `setParams.asm`, `SetTemp.asm`; scripts preserve the complete probe/repair procedure.

## Latest increment: 3D init persistence

- Matched `init-likes-v2` probes proved vendor retains Like modification state across `init !pdb`; local cleared it. The first `init-likes` attempt had incorrect Tcl scope and is not evidence.
- `Initialize.cpp` now restores retained Like entries for SInterconnect in 3D, retaining the old sprocess branch. Both Release targets (`sinterconnect_run`, `geo_run`) built successfully under the shared lock (second incremental build batch).
- Full package rerun `retained-likes-local` still has exact 1,012 numerical field groups, checked topology and field attributes.
- Saved parameter comparison now has **0 missing**, **2 extra**, and **1 changed** key: `Params&Resin_SmearBeol&Like`, vendor `Nitride_Resin`, local `Copper_SmearBeol`. This changed value was previously hidden among missing keys; it is not yet attributed to the latest repair.
- Output sizes are now 39,221,879 vendor / 39,225,831 local; raw bytes still differ.
- `solve-flags` vendor/local snapshots are the next active sequential probe. No regressions or completion claim yet.

## Root-cause increment: honor SI init !pdb

`init-state` probes proved both flags absent at startup and before init in both binaries, but present only locally after init. `init-likes-v2` also proved the Resin_SmearBeol inheritance mismatch originates during init, not material creation. `nativeInitReaderParams` had forced pdb=true for all non-RCFX tools. SI now honors the parsed pdb option and bypasses the legacy load-then-cleanup workaround; the previous SI retained-Like workaround was removed. This is a source/input-state fix, not output filtering.

Third incremental Release build batch rebuilt sinterconnect_run and geo_run. `pdb-gate-local` matches all 459 saved parameter keys/values (no missing, extra, or changed), all 1,012 numerical field groups, topology and field attributes. File sizes are both 39,221,879 bytes. Structural parsing of HDF5 v1 object headers (including continuation blocks) identified 1,086 timestamp fields per file. All 2,172 differing bytes fall in those exact timestamp ranges: **timestamp-excluded byte-exact**; originals were not modified. Proof: `pdb-gate-timestamp-proof.json`. The first timestamp-check tool attempt stopped traversal early and is superseded by the corrected complete traversal.

Latest-binary multistep and implicit cases also pass timestamp-excluded byte equality against retained identity-matched vendor references (`final-*-timestamp-proof.json`). The validation runner's subsequent uniform attempt exited before starting a product: shared-heavy-lock timeout, no product stdout/stderr or exit record. This is a runner scheduling failure, not a solver failure. The matrix is still processing remaining lock acquisitions; inspect its actual terminal state before retrying only cases without product exit records.

Next required work: complete remaining latest-binary cases, post-repair execution/state probes, full affected build and required shared regressions, dependency/independence audit, exact error/warning comparison, final report and patch artifacts. Goal remains active.

## Current checkpoint: product-gated temperature initialization

Final source candidate: 16 modified files; Release sinterconnect_run SHA256 d223681b488443d6361471cd22a621f4be94827ee6d8798e665fa73c1e115ebc. A fresh local thermal-to-mechanics chain now matches vendor files byte-exactly except structurally decoded timestamps. The original eight mechanics scenarios and thermal-strain mapping had passed before the last registration-only correction; they are being rechecked on this candidate.

The intermediate SI SetTemp registration mistakenly affected geo_run through their shared installCsseMechanicsCommands helper. Minimum regression caught 9_101_insert_min failing; source now gates registration with an explicit SI-only flag. The targeted insert rerun passes. Full final chain run-product-gated-validation.sh is active; terminal session 7008. It runs end-to-end, certified-v3 eight-case matrix, strain-v3-local, settemp-unit-v3-local, full required regressions and final identity/summary reconciliation. Do not mark complete until this chain finishes and product-gated-verification-summary.json includes reconciled regression results. The report's regression section is still marked as pending.

Earlier final-regressions/ is a pre-SetTemp checkpoint, not final evidence for this new executable. e2e-final-regressions/ is superseded (min 5/6); its own process tree was safely stopped. The latest final regression directory is product-gated-regressions/. Do not delete or conflate these checkpoints.

