set pagination off
set confirm off
set breakpoint pending off
set print thread-events off
python
import gdb
class Return(gdb.FinishBreakpoint):
    def stop(self):
        print('PROBE needPDESolve RETURN eax=',gdb.parse_and_eval('$eax'))
        return False
class Observe(gdb.Breakpoint):
    def stop(self):
        obj=int(gdb.parse_and_eval('$rdi'))
        mgr=int(gdb.parse_and_eval('*(unsigned long long*)%d' % (obj+0x130)))
        print('PROBE', self.location, 'manager_flags=', bytes(gdb.selected_inferior().read_memory(mgr+0x58,8)).hex())
        if 'needPDESolve' in self.location:
            Return(gdb.newest_frame(), internal=True)
        return False
class Event(gdb.Breakpoint):
    def stop(self):
        print('PROBE EVENT',self.location)
        return False
Observe('_ZN6floops10Controller13diffusionStepEN8TcadMath6ZfloatERd')
Observe('_ZN6floops10Controller12needPDESolveENS_10SolverTypeE')
Event('_ZN6floops10Controller21doDiffusionPreProcessEv')
end
run
