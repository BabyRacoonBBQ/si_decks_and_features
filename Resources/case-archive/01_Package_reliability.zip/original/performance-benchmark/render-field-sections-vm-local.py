"""Fixed-camera horizontal clipping of archived fields; no solver run."""
from pathlib import Path
p=Path(__file__).with_name('render-package-animation-vm-local.py')
exec(p.read_text().split('start=time.time();samples=')[0])
W,H=800,544
win.SetSize(W,H)
ren.SetViewport(0,0,1,1)
OUT=Path('/home/mozztcad/tmp/package-benchmark-20261010/reliability-local');OUT.mkdir(parents=True,exist_ok=True)
theta=math.radians(35);elev=math.radians(32)
radius*=1.18  # Keep the complete leads inside the fixed frame throughout the sweep.
camera.SetPosition(focus[0]+radius*math.cos(theta)*math.cos(elev),focus[1]+radius*math.sin(theta)*math.cos(elev),focus[2]+radius*math.sin(elev))
camera.SetFocalPoint(*focus);camera.SetViewUp(0,0,1)
plane.SetNormal(0,0,1)
cuts=[0.]*6+[smooth(i/23) for i in range(24)]+[1-smooth(i/23) for i in range(24)]+[0.]*6
manifest={'renderer':'VTK '+vtk.vtkVersion.GetVTKVersion(),'camera':'fixed','axis':'display z = negative source x; horizontal section','cuts':cuts,'frame_ms':100,'deformation_scale':0,'fields':{}}
for key,field,source,scale in [('temp','Temperature',INPUT,1),('u','Displacement',Path('/home/mozztcad/tmp/package-benchmark-20261010/demo-coupled-current/result_sis.tdr'),1e4),('stress','MisesStressMax',Path('/home/mozztcad/tmp/package-benchmark-20261010/demo-coupled-current/result_sis.tdr'),1e-10)]:
 with h5py.File(source) as f:
  g=f['collection/geometry_0'];assert np.array_equal(g['vertex'][:],v)
  data={(int(o.attrs['region']),name(o.attrs['name'])):o['values'][:] for o in g['state_0'].values() if 'values' in o and 'region' in o.attrs}
  arrays=[]
  for region,grid in zip(regions,grids):
   ids=np.unique(vtk_to_numpy(grid.GetCells().GetConnectivityArray()))
   a=data[int(region['region'][7:]),field]
   if key=='u':a=np.linalg.norm(a.reshape(-1,3),axis=1)
   a=a.reshape(-1)*scale;assert len(a)==len(ids)
   values=np.zeros(len(pts));values[ids]=a;arrays.append((values,a))
  lo=min(float(a.min()) for _,a in arrays);hi=max(float(a.max()) for _,a in arrays)
  lut=vtk.vtkLookupTable();lut.SetHueRange(.667,0);lut.SetRange(lo,hi);lut.Build()
  for grid,actor,clip,(values,a) in zip(grids,actors,clippers,arrays):
   grid.GetPointData().SetScalars(numpy_to_vtk(values,deep=True));grid.Modified()
   mapper=actor.GetMapper();mapper.SetInputConnection(clip.GetOutputPort());mapper.SetScalarModeToUsePointData();mapper.ScalarVisibilityOn();mapper.SetLookupTable(lut);mapper.SetScalarRange(lo,hi)
   actor.SetVisibility(True);actor.GetProperty().EdgeVisibilityOff()
  frames=[]
  for index,cut in enumerate(cuts):
   z=(high[2]+.02)*(1-cut)+(low[2]+.08*(high[2]-low[2]))*cut
   plane.SetOrigin(0,0,z);ren.ResetCameraClippingRange()
   win.Render();window_image.Modified();window_image.Update()
   raw=vtk_to_numpy(window_image.GetOutput().GetPointData().GetScalars()).reshape(H,W,3)
   frames.append(Image.fromarray(np.flipud(raw).copy()))
  poster=18;frames[poster].save(OUT/(key+'-section.png'))
  frames[0].save(OUT/(key+'-section.gif'),save_all=True,append_images=frames[1:],duration=100,loop=0,optimize=False,disposal=2)
  manifest['fields'][key]={'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'field':field,'range':[lo,hi],'frames':len(frames),'poster_frame':poster,'all_solid_regions_visible':True}
  print('Rendered '+key,flush=True)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
win.Finalize()

