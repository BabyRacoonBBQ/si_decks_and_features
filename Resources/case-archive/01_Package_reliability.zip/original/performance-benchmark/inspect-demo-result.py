from pathlib import Path
import h5py,numpy as np,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
out={}
with h5py.File(r/'demo-coupled-vendor/result_sis.tdr') as f:
    g=f['collection/geometry_0'];s=g['state_0']
    for field in s.values():
        if not isinstance(field,h5py.Group) or 'values' not in field:continue
        name=field.attrs.get('name','');name=name.decode() if isinstance(name,bytes) else str(name)
        if 'Displacement' not in name and 'Stress' not in name:continue
        a=np.asarray(field['values'])
        if not a.size:continue
        row=out.setdefault(name,{'min':float('inf'),'max':-float('inf'),'attributes':{k:str(v) for k,v in field.attrs.items()}})
        row['min']=min(row['min'],float(np.min(a)));row['max']=max(row['max'],float(np.max(a)))
        for child in field.values():
            if isinstance(child,h5py.Group):row[child.name.rsplit('/',1)[-1]]={k:str(v) for k,v in child.attrs.items()}
(r/'demo-mechanics-fields.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
