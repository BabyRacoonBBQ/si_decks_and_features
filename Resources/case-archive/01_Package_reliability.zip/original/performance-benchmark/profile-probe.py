import gdb, struct
active=False
class Done(gdb.FinishBreakpoint):
 def stop(self):
  print('PROBE setParams return eax='+str(gdb.parse_and_eval('$eax')))
  gdb.execute('quit')
  return True
class Entry(gdb.Breakpoint):
 def stop(self):
  global active
  active=True
  print('PROBE setParams entry implicit='+str(gdb.parse_and_eval('$edx')))
  print(gdb.execute('bt 6',to_string=True))
  Done(gdb.newest_frame(),internal=True)
  return False
class Step(gdb.Breakpoint):
 def stop(self):
  p=int(gdb.parse_and_eval('$rsi'))
  data=bytes(gdb.selected_inferior().read_memory(p,0x30))
  print('PROBE AddStep rate,time,start,temperature,final='+str(struct.unpack_from('<5d',data,8)))
  def walk(n):
   if not n:return
   b=bytes(gdb.selected_inferior().read_memory(n,65))
   walk(struct.unpack_from('<Q',b,16)[0])
   s,l=struct.unpack_from('<QQ',b,32)
   print('PROBE option '+bytes(gdb.selected_inferior().read_memory(s,l)).decode()+'='+str(b[64]))
   walk(struct.unpack_from('<Q',b,24)[0])
  root=struct.unpack('<Q',bytes(gdb.selected_inferior().read_memory(p+0xb0,8)))[0]
  walk(root)
  return False
class Rewrite(gdb.Breakpoint):
 def stop(self):
  print('PROBE temperature SetValue '+gdb.parse_and_eval('(char*)$rdx').string())
  return False
Entry('floops::Temp_Ramp::setParams(pdblib::ParamParse&, bool, floops::AnnealStep* (*)())')
Step('floops::Temp_Ramp::AddStep(floops::AnnealStep&)')
if 'sinterconnect_run' not in gdb.current_progspace().filename: Rewrite('*0x17629e1')
for b in gdb.breakpoints():
 if b.pending: raise RuntimeError('unresolved '+b.location)
gdb.execute('run '+('' if 'sinterconnect_run' in gdb.current_progspace().filename else '--noSyntaxCheck ')+'case.cmd > probe-stdout.log 2> probe-stderr.log')


