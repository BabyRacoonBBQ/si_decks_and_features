from pathlib import Path
import json,statistics
r=Path('/home/mozztcad/tmp/package-benchmark-20261010')
data=json.loads((r/'benchmark-results.json').read_text())
v,l=data['summary']['vendor'],data['summary']['local']
lines=['# Package heat-transfer benchmark — StressThermal vs vendor','',
'The repaired Release `sinterconnect_run` completes the selected package heat-transfer case. Performance is reported for this steady thermal deck only; it is not a general product speedup claim. See the run-environment table before interpreting elapsed-time ratios.','',
'## VM and execution boundary','',
'All machine information was collected inside `192.168.43.128`. Rocky Linux 8.10, kernel `4.18.0-553.el8_10.x86_64`, VMware guest, 10 vCPUs, approximately 12.4 GiB RAM. The guest-reported CPU model is Intel Core i7-13700F. No host-machine inventory was collected.','',
'Both binaries run sequentially on guest CPU 4 with `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, a 6 GiB virtual-memory limit, and a 300 s timeout. Measured repetitions alternate execution order: odd-numbered rounds vendor/local, even-numbered rounds local/vendor. Selected round numbers appear in the environment table. Each starts after five 1 s samples with at least 95% guest idle and no swapping. No GDB, Frida, or preload instrumentation is present.','',
'The local binary is CMake Release (`-O3 -DNDEBUG`), built from `4140959ce963437b066e36dcc47703ac609881a1` plus the uncommitted thermal-entry patch. Native timer labels are retained. Vendor runs use `--noSyntaxCheck`; the local runner has no corresponding option. End-to-end startup work is therefore product-specific.','',
'## Deck and mesh','',
'Adapted from `Applications_Library/Backend/Package_ThermomechanicalReliability`. The original thermal stage uses SDevice; this benchmark expresses its package geometry and material context in a SInterconnect thermal deck. It is an adapted engineering example, not an unchanged vendor reference deck.','',
'- 107,792 spatial vertices; 129,399 material nodes reported by both binaries.',
'- 593,869 tetrahedral volume elements: 568,909 solid and 24,960 ambient Gas.',
'- 15 solid regions, 1 Gas region, 7 distinct solid materials.',
'- External mesh retained by `Grid AddGasMesh=0`; mesh generation is excluded from executable timings.',
'- Steady 5 W die power, ambient 300 K, conduction in all solids.',
'- Top Gas-interface radiation, emissivity 0.8; side convection 25 W/(m² K); Copper bottom heat-sink convection 1000 W/(m² K). Radiation and convection act on separate boundary sets.','',
'| Material | Conductivity W/(m K) | Basis |','|---|---:|---|',
'| Silicon | 148 | Benchmark assumption |','| Copper / Copperline | 401 | Package parameter file |','| Solder | 41 | Package parameter file |','| Resin | 0.168 | Package parameter file |','| SmearBeol | 1.5 | Effective BEOL assumption |','| Aluminum | 237 | Benchmark assumption |','',
'The mesh and inputs are identical across each vendor/local pair. The measured exchange files are TDR16 because that is the vendor comparison boundary; this does not validate a GFR export path.','',
'## Native total and inclusive solve timers','',
'Values are medians of three runs. Parenthesized ranges are min–max.','',
'| Metric | Vendor | Release local |','|---|---:|---:|']
for key in ['Elapsed Time','User Time','CPU Time']:
    lines.append(f"| Native {key} (s) | {v['native_timers'][key]:.2f} | {l['native_timers'][key]:.2f} |")
for key,label in [('solve_elapsed','Native inclusive solve (s)'),('external_wall','External wall clock (s)'),('max_rss_kib','Peak RSS (KiB)')]:
    def f(g):
        s=g[key];return f"{s['median']:.2f} ({s['min']:.2f}–{s['max']:.2f})"
    lines.append(f'| {label} | {f(v)} | {f(l)} |')
lines+=['',f"The observed inclusive-solve ratio is {v['solve_elapsed']['median']/l['solve_elapsed']['median']:.3f}× (vendor/local). End-to-end elapsed time also contains startup/waiting and I/O; its ratio must not be described as a solver acceleration.",'',
'## Every reported native module','',
'A final `select max name=Temperature info=3` enables the full native timer report after the simulation and output finish. Both decks contain this same command. Values below are medians in seconds. `0.00` means rounded to native timer resolution, not absent work. Names such as “Mechanics step” are native timer labels; this deck solves thermal physics only.','',
'| Native timer | Vendor CPU | Local CPU | Vendor elapsed | Local elapsed | Calls V / L |','|---|---:|---:|---:|---:|---|']
names=set(v['native_elapsed'])|set(l['native_elapsed'])
for name in sorted(names,key=lambda n:-v['native_elapsed'].get(n,{}).get('median',0)):
    vals=[]
    for group,section in [(v,'native_cpu'),(l,'native_cpu'),(v,'native_elapsed'),(l,'native_elapsed')]:
        x=group[section].get(name); vals.append(f"{x['median']:.2f}" if x else 'not reported')
    calls=[]
    for group in [v,l]:
        values=group['native_elapsed'].get(name,{}).get('calls',[])
        calls.append(str(values[0]) if values and len(set(values))==1 else str(values) if values else 'not reported')
    lines.append('| '+name+' | '+' | '.join(vals)+' | '+' / '.join(calls)+' |')
lines+=['','The detailed stopwatch categories and inclusive `Elapsed time for solve` have different accounting boundaries. Do not add the inclusive timer to its submodules. Native total elapsed time also includes time outside the detailed stopwatch categories.','',
'## Environment for every measured run','',
'`vmstat` is sampled each second; its first cumulative-since-boot row and repeated headers are excluded. Swap amounts below are sums of the 1 s samples in KiB. A strict zero-swap criterion is reported independently rather than silently relaxed.','',
'| Run | Pre-run mean idle % | During mean idle % | Sampled swap in / out KiB | Kernel in / out pages | Strict zero-swap |','|---|---:|---:|---:|---:|---|']
for run in data['runs']:
    b,d=run['before_load'],run['during_load']
    k=run.get('kernel_swap_delta_pages',{})
    lines.append(f"| {run['rep']} {run['kind']} | {b['idle_mean']:.2f} | {d['idle_mean']:.2f} | {d['swap_in_kib']} / {d['swap_out_kib']} | {k.get('pswpin','not recorded')} / {k.get('pswpout','not recorded')} | {run['environment_verdict']} |")
bad=[x for x in data['runs'] if x['environment_verdict']!='VALID_NO_VM_SWAP']
lines+=['',('**Environmental qualification:** Some runs contain guest-wide swap activity, as listed above. These are observational measurements, not a clean zero-swap performance certification. The logs cannot attribute those pages to the solver versus unrelated guest processes. Small performance differences should not be over-interpreted.' if bad else 'All six measured runs passed the strict zero-swap check.'),'',
'Pre-run guest load is the matching criterion. During-run idle averages also include the measured program itself and its startup waits; the higher vendor average does not imply that an unrelated workload was added to the local run.','',
'Earlier warm-up, mesh-calibration, GDB, boundary-control, and cache-pressure runs are excluded. Earlier measurements remain as diagnostic evidence. Read-only eviction of the completed backup archive’s page cache freed approximately 5 GiB without changing archive contents. The user set `vm.swappiness` from 30 to 0 for the rebenchmark, then restored it to 30 after measurement. The restored value was independently read back from `/proc/sys/vm/swappiness`.','',
'## Correctness and physical controls','',
'Each of the three measured fine-mesh pairs has 354 exactly matching numeric field groups, including Temperature, TemperatureGradient and HeatFlux, matching compared topology arrays and field attributes, and no missing/extra fields. Full TDR byte identity is not established: global metadata/provenance and HDF5 storage differ or remain unclassified.','',
'Peak temperature is 489.518175350140 K. The log’s global minimum of 0 K belongs to inactive Gas and must not be interpreted as a physical package temperature.','',
'Vendor-only mechanism controls on the same fine mesh: emissivity zero raises the peak to 491.680426556492 K; removing side and bottom convection raises it to 2484.634597281299 K. The latter is a numerical mechanism check far outside a credible package operating regime. These controls are excluded from timing.','',
'## Thermomechanical continuation and regressions','',
'The SI gate, minimum-deck gate (6/6), transform gate (18/18 plus parameter probes), and init/struct gate (8/8) passed. The full Release build passed, but full CTest passed only 24/34; see `ctest-failures.md` for the 10 unresolved failures. Repository-wide validation is not all green.','',
'The vendor completes a coarser-grid thermomechanical demonstration; local temperature-profile import remains unrecovered. See `continuation-results.md` for the transfer deck, displacement/stress results and limits. The fine-grid mechanical solve exceeded the 6 GiB virtual-memory cap in the vendor and is not presented as successful.','',
'## Reproduction and evidence','',
f'VM evidence root: `{r}`. Local report folder: `C:/Users/Yuanyuan/Desktop/si/architecture-overview/StressThermal/performance-benchmark/`.','',
'- `benchmark-results.json`: every repetition, timer, load statistic, and binary/deck/mesh SHA256.',
'- Measured run directories (absolute paths in `benchmark-results.json`): stdout, stderr, native timers, exit status and load samples.',
'- `package-vendor/case.cmd`, `mesh-package-final/`: deck, material definitions, geometry and measured mesh.',
'- `formal-detailed.py`, `run-final-case.sh`: sequential measurement procedure.',
'- `thermal-recovery/`: binary-probing evidence, Release build/regression logs and uncommitted repair patch.',
'- `thermal-repair-report.md`: repair scope and unverified branches.','']
(r/'package-heat-benchmark.md').write_text('\n'.join(lines))
print(r/'package-heat-benchmark.md')
