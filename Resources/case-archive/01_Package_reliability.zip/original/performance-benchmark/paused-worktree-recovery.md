# Paused info2 worktree recovery

Thread remains paused: `codex://threads/01a0b261-ba0c-7df3-9253-532c450388ea`.

Remote repository: https://cnb.cool/s_project/geo3d

Verified backup branch: `backup/paused-info2-20261010-4e9f269d`

Verified commit: `4e9f269d8ad0cbc21f5b24f8576bbc7171a56b8b`

Original remote branch was not modified. Local worktree `/home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2` and local branch `codex/recover-3d-interconnect-info2` were removed only after successful remote verification and full archive comparison. No integration or new regression-pass claim is made for this WIP checkpoint.

Full pre-checkpoint working-directory archive, including untracked evidence and ignored build artifacts (excluding the linked-worktree `.git` pointer):

`/home/mozztcad/tmp/paused-info2-20261010/worktree.tar.gz`

SHA256: `64b818b33918e494c2b0fa79ec96d7bd8cde95e0ee30bdbd38ca19ab562f3cf6`

Archive size: 7,294,572,067 bytes. The archive is local to the VM, not on the Git remote. Do not delete it if those artifacts are needed. `tar --diff` against the original worktree completed successfully before removal. Remote code checkpoint includes the newly added pause handoff that postdates the archive.

VM /home free space after cleanup: 76 GiB. Approximately 10 GiB net space reclaimed after retaining the full compressed archive.

## Restore when the user resumes the paused thread

Run on the VM; confirm the destination path does not already exist first:

```bash
git -C /home/mozztcad/geo3d fetch origin refs/heads/backup/paused-info2-20261010-4e9f269d
git -C /home/mozztcad/geo3d worktree add -b codex/recover-3d-interconnect-info2 /home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2 FETCH_HEAD
sha256sum -c /home/mozztcad/tmp/paused-info2-20261010/archive.sha256
tar -xzf /home/mozztcad/tmp/paused-info2-20261010/worktree.tar.gz -C /home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2
git -C /home/mozztcad/geo3d-worktrees/recover-3d-interconnect-info2 status --short
```

Full operation record: `/home/mozztcad/tmp/paused-info2-20261010/cleanup-complete.json`.
