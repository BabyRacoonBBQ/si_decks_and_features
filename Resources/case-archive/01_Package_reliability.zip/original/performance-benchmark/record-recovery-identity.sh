#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
{
 git branch --show-current
 git rev-parse HEAD
 git status --short
 git diff --stat
 rg 'CMAKE_BUILD_TYPE:|CMAKE_CXX_FLAGS_RELEASE:|RECON_BISECT:' build/CMakeCache.txt
 for b in build/sinterconnect_run build/geo_run build/libbrep_recon.so; do
  realpath "$b"
  stat -c 'bytes=%s mtime=%y' "$b"
  sha256sum "$b"
  file "$b"
  readelf -n "$b" | rg 'Build ID' || true
 done
 ldd build/sinterconnect_run
 cat build/CMakeFiles/sinterconnect_run.dir/link.txt
} > "$r/latest-build-identity.txt"
git diff > "$r/recovery.patch"
