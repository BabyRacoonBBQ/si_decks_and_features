#!/bin/bash
set -eu
root=/home/mozztcad/tmp/package-benchmark-20261010
rec=$root/thermomechanical-recovery
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 3600 9
ulimit -v 6291456
for kind in vendor local; do
 dir=$root/e2e-lifecycle-$kind
 mkdir "$dir"
 cp "$root/demo-thermal-$kind/"{case.cmd,datexcodes.txt} "$dir/"
 cd "$dir"
 bin=/home/mozztcad/geo3d/build/sinterconnect_run
 if [ "$kind" = vendor ]; then bin=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect; fi
 sha256sum "$bin" case.cmd datexcodes.txt ../mesh-roof/package_msh.tdr "$rec/probe-thermal-lifecycle.py" > identities.sha256
 timeout -k 10 200 taskset -c 4 gdb -q -batch -ex 'set pagination off' -ex 'set confirm off' -ex 'set breakpoint pending off' -ex "source $rec/probe-thermal-lifecycle.py" --args "$bin" > probe.log 2>&1
 test -f lifecycle.json
 tail -3 probe.log
 done
