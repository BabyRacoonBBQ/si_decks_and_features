"""Exploded display of original TDR regions, without synthetic CAD geometry.

Reference: https://github.com/pyvista/pyvista (actor transforms / MultiBlock).
Uses its underlying VTK actor-position approach; source nodes remain unchanged.
"""
from pathlib import Path
exec(Path(__file__).with_name('render-package-animation.py').read_text().split('start=time.time();samples=')[0])
W,H=1000,680
win.SetSize(W,H);ren.SetViewport(0,0,1,1)
OUT=ROOT/'exploded-visualization';OUT.mkdir(exist_ok=True)
original_points=pts.copy()
span=float(max(high-low))
offsets={'Copper':(0,0,0),'Solder':(0,0,.13*span),
 'Silicon':(0,0,.36*span),'SmearBeol':(0,0,.57*span),
 'Aluminum':(0,0,.68*span),'Copperline':(0,0,.85*span),
 'Resin':(.65*span,-.92*span,.22*span)}
all_bounds=[]
for grid,actor,region in zip(grids,actors,regions):
 actor.GetMapper().SetInputData(grid)
 actor.GetProperty().EdgeVisibilityOff()
 ids=np.unique(vtk_to_numpy(grid.GetCells().GetConnectivityArray()))
 xyz=pts[ids];delta=np.array(offsets[region['material']])
 region['display_translation_mm']=delta.tolist()
 region['source_bounds_mm']=[xyz.min(0).tolist(),xyz.max(0).tolist()]
 all_bounds.extend([xyz.min(0),xyz.max(0),xyz.min(0)+delta,xyz.max(0)+delta])
bounds=np.array(all_bounds);aim=(bounds.min(0)+bounds.max(0))/2
theta=math.radians(35);elev=math.radians(23)
camera.SetPosition(*(aim+span*5*np.array([math.cos(theta)*math.cos(elev),math.sin(theta)*math.cos(elev),math.sin(elev)])))
camera.SetFocalPoint(*aim);camera.SetViewUp(0,0,1);camera.ParallelProjectionOn()
camera.SetParallelScale(span*.82)
caption=add_text('Original package',26,12,30,bold=True)
labels=[]
for material,label in [('Resin','Resin'),('Silicon','Silicon die'),('Copper','Cu frame'),('Solder','Solder'),('SmearBeol','BEOL'),('Aluminum','Aluminum'),('Copperline','Cu wires')]:
 ids=np.concatenate([np.unique(vtk_to_numpy(g.GetCells().GetConnectivityArray())) for g,r in zip(grids,regions) if r['material']==material])
 xyz=pts[ids];anchor=(xyz.min(0)+xyz.max(0))/2+np.array(offsets[material])
 actor=add_text(label,0,0,25,COLORS[material],True)
 # Darken light material labels for readability.
 if material in ('Resin','Aluminum','Solder'):actor.GetTextProperty().SetColor(.2,.28,.34)
 labels.append((actor,anchor,material))
def frame(t):
 for actor,region in zip(actors,regions):
  actor.SetPosition(*(t*np.array(offsets[region['material']])))
 caption.SetInput('Exploded view' if t>.01 else 'Original package')
 ren.ResetCameraClippingRange();win.Render()
 for actor,anchor,material in labels:
  actor.SetVisibility(t>.98)
  ren.SetWorldPoint(*anchor,1);ren.WorldToDisplay();x,y,_=ren.GetDisplayPoint()
  # Labels sit outside the parts; never overlay the silicon surface.
  actor.SetPosition(x+105 if material!='Resin' else max(20,x-70),y-5)
  if material=='Copperline':actor.SetPosition(810,H-130)
  if material=='Copper':actor.SetPosition(800,35)
  if material in ('Copperline','Copper'):
   actor.GetTextProperty().SetColor(.09,.18,.26)
 win.Render();window_image.Modified();window_image.Update()
 raw=vtk_to_numpy(window_image.GetOutput().GetPointData().GetScalars()).reshape(H,W,3)
 return Image.fromarray(np.flipud(raw).copy())
frame(0).save(OUT/'assembled.png')
frame(1).save(OUT/'package-exploded.png')
if '--preview' not in sys.argv:
 # Include the two transition endpoints: (25 + 2) * 3 = 81 frames at full expansion.
 ts=[0.]*10+[smooth(i/29) for i in range(30)]+[1.]*79+[1-smooth(i/29) for i in range(30)]+[0.]*5
 frames=[frame(t) for t in ts]
 palette=frames[40].quantize(colors=256,method=Image.Quantize.MEDIANCUT)
 quant=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in frames]
 quant[0].save(OUT/'package-exploded.gif',save_all=True,append_images=quant[1:],duration=100,loop=0,optimize=False,disposal=2)
 assert np.array_equal(pts,original_points)
 manifest={'input':str(INPUT),'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
  'renderer':'VTK '+vtk.vtkVersion.GetVTKVersion(),'reference':'https://github.com/pyvista/pyvista',
  'regions':regions,'vertices':len(pts),'solid_tetrahedra':total-gas,'source_nodes_unchanged':True,
  'semantics':'Every displayed body consists of original TDR tetrahedra. No new part, remeshing, clipping or geometry scaling. Gas hidden. Rigid actor translations only; separation distances are illustrative, not physical deformation or a disassembly procedure.',
  'frames':len(ts),'duration_ms':len(ts)*100}
 (OUT/'exploded-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'output':str(OUT),'regions':regions}),flush=True)
win.Finalize()

