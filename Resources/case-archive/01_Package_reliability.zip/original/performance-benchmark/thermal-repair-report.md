# Thermal entry recovery — validation record

Worktree: `/home/mozztcad/geo3d`, branch `main`, base commit `4140959ce963437b066e36dcc47703ac609881a1`. Changes remain uncommitted. The paused recovery worktree has not been resumed.

The repaired Release executable completes the steady thermal package case locally. On the 107,792-point mesh, all 354 compared field groups are numerically exact against the vendor output, including Temperature, TemperatureGradient, and HeatFlux. Compared topology arrays and field attributes match. The complete TDR files are **not byte-identical**; global tags, provenance, and HDF5 storage differences have not been fully classified.

This verifies this steady, single-physics thermal path. It does not establish recovery of transient thermal ramps, simultaneous coupled modes, or every vendor execution branch.

| File | Proven problem | Change and evidence |
|---|---|---|
| `src/abi/sinterconnect/SolveController.cpp` | The shared process build admitted mechanics/electrostatic only. | Route pure thermal through the existing complete structure/supply/ramp preparation body. Vendor SI `prepareStructure` is at `0x1222820`, size `0x180e`; captured callbacks include `preProcessStructure` and `preProcessSupplyContact`. Other unverified mode combinations still fail explicitly. |
| `src/abi/floops/floops/Controller.cpp` | `needPDESolve` stopped at the first inactive generic solution. The local field stayed at 300 K while the vendor heated the package. | Continue scanning until any generic solution needs solving. Vendor instructions `0x17251be–0x17251ef` establish this loop. GDB initially recorded vendor return 1 versus local return 0 with matching manager flags. |
| `src/abi/floops/floops/Time_TRBDF.cpp` | All thermal calls were rejected before the already implemented matrix/Newton path. | Admit only verified steady thermal solves without ramps. Vendor SI `Time_TRBDF::Solve` starts at `0x1770690`; thermal-specific branches suppress imposed-temperature updates. Transient thermal paths remain guarded. |
| `src/abi/floops/floops/TdrWriterUtils.cpp` | Output rejected `K*cm^-1`, then `W*cm^-2`. | Restore `K*cm^-1`, `W*cm^-2`, and `W*cm^-3` metadata from vendor TDR output. Preserve the vendor's zero exponent array for the two named watt-based compound units rather than substituting inferred dimensions. |

Build: existing CMake Release target `sinterconnect_run`, `-O3 -DNDEBUG`, incremental builds with two jobs. Timed runs have no GDB, Frida, or preload observer. No vendor executable or installation file was modified.

Existing SI regression: `scripts/verify_si.sh` passed, including cantilever and inverter. Shared-code regressions also passed: `scripts/verify.sh --min` 6/6, `verify_transform.sh --no-build` SyntaxCheck/formal probes plus 18/18 TDR16 cases, and `verify_init_struct.sh --no-build` 8/8. `git diff --check` and the full Release build passed. Full CTest passed 24/34; the 10 unresolved failures are documented in `ctest-failures.md`. Repository-wide validation is not all green.

Early diagnostic runs that automatically regenerated a coarse mesh are excluded from benchmark results. Those trials also exposed Gas-interface and ill-conditioned gradient differences. Retaining the externally generated mesh produced exact fields on both the 17,171-point and 107,792-point meshes.

Evidence directory: `/home/mozztcad/tmp/package-benchmark-20261010/thermal-recovery/`.

- `prepareStructure.asm`, `solve_tcl.asm`, `TRBDF.asm`: vendor static evidence.
- `vendor-entry/probe.log`: structure-preparation runtime evidence.
- `pde-vendor/probe.log`, `pde-local/probe.log`: first PDE-entry divergence.
- `build-*.log`, `verify-si.log`: build and SI regression results.
- `repair.patch`, `repaired-binary.sha256`: changes and binary identity.
- Parent `package-comparison.json`, `formal-field-comparison.json`: numeric/topology/field-attribute comparisons.

The diagnostic breakpoint coverage is partial; full call-tree equivalence has not been claimed.
