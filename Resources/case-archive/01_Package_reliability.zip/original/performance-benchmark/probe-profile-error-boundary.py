import gdb,json,struct
from pathlib import Path
records=[]; interp=None

def q(p):return struct.unpack('<Q',bytes(gdb.selected_inferior().read_memory(p,8)))[0]
def reg(n):return int(gdb.parse_and_eval('$'+n))
def s(p):return gdb.Value(p).cast(gdb.lookup_type('char').pointer()).string() if p else None
def result():
 if not interp:return None
 legacy=s(q(interp))
 return legacy or s(q(q(interp+0x2a8)+8))
class End(gdb.FinishBreakpoint):
 def __init__(self,k):super().__init__(gdb.newest_frame(),internal=True);self.k=k
 def stop(self):
  records.append({'event':self.k+' return','code':reg('eax'),'result':result()})
  return False
class BP(gdb.Breakpoint):
 def __init__(self,sym,k):super().__init__(sym);self.k=k
 def stop(self):
  global interp
  if self.k=='check':interp=q(reg('rsi'))
  records.append({'event':self.k+' entry','result':result()})
  End(self.k)
  return False
BP('sinterconnect::SolveCmd::solveErrorCheck(pdblib::ParamParse&, pdblib::TclInterp_cl&)','check')
BP('sinterconnect::SolveCmd::solve_tcl(int, char**, pdblib::ParamParse&)','solve')
if 'sinterconnect_run' in gdb.current_progspace().filename:
 BP('(anonymous namespace)::SolveTemporaryPdbCleanup::~SolveTemporaryPdbCleanup() [clone .part.0]','cleanup')
for bp in gdb.breakpoints():
 if bp.pending:raise RuntimeError('unresolved '+bp.location)
vendor='sinterconnect_run' not in gdb.current_progspace().filename
gdb.execute('run '+('--noSyntaxCheck ' if vendor else '')+'case.cmd > product.stdout 2> product.stderr')
if gdb.selected_inferior().pid:raise RuntimeError('inferior still alive')
Path('error-boundary.json').write_text(json.dumps(records,indent=2))
print('ERROR_BOUNDARY '+json.dumps(records))
