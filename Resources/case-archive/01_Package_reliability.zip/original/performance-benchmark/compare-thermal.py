import hashlib,json,sys
from pathlib import Path
import h5py,numpy as np
a,b=map(Path,sys.argv[1:3])
report={'reference':str(a),'candidate':str(b),'fields':{},'topology_differences':[],'metadata_differences':[]}
rawa,rawb=a.read_bytes(),b.read_bytes()
report['raw']={'reference_size':len(rawa),'candidate_size':len(rawb),'reference_sha256':hashlib.sha256(rawa).hexdigest(),'candidate_sha256':hashlib.sha256(rawb).hexdigest(),'identical':rawa==rawb,'first_difference':next((i for i,(x,y) in enumerate(zip(rawa,rawb)) if x!=y),None),'differing_bytes':sum(x!=y for x,y in zip(rawa,rawb))+abs(len(rawa)-len(rawb))}
def fields(f):
 result={}
 for geom in f['collection'].values():
  if not isinstance(geom,h5py.Group) or not geom.name.rsplit('/',1)[-1].startswith('geometry_'):continue
  for state in geom.values():
   if not isinstance(state,h5py.Group) or not state.name.rsplit('/',1)[-1].startswith('state_'):continue
   for obj in state.values():
    if isinstance(obj,h5py.Group) and 'values' in obj:
     name=obj.attrs['name'];name=name.decode() if isinstance(name,bytes) else str(name)
     key=f"{geom.name}/{state.name.rsplit('/',1)[-1]}/{obj.attrs.get('region',-1)}/{name}"
     result[key]=obj
 return result
with h5py.File(a) as fa,h5py.File(b) as fb:
 af,bf=fields(fa),fields(fb)
 report['missing_fields']=sorted(set(af)-set(bf));report['extra_fields']=sorted(set(bf)-set(af))
 for key in sorted(set(af)&set(bf)):
  x,y=np.asarray(af[key]['values']),np.asarray(bf[key]['values'])
  item={'shape_match':x.shape==y.shape}
  if item['shape_match']:
   delta=np.abs(x.astype(float)-y.astype(float));scale=max(float(np.max(np.abs(x))),1e-300)
   item.update(exact=bool(np.array_equal(x,y)),max_abs=float(np.max(delta)),relative_to_max=float(np.max(delta))/scale,reference_min=float(np.min(x)),reference_max=float(np.max(x)))
  report['fields'][key]=item
  for attr in set(af[key].attrs)|set(bf[key].attrs):
   if attr not in af[key].attrs or attr not in bf[key].attrs or not np.array_equal(af[key].attrs[attr],bf[key].attrs[attr]):report['metadata_differences'].append([key,attr])
 def topo(name,obj):
  if isinstance(obj,h5py.Dataset) and '/state_' not in name and ('/vertex' in name or '/elements' in name):
   if name not in fb or not np.array_equal(obj[()],fb[name][()]):report['topology_differences'].append(name)
 fa.visititems(topo)
report['max_field_abs']=max((x.get('max_abs',float('inf')) for x in report['fields'].values()),default=None)
out=Path(sys.argv[3]);out.write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='fields'},indent=2))
print('field_groups',len(report['fields']))
for name in ['Temperature','TemperatureGradient','HeatFlux']:
 rows=[v for k,v in report['fields'].items() if k.endswith('/'+name)]
 print(name,'max_abs',max((v.get('max_abs',float('inf')) for v in rows),default=None),'max_relative',max((v.get('relative_to_max',float('inf')) for v in rows),default=None))
