from pathlib import Path
import shutil,subprocess,hashlib,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010').resolve()
repo=Path('/home/mozztcad/geo3d').resolve()
src=repo/'.local/verification/syntaxcheck/transform'
dst=r/'thermal-recovery/transform-verification'
assert src.resolve().is_relative_to(repo) and dst.resolve().is_relative_to(r)
if src.exists():
    if dst.exists():raise RuntimeError('Evidence destination already exists; not replacing it')
    shutil.move(str(src),str(dst))
# Other pre-existing .local data, including doping evidence, is untouched.
diff=subprocess.check_output(['git','-C',str(repo),'diff'])
(r/'thermal-recovery/repair.patch').write_bytes(diff)
status=subprocess.check_output(['git','-C',str(repo),'status','--short'],text=True)
(r/'thermal-recovery/final-status.txt').write_text(status)
sha=hashlib.sha256((repo/'build/sinterconnect_run').read_bytes()).hexdigest()
timed=(r/'sw0-r1-local/identities.sha256').read_text().split()[0]
out={'source_status':status,'final_binary_sha256':sha,'timed_binary_sha256':timed,'binary_unchanged_after_tests':sha==timed,'swappiness_restored':int(Path('/proc/sys/vm/swappiness').read_text()),'transform_evidence_moved_to':str(dst)}
(r/'final-verification.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
