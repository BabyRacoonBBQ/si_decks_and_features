from pathlib import Path
p=Path('/home/mozztcad/geo3d/src/abi/floops/floops/Initialize.cpp');s=p.read_text()
a='''        params.scale = 10000.0;
        params.pdb = true;'''
b='''        params.scale = 10000.0;
        // SI init !pdb must not import persisted solver/material state.
        // Package init-state probes locate the first divergence at this gate.
        const bool isSinterconnectTool =
            floops::_globalPool->jobInfo->getToolName() == VOF_STR("SINTERCONNECT");
        params.pdb = isSinterconnectTool
            ? parser.BooleanLookup(VOF_STR("pdb")) : true;'''
assert s.count(a)==1;s=s.replace(a,b)
a='''    const bool discardLoadedPdb =
        parser.isSpecified(VOF_STR("pdb")) && !parser.BooleanLookup(VOF_STR("pdb"));'''
b='''    // SI's reader honors !pdb directly. The non-SI legacy read/restore
    // path must not clear the SI deck's existing material modification state.
    const bool discardLoadedPdb =
        floops::_globalPool->jobInfo->getToolName() != VOF_STR("SINTERCONNECT")
        && parser.isSpecified(VOF_STR("pdb"))
        && !parser.BooleanLookup(VOF_STR("pdb"));'''
assert s.count(a)==1;s=s.replace(a,b)
a='''            // SI preserves material/interface Like modification state across
            // 3D init !pdb (package init-likes-v2 vendor/local probe). The
            // existing sprocess 3D adaptive-flip persistence path is separate.
            if (fieldServer->dimension == 3 && !isSinterconnectTool) {'''
assert s.count(a)==1;s=s.replace(a,'''            if (fieldServer->dimension == 3) {''')
p.write_text(s)
e=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
(e/'pdb-gate-diagnosis.md').write_text('''# SI init !pdb input-state gate
init-state probes: both binaries have absent Compute/Converged and Math/Internal.FTS.NegErrCntrl at startup and immediately before init. Only local has their stored thermal-file values after init. init-likes-v2 shows Resin_SmearBeol Like=Nitride_Resin before init in both; local imports Copper_SmearBeol after init, vendor preserves Nitride_Resin. These agree with the input-file state. Source nativeInitReaderParams forcibly sets params.pdb=true for every non-RCFX tool, including SI. Tdr_reader::read then calls ReadModifiedParams under params.pdb. A later discardLoadedPdb cleanup only resets modification bookkeeping; it cannot undo imported live values.

Repair batch: SI reader takes the parsed pdb option; SI no longer uses the legacy load-then-cleanup workaround. The earlier retained-Like special case is removed because the root fix preserves original state without clearing it. sprocess and RCFX paths are unchanged. No layout, ownership, or output filtering change. Requires matched full package and init-state reruns plus shared regressions.
''')
