from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
probe='''
proc flagState {label} {
 puts "FLAGSTATE $label"
 foreach pair {{Params&Compute Converged} {Params&Compute Modify} {Params&Math Internal.FTS.NegErrCntrl} {Params&Math Modify} {Params Compute&Converged} {Params Math&Internal.FTS.NegErrCntrl}} {
  lassign $pair a k
  if {[info exists ::${a}($k)]} {puts "FLAG $a $k [set ::${a}($k)]"} else {puts "FLAG $a $k ABSENT"}
 }
}
'''
s=(r/'initial-local/case.cmd').read_text()
s=probe+s
s=s.replace('mode mechanics','flagState before-mode\nmode mechanics\nflagState before-solve')
s=s.replace('puts "COUPLED_TMAX','flagState after-solve\nputs "COUPLED_TMAX')
for kind in ['vendor','local']:
 d=r/('solve-flags-'+kind);d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(s)
 for f in ['settings.cmd','mp.cmd','datexcodes.txt']:(d/f).write_bytes((r/'initial-local'/f).read_bytes())
