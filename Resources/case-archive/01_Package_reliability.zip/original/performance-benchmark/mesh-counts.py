import h5py,json,sys
from pathlib import Path
p=Path(sys.argv[1])
with h5py.File(p) as f:
 g=f['collection/geometry_0'];rows=[]
 for key,r in g.items():
  if key.startswith('region_') and int(r.attrs.get('type',-1))==0:
   count=sum(int(v.attrs.get('number of elements',0)) for n,v in r.items() if n.startswith('elements'))
   rows.append({'region':key,'name':str(r.attrs.get('name')),'material':str(r.attrs.get('material')),'attributes':{k:str(v) for k,v in r.attrs.items()},'elements':count,'datasets':{n:list(v.shape) for n,v in r.items() if isinstance(v,h5py.Dataset)}})
 print(json.dumps({'path':str(p),'vertices':int(g.attrs['number of vertices']),'bulk_regions':rows},indent=2))
