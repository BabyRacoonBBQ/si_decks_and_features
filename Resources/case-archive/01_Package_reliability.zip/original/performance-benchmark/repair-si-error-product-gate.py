from pathlib import Path
r=Path('/home/mozztcad/geo3d')
p=r/'src/abi/floops/floops/FLPS.cpp';s=p.read_text()
a='''{
    const bool interconnect = floops::_globalPool'''
b='''{
#if RECON_SPROCESS
    const bool interconnect = floops::_globalPool'''
assert s.count(a)==1;s=s.replace(a,b)
a='''        FLPS_exit(EXIT_FAILURE);
    }
#if RECON_SPROCESS
    writeDiagnostic'''
b='''        FLPS_exit(EXIT_FAILURE);
    }
#endif
#if RECON_SPROCESS
    writeDiagnostic'''
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
p=r/'src/abi/floops/floops/FloopsCmd.cpp';s=p.read_text()
a='''    int result;
    try {''';b='''    int result;
#if RECON_SPROCESS
    try {'''
assert s.count(a)==1;s=s.replace(a,b)
a='''        FLPS_exit(1);
    }

    //''';b='''        FLPS_exit(1);
    }
#else
    result = cmd->second(argc, const_cast<char**>(argv), parser);
#endif

    //'''
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
e=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(e/'build-all-error-boundaries.sh').read_text().replace('build-all-error-boundaries.log','build-all-error-boundaries-v2.log')
(e/'build-all-error-boundaries-v2.sh').write_text(s)
