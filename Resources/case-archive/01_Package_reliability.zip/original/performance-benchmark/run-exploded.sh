#!/bin/bash
set -e
cd /home/mozztcad/tmp/package-benchmark-20261010/demo-thermal-vendor
Xvfb :97 -screen 0 1000x680x24 > exploded-xvfb.log 2>&1 &
render_display_pid=$!
trap 'kill "$render_display_pid" 2>/dev/null || true' EXIT
sleep 1
DISPLAY=:97 PYTHONNOUSERSITE=1 python3 render-package-exploded.py "$@"
