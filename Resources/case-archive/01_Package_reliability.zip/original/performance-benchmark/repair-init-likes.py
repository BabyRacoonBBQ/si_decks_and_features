from pathlib import Path
r=Path('/home/mozztcad/geo3d');p=r/'src/abi/floops/floops/Initialize.cpp'
s=p.read_text()
a='''        for (const auto& entry : retainedLikeParams) {
            if (fieldServer->dimension == 3) {
                break;
            }'''
b='''        for (const auto& entry : retainedLikeParams) {
            // SI preserves material/interface Like modification state across
            // 3D init !pdb (package init-likes-v2 vendor/local probe). The
            // existing sprocess 3D adaptive-flip persistence path is separate.
            if (fieldServer->dimension == 3 && !isSinterconnectTool) {
                break;
            }'''
assert s.count(a)==1
p.write_text(s.replace(a,b))
e=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
(e/'init-like-diagnosis.md').write_text('''# Init Like-state divergence
Matched init-likes-v2 probes show Params&AlGaN_Copperline Like=AlGaN_Copper, Modify=Like before init in both binaries. After init !load.commands !pdb, vendor retains Modify=Like while local clears it. Representative of the 251 missing Like output tags; compare all tags after repair. Minimal material-tags and material-save probes already showed creation and save callback input equivalence for Like keys before init. First init-likes probe had a Tcl local/global scoping error and supplies no valid state evidence.
Source cause: Initialize.cpp discards retainedLikeParams whenever dimension==3, inherited from sprocess adaptive-flip commit dc6ee594eb. Repair limits that existing skip to non-SI, preserving SI Like state via the existing setModifiedParameter path. No layout or ownership changes. Shared geo_run is rebuilt; sprocess branch is unchanged but mandatory regressions remain required.
''')
