from pathlib import Path
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
s=(r/'run-profile-case.sh').read_text().replace('flock -w 30 9','echo "WAITING_FOR_HEAVY_LOCK $(date -u +%FT%TZ)"\nflock -w 600 9 || { echo LOCK_TIMEOUT; exit 75; }\necho "ACQUIRED_HEAVY_LOCK $(date -u +%FT%TZ)"')
(r/'run-profile-case-queued.sh').write_text(s)
