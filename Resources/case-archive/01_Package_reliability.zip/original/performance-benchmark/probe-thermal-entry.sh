#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/package-benchmark-20261010
mkdir -p "$root/thermal-recovery/vendor-entry"
cd "$root/thermal-recovery/vendor-entry"
cp "$root/vendor-smoke/datexcodes.txt" .
sed 's|../mesh-coarse/|../../mesh-coarse/|;s/57142.857142857<W\/cm3>/5714.2857142857/' "$root/vendor-smoke/case.cmd" > case.cmd
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
set +e
timeout -k 10 180 taskset -c 4 gdb -q -batch -x "$root/probe-thermal-entry.gdb" --args /home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect --noSyntaxCheck case.cmd > probe.log 2>&1
result=$?
echo "$result" > exit.txt
tail -12 probe.log
exit "$result"
