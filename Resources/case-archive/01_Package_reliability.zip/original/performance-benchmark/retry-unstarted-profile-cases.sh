#!/bin/bash
set -u
r=/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery
for label in uniform missing conflict no-time; do
 if [ -f "$r/final-$label-local/exit.txt" ]; then echo "already executed: $label";continue;fi
 bash "$r/run-profile-case-queued.sh" local "final-$label" > "$r/final-$label-retry.log" 2>&1
 echo "$label runner_exit=$?"
done
