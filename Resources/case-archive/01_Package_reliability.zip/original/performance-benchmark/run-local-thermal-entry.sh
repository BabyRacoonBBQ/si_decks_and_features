#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/package-benchmark-20261010
mkdir -p "$root/thermal-recovery/local-entry"
cd "$root/thermal-recovery/local-entry"
cp ../vendor-entry/datexcodes.txt ../vendor-entry/case.cmd .
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
set +e
/usr/bin/time -v timeout -k 10 180 taskset -c 4 /home/mozztcad/geo3d/build/sinterconnect_run case.cmd > stdout.log 2> stderr.log
result=$?
echo "$result" > exit.txt
tail -20 stdout.log
head -10 stderr.log
exit "$result"
