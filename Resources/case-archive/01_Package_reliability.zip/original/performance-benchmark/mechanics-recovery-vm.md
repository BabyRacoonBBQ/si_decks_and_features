# Mechanics recovery report — VM only

Date: 2026-10-12
VM: mozztcad@192.168.43.128
Repository: /home/mozztcad/geo3d
Deck: /home/mozztcad/tmp/local-mechanics/linear-buckling/case.cmd
Release binary: /home/mozztcad/geo3d/build/sinterconnect_run
Release SHA-256: 9129774b230a3b6829a02e2f2373bb7fe5d8e5cf49ea289eb514b63dc1d3cf4e
Final TDR SHA-256: 60d2f81ac30f6975bb0f1578acc3eb791abc992d29452a917f5af691a81b1f13

## Recovery

Vendor probing/decompilation established generalized buckling mode 2: the operator applies the geometric-stiffness matrix through the inverse ordinary stiffness matrix, and the reported critical load is the reciprocal of the internal eigenvalue. The local arpack_gv path now follows that convention. The inverse solve uses the existing VM Pardiso implementation; a small MKL generalized Ritz solve completes the requested mode extraction. Temporary CSR and element diagnostics were removed before the final build.

## Clean verification

The final VM Release run completed with one expected deck warning (No time has been specified. Only elastic solve will be done.) and reported:

- Mode 1 critical load: 71.7609
- Mode 2 critical load: 71.7609
- Mode 3 critical load: 609.8

These values match the vendor report for the same deck. The vendor/local TDR comparison has no missing or extra field groups. Displacement, temperature, stress, strain, energy, and auxiliary fields are exact or at machine precision. Buckling mode vectors are allowed to differ by sign/rotation within the degenerate first two modes and by normalization; their critical values match.

The existing mechanics GIFs were intentionally left unchanged, per request.
