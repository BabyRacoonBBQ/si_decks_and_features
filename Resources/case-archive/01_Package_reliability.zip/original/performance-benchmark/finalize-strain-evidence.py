from pathlib import Path
import json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
p=r/'thermal-strain-comparison.json';x=json.loads(p.read_text())
assert [e['mapping_epoch'] for e in x['vendor']]==[1,2,3,4]
x['coverage']='One representative Copper volume element after each of the four mapped-temperature updates. The initially armed probe had no pre-mapping hit. This is not an all-integration-point trace. In the exercised small-deformation path, the thermal-strain contribution is the input buffer minus the output buffer.'
for e in x['vendor']:
 expected=e['alpha_base']*(e['current_temperature']-e['previous_temperature'])
 assert e['thermal_strain_contribution']==[expected,expected,expected,0.0,0.0,0.0]
x['isotropic_increment_formula_exact']=True;p.write_text(json.dumps(x,indent=2))
p=r/'verification-summary.json';s=json.loads(p.read_text());s['thermal_strain']=x;s['mapping_build_note']='Both the final eight-case matrix and the final strain/mapping probe use the final Release executable; earlier v2 evidence is retained as a checkpoint.'
expected=(r/'final-build.sha256').read_text().split()[0]
assert (r/'strain-local/identities.sha256').read_text().split()[0]==expected
p.write_text(json.dumps(s,indent=2))
print('Thermal-strain increment = alpha * delta T: exact in all four sampled steps')
