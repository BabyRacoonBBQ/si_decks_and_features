from pathlib import Path
import re,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
p=r/'final-regressions/ctest.log';s=p.read_text(errors='replace')
latest=re.findall(r'^\s*(\d+) - ([^\n]+)',s.split('The following tests FAILED:')[-1],re.M)
prior=json.loads((r/'regressions/ctest-comparison.json').read_text())
x={'current_failures':latest,'same_as_thermal_checkpoint':latest==[tuple(t) for t in prior['thermal_checkpoint']],'same_as_coupling_core_checkpoint':latest==[tuple(t) for t in prior['thermomechanical']],'qualification':'No pristine-HEAD rebuild; this compares observed checkpoints only.'}
assert len(latest)==10 and x['same_as_thermal_checkpoint'] and x['same_as_coupling_core_checkpoint']
(r/'final-regressions/ctest-comparison.json').write_text(json.dumps(x,indent=2))
s=json.loads((r/'verification-summary.json').read_text());s['final_regression_exits']=dict(line.split('=') for line in (r/'final-regressions/exits.txt').read_text().splitlines());s['ctest_comparison']=x
(r/'verification-summary.json').write_text(json.dumps(s,indent=2))
print(s['final_regression_exits']);print('CTest: same 10 failed tests as both previous checkpoints')
