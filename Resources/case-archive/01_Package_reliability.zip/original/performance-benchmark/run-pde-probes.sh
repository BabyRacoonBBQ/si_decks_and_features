#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/package-benchmark-20261010
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
for kind in vendor local; do
 mkdir -p "$root/thermal-recovery/pde-$kind"
 cd "$root/thermal-recovery/pde-$kind"
 cp ../vendor-entry/datexcodes.txt ../vendor-entry/case.cmd .
 binary=/home/mozztcad/geo3d/build/sinterconnect_run
 extra=()
 if [ "$kind" = vendor ]; then
  binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
  extra=(--noSyntaxCheck)
 fi
 set +e
 timeout -k 10 150 taskset -c 4 gdb -q -batch -x "$root/probe-thermal-pde.gdb" --args "$binary" "${extra[@]}" case.cmd > probe.log 2>&1
 result=$?
 set -e
 echo "$result" > gdb-exit.txt
 grep 'PROBE' probe.log || tail -8 probe.log
done
