# VM-rendered package visualization

The delivered GIF is rendered and encoded on `mozztcad@192.168.43.128` from the existing `demo-thermal-vendor/result_sis.tdr`. The simulation is not rerun and the TDR is unchanged.

- VM GIF: `/home/mozztcad/tmp/package-benchmark-20261010/demo-thermal-vendor/package-mesh-rotation-section.gif`
- VM renderer and runner: `render-package-animation.py`, `run-package-animation.sh` in that same directory.
- VM manifests and stills: `mesh-visualization/manifest.json`, `mesh-visualization/field-stills.json`, `mesh-visualization/{temp,u,stress}-vm.png`.
- Local assets: `reliability-figures/`; their hashes match the VM manifests.
- GIF: 1000 × 680; 180 rendered frames, 148 encoded frames (identical adjacent frames combined); 14.4-second looping playback.
- Mesh: 17,171 vertices; 88,813 tetrahedra including 6,336 Gas tetrahedra. Gas is hidden; 82,477 solid tetrahedra are visualized.
- Animation: perspective orbit, single-plane section A, full restoration, single-plane section B and full restoration. No simultaneous clipping planes. It is a geometry animation, not a transient or deformed-state animation.
- The three field stills are also VTK-rendered on the VM. Their maxima match the archived results: 489.4564439302808 K; 23.671581775702812 µm; 1.1055737403071118 GPa.

The working HTML, PPTX and draw.io contain the case as page 3. An independent `StressThermal-with-reliability.{html,pptx,drawio}` snapshot is retained because another active workflow is updating `StressThermal-generator.cjs`. Its current Mechanics animations were preserved. Rebuild this snapshot with `node architecture-overview/StressThermal-with-reliability.cjs`; case content is in `architecture-overview/reliability-slide.cjs`. Do not replace newer unrelated slide edits with an older snapshot.

Checks: HTML has no JavaScript errors or measured text overflow; seven feature dialogs work; enlarged GIF is 1000 × 680 and changes frames; PowerPoint opened and rendered all five pages; PPTX ZIP/XML and draw.io XML parse successfully. The bundled Python schema validator could not run because `defusedxml` is absent; native PowerPoint opening/rendering was used as the compatibility check. Animated playback was verified in HTML; PowerPoint's exported previews are static.

Rendering uses the VM's existing VTK 9.2.4 under a private Xvfb display, one low-priority CPU, with user-site Python packages disabled. No solver source, system packages or vendor installation files were changed. Temporary Xvfb is terminated by the runner.

Reference implementation concepts: https://github.com/pyvista/pyvista and https://examples.vtk.org/site/PythonicAPI/UnstructuredGrid/ClipUnstructuredGridWithPlane/ . The delivered implementation uses the existing VTK directly, without installing PyVista.
