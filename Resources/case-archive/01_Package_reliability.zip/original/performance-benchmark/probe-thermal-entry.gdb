set pagination off
set confirm off
set breakpoint pending off
set print thread-events off
python
import gdb
active = False
class Finish(gdb.FinishBreakpoint):
    def stop(self):
        global active
        print('PROBE prepareStructure RETURN', self.return_value)
        active = False
        tcl.enabled = False
        return False
class Entry(gdb.Breakpoint):
    def stop(self):
        global active
        active = True
        tcl.enabled = True
        print('PROBE prepareStructure ENTER')
        print(gdb.execute('bt 5', to_string=True))
        Finish(gdb.newest_frame(), internal=True)
        return False
class Tcl(gdb.Breakpoint):
    def stop(self):
        if active:
            try:
                print('PROBE Tcl_Eval:', gdb.parse_and_eval('(char*)$rsi').string()[:400])
            except Exception as error:
                print('PROBE read error', error)
        return False
Entry('_ZN13sinterconnect15SolveController16prepareStructureEv')
tcl = Tcl('Tcl_Eval')
tcl.enabled = False
end
run
