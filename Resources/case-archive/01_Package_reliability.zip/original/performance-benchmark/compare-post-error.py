from pathlib import Path
import subprocess,json
r=Path('/home/mozztcad/tmp/package-benchmark-20261010/thermomechanical-recovery')
python='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3'
for label,left,right in [('execution-v2','execution-v2-vendor','execution-v2-local'),('execution-v2-reference','multistep-vendor','execution-v2-local'),('catch-recovery','catch-recovery-vendor','catch-recovery-local')]:
 a=r/left/'result_sis.tdr';b=r/right/'result_sis.tdr'
 if not a.exists() or not b.exists():print('PENDING',label);continue
 out=r/(label+'-timestamp-proof.json')
 subprocess.run([python,str(r/'verify-profile-timestamps.py'),str(a),str(b),str(out)],check=True,stdout=subprocess.DEVNULL)
 q=json.loads(out.read_text());print(label,{k:q[k] for k in ['sizes','raw_differences','remaining_differences','timestamp_excluded_byte_exact']})
 if not q['timestamp_excluded_byte_exact']:raise RuntimeError('output mismatch '+label)
if (r/'catch-recovery-local/exit.txt').exists():
 results={}
 for kind in ['vendor','local']:
  lines=(r/('catch-recovery-'+kind)/'stdout.log').read_text(errors='replace').splitlines()
  results[kind]=[x for x in lines if x.startswith('PROBE_ERROR ') or x.startswith('COUPLED_')]
  results[kind+'_exit']=(r/('catch-recovery-'+kind)/'exit.txt').read_text().strip()
 results['equal']=results['vendor']==results['local']
 (r/'catch-recovery-comparison.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results,indent=2))
