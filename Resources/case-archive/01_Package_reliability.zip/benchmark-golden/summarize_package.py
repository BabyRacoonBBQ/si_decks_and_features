"""Evidence-derived package comparison; retains timing qualification limits."""
from pathlib import Path
import json,re,statistics,hashlib
import h5py,numpy as np
from native_timers import mapdl
from stress_recovery import recover_region,von_mises
root=Path(__file__).resolve().parent
vm=json.loads((root/'vm/formal-20261011-a/summary.json').read_text())
accuracy={};si_audit=[]
for tool in ['vendor','stressthermal']:
    p=root/f'vm/formal-20261011-a/r1-{tool}/mechanics_sis.tdr'
    regions=[]
    with h5py.File(p)as f:
        g=f['collection/geometry_0'];v=g['vertex'][:];xyz=np.column_stack([v[k]for k in ('x','y','z')])
        fields={(int(d.attrs['region']),d.attrs['name'].decode()):d for d in g['state_0'].values()if 'values'in d}
        for key,r in g.items():
            if not key.startswith('region_')or int(r.attrs.get('type',-1))!=0 or r.attrs.get('material')==b'Gas':continue
            rid=int(key[7:]);conn=r['elements_0'][:].reshape(-1,5)[:,1:]
            el=fields[rid,'StressEL']['values'][:].reshape(-1,6)*1e-7
            ids,recovered=recover_region(xyz,conn,el)
            nodal=fields[rid,'Stress']['values'][:].reshape(-1,6)*1e-7
            native=fields[rid,'MisesStress']['values'][:]*1e-7
            # Packed symmetric tensor: XX, XY, XZ, YY, YZ, ZZ.
            invariant=von_mises(recovered[:,[0,3,5,1,4,2]])
            if not np.allclose(recovered,nodal,rtol=1e-10,atol=1e-7):raise ValueError('SI region recovery mismatch')
            if not np.allclose(invariant,native,rtol=1e-10,atol=1e-7):raise ValueError('SI invariant mismatch')
            k=int(np.argmax(invariant))
            regions.append({'region':key,'maximum_mises_MPa':float(invariant[k]),'vertex_id_zero_based':int(ids[k]),'position_um':(xyz[ids[k]]*1e4).tolist(),'max_recovery_component_error_MPa':float(np.max(abs(recovered-nodal))),'max_invariant_error_MPa':float(np.max(abs(invariant-native)))})
    si_audit.append({'tool':tool,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'regions':regions})
    rows=[r for r in vm['runs']if r['tool']==tool and r['mode']=='mechanics']
    accuracy[tool]={'maximum_temperature_K':rows[0]['temperature_max_K'],'maximum_mises_MPa':max(r['maximum_mises_MPa']for r in regions),'repetitions_identical_scalar_maxima':len(set((r['temperature_max_K'],r['current_mises_max_MPa'])for r in rows))==1}
mapdl_runs=[]
for rep in [1,2,3]:
    d=root/f'mapdl/formal-20261011-r{rep}'
    temperature=np.loadtxt(d/'thermal/temperature.txt');cdb=(d/'thermal/model.cdb').read_text()
    offset=float(re.search(r'^TOFFST,([\d.]+)',cdb,re.M)[1])
    corrected=root/f'mapdl/orientation-corrected-r{rep}'
    recovery=json.loads((corrected/'mechanics/regionwise-recovery.json').read_text())
    rec={'rep':rep,'maximum_temperature_K':float(temperature[:,1].max()+offset),'temperature_offset_K':offset,'maximum_mises_MPa':recovery['maximum']['maximum_mises_MPa'],'timings':{}}
    for mode in ['thermal','mechanics']:
        md=(corrected if mode=='mechanics' else d)/mode;meta=json.loads((md/'run.json').read_text());log=(md/'solve.out').read_text(errors='replace')
        if meta['exit']!=0:raise ValueError('MAPDL failure')
        parsed=mapdl(log,(md/'stage_timers.txt').read_text())
        if not parsed['completed']:raise ValueError('MAPDL completion missing')
        rec['timings'][mode]=parsed
    rec['source_runs']={'thermal':str(d/'thermal'),'mechanics':str(corrected/'mechanics')}
    rec['crystal_orientation']='Explicit default source crystal-to-global rotation, independently checked against native source stress/strain and MAPDL affine patch'
    mapdl_runs.append(rec)
accuracy['mapdl']={'maximum_temperature_K':mapdl_runs[0]['maximum_temperature_K'],'maximum_mises_MPa':mapdl_runs[0]['maximum_mises_MPa'],'repetitions_identical_scalar_maxima':len(set((r['maximum_temperature_K'],r['maximum_mises_MPa'])for r in mapdl_runs))==1}
comparisons={}
for golden in ['vendor','mapdl']:
    comparisons[golden]={}
    for metric in ['maximum_temperature_K','maximum_mises_MPa']:
        a,b=accuracy['stressthermal'][metric],accuracy[golden][metric]
        comparisons[golden][metric]={'difference':a-b,'relative_difference_percent':100*(a-b)/b}
report={'case':'Package thermomechanical reliability','mesh':json.loads((root/'package/mesh-inventory.json').read_text()),'accuracy':accuracy,'stress_recovery_audit':si_audit,'differences_StressThermal_minus_golden':comparisons,'vm_timing':vm,'mapdl_runs':mapdl_runs,'limitations':['Host and VM are distinct environments on the same physical machine.','Some VM runs had nonzero system swap counters; no strict-no-swap median is established for vendor mechanics.','MAPDL native total includes diagnostic postprocessing exports. Compare native compute stages separately; do not sum nested timers.','Temperatures use the source convention retained by TOFFST=273.156, not an assumed 273.15 offset.','Peak agreement between tools is not proof of continuum accuracy or convergence.']}
(root/'package-comparison-formal.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'accuracy':accuracy,'differences':comparisons},indent=2))
