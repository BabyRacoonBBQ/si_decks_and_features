# Stress comparison contract

Status: formal three-tool runs are waiting for the user's restart notification.
No solver was launched for this offline audit.

## What is held equal

The same physical problem, mesh geometry, material laws, loads, boundary
conditions, reference temperature and field units are required. Thermal FEM
versus FVM is an intended cross-tool discretization difference, not a reason
to exclude the comparison. Do not tune material values to make maxima agree.

Primary stress metric: maximum current-state von Mises stress in MPa, after
the same regionwise recovery of the six stress tensor components. Preserve
material-side/interface values; do not merge regions merely because their
material names agree. Report the region and location of each maximum.
Temperature is reported in K, with temperature differences also in K.

## Evidence for recovery

Sentaurus Interconnect UG Chapter 2, "Description of Output Fields" and
"Nodal Stress and Strain at Like-Material and Same-Material Interfaces",
distinguishes Gauss-point, element and nodal stresses and describes regionwise
interpolation. The UG alone does not establish the precise averaging weights.

Read-only inspection of the current sinterconnect_run implementation found:

- MechController.cpp: element-to-node projection precedes MisesStress().
- DataUtil.cpp: projectElementToNode normalizes weighted tensor contributions.
- Volume.cpp: a linear tetrahedron contributes V/4 to each node; TS4Interp
  instead uses V, which gives the same normalized result for all-tet meshes.
- MechData.cpp: MisesStress operates on the nodal tensor; MisesStressMax is
  a running history maximum and is not automatically the current-state field.

This is corroborated by actual archived vendor output, not solely by the
reconstructed implementation. check_vendor_stress_recovery.py reads StressEL
and Stress from the archived package TDR and reconstructs each region.
All 15 solid regions match volume-weighted tensor recovery, with maximum
component discrepancy below 6e-13 MPa. Arithmetic averaging fails this test.
See vendor-stress-recovery-audit.json for every region, input path and hash.
This proof applies to this first-order tetrahedral case, not all element types
or every smoothing/history configuration.

## ANSYS adjustments

MAPDL POST1 default derived nodal processing averages element contributions.
AVPRIN,0 averages components before calculating derived principal/equivalent
values; AVPRIN,1 changes that order. AVPRIN,0 alone does not establish the
volume-weighted recovery demonstrated above.

- Export element stress components in the global coordinate system.
- Recover a consistent element tensor, preserving its physical output location.
- Within each original region, sum V * tensor and divide by sum(V) at each node.
- Compute von Mises from the recovered tensor and take the spatial maximum.
- Keep native ANSYS averaged and unaveraged maxima as separately labelled
  diagnostics, not as interchangeable primary benchmark numbers.
- Audit the same current-state versus history distinction on both SI tools.

The runner now saves raw element stress components and region membership for
this calculation. End-to-end normalized MAPDL stress extraction remains to be
validated when solver/postprocessing work resumes. No normalized cross-tool
stress error is claimed yet.

The earlier 1106.643329 MPa native MAPDL averaged maximum is diagnostic only.
It must not be presented as a matched-recovery comparison with the archived
vendor 1105.573740 MPa value. The earlier postprocessing driver also placed
ESOL in the wrong PRNSOL argument slot; the formal driver now uses
`PRNSOL,S,PRIN,,,,,ESOL` (DataKey is argument 7). Previous logs are preserved.

Official references:

- [POST1 derived nodal data processing](https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_thry/thy_post1.html)
- [AVPRIN](https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_cmd/Hlp_C_AVPRIN.html)
- [PRNSOL](https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/ans_cmd/Hlp_C_PRNSOL.html)

## Converter validation status

Thermal CDB and exact same-mesh nodal temperature transfer are implemented.
The final relevant regression suite passed 81 tests and 12 subtests.
Native analytical conduction, convection and radiation checks were performed
before the requested benchmark pause. These are solver-validity checks, not
performance measurements. Transient thermal CDB and arbitrary intermesh
temperature interpolation are outside the implemented profile.


## Offline implementation verification

`stress_recovery.py` implements regionwise linear-tetrahedron volume weighting
and a canonical six-component von Mises invariant (MPa). Seven tests pass:
unequal volumes, separate region sides, hydrostatic stress, pure shear,
noncommuting averaging/invariant operations, and invalid-data rejection.
The same recovery routine also reproduces all 15 solid-region nodal Stress
fields in the archived vendor TDR. Test evidence: stress-recovery-tests.xml.
The invariant routine requires explicit XX, YY, ZZ, XY, YZ, XZ column order;
source adapters must establish that order before calling it.

MAPDL raw component export and conversion from its stress output location to
the common element-tensor representation still need native verification.
No new MAPDL or SI execution was started during the pause.

## Resumed native MAPDL recovery audit

The saved calibration RST was read with native MAPDL POST1, RSYS,0 and
PRESOL,S,COMP. All 82,477 elements and 329,908 element-node rows are covered.
The explicit SX/SY/SZ/SXY/SYZ/SXZ headers establish canonical component order.
Recomputed equivalent stress differs from native PRESOL,S,PRIN by at most
6.54e-8 MPa. CDB coordinates and connectivity were checked against the source
TDR, preserving each original region. Volume-weighted tensor recovery gives
1106.6433291616777 MPa at vertex 97 (zero based), region frame / Copper.
This remains a calibration result, not a formal three-tool comparison.

SOLID285 corner tensors have varying hydrostatic parts. The mean-of-corners
element tensor was checked against corner-specific volume-weighted recovery
for every region; every nodal Mises discrepancy is below 1e-3 MPa. This
explicit numerical check bounds the effect for this case only.
Evidence: mapdl/component-recovery-audit/component-audit.json and
regionwise-recovery.json; reproduce with audit_mapdl_components.py and
recover_mapdl_calibration.py.
