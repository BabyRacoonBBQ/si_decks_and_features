# Recovery completed — 2026-10-11

Release sinterconnect_run now completes the original copper-pillar global solve and local submodel using its own global displacement. Essential point constraints are retained. Point displacement and face-point penalty assembly were recovered against vendor evidence; nonzero nodal-rate and anchored face regressions pass.

All three formal repetitions completed for StressThermal and Golden tool - S (12 native stages); all 12 full field datasets and own-global mapping hashes passed audit. Existing Golden tool - A provides three completed own-global pipelines with equivalent regionwise stress recovery.

StressThermal peak Mises: global 887.6781968741105 MPa; local 703.7011053179518 MPa. Median native solve: global 16.69 s; local 43.02 s. Performance observations retain swap/load and timing-scope qualifications; no unconditional speedup claim.

Case 2 Accuracy and Performance values are published in the current seven-slide HTML/draw.io/PPTX/SVG exports. The latest two-row performance layout and all other current pages are preserved. Future Plan changed independently during final checking; its latest content was retained and re-exported. 38 completion checks passed in recovery/completion-audit.json.

Evidence: pillar-benchmark.json; pillar-benchmark-report.md; vm/formal-pillar-recovered-a/all-repetitions-field-audit.json; recovery/source-provenance.json; recovery/point-recovery-final.patch; recovery/build-5.log; recovery/node-rate-verification.json; recovery/face-cursor-verification.json. Source files remain in /home/mozztcad/geo3d; no commit was requested or created.

---

## Historical work log (superseded where it reports unsupported recovery)

# Two-case, three-tool Benchmark slide

Deliverable: one NEW Benchmark slide after Application cases, with left/right
case columns and Accuracy / Performance sections. Existing five slides are
preserved. Current scope and execution state: CURRENT-GOAL.md.

## Results and evidence

- Package: three repetitions per tool and physics stage completed. See
  package-comparison-formal.json and package-benchmark-report.md. MAPDL
  mechanics uses orientation-corrected-r1/r2/r3; the old unrotated-silicon
  mechanics runs are superseded. Thermal retains formal-20261011-r1/r2/r3.
  Each tool uses its own spatial temperature solution.
- Pillar: Vendor and MAPDL global-to-local accuracy calibration completed,
  each mapping its own global displacement. StressThermal fails the original
  point constraint, which has not been removed. See pillar/calibration-summary.json.
- Pillar formal repeated timing has completed; the final evidence is in
  pillar/pillar-benchmark.json and pillar/pillar-benchmark-report.md.

## Comparison contract

Package: 82,477 solid tetrahedra / 15,653 active vertices, seven materials,
5 W die heating, ambient 300 K, conduction/convection/radiation. Source
TOFFST=273.156 is preserved. MAPDL thermal FEM and SI thermal FVM may differ.
Pillar: global 43,994 vertices / 246,681 tetrahedra; local 75,969 / 422,904.
Cooling 180 to 25 C is prescribed, not a solved-temperature accuracy test.

Current von Mises is computed after volume-weighted tensor recovery within
original regions, preserving interface sides. Historical maxima, unaveraged
peaks and cross-material averages are not mixed. See stress-comparison-contract.md.
Default silicon crystal rotation is explicit and independently verified.

Host: Windows 11 Home Chinese 10.0.26200, i7-13700F, 16 cores / 24 logical
processors, 16 GiB RAM. VMware guest: Rocky Linux 8.10, 10 vCPU / 12.4 GiB RAM.
Sentaurus W-2024.09-SP1 and Release sinterconnect_run: guest CPU 4, one thread.
MAPDL 2026 R1 / 26.1: host SMP, one requested thread. Binary hashes and fresh
machine/load records accompany runs. Host and guest are different environments.

Native total, native solve and CPU/elapsed module timers retain their scopes;
nested timers are not summed. Some VM observations contain swap activity,
which qualifies the results. MAPDL mapping/conversion is outside native timing
and is separately measured. Failed runs receive no performance score.

## Converter verification

Repository: D:/my_repos/si_to_ans_converter. Existing source reader, neutral Ix
model and CDB writer perform conversion; native drivers do not replace physics.

- ../converter-work/rotation-regression.xml: 109 tests + 12 subtests.
- ../converter-work/crystal-tests.xml: 11 rotation/JSON/target tests.
- ../converter-work/elastic-profile-tests.xml: 12 source-profile tests.
- ../converter-work/mapdl-checks/verification.json: native analytical thermal checks.
- pillar/point-spc-host-verified/verification.json: native point constraints.
- pillar/mapped-boundary-native-verified/verification.json: mapped exterior,
  free interior vertex, all six stress components.
- pillar/rotated-cubic-native/verification.json: anisotropic native patch.
- pillar/converter-mapping-audit.json and submodel-adapter-audit.json:
  all 10,754 real boundary vertices / 32,262 components checked.

## Artifacts

../architecture-overview/StressThermal/StressThermal-physics.html#benchmark,
editable draw.io, PPTX, SVG and scene.json are generated together. The layout
checker saves benchmark-preview.png and benchmark-layout-check.json. All five
other scene objects are checked against pillar/other-slides-before-final-render.json.
The earlier unmodified-slides-before.json is retained as a historical snapshot;
subsequent user edits on those slides are preserved.
Raw calibration and failed attempts remain archived; only selected completed
formal runs enter timing tables.
