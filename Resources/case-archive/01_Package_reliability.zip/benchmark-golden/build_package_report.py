from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent
d=json.loads((root/'package-comparison-formal.json').read_text())
env=json.loads((root/'vm/formal-20261011-a/environment.json').read_text())
lines=['# Package three-tool benchmark','',
'All three repetitions per tool and per physics stage completed. This is the package column of the new Benchmark slide. The separate copper-pillar results and recorded unsupported-tool limitation are in pillar/pillar-benchmark-report.md.','',
'## Case and accuracy','',
'Frozen mesh: 82,477 solid tetrahedra, 15,653 solid-used vertices (17,171 geometric vertices including Gas-only vertices). Seven solid materials. 5 W die heating; ambient 300 K; conduction, convection and radiation. The temperature solution from each tool drives its own linear thermomechanical solve. Bottom displacements are fixed; the reference temperature is 300 K in the source convention. MAPDL thermal uses FEM; the SI tools use FVM.','',
'Stress is the current-state von Mises invariant after volume-weighted tensor recovery within each original region, preserving interface sides. Native peak values were verified against recovered StressEL/Stress in both SI tools. MAPDL element-node component order and invariant were checked against native output, then the same regional weighting was applied. Peak recovery is independent of historical MisesStressMax.','',
'| Tool | Tmax (K) | Maximum von Mises (MPa) | Three runs repeat peaks |','|---|---:|---:|---|']
for tool,a in d['accuracy'].items():lines.append(f"| {tool} | {a['maximum_temperature_K']:.9f} | {a['maximum_mises_MPa']:.9f} | {a['repetitions_identical_scalar_maxima']} |")
lines+=['','| StressThermal minus golden | Temperature difference (K) | Stress relative difference (%) |','|---|---:|---:|']
for tool,a in d['differences_StressThermal_minus_golden'].items():lines.append(f"| {tool} | {a['maximum_temperature_K']['difference']:.9f} | {a['maximum_mises_MPa']['relative_difference_percent']:.9f} |")
lines+=['','Agreement between tools does not prove continuum accuracy or mesh convergence. Temperature conversion uses the deck-specific absolute-zero offset 273.156 K, explicitly retained in MAPDL TOFFST, rather than silently substituting 273.15.','',
'## Timing qualification','',
'These are observed native timings, not an unconditional speedup claim. Vendor startup/license waiting is included in native total. SI inclusive solve and MAPDL computing-solution scopes are listed separately and may have different instrumentation boundaries. MAPDL native totals include the benchmark diagnostic exports. Nested native module timers must not be summed.','',
'VM run order alternated across three rounds. Both SI tools used guest CPU 4, one thread, identical decks and mesh, with binary hashes checked before every stage. Pre-run VM samples required at least 95% idle and no swap IO. Some runs nonetheless had small nonzero system swap-in counters during execution; the strict no-swap criterion did not pass for any vendor mechanics repetition. Raw results are retained, without presenting them as clean no-swap medians.','',
'| Tool | Stage | Native total median [range], s | Native solve/compute median [range], s |','|---|---|---:|---:|']
for r in d['vm_timing']['summary']:
 a,b=r['native_total_s'],r['inclusive_solve_s'];lines.append(f"| {r['tool']} | {r['mode']} | {a['median']:.3f} [{a['min']:.3f}, {a['max']:.3f}] | {b['median']:.3f} [{b['min']:.3f}, {b['max']:.3f}] |")
for mode in ['thermal','mechanics']:
 a=[r['timings'][mode]['totals']['elapsed']for r in d['mapdl_runs']];b=[next(t['seconds']for t in r['timings'][mode]['native_stages']if t['label']=='Elapsed time spent computing solution')for r in d['mapdl_runs']]
 lines.append(f'| MAPDL | {mode} | {statistics.median(a):.3f} [{min(a):.3f}, {max(a):.3f}] | {statistics.median(b):.3f} [{min(b):.3f}, {max(b):.3f}] |')
lines+=['','## Recorded load','', '| Run | Stage | Host mean / peak CPU (%) | Min host available GiB | VM swap-in / swap-out pages |','|---|---|---:|---:|---:|']
for r in d['vm_timing']['runs']:
 h=r['host_load'];sw=r['vm_swap_pages'];lines.append(f"| {r['run']} | {r['mode']} | {h['mean_cpu_percent']:.2f} / {h['max_cpu_percent']:.2f} | {h['min_available_GiB']:.2f} | {sw['pswpin']} / {sw['pswpout']} |")
for rep in [1,2,3]:
 for mode in ['thermal','mechanics']:
  tag=f'orientation-corrected-r{rep}' if mode=='mechanics' else f'formal-20261011-r{rep}'
  samples=[json.loads(s)for s in (root/f'host-mapdl/{tag}/host-load.jsonl').read_text().splitlines()]
  meta=json.loads((root/f'mapdl/{tag}/{mode}/run.json').read_text());h=[s for s in samples if meta['start_epoch']<=s['epoch']<=meta['start_epoch']+meta['wall_seconds']]
  lines.append(f"| MAPDL r{rep} | {mode} | {statistics.mean(s['cpu_percent']for s in h):.2f} / {max(s['cpu_percent']for s in h):.2f} | {min(s['available_memory']for s in h)/2**30:.2f} | Not a VM run |")
lines+=['','## Machine and identities','',
'Same physical i7-13700F host: Windows 11 Home Chinese 10.0.26200, 16 cores / 24 logical processors, 16 GiB RAM. VMware guest: Rocky Linux 8.10, 10 vCPU, 12.4 GiB RAM. Host and guest are distinct benchmark environments. No VM solve ran concurrently with MAPDL measurements.','',
'MAPDL: 2026 R1 / 26.1 / UP20260202, SMP, one requested thread. Sentaurus sinterconnect: installed W-2024.09-SP1; --noSyntaxCheck. StressThermal: sinterconnect_run from the CMake Release build.','',
f"VM source HEAD: `{env['source_commit'].strip()}`. Uncommitted source status and full CPU/kernel/memory records are retained in `vm/formal-20261011-a/environment.json`.", '']
for k,v in env['binary_sha256'].items():lines.append(f'- {k} SHA-256: `{v}`')
lines+=['',f"Mesh SHA-256: `{d['mesh']['sha256']}`",'', '## Native module timings','', 'All tables below use the native labels and medians of three repetitions. CPU and elapsed times are separate.']
for tool in ['vendor','stressthermal']:
 for mode in ['thermal','mechanics']:
  rows=[r for r in d['vm_timing']['runs']if r['tool']==tool and r['mode']==mode]
  for kind in ['module_cpu','module_elapsed']:
   lines+=['',f'### {tool}: {mode}, {kind}','','| Native label | Median seconds | Calls per run |','|---|---:|---|']
   names=sorted({m['label']for r in rows for m in r['native_timers'][kind]})
   for name in names:
    vals=[m for r in rows for m in r['native_timers'][kind]if m['label']==name]
    lines.append(f"| {name} | {statistics.median(m['seconds']for m in vals):.3f} | {', '.join(str(m['calls'])for m in vals)} |")
for mode in ['thermal','mechanics']:
 lines+=['',f'### MAPDL: {mode}','','| Native label | Median seconds |','|---|---:|']
 names=sorted({m['label']for r in d['mapdl_runs']for m in r['timings'][mode]['native_stages']})
 for name in names:
  vals=[m['seconds']for r in d['mapdl_runs']for m in r['timings'][mode]['native_stages']if m['label']==name];lines.append(f'| {name} | {statistics.median(vals):.3f} |')
lines+=['','## Reproduce / evidence','',
'- `package/thermal_bench.cmd`, `package/mechanics_bench.cmd`, `package/mesh.tdr`: matched source inputs.',
'- `run_vm.py`, `run_mapdl.py`, `monitor_vm_run.py`: runners and load monitor.',
'- `vm/formal-20261011-a/`: per-run input copies, native logs, hashes, load and matched output files.',
'- `mapdl/formal-20261011-r*/`: generated CDB, native drivers/logs/results, temperature and stress exports.',
'- `package-comparison-formal.json`: full machine-readable comparison and SI stress audits.',
'- `mapdl/orientation-corrected-r*/mechanics/regionwise-recovery.json`: corrected recovered maxima and their locations. Earlier formal mechanics runs used unrotated silicon stiffness and are superseded.',
'- `package-orientation-audit.json` and `pillar/rotated-cubic-native/verification.json`: independent native source stress/strain and MAPDL affine-patch verification of the rotated cubic tensor. Thermal solutions are unchanged and reused with hashes in each corrected run.',
'- `summarize_package.py`, `recover_mapdl_calibration.py`, `build_package_report.py`: offline regeneration.',
'- Previous native converter analytical checks and regression evidence are indexed in README.md.',
'','Timing conclusions remain qualified by the recorded swap activity, native instrumentation scopes and host/VM differences. These observations do not establish an unconditional speedup.']
(root/'package-benchmark-report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(root/'package-benchmark-report.md')
