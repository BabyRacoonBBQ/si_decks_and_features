import numpy as np
import pytest
from stress_recovery import recover_region, von_mises


def example():
    # Shared face, distinct volumes 1/6 and 3/6.
    xyz = np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.],[0.,0.,1.],[0.,0.,-3.]])
    conn = np.array([[0,1,2,3],[0,2,1,4]])
    stress = np.zeros((2,6)); stress[:,0] = [10.,30.]
    return xyz,conn,stress


def test_volume_weighting_not_arithmetic():
    ids,s = recover_region(*example())
    assert ids.tolist() == [0,1,2,3,4]
    assert s[:,0] == pytest.approx([25.,25.,25.,10.,30.])
    assert von_mises(s) == pytest.approx([25.,25.,25.,10.,30.])


def test_region_sides_are_independent():
    xyz,conn,stress=example()
    _,a=recover_region(xyz,conn[:1],stress[:1])
    _,b=recover_region(xyz,conn[1:],stress[1:])
    assert a[0,0] == 10.
    assert b[0,0] == 30.


def test_invariant_stress_and_order_of_operations():
    assert von_mises([[100.,100.,100.,0.,0.,0.]])[0] == 0.
    assert von_mises([[0.,0.,0.,10.,0.,0.]])[0] == pytest.approx(np.sqrt(3)*10.)
    xyz,conn,s=example(); s[:,0]=[30.,-10.]
    _,nodal=recover_region(xyz,conn,s)
    # Cancellation of the tensor precedes the nonlinear invariant.
    assert von_mises(nodal)[0] == pytest.approx(0.,abs=1e-13)
    assert np.average(von_mises(s),weights=[1.,3.]) == 15.


@pytest.mark.parametrize('bad',['duplicate','degenerate','missing','nonfinite'])
def test_invalid_recovery_rejected(bad):
    xyz,conn,s=example()
    if bad=='duplicate':conn[1]=conn[0]
    if bad=='degenerate':xyz[4]=xyz[0]
    if bad=='missing':conn[1,3]=99
    if bad=='nonfinite':s[1,0]=np.nan
    with pytest.raises(ValueError):recover_region(xyz,conn,s)
