foreach mat {Silicon Copper Solder Aluminum Nitride} {
 foreach key {Viscosity0 ViscosityW IsCreep IsPlastic IsViscoPlastic Anisotropic} {
  if {![catch {pdbGet $mat Mechanics $key} value]} {puts "BENCH_DEFAULT $mat $key $value"}
 }
}
