from pathlib import Path
import subprocess,json
root=Path(__file__).parent
src=root/'mapdl/calibration-fixed/mechanics'
out=root/'mapdl/post-diagnostic';out.mkdir(exist_ok=True)
cmd=f'''/BATCH
/CLEAR,NOSTART
CDREAD,DB,'{(src/'model').as_posix()}',cdb
/POST1
FILE,'{(src/'mechanics').as_posix()}',rst
SET,LAST
/GRAPHICS,FULL
/FORMAT,10,E,24,16
AVPRIN,0
'''
for mid in range(1,8):
    cmd+=f'''ALLSEL,ALL
ESEL,S,MAT,,{mid}
NSLE,S
/OUTPUT,material_{mid}_stress,txt
PRNSOL,S,PRIN,,,,ESOL
/OUTPUT
'''
cmd+='''ALLSEL,ALL
*DIM,dispx,ARRAY,17171,1
*DIM,dispy,ARRAY,17171,1
*DIM,dispz,ARRAY,17171,1
*VGET,dispx(1,1),NODE,1,U,X
*VGET,dispy(1,1),NODE,1,U,Y
*VGET,dispz(1,1),NODE,1,U,Z
*CFOPEN,displacement,txt
*VWRITE,SEQU,dispx(1,1),dispy(1,1),dispz(1,1)
(F12.0,3E26.17)
*CFCLOS
FINISH
/EXIT,NOSAVE
'''
(out/'post.inp').write_text(cmd)
p=subprocess.run([r'D:\Program Files\ANSYS Inc\v261\ansys\bin\winx64\ANSYS261.exe','-b','-smp','-np','1','-m','256','-db','64','-j','post','-i','post.inp','-o','post.out'],cwd=out,creationflags=subprocess.CREATE_NO_WINDOW,timeout=120,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'launcher.log').write_bytes(p.stdout)
print('post-only exit',p.returncode)
