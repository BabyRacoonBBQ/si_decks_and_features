"""Host load evidence while running a sequential benchmark in the VM."""
import ctypes,json,subprocess,time,sys
from pathlib import Path
from ctypes import wintypes
root=Path(__file__).resolve().parent
tag=sys.argv[1]
local_mapdl=len(sys.argv)>2 and sys.argv[2]=='--mapdl'
pillar_vm=len(sys.argv)>2 and sys.argv[2] in ('--pillar-vm','--pillar-recovered')
pillar_mapdl=len(sys.argv)>2 and sys.argv[2]=='--pillar-mapdl'
out=(root/'pillar/host-vm' if pillar_vm else root/'pillar/host-mapdl' if pillar_mapdl else root/('host-mapdl' if local_mapdl else 'vm'))/tag
out.mkdir(parents=True,exist_ok=False)
class Memory(ctypes.Structure):
    _fields_=[('length',wintypes.DWORD),('load',wintypes.DWORD)]+[(n,ctypes.c_ulonglong)for n in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]
def snapshot():
    ft=[wintypes.FILETIME()for _ in range(3)]
    if not ctypes.windll.kernel32.GetSystemTimes(*(ctypes.byref(t)for t in ft)):raise ctypes.WinError()
    times=[(t.dwHighDateTime<<32)|t.dwLowDateTime for t in ft]
    m=Memory();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
    return dict(epoch=time.time(),idle=times[0],kernel=times[1],user=times[2],total_memory=m.total,available_memory=m.available,memory_load_percent=m.load)
remote='source /home/mozztcad/geo3d/.env >/dev/null 2>&1; /home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3.11 /home/mozztcad/si-bench/golden-package-20261010/run_vm.py '+tag
args=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','mozztcad@192.168.43.128',remote]
if pillar_vm:
    args[-1]='source /home/mozztcad/geo3d/.env >/dev/null 2>&1; /home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/python3.11 /home/mozztcad/si-bench/golden-pillar-20261011/run_formal_vm.py '+tag
if pillar_vm and sys.argv[2]=='--pillar-recovered':
    args[-1]=args[-1].replace('run_formal_vm.py','run_recovered_vm.py')
if local_mapdl:
    args=[sys.executable,str(root/'run_mapdl.py'),tag]+(sys.argv[3:] or ['both'])
if pillar_mapdl:
    args=[sys.executable,str(root/'pillar/run_formal_mapdl.py'),tag]
with (out/'host-load.jsonl').open('w')as samples,(out/'runner.log').open('w')as log:
    prev=snapshot()
    for _ in range(5):
        time.sleep(1);now=snapshot();dt=now['kernel']+now['user']-prev['kernel']-prev['user'];now['cpu_percent']=100*(1-(now['idle']-prev['idle'])/dt)if dt else 0
        samples.write(json.dumps(now)+'\n');samples.flush();prev=now
    p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    print('CHILD_PID',p.pid,flush=True)
    while p.poll()is None:
        time.sleep(1);now=snapshot();dt=now['kernel']+now['user']-prev['kernel']-prev['user'];now['cpu_percent']=100*(1-(now['idle']-prev['idle'])/dt)if dt else 0
        samples.write(json.dumps(now)+'\n');samples.flush();prev=now
    (out/'exit.json').write_text(json.dumps({'exit':p.returncode,'finish_epoch':time.time()}))
    print('EXIT',p.returncode,flush=True)
sys.exit(p.returncode)
