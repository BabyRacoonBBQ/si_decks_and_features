# Package three-tool benchmark

All three repetitions per tool and per physics stage completed. This is the package column of the new Benchmark slide. The separate copper-pillar results and recorded unsupported-tool limitation are in pillar/pillar-benchmark-report.md.

## Case and accuracy

Frozen mesh: 82,477 solid tetrahedra, 15,653 solid-used vertices (17,171 geometric vertices including Gas-only vertices). Seven solid materials. 5 W die heating; ambient 300 K; conduction, convection and radiation. The temperature solution from each tool drives its own linear thermomechanical solve. Bottom displacements are fixed; the reference temperature is 300 K in the source convention. MAPDL thermal uses FEM; the SI tools use FVM.

Stress is the current-state von Mises invariant after volume-weighted tensor recovery within each original region, preserving interface sides. Native peak values were verified against recovered StressEL/Stress in both SI tools. MAPDL element-node component order and invariant were checked against native output, then the same regional weighting was applied. Peak recovery is independent of historical MisesStressMax.

| Tool | Tmax (K) | Maximum von Mises (MPa) | Three runs repeat peaks |
|---|---:|---:|---|
| vendor | 489.456443930 | 1105.423199106 | True |
| stressthermal | 489.456443930 | 1105.423199106 | True |
| mapdl | 489.433136142 | 1106.836051258 | True |

| StressThermal minus golden | Temperature difference (K) | Stress relative difference (%) |
|---|---:|---:|
| vendor | 0.000000000 | 0.000000000 |
| mapdl | 0.023307788 | -0.127647826 |

Agreement between tools does not prove continuum accuracy or mesh convergence. Temperature conversion uses the deck-specific absolute-zero offset 273.156 K, explicitly retained in MAPDL TOFFST, rather than silently substituting 273.15.

## Timing qualification

These are observed native timings, not an unconditional speedup claim. Vendor startup/license waiting is included in native total. SI inclusive solve and MAPDL computing-solution scopes are listed separately and may have different instrumentation boundaries. MAPDL native totals include the benchmark diagnostic exports. Nested native module timers must not be summed.

VM run order alternated across three rounds. Both SI tools used guest CPU 4, one thread, identical decks and mesh, with binary hashes checked before every stage. Pre-run VM samples required at least 95% idle and no swap IO. Some runs nonetheless had small nonzero system swap-in counters during execution; the strict no-swap criterion did not pass for any vendor mechanics repetition. Raw results are retained, without presenting them as clean no-swap medians.

| Tool | Stage | Native total median [range], s | Native solve/compute median [range], s |
|---|---|---:|---:|
| vendor | thermal | 41.000 [41.000, 41.000] | 2.300 [2.280, 2.500] |
| vendor | mechanics | 44.000 [44.000, 44.000] | 4.240 [4.130, 4.420] |
| stressthermal | thermal | 5.000 [5.000, 6.000] | 2.250 [2.220, 2.400] |
| stressthermal | mechanics | 12.000 [11.000, 12.000] | 7.070 [6.560, 7.360] |
| MAPDL | thermal | 26.759 [25.769, 27.927] | 8.300 [7.600, 8.500] |
| MAPDL | mechanics | 31.865 [31.850, 31.940] | 10.000 [9.600, 10.100] |

## Recorded load

| Run | Stage | Host mean / peak CPU (%) | Min host available GiB | VM swap-in / swap-out pages |
|---|---|---:|---:|---:|
| r1-stressthermal | thermal | 10.07 / 12.65 | 1.19 | 0 / 0 |
| r1-stressthermal | mechanics | 14.32 / 26.37 | 0.84 | 0 / 0 |
| r1-vendor | thermal | 9.50 / 22.92 | 0.83 | 20 / 0 |
| r1-vendor | mechanics | 13.78 / 34.83 | 0.54 | 6 / 0 |
| r2-stressthermal | thermal | 22.18 / 32.10 | 0.77 | 0 / 0 |
| r2-stressthermal | mechanics | 17.60 / 31.18 | 0.78 | 0 / 0 |
| r2-vendor | thermal | 16.51 / 50.23 | 0.31 | 4 / 0 |
| r2-vendor | mechanics | 11.63 / 26.15 | 0.58 | 3 / 0 |
| r3-stressthermal | thermal | 13.02 / 19.62 | 1.18 | 0 / 0 |
| r3-stressthermal | mechanics | 10.56 / 14.84 | 1.55 | 0 / 0 |
| r3-vendor | thermal | 10.47 / 39.01 | 1.29 | 0 / 0 |
| r3-vendor | mechanics | 11.83 / 28.45 | 1.29 | 1 / 0 |
| MAPDL r1 | thermal | 10.22 / 18.02 | 1.22 | Not a VM run |
| MAPDL r1 | mechanics | 14.22 / 22.46 | 0.09 | Not a VM run |
| MAPDL r2 | thermal | 25.97 / 56.88 | 0.37 | Not a VM run |
| MAPDL r2 | mechanics | 11.44 / 18.61 | 0.48 | Not a VM run |
| MAPDL r3 | thermal | 8.70 / 13.30 | 1.57 | Not a VM run |
| MAPDL r3 | mechanics | 10.26 / 19.04 | 0.45 | Not a VM run |

## Machine and identities

Same physical i7-13700F host: Windows 11 Home Chinese 10.0.26200, 16 cores / 24 logical processors, 16 GiB RAM. VMware guest: Rocky Linux 8.10, 10 vCPU, 12.4 GiB RAM. Host and guest are distinct benchmark environments. No VM solve ran concurrently with MAPDL measurements.

MAPDL: 2026 R1 / 26.1 / UP20260202, SMP, one requested thread. Sentaurus sinterconnect: installed W-2024.09-SP1; --noSyntaxCheck. StressThermal: sinterconnect_run from the CMake Release build.

VM source HEAD: `4140959ce963437b066e36dcc47703ac609881a1`. Uncommitted source status and full CPU/kernel/memory records are retained in `vm/formal-20261011-a/environment.json`.

- vendor SHA-256: `6b5f30b801b08012dd846b339c4e4275502c5d1ee526420c4be315623d178464`
- stressthermal SHA-256: `14e24e53d195bbec68acfe26e03c37fab7828f8b5b5d2d7fda0bd5d12d5977d1`

Mesh SHA-256: `7a9ce3121b4fa91b4514c54ee03bf999e6f754426cedfc7ade5a4389d86a3b78`

## Native module timings

All tables below use the native labels and medians of three repetitions. CPU and elapsed times are separate.

### vendor: thermal, module_cpu

| Native label | Median seconds | Calls per run |
|---|---:|---|
| BoxMethod by Region | 1.560 | 1, 1, 1 |
| Mechanics step | 0.000 | 1, 1, 1 |
| Other Program Parts | 1.290 | 1, 1, 1 |
| Prepare structure | 0.000 | 1, 1, 1 |
| Serial mode assembly. | 0.020 | 5, 5, 5 |
| SetTemp command | 0.000 | 1, 1, 1 |
| Solve step time. | 0.210 | 1, 1, 1 |
| Solver(PDE). | 0.270 | 3, 3, 3 |
| Store nodal values: Serial. | 0.000 | 80, 80, 80 |
| TS4Geom | 0.000 | 1, 1, 1 |
| Total time spent in Symbolic. | 0.030 | 1, 1, 1 |
| circuit command | 0.000 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| equation command | 0.000 | 14, 14, 14 |
| init command | 0.960 | 1, 1, 1 |
| mater command | 0.050 | 95, 95, 95 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.010 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 68, 68, 68 |
| sel command | 0.060 | 71, 71, 71 |
| select command | 0.010 | 6, 6, 6 |
| solution command | 0.000 | 89, 89, 89 |
| solve command | 0.110 | 1, 1, 1 |
| struct command | 1.100 | 1, 1, 1 |
| supply command | 0.000 | 9, 9, 9 |
| term command | 0.020 | 87, 87, 87 |

### vendor: thermal, module_elapsed

| Native label | Median seconds | Calls per run |
|---|---:|---|
| BoxMethod by Region | 1.610 | 1, 1, 1 |
| Mechanics step | 0.000 | 1, 1, 1 |
| Other Program Parts | 1.340 | 1, 1, 1 |
| Prepare structure | 0.000 | 1, 1, 1 |
| Serial mode assembly. | 0.020 | 5, 5, 5 |
| SetTemp command | 0.000 | 1, 1, 1 |
| Solve step time. | 0.220 | 1, 1, 1 |
| Solver(PDE). | 0.280 | 3, 3, 3 |
| Store nodal values: Serial. | 0.000 | 80, 80, 80 |
| TS4Geom | 0.000 | 1, 1, 1 |
| Total time spent in Symbolic. | 0.030 | 1, 1, 1 |
| circuit command | 0.000 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| equation command | 0.000 | 14, 14, 14 |
| init command | 0.990 | 1, 1, 1 |
| mater command | 0.050 | 95, 95, 95 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.010 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 68, 68, 68 |
| sel command | 0.060 | 71, 71, 71 |
| select command | 0.010 | 6, 6, 6 |
| solution command | 0.000 | 89, 89, 89 |
| solve command | 0.110 | 1, 1, 1 |
| struct command | 1.130 | 1, 1, 1 |
| supply command | 0.000 | 9, 9, 9 |
| term command | 0.020 | 87, 87, 87 |

### vendor: mechanics, module_cpu

| Native label | Median seconds | Calls per run |
|---|---:|---|
| Mechanics assembly (serial mode) | 0.340 | 1, 1, 1 |
| Mechanics preassembly | 0.100 | 1, 1, 1 |
| Mechanics step | 1.320 | 1, 1, 1 |
| Other Program Parts | 1.230 | 1, 1, 1 |
| Prepare structure | 0.000 | 1, 1, 1 |
| Solve step time. | 0.030 | 1, 1, 1 |
| Solver(Mechanics) | 1.910 | 1, 1, 1 |
| circuit command | 0.000 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| init command | 0.880 | 1, 1, 1 |
| mater command | 0.050 | 94, 94, 94 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.000 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 66, 66, 66 |
| sel command | 0.040 | 191, 191, 191 |
| select command | 0.010 | 7, 7, 7 |
| solution command | 0.000 | 84, 84, 84 |
| solve command | 0.420 | 1, 1, 1 |
| stressdata command | 0.000 | 1, 1, 1 |
| struct command | 2.410 | 1, 1, 1 |
| supply command | 0.000 | 3, 3, 3 |
| term command | 0.000 | 6, 6, 6 |

### vendor: mechanics, module_elapsed

| Native label | Median seconds | Calls per run |
|---|---:|---|
| Mechanics assembly (serial mode) | 0.350 | 1, 1, 1 |
| Mechanics preassembly | 0.100 | 1, 1, 1 |
| Mechanics step | 1.360 | 1, 1, 1 |
| Other Program Parts | 1.290 | 1, 1, 1 |
| Prepare structure | 0.000 | 1, 1, 1 |
| Solve step time. | 0.030 | 1, 1, 1 |
| Solver(Mechanics) | 1.970 | 1, 1, 1 |
| circuit command | 0.000 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| init command | 0.910 | 1, 1, 1 |
| mater command | 0.060 | 94, 94, 94 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.000 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 66, 66, 66 |
| sel command | 0.040 | 191, 191, 191 |
| select command | 0.010 | 7, 7, 7 |
| solution command | 0.000 | 84, 84, 84 |
| solve command | 0.440 | 1, 1, 1 |
| stressdata command | 0.000 | 1, 1, 1 |
| struct command | 2.490 | 1, 1, 1 |
| supply command | 0.000 | 3, 3, 3 |
| term command | 0.000 | 6, 6, 6 |

### stressthermal: thermal, module_cpu

| Native label | Median seconds | Calls per run |
|---|---:|---|
| BoxMethod by Region | 1.560 | 1, 1, 1 |
| Mechanics step | 0.000 | 1, 1, 1 |
| Other Program Parts | 1.340 | 1, 1, 1 |
| Prepare structure | 0.000 | 1, 1, 1 |
| Serial mode assembly. | 0.020 | 5, 5, 5 |
| SetTemp command | 0.010 | 1, 1, 1 |
| Solve step time. | 0.210 | 1, 1, 1 |
| Solver(PDE). | 0.250 | 3, 3, 3 |
| Store nodal values: Serial. | 0.000 | 80, 80, 80 |
| TS4Geom | 0.010 | 1, 1, 1 |
| Total time spent in Symbolic. | 0.020 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| equation command | 0.000 | 14, 14, 14 |
| init command | 0.800 | 1, 1, 1 |
| mater command | 0.050 | 95, 95, 95 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.010 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 72, 72, 72 |
| sel command | 0.070 | 71, 71, 71 |
| select command | 0.010 | 6, 6, 6 |
| solution command | 0.010 | 89, 89, 89 |
| solve command | 0.110 | 1, 1, 1 |
| struct command | 1.130 | 1, 1, 1 |
| supply command | 0.000 | 9, 9, 9 |
| term command | 0.020 | 87, 87, 87 |

### stressthermal: thermal, module_elapsed

| Native label | Median seconds | Calls per run |
|---|---:|---|
| BoxMethod by Region | 1.610 | 1, 1, 1 |
| Mechanics step | 0.000 | 1, 1, 1 |
| Other Program Parts | 1.400 | 1, 1, 1 |
| Prepare structure | 0.000 | 1, 1, 1 |
| Serial mode assembly. | 0.020 | 5, 5, 5 |
| SetTemp command | 0.010 | 1, 1, 1 |
| Solve step time. | 0.220 | 1, 1, 1 |
| Solver(PDE). | 0.250 | 3, 3, 3 |
| Store nodal values: Serial. | 0.000 | 80, 80, 80 |
| TS4Geom | 0.010 | 1, 1, 1 |
| Total time spent in Symbolic. | 0.020 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| equation command | 0.000 | 14, 14, 14 |
| init command | 0.830 | 1, 1, 1 |
| mater command | 0.050 | 95, 95, 95 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.010 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 72, 72, 72 |
| sel command | 0.070 | 71, 71, 71 |
| select command | 0.010 | 6, 6, 6 |
| solution command | 0.010 | 89, 89, 89 |
| solve command | 0.120 | 1, 1, 1 |
| struct command | 1.160 | 1, 1, 1 |
| supply command | 0.000 | 9, 9, 9 |
| term command | 0.020 | 87, 87, 87 |

### stressthermal: mechanics, module_cpu

| Native label | Median seconds | Calls per run |
|---|---:|---|
| BoxMethod by Region | 1.570 | 1, 1, 1 |
| Mechanics assembly (serial mode) | 0.570 | 1, 1, 1 |
| Mechanics preassembly | 0.180 | 1, 1, 1 |
| Mechanics step | 1.590 | 1, 1, 1 |
| Other Program Parts | 1.350 | 1, 1, 1 |
| Solve step time. | 0.030 | 1, 1, 1 |
| Solver(Mechanics) | 2.450 | 1, 1, 1 |
| TS4Geom | 0.010 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| init command | 0.730 | 1, 1, 1 |
| mater command | 0.050 | 94, 94, 94 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.010 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 70, 70, 70 |
| sel command | 0.040 | 231, 231, 231 |
| select command | 0.010 | 7, 7, 7 |
| solution command | 0.010 | 84, 84, 84 |
| solve command | 0.490 | 1, 1, 1 |
| stressdata command | 0.000 | 1, 1, 1 |
| struct command | 3.040 | 1, 1, 1 |
| supply command | 0.000 | 3, 3, 3 |
| term command | 0.000 | 6, 6, 6 |

### stressthermal: mechanics, module_elapsed

| Native label | Median seconds | Calls per run |
|---|---:|---|
| BoxMethod by Region | 1.610 | 1, 1, 1 |
| Mechanics assembly (serial mode) | 0.590 | 1, 1, 1 |
| Mechanics preassembly | 0.190 | 1, 1, 1 |
| Mechanics step | 1.640 | 1, 1, 1 |
| Other Program Parts | 1.410 | 1, 1, 1 |
| Solve step time. | 0.030 | 1, 1, 1 |
| Solver(Mechanics) | 2.520 | 1, 1, 1 |
| TS4Geom | 0.010 | 1, 1, 1 |
| contact command | 0.000 | 5, 5, 5 |
| init command | 0.760 | 1, 1, 1 |
| mater command | 0.050 | 94, 94, 94 |
| math command | 0.000 | 9, 9, 9 |
| mgoals command | 0.010 | 1, 1, 1 |
| mode command | 0.000 | 2, 2, 2 |
| region command | 0.010 | 70, 70, 70 |
| sel command | 0.050 | 231, 231, 231 |
| select command | 0.010 | 7, 7, 7 |
| solution command | 0.010 | 84, 84, 84 |
| solve command | 0.500 | 1, 1, 1 |
| stressdata command | 0.000 | 1, 1, 1 |
| struct command | 3.130 | 1, 1, 1 |
| supply command | 0.000 | 3, 3, 3 |
| term command | 0.000 | 6, 6, 6 |

### MAPDL: thermal

| Native label | Median seconds |
|---|---:|
| Elapsed time in element formation & assembly | 4.000 |
| Elapsed time in element result calculations | 3.300 |
| Elapsed time in equation solver | 0.500 |
| Elapsed time spent computing solution | 8.300 |
| Elapsed time spent obtaining a license | 1.400 |
| Elapsed time spent post-processing model (/POST1) | 0.600 |
| Elapsed time spent pre-processing model (/PREP7) | 0.500 |
| Elapsed time spent solution - postprocessing | 0.000 |
| Elapsed time spent solution - preprocessing | 0.600 |
| Total CPU time for main thread | 9.600 |
| Total CPU time summed for all threads | 9.600 |

### MAPDL: mechanics

| Native label | Median seconds |
|---|---:|
| Elapsed time in element formation & assembly | 2.900 |
| Elapsed time in element result calculations | 5.400 |
| Elapsed time in equation solver | 1.700 |
| Elapsed time spent computing solution | 10.000 |
| Elapsed time spent obtaining a license | 1.400 |
| Elapsed time spent post-processing model (/POST1) | 4.100 |
| Elapsed time spent pre-processing model (/PREP7) | 0.600 |
| Elapsed time spent solution - postprocessing | 0.000 |
| Elapsed time spent solution - preprocessing | 0.300 |
| Total CPU time for main thread | 13.900 |
| Total CPU time summed for all threads | 13.900 |

## Reproduce / evidence

- `package/thermal_bench.cmd`, `package/mechanics_bench.cmd`, `package/mesh.tdr`: matched source inputs.
- `run_vm.py`, `run_mapdl.py`, `monitor_vm_run.py`: runners and load monitor.
- `vm/formal-20261011-a/`: per-run input copies, native logs, hashes, load and matched output files.
- `mapdl/formal-20261011-r*/`: generated CDB, native drivers/logs/results, temperature and stress exports.
- `package-comparison-formal.json`: full machine-readable comparison and SI stress audits.
- `mapdl/orientation-corrected-r*/mechanics/regionwise-recovery.json`: corrected recovered maxima and their locations. Earlier formal mechanics runs used unrotated silicon stiffness and are superseded.
- `package-orientation-audit.json` and `pillar/rotated-cubic-native/verification.json`: independent native source stress/strain and MAPDL affine-patch verification of the rotated cubic tensor. Thermal solutions are unchanged and reused with hashes in each corrected run.
- `summarize_package.py`, `recover_mapdl_calibration.py`, `build_package_report.py`: offline regeneration.
- Previous native converter analytical checks and regression evidence are indexed in README.md.

Timing conclusions remain qualified by the recorded swap activity, native instrumentation scopes and host/VM differences. These observations do not establish an unconditional speedup.
