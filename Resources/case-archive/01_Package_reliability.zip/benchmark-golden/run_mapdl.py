"""Run converter-generated model archives with separate MAPDL solve drivers."""
from pathlib import Path
import sys,subprocess,shutil,json,time,hashlib
sys.path.insert(0,r'D:\my_repos\si_to_ans_converter')
from converter_core.conversion.deserialize import CmdToIxDeserializer
from converter_core.conversion.serialize import IxDataSerializer
from converter_core.input.ix_temperature import IxTemperatureField
ROOT=Path(__file__).parent
CASE=ROOT/'package'
EXE=Path(r'D:\Program Files\ANSYS Inc\v261\ansys\bin\winx64\ANSYS261.exe')
TAG=sys.argv[1] if len(sys.argv)>1 else 'calibration'
OUT=ROOT/'mapdl'/TAG
MODE=sys.argv[2] if len(sys.argv)>2 else 'both'

def run(mode,ix,output_root=None):
    d=(Path(output_root) if output_root is not None else OUT)/mode;d.mkdir(parents=True,exist_ok=True)
    if (d/'solve.out').exists():raise RuntimeError('Refusing to overwrite an existing run')
    prep_started=time.perf_counter()
    IxDataSerializer.write(ix,d/'model.cdb')
    (d/'model-manifest.json').write_text(json.dumps(dict(
        material_names=[m.name for m in ix.materials],
        node_ids=sorted({r[0] for b in ix.mesh.nodes for r in b._data}),
        volume_elements=sum(len(b._data) for b in ix.mesh.elements),
        region_element_ids={s.name:list(s._data) for s in ix.mesh.element_sets},
        stress_recovery='Native per-material AVPRIN,0 is diagnostic only. Primary comparison requires regionwise volume-weighted element tensor recovery, then von Mises.',
    ),indent=2))
    node_max=max(r[0] for b in ix.mesh.nodes for r in b._data)
    post='''*DIM,vals,ARRAY,{n},1
*VGET,vals(1,1),NODE,1,TEMP
*CFOPEN,temperature,txt
*VWRITE,SEQU,vals(1,1)
(F12.0,E26.17)
*CFCLOS
'''.format(n=node_max) if mode=='thermal' else '''/OUTPUT,element_stress,txt
/FORMAT,10,E,24,16
PRESOL,S,PRIN
/OUTPUT
*DIM,dispx,ARRAY,{n},1
*DIM,dispy,ARRAY,{n},1
*DIM,dispz,ARRAY,{n},1
*VGET,dispx(1,1),NODE,1,U,X
*VGET,dispy(1,1),NODE,1,U,Y
*VGET,dispz(1,1),NODE,1,U,Z
*CFOPEN,displacement,txt
*VWRITE,SEQU,dispx(1,1),dispy(1,1),dispz(1,1)
(F12.0,3E26.17)
*CFCLOS
'''.format(n=node_max)
    if mode == 'mechanics':
        import re
        # Read actual target material IDs; do not infer them from source order.
        material_ids=sorted({int(m.group(1)) for m in re.finditer(
            r'^MPDATA,UNBL,1,(?:EX|C11),([0-9]+),',
            (d/'model.cdb').read_text(),re.MULTILINE)} | {int(m.group(1)) for m in re.finditer(
            r'^TB,ANEL,([0-9]+),',(d/'model.cdb').read_text(),re.MULTILINE)})
        if not material_ids:
            raise ValueError('No structural material IDs found in exported CDB')
        for mid in material_ids:
            post+=f'''ALLSEL,ALL
ESEL,S,MAT,,{mid}
NSLE,S
/GRAPHICS,FULL
AVPRIN,0
/OUTPUT,material_{mid}_stress,txt
PRNSOL,S,PRIN,,,,,ESOL
/OUTPUT
'''
        post+='ALLSEL,ALL\n'
        post+='''/OUTPUT,element_stress_components,txt
/FORMAT,10,E,24,16
RSYS,0
PRESOL,S,COMP
/OUTPUT
'''
    driver='''/BATCH
/CLEAR,NOSTART
*GET,tstart,ACTIVE,0,TIME,WALL
CDREAD,DB,model,cdb
*GET,tread,ACTIVE,0,TIME,WALL
/SOLU
ANTYPE,STATIC
EQSLV,SPARSE
NSUBST,1
NEQIT,100
OUTRES,ALL,ALL
SOLVE
*GET,tsolve,ACTIVE,0,TIME,WALL
FINISH
/POST1
SET,LAST
'''+post+'''*GET,tpost,ACTIVE,0,TIME,WALL
*CFOPEN,stage_timers,txt
*VWRITE,tstart,tread,tsolve,tpost
(4E26.17)
*CFCLOS
FINISH
/EXIT,NOSAVE
'''
    (d/'solve.inp').write_text(driver)
    preparation_seconds=time.perf_counter()-prep_started
    started=time.time()
    args=[str(EXE),'-b','-smp','-np','1','-m','1024','-db','256','-j',mode,'-i','solve.inp','-o','solve.out']
    print('START',mode,d,flush=True)
    with (d/'launcher.log').open('wb') as launcher:
        p=subprocess.run(args,cwd=d,stdout=launcher,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,timeout=900)
    (d/'run.json').write_text(json.dumps(dict(args=args,exit=p.returncode,wall_seconds=time.time()-started,
       start_epoch=started,archive_and_driver_preparation_seconds=preparation_seconds,cdb_sha256=hashlib.sha256((d/'model.cdb').read_bytes()).hexdigest()),indent=2))
    log=(d/'solve.out').read_text(errors='replace')
    if p.returncode or '*** ERROR ***' in log or '*** FATAL ***' in log:raise RuntimeError(f'{mode} failed; inspect {d}')
    print('DONE',mode,time.time()-started,flush=True)
    return d

if __name__=='__main__' and MODE in ('both','thermal'):
    thermal=CmdToIxDeserializer().deserialize(CASE/'thermal_bench.cmd')
    td=run('thermal',thermal)
if __name__=='__main__' and MODE in ('both','mechanics','shared'):
    mechanical=CmdToIxDeserializer().deserialize(CASE/'mechanics_bench.cmd')
    if MODE!='shared':
        td=ROOT/'mapdl'/sys.argv[3]/'thermal' if len(sys.argv)>3 else OUT/'thermal'
        data={int(float(n)):float(t) for n,t in (row.split() for row in (td/'temperature.txt').read_text().splitlines())}
        ids={r[0] for b in mechanical.mesh.nodes for r in b._data}
        mechanical.steps[0].predefined_fields=[IxTemperatureField([],None,node_values={n:data[n] for n in ids})]
        (OUT/'temperature-provenance.json').write_text(json.dumps({'source':str(td/'temperature.txt'), 'sha256':hashlib.sha256((td/'temperature.txt').read_bytes()).hexdigest(),'scope':'MAPDL own thermal solution; reused because thermal physics is unchanged'},indent=2))
    run('mechanics',mechanical)
