# Current recovery goal — 2026-10-11

Recover Release sinterconnect_run functionality required by the original copper-pillar global-to-local submodel. Complete global solution, own-global displacement transfer and local solution with all essential source constraints retained. Golden-tool fields must never substitute for StressThermal fields.

## Deliverables and current user layout

- Case 1 — Package thermomechanical reliability: case figures/content on the left; separate Accuracy and Performance boxes on the right.
- Case 2 — Submodelling: the same layout, filled from verified three-tool measurements.
- Preserve all other current user edits, including Future Plan. Synchronize HTML, editable draw.io, PPTX and SVG.
- Use Golden tool - S and Golden tool - A. No visible machine information; retain timing environment and scope qualifications in evidence/report.
- Verify equivalent regionwise current von Mises postprocessing, three real repetitions, own-global mapping provenance, native timers and load records.

## Current verified state

Point displacement and face-point penalty constraints have been recovered in the VM source tree. Release build succeeded. Node-rate analytic/vendor regression and anchored face-point vendor regression passed; the final face regression reproduces all four native fields exactly. The original global/local functional pipeline succeeded using its own global displacement.

The formal runner `formal-pillar-recovered-a` is active (host SSH PID 25744, unified session 88161). The first two vendor/StressThermal global-local repetitions completed with exit 0. Revalidate process/log state before further action; do not start duplicate solves. Some observations include guest swap activity, retained rather than silently discarded.

Existing MAPDL `formal-pillar-mapdl-a` supplies three completed own-global pipelines. Collect and audit the new native results after the runner terminates, compare full fields for every repetition, regenerate the report, update only Case 2 result cells, then verify current render and synchronized exports.

## Completion gate

The old completion-audit.json covers an earlier scope that allowed an unsupported StressThermal case. It does not prove this recovery goal. Completion requires all recovered pipelines, source/vendor and regression evidence, repeated benchmark results, own-global provenance, equivalent postprocessing and actual exported-artifact checks. Missing or uncertain evidence keeps this goal active.

## Completion evidence

# Recovery completed — 2026-10-11

Release sinterconnect_run now completes the original copper-pillar global solve and local submodel using its own global displacement. Essential point constraints are retained. Point displacement and face-point penalty assembly were recovered against vendor evidence; nonzero nodal-rate and anchored face regressions pass.

All three formal repetitions completed for StressThermal and Golden tool - S (12 native stages); all 12 full field datasets and own-global mapping hashes passed audit. Existing Golden tool - A provides three completed own-global pipelines with equivalent regionwise stress recovery.

StressThermal peak Mises: global 887.6781968741105 MPa; local 703.7011053179518 MPa. Median native solve: global 16.69 s; local 43.02 s. Performance observations retain swap/load and timing-scope qualifications; no unconditional speedup claim.

Case 2 Accuracy and Performance values are published in the current seven-slide HTML/draw.io/PPTX/SVG exports. The latest two-row performance layout and all other current pages are preserved. Future Plan changed independently during final checking; its latest content was retained and re-exported. 38 completion checks passed in recovery/completion-audit.json.

Evidence: pillar-benchmark.json; pillar-benchmark-report.md; vm/formal-pillar-recovered-a/all-repetitions-field-audit.json; recovery/source-provenance.json; recovery/point-recovery-final.patch; recovery/build-5.log; recovery/node-rate-verification.json; recovery/face-cursor-verification.json. Source files remain in /home/mozztcad/geo3d; no commit was requested or created.
