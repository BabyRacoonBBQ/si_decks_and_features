"""Audit saved MAPDL stresses against its own native equivalent stress output."""
from pathlib import Path
import re,json,hashlib
import numpy as np
from stress_recovery import von_mises
root=Path(__file__).resolve().parent
raw=root/'mapdl/component-recovery-audit/element_components.txt'
principal=root/'mapdl/calibration-fixed/mechanics/element_stress.txt'
num=re.compile(r'[+-]?\d+\.\d+E[+-]\d+')
def parse(path,components):
    result={};eid=None;pending=None
    for line in path.read_text().splitlines():
        m=re.search(r'ELEMENT=\s*(\d+)\s+SOLID285',line)
        if m:eid=int(m[1]);continue
        if eid is None:continue
        vals=num.findall(line)
        if not vals:continue
        node=re.match(r'^\s+(\d+)\s+(?=[+-]?\d+\.)',line)
        if node:
            key=(eid,int(node.group(1)));data=[float(v) for v in vals]
            if components:
                if len(data)!=5:raise ValueError('Unexpected component row')
                pending=(key,data)
            else:
                if len(data)!=5:raise ValueError('Unexpected principal row')
                result[key]=data[-1]
        elif components and pending and len(vals)==1:
            key,data=pending;result[key]=data+[float(vals[0])];pending=None
    if pending:raise ValueError('Incomplete tensor')
    return result
def audit():
    components=parse(raw,True);native=parse(principal,False)
    if set(components)!=set(native):raise ValueError('Native output coverage mismatch')
    keys=sorted(components);s=np.array([components[k] for k in keys]);vm=von_mises(s)
    ref=np.array([native[k] for k in keys]);error=np.abs(vm-ref)
    if not np.allclose(vm,ref,rtol=2e-7,atol=1e-4):raise ValueError('Tensor ordering/unit audit failed')
    if len(keys)!=82477*4:raise ValueError('Incomplete element coverage')
    dev=s.copy();dev[:,:3]-=np.mean(dev[:,:3],axis=1)[:,None]
    dev=dev.reshape(-1,4,6)
    report={'scope':'Saved MAPDL calibration, not a matched cross-tool benchmark',
     'component_order':['XX','YY','ZZ','XY','YZ','XZ'],'stress_unit':'MPa',
     'coordinate_system':'global (RSYS,0)', 'elements':82477,'element_node_rows':len(keys),
     'native_vs_recomputed_mises_max_abs_error_MPa':float(error.max()),
     'unaveraged_max_MPa':float(ref.max()),
     'max_corner_deviatoric_component_range_MPa':float(np.ptp(dev,axis=1).max()),
     'max_corner_tensor_component_range_MPa':float(np.ptp(s.reshape(-1,4,6),axis=1).max()),
     'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),
     'principal_sha256':hashlib.sha256(principal.read_bytes()).hexdigest(),
     'conclusion':'Native equivalent stress and exported global tensor components agree. Regionwise recovery remains a separate step; do not treat the unaveraged peak as the primary comparison.'}
    (root/'mapdl/component-recovery-audit/component-audit.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    

if __name__=='__main__':audit()
