"""Read saved calibration results only; not a performance measurement."""
from pathlib import Path
import subprocess, json, hashlib, time
root=Path(__file__).resolve().parent
src=root/'mapdl/calibration-fixed/mechanics'
out=root/'mapdl/component-recovery-audit'
out.mkdir(exist_ok=True)
if (out/'post.out').exists():
    raise RuntimeError('Refusing to overwrite native evidence')
driver=f"""/BATCH
/CLEAR,NOSTART
CDREAD,DB,'{(src/'model').as_posix()}',cdb
/POST1
FILE,'{(src/'mechanics').as_posix()}',rst
SET,LAST
ALLSEL,ALL
RSYS,0
/GRAPHICS,FULL
/FORMAT,10,E,24,16
/OUTPUT,element_components,txt
PRESOL,S,COMP
/OUTPUT
FINISH
/EXIT,NOSAVE
"""
(out/'post.inp').write_text(driver)
exe=r'D:\Program Files\ANSYS Inc\v261\ansys\bin\winx64\ANSYS261.exe'
t=time.time()
p=subprocess.run([exe,'-b','-smp','-np','1','-m','512','-db','128','-j','post','-i','post.inp','-o','post.out'],cwd=out,creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
(out/'launcher.log').write_bytes(p.stdout)
(out/'audit-run.json').write_text(json.dumps({'purpose':'Saved calibration component export; not benchmark timing','exit':p.returncode,'elapsed_seconds':time.time()-t,'rst_sha256':hashlib.sha256((src/'mechanics.rst').read_bytes()).hexdigest()},indent=2))
log=(out/'post.out').read_text(errors='replace')
if p.returncode or '*** ERROR ***' in log:raise RuntimeError('Native export failed; inspect post.out')
print(out)
