import pytest
from native_timers import sentaurus,mapdl


def test_sentaurus_separates_wall_cpu_and_native_scopes():
    text='''Elapsed Time: 00:02:12
User Time: 00:01:34
CPU Time: 00:01:30
Elapsed time for solve 95.11s
Detailed CPU time report:
30.25 sec (32.1%) Solver(Mechanics) (310 calls).
Detailed elapsed time report:
31.28 sec (32.2%) Solver(Mechanics) (310 calls).
'''
    r=sentaurus(text)
    assert r['totals']=={'elapsed':132.,'user':94.,'cpu':90.}
    assert r['module_cpu'][0]['seconds']==30.25
    assert r['module_elapsed'][0]['seconds']==31.28
    assert r['solve_elapsed']==[95.11]


def test_mapdl_hours_and_nested_statistics():
    r=mapdl('''Elapsed Time (sec) = 30.992
Elapsed time spent computing solution : 10.3 seconds
Elapsed time in equation solver : 0.7 seconds
RUN COMPLETED
''','0.001 0.002 0.004 0.005')
    assert r['totals']['elapsed']==30.992
    assert r['driver_intervals']['archive_read']==pytest.approx(3.6)
    assert len(r['native_stages'])==2
    assert r['completed']


def test_failure_and_missing_timers_are_not_success():
    assert not mapdl('Elapsed Time (sec) = 12\n*** ERROR ***\nRUN COMPLETED')['completed']
    with pytest.raises(ValueError):sentaurus('solver finished')
    with pytest.raises(ValueError):mapdl('Elapsed Time (sec) = 1','0 1 0 2')
