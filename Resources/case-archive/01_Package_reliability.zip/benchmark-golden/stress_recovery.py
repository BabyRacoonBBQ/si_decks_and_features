"""Common linear-tetrahedron stress recovery; inputs use MPa and one length unit.

Canonical tensor columns: XX, YY, ZZ, XY, YZ, XZ (physical shear stress).
Call separately for every original region. Never concatenate region outputs
and average coincident interface nodes. No solver or file IO occurs here.
"""
import numpy as np


def von_mises(stress_mpa):
    s = np.asarray(stress_mpa, dtype=float)
    if s.ndim != 2 or s.shape[1] != 6 or not np.all(np.isfinite(s)):
        raise ValueError('Expected finite N x 6 stress tensor components in MPa')
    xx, yy, zz, xy, yz, xz = s.T
    return np.sqrt(.5*((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)
                   +3*(xy*xy+yz*yz+xz*xz))


def recover_region(xyz, connectivity, element_stress):
    """Return vertex indices and V-weighted nodal tensors in input column order.

    xyz: coordinates; connectivity: zero-based linear tetrahedron vertex rows;
    element_stress: one constant/centroid tensor per tetrahedron. Conversion
    from integration-point or extrapolated values must be verified upstream.
    """
    xyz = np.asarray(xyz, dtype=float)
    conn = np.asarray(connectivity)
    stress = np.asarray(element_stress, dtype=float)
    if xyz.ndim != 2 or xyz.shape[1] != 3 or not np.all(np.isfinite(xyz)):
        raise ValueError('Invalid coordinates')
    if conn.ndim != 2 or conn.shape[1] != 4 or not len(conn) or conn.dtype.kind not in 'iu':
        raise ValueError('Expected integer tetrahedral connectivity')
    if np.any(conn < 0) or np.any(conn >= len(xyz)):
        raise ValueError('Connectivity references missing nodes')
    if stress.shape != (len(conn), 6) or not np.all(np.isfinite(stress)):
        raise ValueError('Expected one finite tensor per tetrahedron')
    if len(np.unique(np.sort(conn, axis=1), axis=0)) != len(conn):
        raise ValueError('Duplicate tetrahedron')
    points = xyz[conn]
    volumes = np.abs(np.linalg.det(points[:, 1:]-points[:, :1]))/6.
    if np.any(volumes <= 0) or not np.all(np.isfinite(volumes)):
        raise ValueError('Degenerate tetrahedron')
    ids = np.unique(conn)
    local = np.searchsorted(ids, conn)
    sums = np.zeros((len(ids), 6))
    weights = np.zeros(len(ids))
    for corner in range(4):
        np.add.at(sums, local[:, corner], stress*volumes[:, None])
        np.add.at(weights, local[:, corner], volumes)
    return ids, sums/weights[:, None]
