from pathlib import Path
import os,sys,subprocess,json,time,hashlib,shutil,platform,fcntl
ROOT=Path('/home/mozztcad/si-bench/golden-package-20261010')
BIN={'vendor':Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect'),
     'stressthermal':Path('/home/mozztcad/geo3d/build/sinterconnect_run')}
tag=sys.argv[1] if len(sys.argv)>1 else 'calibration'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
lock=open('/tmp/geo3d-sinterconnect-heavy.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TDR_VERSION='16',PYTHONNOUSERSITE='1')
for k in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(k,None)
environment={k:subprocess.check_output(cmd,text=True) for k,cmd in {
    'os':['cat','/etc/os-release'],'cpu':['lscpu'],'memory':['free','-b'],'kernel':['uname','-a'],
    'source_commit':['git','-C','/home/mozztcad/geo3d','rev-parse','HEAD'],
    'source_dirty':['git','-C','/home/mozztcad/geo3d','status','--short']}.items()}
environment['binary_sha256']={k:sha(p) for k,p in BIN.items()}
environment['affinity_cpu']=4;environment['threads']=1
(ROOT/f'environment-{tag}.json').write_text(json.dumps(environment,indent=2))

def swap():
    return {r.split()[0]:int(r.split()[1]) for r in Path('/proc/vmstat').read_text().splitlines() if r.startswith(('pswpin ','pswpout '))}
def settle(d,mode):
    for attempt in range(12):
        s=subprocess.check_output(['vmstat','1','6'],text=True)
        (d/f'{mode}-load-before-{attempt}.txt').write_text(s)
        rows=[list(map(int,r.split())) for r in s.splitlines() if r.split() and r.split()[0].isdigit()][1:]
        if rows and all(r[6]==0 and r[7]==0 and r[14]>=95 for r in rows):return
    raise RuntimeError('VM load did not settle; no benchmark launched')

reps=[0] if tag.startswith('calibration') else [1,2,3]
for rep in reps:
    kinds=['vendor','stressthermal'] if rep%2 else ['stressthermal','vendor']
    for kind in kinds:
        d=ROOT/f'{tag}-r{rep}-{kind}';d.mkdir(exist_ok=False)
        for p in (ROOT/'inputs').iterdir():shutil.copy2(p,d/p.name)
        for mode in ('thermal','mechanics'):
            settle(d,mode)
            if sha(BIN[kind])!=environment['binary_sha256'][kind]:raise RuntimeError('Binary changed during benchmark')
            before=swap(); t=time.time()
            monitor_file=(d/f'{mode}-load.txt').open('w')
            mon=subprocess.Popen(['vmstat','1'],stdout=monitor_file)
            args=['/usr/bin/time','-v','timeout','-k','10','600','taskset','-c','4',str(BIN[kind])]
            if kind=='vendor':args+=['--noSyntaxCheck']
            args += [f'{mode}_bench.cmd']
            print('BEGIN',tag,rep,kind,mode,flush=True)
            with (d/f'{mode}-stdout.log').open('w') as out,(d/f'{mode}-stderr.log').open('w') as err:
                p=subprocess.run(args,cwd=d,env=env,stdout=out,stderr=err)
            mon.terminate();mon.wait();monitor_file.close()
            after=swap()
            meta=dict(exit=p.returncode,wall_seconds=time.time()-t,start_epoch=t,swap_before=before,swap_after=after,
               timing_no_vm_swap=before==after,binary_sha256=sha(BIN[kind]),deck_sha256=sha(d/f'{mode}_bench.cmd'),mesh_sha256=sha(d/'mesh.tdr'))
            (d/f'{mode}-run.json').write_text(json.dumps(meta,indent=2))
            print('END',kind,mode,json.dumps(meta),flush=True)
            if p.returncode:raise RuntimeError('Solver failed; inspect saved logs')
            if not (d/f'{mode}_sis.tdr').exists():raise RuntimeError('Missing result artifact')
print('BENCHMARK_COMPLETE',tag,flush=True)
