"""Copy completed VM benchmark evidence without changing the remote runs."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
tag=sys.argv[1]
if not all(c.isalnum()or c in '-_' for c in tag):raise ValueError('Invalid tag')
remote='/home/mozztcad/si-bench/golden-package-20261010'
out=root/'vm'/tag
if not (out/'exit.json').exists():raise RuntimeError('Runner not yet terminal')
subprocess.run(['scp',f'mozztcad@192.168.43.128:{remote}/environment-{tag}.json',str(out/'environment.json')],check=True)
for rep in ([0]if tag.startswith('calibration')else [1,2,3]):
    for kind in ['vendor','stressthermal']:
        d=out/f'r{rep}-{kind}';d.mkdir(exist_ok=True)
        rd=f'{remote}/{tag}-r{rep}-{kind}'
        for glob in ['*-run.json','*-stdout.log','*-stderr.log','*-load*.txt','*.cmd']:
            subprocess.run(['scp',f'mozztcad@192.168.43.128:{rd}/{glob}',str(d)],check=True)
        # One complete matched output pair is sufficient for recovery validation;
        # all native scalar values and timers remain available for every repetition.
        if rep in (0,1):
            for name in ['thermal_sis.tdr','mechanics_sis.tdr']:
                subprocess.run(['scp',f'mozztcad@192.168.43.128:{rd}/{name}',str(d/name)],check=True)
print(out)
