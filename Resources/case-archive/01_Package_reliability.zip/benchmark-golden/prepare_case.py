from pathlib import Path
import shutil,json
r=Path(__file__).parent/'package'
src=(r/'thermal.cmd').read_text()
(r/'thermal_bench.cmd').write_text(src.replace('../mesh-roof/package_msh.tdr','mesh.tdr').replace('tdr=result','tdr=thermal')+'\nselect max name=Temperature info=3\n')
shutil.copy2(r/'coarse_msh.tdr',r/'mesh.tdr')
# Same material constants as the package demonstration. Explicit linear elastic
# case for cross-solver comparison; no plasticity/creep/contact or stress history.
materials={'Silicon':(162e9,.28,3.05e-6),'Copper':(111.5e9,.343,17.75e-6),
 'Copperline':(111.5e9,.343,17.15e-6),'Solder':(9*54.952e9*17.399e9/(3*54.952e9+17.399e9),(3*54.952e9-2*17.399e9)/(2*(3*54.952e9+17.399e9)),21.5e-6),
 'Aluminum':(86e9,.30,24.4e-6),'SmearBeol':(66.5e9,.29,15.3e-6),'Resin':(13e9,.25,34e-6)}
lines=['math numThreads=1','pdbSet Grid AddGasMesh 0',
 'pdbSetDouble Mechanics RefThExpCoeff 0.0','pdbSet Mechanics StressHistory 0',
 'pdbSet Mechanics SaveMaxStress 1','pdbSet Mechanics Save.Displacement.Field 1']
for name,parent in [('Copperline','Copper'),('SmearBeol','Nitride'),('Resin','Copper')]:
    lines.append(f'mater add name={name} new.like={parent}')
for name,(E,nu,alpha) in materials.items():
    K=E/(3*(1-2*nu));G=E/(2*(1+nu))
    lines += [f'pdbSet {name} Mechanics BulkModulus {K*10:.16g}',f'pdbSet {name} Mechanics ShearModulus {G*10:.16g}',
              f'pdbSet {name} Mechanics ThExpCoeff {alpha:.16g}',f'pdbSetBoolean {name} Mechanics IsPlastic 0',
              f'pdbSetBoolean {name} Mechanics IsViscoPlastic 0',f'pdbSetBoolean {name} Mechanics Anisotropic {int(name=="Silicon")}']
lines += ['pdbSet Silicon Mechanics C11 165.7e10','pdbSet Silicon Mechanics C12 63.9e10','pdbSet Silicon Mechanics C44 79.6e10',
 'init tdr=thermal_sis.tdr !load.commands !pdb','select z=Temperature name=FinalTemp store',
 'stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}','mode mechanics',
 'solve temperature=26.844<C> time=1<s> init=1<s> maxstep=1<s> t.final.profile=FinalTemp info=2',
 'puts "BENCH_TMAX [select max name=FinalTemp]"','puts "BENCH_MISES_CURRENT [select max name=MisesStress]"','puts "BENCH_MISES_HISTORY [select max name=MisesStressMax]"',
 'struct tdr=mechanics','select max name=FinalTemp info=3']
(r/'mechanics_bench.cmd').write_text('\n'.join(lines)+'\n')
(r/'material-spec.json').write_text(json.dumps({name:dict(E_Pa=v[0],nu=v[1],alpha_per_K=v[2]) for name,v in materials.items()},indent=2))
print(r)
