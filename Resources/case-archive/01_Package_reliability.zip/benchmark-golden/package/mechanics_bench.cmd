math numThreads=1
pdbSet Grid AddGasMesh 0
pdbSetDouble Mechanics RefThExpCoeff 0.0
pdbSet Mechanics StressHistory 0
pdbSet Mechanics SaveMaxStress 1
pdbSet Mechanics Save.Displacement.Field 1
mater add name=Copperline new.like=Copper
mater add name=SmearBeol new.like=Nitride
mater add name=Resin new.like=Copper
pdbSet Silicon Mechanics BulkModulus 1227272727272.727
pdbSet Silicon Mechanics ShearModulus 632812500000
pdbSet Silicon Mechanics ThExpCoeff 3.05e-06
pdbSetBoolean Silicon Mechanics IsPlastic 0
pdbSetBoolean Silicon Mechanics IsViscoPlastic 0
pdbSetBoolean Silicon Mechanics Anisotropic 1
pdbSet Copper Mechanics BulkModulus 1183651804670.913
pdbSet Copper Mechanics ShearModulus 415115413253.9092
pdbSet Copper Mechanics ThExpCoeff 1.775e-05
pdbSetBoolean Copper Mechanics IsPlastic 0
pdbSetBoolean Copper Mechanics IsViscoPlastic 0
pdbSetBoolean Copper Mechanics Anisotropic 0
pdbSet Copperline Mechanics BulkModulus 1183651804670.913
pdbSet Copperline Mechanics ShearModulus 415115413253.9092
pdbSet Copperline Mechanics ThExpCoeff 1.715e-05
pdbSetBoolean Copperline Mechanics IsPlastic 0
pdbSetBoolean Copperline Mechanics IsViscoPlastic 0
pdbSetBoolean Copperline Mechanics Anisotropic 0
pdbSet Solder Mechanics BulkModulus 549519999999.9999
pdbSet Solder Mechanics ShearModulus 173990000000
pdbSet Solder Mechanics ThExpCoeff 2.15e-05
pdbSetBoolean Solder Mechanics IsPlastic 0
pdbSetBoolean Solder Mechanics IsViscoPlastic 0
pdbSetBoolean Solder Mechanics Anisotropic 0
pdbSet Aluminum Mechanics BulkModulus 716666666666.6665
pdbSet Aluminum Mechanics ShearModulus 330769230769.2308
pdbSet Aluminum Mechanics ThExpCoeff 2.44e-05
pdbSetBoolean Aluminum Mechanics IsPlastic 0
pdbSetBoolean Aluminum Mechanics IsViscoPlastic 0
pdbSetBoolean Aluminum Mechanics Anisotropic 0
pdbSet SmearBeol Mechanics BulkModulus 527777777777.7777
pdbSet SmearBeol Mechanics ShearModulus 257751937984.4961
pdbSet SmearBeol Mechanics ThExpCoeff 1.53e-05
pdbSetBoolean SmearBeol Mechanics IsPlastic 0
pdbSetBoolean SmearBeol Mechanics IsViscoPlastic 0
pdbSetBoolean SmearBeol Mechanics Anisotropic 0
pdbSet Resin Mechanics BulkModulus 86666666666.66666
pdbSet Resin Mechanics ShearModulus 52000000000
pdbSet Resin Mechanics ThExpCoeff 3.4e-05
pdbSetBoolean Resin Mechanics IsPlastic 0
pdbSetBoolean Resin Mechanics IsViscoPlastic 0
pdbSetBoolean Resin Mechanics Anisotropic 0
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
init tdr=thermal_sis.tdr !load.commands !pdb
select z=Temperature name=FinalTemp store
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
mode mechanics
solve temperature=26.844<C> time=1<s> init=1<s> maxstep=1<s> t.final.profile=FinalTemp info=2
puts "BENCH_TMAX [select max name=FinalTemp]"
puts "BENCH_MISES_CURRENT [select max name=MisesStress]"
puts "BENCH_MISES_HISTORY [select max name=MisesStressMax]"
struct tdr=mechanics
select max name=FinalTemp info=3
