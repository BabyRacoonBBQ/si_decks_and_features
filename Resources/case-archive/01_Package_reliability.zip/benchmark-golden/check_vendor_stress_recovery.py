"""Offline audit of an archived vendor TDR; never launches a solver."""
from pathlib import Path
import h5py,numpy as np,json,hashlib
from stress_recovery import recover_region
root=Path(__file__).parent
path=root.parent/'architecture-overview/StressThermal/performance-benchmark/slide-evidence/demo-coupled-vendor/result_sis.tdr'
text=lambda x:x.decode() if isinstance(x,bytes) else str(x)
report={'input':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'status':'Archived result recovery audit, not a fresh benchmark','regions':[]}
with h5py.File(path) as f:
    g=f['collection/geometry_0'];v=g['vertex'][:]
    xyz=np.column_stack([v[a] for a in ('x','y','z')])
    fields={(int(d.attrs['region']),text(d.attrs['name'])):d for d in g['state_0'].values() if 'values' in d}
    for key,r in g.items():
        if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0 or text(r.attrs.get('material'))=='Gas':continue
        rid=int(key[7:]);conn=r['elements_0'][:].reshape(-1,5)
        assert np.all(conn[:,0]==5)
        conn=conn[:,1:];ids=np.unique(conn);local=np.searchsorted(ids,conn)
        x=xyz[conn];vol=np.abs(np.linalg.det(x[:,1:]-x[:,:1]))/6.
        el=fields[rid,'StressEL']['values'][:].reshape(-1,6)
        nodal=fields[rid,'Stress']['values'][:].reshape(-1,6)
        recovered_ids,recovered=recover_region(xyz,conn,el)
        if not np.array_equal(recovered_ids,ids) or not np.allclose(recovered,nodal,rtol=1e-11,atol=1e-3):
            raise ValueError(f'Common recovery disagrees with vendor Stress in region {rid}')
        errors={}
        for name,w in [('volume',vol),('arithmetic',np.ones(len(vol)))]:
            sums=np.zeros((len(ids),6));den=np.zeros(len(ids))
            for j in range(4):
                np.add.at(sums,local[:,j],el*w[:,None]);np.add.at(den,local[:,j],w)
            reconstructed=sums/den[:,None]
            errors[name]={'max_abs_component_error_mpa':float(np.max(np.abs(reconstructed-nodal))*1e-7),
                         'relative_l2':float(np.linalg.norm(reconstructed-nodal)/np.linalg.norm(nodal))}
        report['regions'].append({'region':rid,'material':text(r.attrs['material']),'elements':len(el),'nodes':len(ids),'errors':errors})
out=root/'vendor-stress-recovery-audit.json';out.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report['regions'],indent=2))
