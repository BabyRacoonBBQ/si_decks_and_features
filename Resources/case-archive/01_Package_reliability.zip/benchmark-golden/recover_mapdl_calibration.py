"""Regionwise recovery of audited MAPDL calibration stresses on the source mesh."""
from pathlib import Path
import json,re,hashlib,sys
import h5py,numpy as np
from stress_recovery import recover_region,von_mises
from audit_mapdl_components import parse
root=Path(__file__).resolve().parent
run=root/'mapdl'/sys.argv[1]/'mechanics' if len(sys.argv)>1 else root/'mapdl/calibration-fixed/mechanics'
if len(sys.argv)>2:run=Path(sys.argv[1]).resolve()
cdb=run/'model.cdb'
mesh=root/'package/mesh.tdr'
if len(sys.argv)>2:mesh=Path(sys.argv[2]).resolve()
raw=run/'element_stress_components.txt' if len(sys.argv)>1 else root/'mapdl/component-recovery-audit/element_components.txt'
stress=parse(raw,True)
lines=cdb.read_text().splitlines();nodes={};elements={}
for n,line in enumerate(lines):
    if line.startswith('NBLOCK,'):
        for row in lines[n+2:]:
            if row.startswith('N,'):break
            nid=int(row[:9]);nodes[nid]=[float(row[k:k+21])for k in (27,48,69)]
    if line.startswith('EBLOCK,'):
        for row in lines[n+2:]:
            vals=[int(row[k:k+10])for k in range(0,len(row),10)]
            if vals[0]==-1:break
            if vals[8]!=4:raise ValueError('Non-tetrahedron in structural archive')
            elements[vals[10]]=vals[11:15]
lookup={tuple(sorted(conn)):eid for eid,conn in elements.items()}
if len(lookup)!=len(elements):raise ValueError('Duplicate structural connectivity')
report={'scope':'Regionwise recovery for '+str(run),'unit':'MPa','regions':[],
        'mesh_sha256':hashlib.sha256(mesh.read_bytes()).hexdigest(),
        'method':'Original-region volume-weighted tensor recovery, followed by current-state von Mises. Centroid tensor is mean of four element-node tensors; checked against corner-specific recovery.'}
text=lambda v:v.decode()if isinstance(v,bytes)else str(v)
with h5py.File(mesh)as f:
    g=f['collection/geometry_0'];v=g['vertex'][:];xyz=np.column_stack([v[k]for k in ('x','y','z')])
    unit=text(g.attrs.get('unit:name','um'))
    if unit not in ('um','cm'):raise ValueError('Unaudited source coordinate unit')
    if unit=='cm':xyz*=1e4
    for nid,coord in nodes.items():
        if not np.allclose(xyz[nid-1]/1000,coord,rtol=1e-10,atol=1e-10):raise ValueError('CDB/source coordinate mismatch')
    covered=set()
    for key,r in g.items():
        if not key.startswith('region_')or int(r.attrs.get('type',-1))!=0 or text(r.attrs.get('material'))=='Gas':continue
        packed=r['elements_0'][:].reshape(-1,5)
        if not np.all(packed[:,0]==5):raise ValueError('Non-tetrahedral region')
        conn=packed[:,1:];eids=[lookup[tuple(sorted(row+1))]for row in conn];covered.update(eids)
        corners=np.array([[stress[eid,int(nid+1)]for nid in row]for eid,row in zip(eids,conn)])
        ids,tensor=recover_region(xyz,conn,corners.mean(axis=1));vm=von_mises(tensor)
        # Independent corner-based recovery checks the effect of within-element variation.
        pts=xyz[conn];vol=np.abs(np.linalg.det(pts[:,1:]-pts[:,:1]))/6
        sums=np.zeros_like(tensor);weights=np.zeros(len(ids));loc=np.searchsorted(ids,conn)
        for j in range(4):np.add.at(sums,loc[:,j],corners[:,j]*vol[:,None]);np.add.at(weights,loc[:,j],vol)
        corner_vm=von_mises(sums/weights[:,None]);delta=float(np.max(np.abs(vm-corner_vm)))
        if delta>1e-3:raise ValueError('Centroid/corner recovery equivalence not established')
        n=int(np.argmax(vm));report['regions'].append({'region':key,'name':text(r.attrs.get('name',key)),'material':text(r.attrs['material']),'elements':len(conn),'maximum_mises_MPa':float(vm[n]),'vertex_id_zero_based':int(ids[n]),'position_um':xyz[ids[n]].tolist(),'centroid_vs_corner_mises_max_difference_MPa':delta})
    if covered!=set(elements):raise ValueError('Source regions do not cover all structural elements')
report['maximum']=max(report['regions'],key=lambda r:r['maximum_mises_MPa'])
output=run/'regionwise-recovery.json' if len(sys.argv)>1 else root/'mapdl/component-recovery-audit/regionwise-recovery.json'
output.write_text(json.dumps(report,indent=2))
print(json.dumps(report['maximum'],indent=2))
