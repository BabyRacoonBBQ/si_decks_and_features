"""Summarize native timers, scalar outputs, and recorded host/VM load."""
from pathlib import Path
import sys,json,re,statistics
from native_timers import sentaurus
root=Path(__file__).resolve().parent/'vm'/sys.argv[1]
samples=[json.loads(line)for line in (root/'host-load.jsonl').read_text().splitlines()]
rows=[]
for d in sorted(root.glob('r*-*')):
    for mode in ['thermal','mechanics']:
        meta=json.loads((d/f'{mode}-run.json').read_text())
        log=(d/f'{mode}-stdout.log').read_text(errors='replace')
        timer=sentaurus(log)
        scalars={k:float(v)for k,v in re.findall(r'^BENCH_(\w+)\s+([\d.eE+\-]+)\s*$',log,re.M)}
        load=[s for s in samples if meta['start_epoch']<=s['epoch']<=meta['start_epoch']+meta['wall_seconds']]
        row={'run':d.name,'tool':d.name.split('-',1)[1],'mode':mode,'metadata':meta,'native_timers':timer,
             'temperature_max_K':scalars.get('TMAX'),'current_mises_max_MPa':scalars.get('MISES_CURRENT',0)*1e-7 if 'MISES_CURRENT'in scalars else None,
             'host_load':{'samples':len(load),'mean_cpu_percent':statistics.mean(s['cpu_percent']for s in load)if load else None,'max_cpu_percent':max((s['cpu_percent']for s in load),default=None),'min_available_GiB':min((s['available_memory']/2**30 for s in load),default=None)},
             'vm_swap_pages':{k:meta['swap_after'][k]-meta['swap_before'][k]for k in meta['swap_before']}}
        if meta['exit']!=0:raise ValueError('Failed run cannot be summarized as completed')
        rows.append(row)
summary=[]
for tool in ['vendor','stressthermal']:
    for mode in ['thermal','mechanics']:
        data=[r for r in rows if r['tool']==tool and r['mode']==mode]
        totals=[r['native_timers']['totals']['elapsed']for r in data]
        solve=[sum(r['native_timers']['solve_elapsed'])for r in data]
        summary.append({'tool':tool,'mode':mode,'runs':len(data),'strict_no_vm_swap_runs':sum(r['metadata']['timing_no_vm_swap']for r in data),'native_total_s':{'median':statistics.median(totals),'min':min(totals),'max':max(totals)},'inclusive_solve_s':{'median':statistics.median(solve),'min':min(solve),'max':max(solve)},'temperature_max_K':[r['temperature_max_K']for r in data],'current_mises_max_MPa':[r['current_mises_max_MPa']for r in data]})
result={'status':'Measured runs. Load qualification must be reviewed before any performance claim. All runs retained, including nonzero system swap counters.','summary':summary,'runs':rows}
(root/'summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(summary,indent=2))
