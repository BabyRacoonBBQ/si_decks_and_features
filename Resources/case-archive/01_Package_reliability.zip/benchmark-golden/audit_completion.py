"""Check the final deliverables and the evidence selected by their reports."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,zipfile
root=Path(__file__).resolve().parent
deck=root.parent/'architecture-overview/StressThermal'
checks=[]
def check(name,condition,evidence):
    checks.append(dict(requirement=name,passed=bool(condition),evidence=str(evidence)))
    if not condition:raise AssertionError(name+': '+str(evidence))
pkg=json.loads((root/'package-comparison-formal.json').read_text(encoding='utf-8'))
pillar=json.loads((root/'pillar/pillar-benchmark.json').read_text(encoding='utf-8'))
scene=json.loads((deck/'scene.json').read_text(encoding='utf-8'))
old=json.loads((root/'pillar/other-slides-before-final-render.json').read_text(encoding='utf-8'))
check('One new slide; latest other five pages preserved',len(scene)==6 and [s for s in scene if s['id']!='benchmark']==old,root/'pillar/other-slides-before-final-render.json')
ids=[s['id'] for s in scene]
check('Benchmark immediately follows Application cases',ids.index('benchmark')==ids.index('reliability')+1,ids)
s=next(s for s in scene if s['id']=='benchmark')
labels=[i['text'] for i in s['items'] if i['type']=='text']
check('Requested S/A naming and no visible machine information',not any('Golden tool 1' in t or 'Golden tool 2' in t or any(k in t for k in ('i7-13700F','Rocky Linux','Windows 11','GiB','vCPU')) for t in labels) and any('Golden tool - S' in t for t in labels) and any('Golden tool - A' in t for t in labels),labels[:4])
check('Two case columns, each with Accuracy / Performance',labels.count('ACCURACY')==2 and labels.count('PERFORMANCE')==2,labels[:4])
check('Real package data for all three tools',set(pkg['accuracy'])=={'vendor','stressthermal','mapdl'} and all(a['repetitions_identical_scalar_maxima'] for a in pkg['accuracy'].values()),root/'package-comparison-formal.json')
check('Corrected silicon mechanics selected',all('orientation-corrected' in r['source_runs']['mechanics'] for r in pkg['mapdl_runs']),root/'package-comparison-formal.json')
check('Pillar measured repetitions cover successful global/local pipelines',len(pillar['summary'])==4 and all(r['runs']==3 and r['identical_peaks'] for r in pillar['summary']),root/'pillar/pillar-benchmark.json')
check('StressThermal actual failure retained without a score',len(pillar['failures'])==1 and pillar['failures'][0]['meta']['exit']!=0 and not any(r['tool']=='stressthermal' for r in pillar['runs']),root/'pillar/pillar-benchmark.json')
check('Each MAPDL submodel uses its own global solution',pillar['accuracy_calibration']['mapdl']['vendor_displacements_used'] is False,root/'pillar/calibration-summary.json')
check('Pillar equivalent stress recovery verified from native tensors',all(a['regional_recovery'] for a in pillar['field_audits']),root/'pillar/pillar-benchmark.json')
check('Host load recorded for every successful pillar measurement',all(r['host_load']['samples']>0 for r in pillar['runs']),root/'pillar/pillar-benchmark.json')
check('Native timers and external conversion/mapping scopes retained',all(r['native_timers'] and r['pipeline_stage_wall_s']>0 for r in pillar['runs']),root/'pillar/pillar-benchmark.json')
identity=json.loads((root/'pillar/release-build-identity.json').read_text(encoding='utf-8'))
check('Release StressThermal identity matches measured executable',identity['CMAKE_BUILD_TYPE']=='Release' and identity['sha256']==pillar['vm_environment']['binary_sha256']['stressthermal'],root/'pillar/release-build-identity.json')
for file in ['rotation-regression.xml','crystal-tests.xml','elastic-profile-tests.xml']:
    suites=ET.parse(root.parent/'converter-work'/file).getroot().iter('testsuite')
    suites=list(suites)
    check('Converter tests: '+file,bool(suites) and all(int(e.get('failures','0'))==0 and int(e.get('errors','0'))==0 for e in suites),file)
thermal=json.loads((root.parent/'converter-work/mapdl-checks/verification.json').read_text(encoding='utf-8'))
check('Native analytical thermal checks',set(thermal)=={'conduction','film','radiation'} and all(v['relative_error']<1e-9 for v in thermal.values()),'converter-work/mapdl-checks')
for folder in ['point-spc-host-verified','mapped-boundary-native-verified','rotated-cubic-native']:
    report=json.loads((root/'pillar'/folder/'verification.json').read_text(encoding='utf-8'))
    check('Native converter check: '+folder,report['status']=='passed',folder)
for suffix in ['html','drawio','pptx']:
    p=deck/f'StressThermal-physics.{suffix}'
    check('Export exists: '+suffix,p.is_file() and p.stat().st_size>1000,p)
with zipfile.ZipFile(deck/'StressThermal-physics.pptx') as z:
    slides=[n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
    check('PPTX contains six editable slides',len(slides)==6 and b'Benchmarks' in z.read('ppt/slides/slide5.xml'),deck/'StressThermal-physics.pptx')
    for name in slides:ET.fromstring(z.read(name))
mx=ET.parse(deck/'StressThermal-physics.drawio').getroot()
check('Draw.io contains six pages',len(mx.findall('diagram'))==6,deck/'StressThermal-physics.drawio')
for report in [root/'package-benchmark-report.md',root/'pillar/pillar-benchmark-report.md']:
    check('Detailed report: '+report.name,report.is_file() and report.stat().st_size>3000,report)
check('Benchmarks visible in HTML', 'id="benchmark"' in (deck/'StressThermal-physics.html').read_text(encoding='utf-8'),deck/'StressThermal-physics.html')
layout=deck/'benchmark-layout-check.json'
check('Rendered bounds evidence exists',layout.is_file(),layout)
check('No rendered text lies outside the slide',not json.loads(layout.read_text(encoding='utf-8'))['outside'],layout)
svg=deck/'svg/05-benchmark.svg'
check('Standalone benchmark SVG exists',svg.is_file() and 'Benchmarks' in svg.read_text(encoding='utf-8'),svg)
ET.parse(svg)
result=dict(status='passed',checks=checks,scope='Artifact and evidence completeness; physical checks are documented in the linked native verification reports',
    slide_sha256=hashlib.sha256((deck/'scene.json').read_bytes()).hexdigest())
(root/'completion-audit.json').write_text(json.dumps(result,indent=2))
print(f'{len(checks)} completion evidence checks passed')
