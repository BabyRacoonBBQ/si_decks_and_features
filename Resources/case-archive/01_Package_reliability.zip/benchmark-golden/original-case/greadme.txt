  Coupled Thermomechanical Reliability
Analysis of Power Semiconductor Packages


                                       Abstract
     This TCAD Sentaurus™ project describes a simulation methodology to assess the
     evolution of mechanical stresses during power-device package assembly. A
     sequential simulation approach is used to examine the stresses and J-integral values
     at each assembly step. Thermal simulations are performed on the full-package
     structure to study the temperature profiles generated during operation. These
     temperature profiles are used in coupled thermal and mechanics simulations to
     assess the reliability impact of thermal stresses generated during operation. These
     simulations provide an insight into the evolution and subsequent changes in the
     residual stresses in power-device packages.
Synopsys and the Synopsys logo are registered trademarks and Sentaurus is a trademark of Synopsys, Inc.
All other products or service names mentioned herein are trademarks of their respective holders and should be treated as such.

Copyright © 2024 Synopsys, Inc. All rights reserved.
Introduction                                                         Simulation Methodology
Modern power semiconductors are used in a wide variety of            This section discusses the simulation methodology.
applications such as electrical power regulation and
distribution, industrial automation, traction control,
automobile systems, telecommunications, and consumer
                                                                     Package Assembly Flow
electronics [1]. The power dissipation in these devices is
significant since the devices handle high voltages and high          The simplified power-device package consists of a silicon
currents. Therefore, power semiconductors require                    die with aluminum contacts. The silicon die is mounted on a
comprehensive analysis and evaluation of package                     copper substrate that acts as a heat sink. Metal lines connect
structures, packaging materials, and assembly processes [2].         the silicon die with the external system. The entire assembly
Earlier research examined the thermal performance and                is encapsulated in resin material. Figure 1 shows the 3D
proposed thermal models for various power semiconductor              geometry of the package structure and a cross section of the
packaging technologies [3][4]. Coupled thermal and                   package structure.
mechanical analyses also have been performed to examine                                                                          Aluminum
the heat dissipation and its reliability impact in power                                                   BEOL
semiconductor package structures [5][6][7].

Power semiconductor package structures undergo a                                                           Silicon               Resin
complex assembly process that exposes them to a multitude
of thermal excursions, which induce residual mechanical
stresses in the package. These residual mechanical stresses
can initiate cracks or delamination. These stresses can also
                                                                                                           Solder
aggravate existing defects and lead to reliability failures.
Therefore, it is necessary to examine the residual stresses in                                             Copper
power semiconductor packages. In addition to the residual
stresses, the heat dissipation during operation introduces           Figure 1   (Left) Three-dimensional geometry of the simplified power-device
                                                                                package and (right) cross section of the package geometry
mechanical stresses in the structure. These stresses can also
affect the package reliability. Therefore, it is imperative to       Figure 2 shows a schematic representation of the package
examine the combined reliability impact of assembly                  assembly flow simulated here [9]. To simulate the package
process–induced stresses and thermal dissipation–induced             assembly process, a silicon die with a smear material layer
stresses in power semiconductor package structures.                  designated for the back-end-of-line (BEOL) layers is
                                                                     created. An aluminum contact is also created on top of the
In this project, the reliability impact of mechanical stresses       BEOL layer. This structure is ramped up to 218°C to attach
is examined for a simplified power-device package [8][9].            the heat slug using lead-free solder [13]. The silicon die
Sentaurus Interconnect is used to generate the three-                attached to the heat slug is cooled to room temperature of
dimensional (3D) package structures, to perform the                  25°C. This structure is again ramped up to 130°C to attach
assembly process simulation, and to examine the                      the contact wires [14]. Then, the structure is cooled to 25°C
mechanical stress distributions [10]. Sentaurus Device is            after wire attachment. The structure with the wires is
used to simulate the temperature distribution in the package         ramped up to 150°C for resin encapsulation [15]. The
structure during operation [11]. This temperature profile is         package is finally cooled to room temperature after resin
used to generate the mechanical stresses generated during            encapsulation.
device operation. Sentaurus Visual is used to analyze the
simulation results [12]. This simulation study provides an           Mechanical stress evolution is examined at each process
insight into mechanical stress evolution and its reliability         step previously described. During the process flow, a 50 µm
impact during power semiconductor packaging and                      corner crack is introduced at the silicon–solder interface to
operation.                                                           determine the impact of process-induced stresses on
                                                                     existing defects. During the package assembly simulation,




Si die with Al    Ramp up        Attach heat slug         Ramp up    Attach wires and               Ramp up                  Add resin and
at 25°C           to 218°C       and cool to 25°C         to 130°C   cool to 25°C                   to 150°C                 cool to 25°C
Figure 2   Schematic representation of the package assembly flow



Copyright © 2024 Synopsys, Inc. All rights reserved.                                                                                          3
the bottom plane of the structure is constrained in the                      When four power sources are simulated in the thermal
vertical direction. Two points on the silicon wafer edge are                 simulation, the bottom contact is maintained at 300 K and a
also constrained along one of the in-plane axes. One of                      convective boundary condition of 5 W/m2K is applied at the
these points is also constrained along the other in-plane                    top contact. In addition, Pulse 1 is applied to contact T0, and
axis. The boundary conditions applied to these points                        Pulse 2 is applied to contacts T1, T2, and T3.
prevent in-plane rotation of the structure.
                                                                                                     3000
                                                                                                                                                Pulse 1
For the metallic constituents of the structure, that is, copper,                                                                                Pulse 2
solder, and aluminum, the incremental plasticity model is                                            2500
used to model the nonlinear material behavior [10]. Table 1
lists the nonlinear material properties used to simulate the                                         2000




                                                                                    Power [W/cm2]
behavior of these materials. Linear elastic material
properties are assumed for the rest of the material
                                                                                                     1500
constituents.

Table 1     Nonlinear metal properties                                                               1000

 Property                              Copper    Solder     Aluminum
                                                                                                      500
 E [GPa]                               111.5     46.2       86.0
                                      0.343     0.4        0.3                                          0
                                                                                                       1.0e-12 1.0e-09 1.0e-06 1.0e-03 1.0e+00
 Coefficient of thermal                17.75     24.7       24.4                                                          Time [s]
 expansion (CTE) [×10–6/°C]
 Rate coefficient for E                –200.0    –200.0     –200.0                                  15000
                                                                                                                                              Pulse 1
 [MPa/°C]                                                                                                                                     Pulse 2
 First yield stress [MPa]              155.0     35.1       11.0                                    12500

 Kinematic hardening modulus           77.0      1.27       77.0
 [GPa]                                                                                              10000
                                                                                    Power [W/cm2]




                                                                                                     7500
Thermal Simulation
                                                                                                     5000
Thermal simulation is performed to determine the
temperature profile in the package structures during
operation. Figure 3 (left) shows the electrical and thermal                                          2500
contacts placed in the 3D package structure. Figure 3 (right)
shows the location of all the contacts along a cutplane in the                                           0
                                                                                                        1.0e-12 1.0e-09 1.0e-06 1.0e-03 1.0e+00
3D structure.
                                                                                                                          Time [s]
                            Cutplane                                Resin
                                                Top                          Figure 4               (Top) Low-power pulses and (bottom) high-power pulses applied to
                                                                                                    the contacts
                                          T1          T3           T2

                                                                             Combined Thermal and Mechanical
                                                                   Silicon
                                                T0
                                                           Bottom
                                                                             Simulation
                                                                  Copper     Mechanical stress simulation is performed to assess the
Figure 3   (Left) Three-dimensional package structure with contacts and
                                                                             stress impact of the thermal profile. To determine the
           (right) contacts along the cutplane                               mechanical stress impact, the package structure with
                                                                             assembly process–induced stresses is heated in such a way
Thermal simulations are performed by applying low-power                      that the final temperature profile matches the temperature
or high-power pulses to the electrical contacts. Figure 4                    profile generated during the thermal simulation.
shows the low-power and high-power pulses applied to the
contacts. When only one power source is simulated in the                     Here, the boundary conditions are imposed to constrain the
thermal simulation, the bottom contact is maintained at                      bottom plane of the package in all directions. In this
300 K and Pulse 1 is applied to contact T0.                                  simulation, the assembly process–induced stress is altered
                                                                             because of the thermal profile generated during operation.



4                                                                                                         Copyright © 2024 Synopsys, Inc. All rights reserved.
This change in stress profile is examined for its reliability    The mesh refinements are defined within the Sentaurus
impact.                                                          Structure Editor interface as follows:
                                                                     (sdedr:define-refeval-window "SolderWin1" "Cuboid"
General Simulation Setup                                               (position 0 (- Y0 50) (- X0 50))
                                                                       (position 35 (+ Y0 50) (+ XDie 50)))

In this project, Sentaurus Interconnect generates the                (sdedr:define-refinement-size "SolderSize1" 40 40 40
structure and simulates the power-device package assembly              20 20 20)
process. Sentaurus Device performs the thermal simulation.           (sdedr:define-refinement-placement "SolderPlace1"
The temperature profile generated by the thermal simulation            "SolderSize1" "SolderWin1")
is used by Sentaurus Interconnect to assess the reliability
impact. Visualization of the structures and stress profiles is   The mesh is generated and saved in TDR format as follows:
performed using Sentaurus Visual. Sentaurus Workbench is             (sde:build-mesh "n@node@_sibashslr")
used as the framework in which to run the entire simulation
flow. Figure 5 shows the simulation flow used here.              This command saves the boundary file and the mesh
                                                                 command file for the complete package structure. The
                                                                 structures and meshes generated here are used in the
Structure Generation
                                                                 subsequent package assembly simulations.
The tool node named dpack_struct generates all the
geometries and the meshes necessary for the package              Package Assembly Simulations
assembly simulation. Here, Sentaurus Structure Editor [16]
is invoked in the external mode to generate the geometries.      The package assembly simulation is split into three different
The following commands show the Sentaurus Structure              tool nodes:
Editor interface:
                                                                 ■     dpak_flow simulates the attachment of the copper
  sde external logfile= n@node@_sde.log SdeCheck {                     heat slug to the die and ramps up the wire bonding
    (sde:clear)                                                        temperature of 130°C.
    (sde:set-process-up-direction 1)
                                                                 ■     dpak_flow_2 simulates the wire bonding operation
      (define   X0 0)                                                  and ramps up the resin curing temperature of 150°C.
      (define   XDie 2500)
      (define   Y0 0)                                            ■     dpak_flow_3 simulates the resin encapsulation and
      (define   YDie 3500)                                             subsequent cooling to room temperature.
      (define   ZDie 200.0)
                                                                 For the package assembly steps simulated here, the structure
      (sdepe:define-pe-domain (list Y0 X0 YDie XDie))            and mesh created in the previous node is initialized in
      (sdepe:add-substrate "material" "Silicon"
                                                                 Sentaurus Interconnect. The following command shows the
        "thickness" ZDie)
  }
                                                                 initialization of the mesh:
                                                                     init tdr= n@node|-1@_sibashs_sis !DelayFullD \
Various parts of the package structure are created using               !load.commands !pdb
appropriate structure generation commands as follows:
                                                                 The stress profile from the previous step is used as the initial
  (sdegeo:create-cuboid
    (position (* -1.0 (- Z0 ZPre)) FrameY0 FrameX0)
                                                                 condition. The following command shows the definition of
    (position (* -1.00 (- Zcurrent ZFrame)) YFrame               the initial condition:
      XFrame) "Copper" "frame")                                      load tdr= n@node@_sibaup_sis.tdr sum




Figure 5   Simulation flow in Sentaurus Workbench



Copyright © 2024 Synopsys, Inc. All rights reserved.                                                                           5
The boundary conditions that fix the bottom plane and             These definitions are necessary for the subsequent thermal
prevent in-plane rotation in the yz plane are defined as          simulation that determines the thermal profile during device
follows:                                                          operation.
    stressdata bc.location= Bottom bc.value= {dx=0}
    stressdata bc.location= Point1 \                              Thermal Simulation
      point.coord= {0 0 0} bc.value= {pdy=0.0 pdz=0.0}
    stressdata bc.location= Point2 \                              The complete package structure generated after the package
      point.coord= {0 0 2500} bc.value= {pdy=0.0}                 assembly simulation is initialized in Sentaurus Device. The
                                                                  following commands show the initialization of the input
An initial crack is defined along the silicon–solder interface:   TDR file and the definition of the parameter, output, plot,
    pdbSet Mechanics Model Crack
                                                                  and log files:
    crack name= crk01 CZM= none \                                   File {
      x.min= -30.0 x.max= 30.0 \                                      Grid= "n@node|-1@_sibashslr_sis.tdr"
      y.min= 3475 y.max= 3500 \                                       Parameters= "@parameter@"
      z.min= 0.0 z.max=@Crksize@ tolerance= 1e0 \                     Output= "@log@"
      mat.1= Silicon mat.2=Solder \                                   Current= "@plot@"
      angle.tolerance= 1.0e0 normal= "-1.0 0.0 0.0"                   Plot= "@tdrdat@"
                                                                    }
The following command shows the definition of the thermal
                                                                  Electrical and thermal contacts are defined using the
ramps used to simulate the package assembly process:
                                                                  Electrode and Thermode sections, respectively. The
    solve stress.relax temperature= 218.0<C> \                    following commands also show the power pulse applied to
      t.final= 25.0<C> delNT= 193.0 time= 1.0<s> \                the thermal contact:
      init= 0.0001<s> maxstep= 0.05<s> info= 2
                                                                    Electrode {
After the mechanics simulation, the J-integral is calculated          {name="bottom" voltage=0.0}
                                                                    }
using the following command:
                                                                    set PULSE2 "(0 at 0 , 0 at @tOffset@, \
    j_integral crack=crk01 x=0.00 \
                                                                      $maxPower1 at $tStart , $maxPower1 at $tEnd , \
      y= [expr 3500.00 - [expr @Crksize@ / 2.00]] \
                                                                      0 at $tFall , 0 at 100)"
      z= [expr @Crksize@ / 2.00] number= 11
                                                                    Thermode {
The following command illustrates how the package                     {name="bottom" Temperature= @<Tamb_K>@}
                                                                      {name="T1"     Temperature= @<Tamb_K>@ \
structure is saved without applying any deformation to the
                                                                        Power=0 Power=!( puts $PULSE2 )! ]}
structure:                                                          }
    struct tdr= n@node@_sibashsup !interfaces !Gas
                                                                  The Plot section defines the output fields to be saved after
To better visualize the results, the deformation is               the simulation is completed. The following command shows
exaggerated by scaling it by a factor of 10 before applying it    an example of the Plot section:
to the structure. The following command demonstrates how            Plot{
the structure is saved after an application of exaggerated            eDensity hDensity TotalCurrent/Vector
deformation:                                                          eCurrent/Vector hCurrent/Vector
    struct tdr= n@node@_sibashsup_defo deform \                       Temperature
      deform.scale= 10.0 !interfaces !Gas                             ElectricField/Vector Potential SpaceCharge
                                                                      CurrentPotential
                                                                    }
For the final package structure, the intrinsic doping profiles
and contacts are defined. The following commands illustrate
                                                                  The lattice temperature and the total heat are calculated and
contact definition:
                                                                  saved for the silicon chip. The following command shows
    contact box Copper name=bottom \                              how to save the lattice temperature and the total heat:
      xlo= 825 ylo= -700 zlo= -1700 \
      xhi= 845 yhi= 4200 zhi= 3400                                  CurrentPlot {
                                                                      LatticeTemperature (
    contact box Silicon name=T0 \                                       Maximum(Material="Silicon")
      xlo= -10 ylo= 0 zlo= 0 \                                        )
      xhi= 10 yhi= 3500 zhi= 2500                                     TotalHeat (
                                                                        Integrate(Material="Silicon")
The intrinsic doping profiles are defined as follows:                 )
                                                                    }
    select z= 1.0e10 region= region_1 name= AsActive store
    select z= 1.0e15 region= region_1 name= PActive store



6                                                                              Copyright © 2024 Synopsys, Inc. All rights reserved.
Finally, the following Solve command is used to perform          The structure is saved and the results are examined after the
the transient thermal simulation:                                simulation to assess the reliability impact.
  Solve {
    Coupled(Iterations= 100 LineSearchDamping= 1e-4)             Visualizing the Results
    { Poisson }
    Coupled { !(puts $EQ)! }
                                                                 Sentaurus Visual visualizes the simulation results:
      NewCurrentPrefix="trans_"                                  ■     The visual3d tool node visualizes the mechanical
                                                                       stresses in the 3D structure.
      Transient (
        InitialTime=0 FinalTime=@tFIN@ Increment=2.0 \           ■     The visual2d tool node visualizes the mechanical
        Decrement=2.1 InitialStep=1e-10 MinStep=1e-12 \                stresses along a 2D cutplane that passes through the
        MaxStep=@<tPulse/10>@                                          center of the crack.
      )
      { Coupled { !(puts $EQ)! }
        Plot (FilePrefix="n@node@_At1sec" Time=(1.0))            The following commands show the initialization of the
      }                                                          results and the creation of the plots:
      Save (fileprefix= "n@node@_tr")                                load_file n@previous|-6@_sibashs_sis.tdr
  }
                                                                     create_plot -dataset n@previous|-6@_sibashs_sis
The temperature profile generated by the thermal simulation          select_plots Plot_n@previous|-6@_sibashs_sis
is used in the subsequent simulation steps to examine the
impact of thermal stress on package reliability.                 Two-dimensional cutplanes are created to examine the
                                                                 results in specific locations. The following commands show
                                                                 an example of the creation of cutplanes:
Combined Thermal and Mechanics
                                                                     create_cutplane \
Simulation
                                                                       -plot Plot_n@previous|-6@_sibashs_sis \
                                                                       -type y -at 3487.5
The temperature profile generated by the thermal simulation
                                                                     create_plot -dataset C1(n@previous|-6@_sibashs_sis)
is processed to create a final temperature profile for the
mechanics simulation. The tool node named tempprofile
                                                                 The following commands show the selection of specific
saves the final temperature profile in TDR format. The
                                                                 stress contours for visualization:
following commands show the creation and storing of the
final temperature profile:                                           set_field_prop \
                                                                       -plot Plot_C1(n@previous|-4@_sibashslr_sis) \
  sel z= LatticeTemperature name= FinalTemp store                      -geom C1(n@previous|-4@_sibashslr_sis) \
  SetTDRList {LatticeTemperature FinalTemp} !Solutions                 MisesStress -show_bands
  struct tdr=n@node@_des.tdr
                                                                     set_field_prop \
The tool node named thermomechanical uses the final                    -plot Plot_C1(n@previous|-4@_sibashslr_sis) \
                                                                       -geom C1(n@previous|-4@_sibashslr_sis) \
temperature profile to determine its reliability impact. Here,
                                                                       MisesStress -min 0.0 -min_fixed
the final package structure that contains the package
assembly–induced stress is initialized as follows:                   set_field_prop \
                                                                       -plot Plot_C1(n@previous|-4@_sibashslr_sis) \
  init tdr= n@node|-3@_sibashslr_sis.tdr \                             -geom C1(n@previous|-4@_sibashslr_sis) \
    !load.commands !pdb                                                MisesStress -max 2.0e+08 -max_fixed

The results that contain the final temperature profile during    The following commands show how the contour legends are
device operations are loaded:                                    manipulated for better visualization:
  load tdr= n@node|-1@_des_sis.tdr sum                               set_legend_prop \
                                                                       -plot Plot_C1(n@previous|-4@_sibashslr_sis) \
The crack is defined according to the description in the               -show_background
previous nodes. The final solution is performed where the            set_legend_prop \
structure is ramped up from room temperature. In this                  -plot Plot_C1(n@previous|-4@_sibashslr_sis) \
thermal ramp, the target temperature is the final temperature          -color_fg #ffffff
profile generated from the thermal simulation. The                   set_legend_prop \
following command illustrates the temperature ramp:                    -plot Plot_C1(n@previous|-4@_sibashslr_sis) \
  solve temperature= 25.0<C> time= 1.0<s> \                            -position {0.8 0.8} -size {0.15 0.5}
    init= 0.0001<s> maxstep= 0.01<s> \
    t.final.profile= FinalTemp info= 2




Copyright © 2024 Synopsys, Inc. All rights reserved.                                                                        7
Results and Discussion                                                       cools from high temperatures, the von Mises effective stress
                                                                             increases in the silicon chip and at the silicon–solder
This section discusses the simulation results.                               interface. This stress is highest when the assembly is
                                                                             completed and at room temperature.
                                                                                 1. Attach heat
Package Assembly Simulation                                                      slug, cool down
                                                                                                                      2. Ramp up
                                                                                                                      to 130°C

A sequential package assembly simulation is performed to                          Crack at silicon–
examine the evolution of mechanical stress during the                             solder interface

package assembly process. For each step of the package                           3. Attach wires,                    4. Ramp up
assembly simulation, the stress from the previous step is                        cool down                           to 150°C
used as the initial condition, the corner crack is defined at
the silicon–solder interface, and the simulation is performed
using appropriate boundary conditions. The J-integral at the                     5. Add resin,                                                       z
crack tip is also evaluated at the end of each simulation step.                  cool down

                                                                                                                                             x
Figure 6 shows the evolution of the shear stress (SXZ)
during the package assembly process. It can be seen that the
stress increases at the material interfaces when the structure               Figure 7     Evolution of shear stress (SXZ) along a cutplane passing through
                                                                                          the center of the crack
is cooled. The shear stress is lower when the structure is
heated during the packaging process.                                         At every step during the package assembly simulation, the
                                                                             J-integral is calculated at the crack tip located at the silicon–
Figure 7 shows the evolution of the shear stress (SXZ) along                 solder interface. Here, the J-integral is calculated at a
a cutplane that passes through the center of the crack. These                specified point and is evaluated along 11 contours around
results also show that the shear stress increases as the                     the crack front. Figure 10 on page 9 shows an average of the
structure is cooled. It is also seen that the shear stress at the            J-integral along these 11 contours at the crack tip for each of
interfaces is highest when the package assembly process is                   the package assembly steps. These results show that the J-
completed.                                                                   integral decreases when the structure is heated, and it
                                                                             increases when the structure is cooled.
Figure 8 on page 9 shows the evolution of the von Mises
effective stress during the package assembly process. It can
be seen that as the structure is heated, the von Mises
effective stress increases in the BEOL layer and aluminum
contact on top of the silicon chip. As the structure cools, the
von Mises stress decreases in the BEOL layer and increases
in the silicon chip.

Figure 9 on page 9 shows the evolution of the von Mises
effective stress along a cutplane that passes through the
center of the crack. Here, it is evident that as the structure


                 Ramp up to 180°C                 Attach heat slug, cool down                 Ramp up to 130°C
Stress-XZ [Pa]
   2.500e+07
   1.667e+07
   8.333e+06
   0.000e+00
   -8.333e+06
   -1.667e+07
                                                             Crack at silicon−
   -2.500e+07
                                                             solder interface




           Add resin, cool down                      Ramp up to 150°C                    Attach wires, cool down
Figure 6   Evolution of shear stress (SXZ) during package assembly process




8                                                                                                Copyright © 2024 Synopsys, Inc. All rights reserved.
                               Ramp up to 180°C                 Attach heat slug, cool down                 Ramp up to 130°C
MisesStress [Pa]
   1.000e+08
   8.333e+07
   6.667e+07
   5.000e+07
   3.333e+07
   1.667e+07
   0.000e+00




                          Add resin, cool down                      Ramp up to 150°C                   Attach wires, cool down
Figure 8                  Evolution of von Mises effective stress during package assembly process



1. Attach heat
                                                                                              Thermal Simulation
                                                     2. Ramp up
slug, cool down                                      to 130°C
                                                                                              Thermal simulations are performed by applying low-power
                                                                                              and high-power pulses to either one or four thermodes in the
                                                                                              package structure. Figure 11 shows the temperature profiles
3. Attach wires,                                     4. Ramp up                               generated in the package structure for different power
cool down                                            to 150°C
                                                                                              settings and different numbers of thermodes. These results
                                                                                              show that higher power results in greater heating of the
                                                                                              package. It also can be seen that more thermodes result in
    5. Add resin,                                                                   z         greater package heating. These temperature profiles are
    cool down
                                                                                              used in subsequent simulations to examine the impact of
                                                                            x                 heat generated during operation on the mechanical stresses
                                                                                              in the package structure.

Figure 9                  Evolution of von Mises effective stress along a cutplane passing
                                                                                                     Low power, one source                    High power, one source
                          through the center of the crack



                   150
                                                                                                                            Lattice Temperature [K]
                                                                                                                                       480.00
                                                                                                                                       450.00
                                                                                                                                       420.00
                   120                                                                              Low power, four   sources          390.00 High    power, four sources
                                                                                                                                       360.00
                                                                                                                                       330.00
                                                                                                                                       300.00
J-Integral [N/m]




                    90




                    60
                                                                                              Figure 11 Thermal profiles generated in the package for different power
                                                                                                        settings and different numbers of thermodes


                    30
                                                                                              Combined Thermal and Mechanics
                                                                                              Simulations
                     0
                         Cool down    Ramp up     Cool down     Ramp up      Cool down        Combined thermal and mechanics simulations are
                         after heat    for wire   after wire    for resin    after resin      performed to assess the reliability impact of operating
                            slug      bonding      bonding       curing        curing
                                                                                              temperatures. An entire package structure with assembly
Figure 10 J-integral at crack tip after each package assembly step                            process–induced residual stresses is heated such that the
                                                                                              final package temperature matches the temperature profile
                                                                                              generated by the thermal simulation.



Copyright © 2024 Synopsys, Inc. All rights reserved.                                                                                                                        9
Figure 12 shows the shear stress (SXZ) in the package                            Figure 14 shows the von Mises effective stress in the
structure before the introduction of thermal stress and after                    package structure before the introduction of thermal stress
the introduction of thermal stress for different power and                       and after the introduction of thermal stress for different
thermode configurations. These results show that for the                         power and thermode configurations. These results show that
low-power setting, the thermal stress does not significantly                     the thermal stresses increase the residual stresses in the
alter the residual stresses in the package structure. However,                   BEOL layers and aluminum contact on top of the silicon
the high-power setting introduces much higher stresses in                        chip. It is also seen that the high-power setting results in
the heat slug.                                                                   larger stresses in the BEOL layer.
                                                    Stress-XZ [Pa]                                                               MisesStress [Pa]
      Without thermal stress                            2.500e+07                      Without thermal stress                       3.200e+08
                                                        1.667e+07                                                                      2.800e+08
                                                        8.333e+06                                                                      2.400e+08
                                                        0.000e+00                                                                      2.000e+08
                                                        -8.333e+06                                                                     1.600e+08
                                                        -1.667e+07                                                                     1.200e+08
                                                        -2.500e+07                                                                     8.000e+07
     Low power, one source                     High power, one source                 Low power, one source                   High power, one source




     Low power, four sources                  High power, four sources                Low power, four sources                 High power, four sources




Figure 12 Vertical stress (SXZ) without thermal stress and with thermal stress   Figure 14 The von Mises effective stress without thermal stress and with
          generated by different power and thermode settings                               thermal stress generated by different power and thermode settings


Figure 13 shows the shear stress (SXZ) in the package                            Figure 15 shows the von Mises effective stress in the
structure along a cutplane that passes through the center of                     package structure along a cutplane that passes through the
the crack, before the introduction of thermal stress and after                   center of the crack, before the introduction of thermal stress
the introduction of thermal stress for different power and                       and after the introduction of thermal stress for different
thermode configurations. It can be seen that the low-power                       power and thermode configurations. It can be observed from
setting does not significantly alter the residual stresses at the                these results that the higher power settings alter the residual
silicon–solder interface. However, the high-power setting                        stresses at the silicon–solder interface.
increases the stress concentration at the crack front.
                                                                                  Without                 Low power,              High power,
 Without                  Low power,                High power,                   thermal                 one source              one source
 thermal                  one source                one source                    stress
 stress




                                                                                 Low power,               High power,                       z
Low power,                High power,                        z                   four sources             four sources
four sources              four sources                                                                                             x
                                                    x




                                                                                 Figure 15 The von Mises effective stress without thermal stress and with
                                                                                           thermal stress generated by different power and thermode settings
Figure 13 Vertical stress (SXZ) without thermal stress and with thermal stress
          generated by different power and thermode settings along a                       along a cutplane passing through the center of the crack
          cutplane passing through the center of the crack




10                                                                                                Copyright © 2024 Synopsys, Inc. All rights reserved.
Figure 16 shows the J-integral at the crack tip in the                             References
complete package without thermal stress and with thermal
stress introduced by various power and thermode settings.                          [1]   B. J. Baliga, “Trends in Power Semiconductor
Here, it is evident that the introduction of thermal stress                              Devices,” IEEE Transactions on Electron Devices,
increases the J-integral values at the crack tip. The increase                           vol. 43, no. 10, pp. 1717–1731, 1996.
in the J-integral is greater for the high-power setting
                                                                                   [2]   Y. Liu and D. Kinzer, “Challenges of Power Electronic
compared to the low-power setting. These results show that
                                                                                         Packaging and Modeling,” in Proceedings of the 12th
the thermal stresses introduced during device operation
                                                                                         International Conference on Thermal, Mechanical and
aggravate existing interfacial defects. These stresses might
                                                                                         Multi-Physics Simulation and Experiments in
also lead to the formation of new defects or the initiation of
                                                                                         Microelectronics and Microsystems (EuroSimE), Linz,
interfacial delamination.
                                                                                         Austria, pp. 1/9–9/9, April 2011.
                    170
                                                                                   [3]   Y. Bulut and K. Pandya, “Thermal Modeling for Power
                                                                                         MOSFETs in DC/DC Applications,” in Proceedings of
                                                                                         the 5th International Conference on Thermal and
                                                                                         Mechanical Simulation and Experiments in Micro-
                    160
                                                                                         Electronics and Micro-Systems (EuroSimE), Brussels,
                                                                                         Belgium, pp. 429–433, May 2004.
 J-Integral [N/m]




                                                                                   [4]   X. Fan, K. T. Aung, and X. Li, “Investigation of
                                                                                         Thermal Performance of Various Power-Device
                                                                                         Packages,” in International Conference on Thermal,
                    150                                                                  Mechanical and Multi-Physics Simulation and
                                                                                         Experiments in Micro-Electronics and Micro-Systems
                                                                                         (EuroSimE), Freiburg-im-Breisgau, Germany, pp. 1–8,
                                                                                         April 2008.
                                                                                   [5]   K. Yang et al., “Numerical Simulations Based Thermal
                    140
                          Low power,   High power,    Low power,    High power,          Reliability of Power Device Packages,” in
                          one source   one source    four sources   four sources         Proceedings of the 14th International Conference on
Figure 16 J-integral at the crack tip without thermal stress and with thermal            Electronic Packaging Technology (ICEPT), Dalian,
          stress introduced by various power and thermode settings
                                                                                         China, pp. 635–641, August 2013.
                                                                                   [6]   T. Anzawa et al., “Reliability Evaluation for Power
Summary                                                                                  Electronics Device using Electrical Thermal and
                                                                                         Mechanical Analysis,” in Proceedings of the 9th
A simulation approach has been developed to progressively
                                                                                         Electronics Packaging Technology Conference
analyze the residual stresses induced by the power-device
                                                                                         (EPTC), Singapore, pp. 94–99, December 2007.
package assembly process. Package reliability at each
process step has been examined by assessing the J-integral                         [7]   C.-S. Yun et al., “Package Reliability Analysis with
at the tip of an existing crack. It is observed that, during the                         Coupled Electro-Thermal and Mechanical Modeling,”
package assembly, the residual stresses decrease when the                                in MRS Symposium, Advanced Interconnects for
structure is heated and increase when the structure is cooled.                           Micro- and Nanoelectronics—Materials, Processes
In addition, during package assembly, lower J-integral                                   and Reliability, vol. 1559, pp. 54–59, 2013.
values are observed for structures at higher temperatures,
and higher J-integral values are observed for structures at                        [8]   D. Hollander, “Packaging Trends and Mounting
lower temperatures. A thermal simulation is performed on                                 Techniques for Power Surface Mount Components,” in
the complete package structure using different power and                                 International Conference on Power Electronics and
thermode settings. The temperature profiles generated by                                 Drive Systems (PEDS), vol. 1, pp. 264–270, February
the thermal simulations are used to examine the impact of                                1995.
thermal stress on package reliability. It is observed that the                     [9]   PowerSO-10RF: the first true RF power SMD
thermal stress generated during device operation alters the                              package,      Application     Note AN1294,
stress profiles in the package and aggravates existing                                   STMicroelectronics, November 2009.
defects. This simulation approach can be effectively used to
assess power-device package reliability during assembly                            [10] Sentaurus™ Interconnect User Guide, Version
and operation.                                                                          W-2024.09, Mountain View, California: Synopsys,
                                                                                        Inc., 2024.
                                                                                   [11] Sentaurus™ Device User Guide, Version W-2024.09,
                                                                                        Mountain View, California: Synopsys, Inc., 2024.


Copyright © 2024 Synopsys, Inc. All rights reserved.                                                                                       11
[12] Sentaurus™ Visual User Guide, Version W-2024.09,
     Mountain View, California: Synopsys, Inc., 2024.
[13] T. Siewert et al., “Database for Solder Properties with
     Emphasis on New Lead-free Solders,” in Properties of
     Lead-Free Solders, Release 4.0, National Institute of
     Standards and Technology & Colorado School of
     Mines, Colorado, February 2002.
[14] L. A. Lim, J. Castaneda, and S. Shirakawa, Fine Pitch
     Copper Wire Bonding Process and Materials Study,
     Product Brochure, Small Precision Tools, Inc.,
     available from https://www.smallprecisiontools.com.
[15] R. L. Hubbard et al., “Low Temperature Curing of
     Epoxies with Microwaves,” in International
     Symposium on Microelectronics, San Diego, CA,
     USA, pp. 1–4, October 2006.
[16] Sentaurus™ Structure Editor User Guide, Version
     W-2024.09, Mountain View, California: Synopsys,
     Inc., 2024.




12                                                             Copyright © 2024 Synopsys, Inc. All rights reserved.

