"""Parse native timer labels without equating CPU time with elapsed time."""
import argparse
import hashlib
import json
from pathlib import Path
import re

NUMBER = r'([0-9]+(?:\.[0-9]+)?)'


def sentaurus(log):
    result = {'tool_family':'Sentaurus-style', 'unit':'s', 'totals':{},
              'module_cpu':[], 'module_elapsed':[], 'solve_elapsed':[]}
    for label,key in [('Elapsed Time','elapsed'),('User Time','user'),('CPU Time','cpu')]:
        values = re.findall(r'^'+label+r':\s*(\d+):(\d+):(\d+(?:\.\d+)?)\s*$',log,re.M)
        if len(values) != 1:
            raise ValueError(f'Expected one native {label}; found {len(values)}')
        h,m,s = map(float,values[0]);result['totals'][key]=3600*h+60*m+s
    section = None
    for line in log.splitlines():
        if line.strip() == 'Detailed CPU time report:':section='module_cpu';continue
        if line.strip() == 'Detailed elapsed time report:':section='module_elapsed';continue
        match = re.fullmatch(r'\s*'+NUMBER+r' sec \('+NUMBER+r'%\) (.+) \((\d+) calls?\)\.\s*',line)
        if match and section:
            sec,pct,label,calls=match.groups()
            result[section].append({'label':label,'seconds':float(sec),'reported_percent':float(pct),'calls':int(calls)})
    result['solve_elapsed']=[float(x) for x in re.findall(r'Elapsed time for solve\s+'+NUMBER+r's',log)]
    result['notes']=['Keep native labels; CPU and elapsed tables are separate.',
                     'Reported percentages can use a different scope from process total.',
                     'Do not sum nested/module timers into a fabricated total.']
    return result


def mapdl(log, stage_clocks=None):
    result={'tool_family':'MAPDL','unit':'s','totals':{},'native_stages':[]}
    matches=re.findall(r'Elapsed Time \(sec\)\s*=\s*'+NUMBER,log)
    if len(matches)!=1:raise ValueError('Missing or ambiguous MAPDL process elapsed total')
    result['totals']['elapsed']=float(matches[0])
    for line in log.splitlines():
        m=re.fullmatch(r'\s*(Elapsed time[^:]+|Total CPU time[^:]+)\s*:\s*'+NUMBER+r' seconds\s*',line)
        if m:result['native_stages'].append({'label':m[1].strip(),'seconds':float(m[2])})
    if stage_clocks is not None:
        values=[float(v) for v in stage_clocks.split()]
        if len(values)!=4 or any(b<a for a,b in zip(values,values[1:])):
            raise ValueError('Expected four monotonically increasing MAPDL WALL clocks in hours')
        result['driver_intervals']={name:3600*(b-a) for name,a,b in zip(
            ['archive_read','solution_command_block','postprocessing_export'],values,values[1:])}
    result['completed']='RUN COMPLETED' in log and '*** ERROR ***' not in log and '*** FATAL ***' not in log
    result['notes']=['Element assembly, equation solver and element results are subcategories of computing solution.',
                     'Driver intervals are separately measured scopes, not replacements for native statistics.',
                     'External launcher wall time remains a separate metric.']
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('tool',choices=['sentaurus','mapdl']);p.add_argument('log',type=Path)
    p.add_argument('--stage-clocks',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();raw=a.log.read_bytes();log=raw.decode('utf-8',errors='replace')
    result=sentaurus(log) if a.tool=='sentaurus' else mapdl(log,a.stage_clocks.read_text() if a.stage_clocks else None)
    result['input']=str(a.log.resolve());result['sha256']=hashlib.sha256(raw).hexdigest()
    a.output.write_text(json.dumps(result,indent=2),encoding='utf-8')
