#!/bin/bash
set -eu
root=/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010
for i in 02 04 06 08 10 12 14; do
 bash "$root/run.sh" "quasistatic/frame-$i"
done
