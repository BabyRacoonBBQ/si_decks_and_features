from pathlib import Path
exec(Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010/render.py').read_text().split('summary={}')[0])
out=root/'arch-pair-visuals';out.mkdir(exist_ok=True)
x,e,f=read(root/'arch-linear/result_sis.tdr')
paths=sorted((root/'arch-snap').glob('frame-*_sis.tdr'))
data=[read(p) for p in paths]
assert all(np.array_equal(x,a) and np.array_equal(e,b) for a,b,_ in data), 'Geometry and connectivity must match exactly'
faces=surface(e)
u=f['BucklingMode1'];u=u/np.linalg.norm(u,axis=1).max()*4
us=[v['Displacement']*1e4 for _,_,v in data]
def draw_frame(v,p,vmax):
 fig=plt.figure(figsize=(8,3.3),dpi=120,facecolor='#F5F7FA')
 ax=fig.add_axes([0,0,1,1],projection='3d',facecolor='#F5F7FA')
 pts=x+v;mag=np.linalg.norm(v,axis=1)
 ax.add_collection3d(Poly3DCollection(pts[faces],facecolors=plt.cm.viridis(np.clip(mag[faces].mean(axis=1)/vmax,0,1)),edgecolors='none'))
 # Actual reference edge, drawn from the undeformed mesh rather than an analytic curve.
 for yy in [-1,1]:
  ids=np.where(abs(x[:,1]-yy)<1e-8)[0]
  edge=[]
  for xx in sorted(set(x[ids,0])):
   row=ids[abs(x[ids,0]-xx)<1e-8];edge.append(row[np.argmax(x[row,2])])
  a=x[edge];ax.plot(a[:,0],a[:,1],a[:,2],color='#9BA7AF',lw=.7,alpha=.7)
 ax.set_xlim(-2,52);ax.set_ylim(-6,6);ax.set_zlim(-8,9)
 ax.set_box_aspect((54,12,17),zoom=1.4);ax.view_init(elev=12,azim=-82);ax.set_proj_type('ortho');ax.set_axis_off()
 fig.savefig(p);plt.close(fig)
def save(name,values,vmax):
 frames=[]
 for j,v in enumerate(values):
  p=out/f'{name}-{j:03d}.png';draw_frame(v,p,vmax);frames.append(Image.open(p).convert('RGB'))
 frames[-1].save(out/(name+'.png'))
 frames[0].save(out/(name+'.gif'),save_all=True,append_images=frames[1:],duration=150,loop=0)
save('linear-buckling-card',[u*a for a in [0]*4+list(np.linspace(0,1,18))+[1]*5+list(np.linspace(1,0,12))],4)
center=np.argmin(np.linalg.norm(x-[25,0,4],axis=1))
jump=int(np.argmax(abs(np.diff([v[center,2] for v in us]))))+1
indices=[0]*4+list(range(jump))+[jump-1]*4+[jump]*5+list(range(jump+1,len(us),3))+[len(us)-1]*5
save('post-buckling-supercritical-card',[us[i] for i in indices],max(np.linalg.norm(v,axis=1).max() for v in us))
report={'nodes':len(x),'elements':len(e),'exact_same_reference_coordinates_and_connectivity':True,'post_saved_states':len(data),'post_animation_state_indices':indices,'jump_step':jump,'eigenvalues':re.findall(r'Mode:\s+\d+\s+EigenValue\s*=\s*([\deE+.-]+)',(root/'arch-linear/stdout.log').read_text())[:3]}
(out/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
