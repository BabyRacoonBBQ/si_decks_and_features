from pathlib import Path
base = Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
source = (base / 'render-arch-pair.py').read_text().split("save('linear-buckling-card'")[0]
source = source.replace('fig.savefig(p);plt.close(fig)',
    "fig.text(.5,.88,phase_label,ha='center',va='center',fontsize=40,fontweight='bold',color='#172D43');fig.savefig(p);plt.close(fig)")
exec(source)
out = base / 'arch-phase-visuals'
out.mkdir(exist_ok=True)
report = json.loads((base / 'arch-pair-visuals/results.json').read_text())
jump = report['jump_step']
indices = report['post_animation_state_indices']
vmax = max(np.linalg.norm(v,axis=1).max() for v in us)
frames = []
for j, state in enumerate(indices):
    phase_label = 'Before snap-through' if state < jump else 'After snap-through'
    p = out / f'phase-{j:03d}.png'
    draw_frame(us[state],p,vmax)
    frames.append(Image.open(p).convert('RGB'))
frames[-1].save(out / 'post-buckling-phases-card.png')
frames[0].save(out / 'post-buckling-phases-card.gif',save_all=True,
    append_images=frames[1:],duration=150,loop=0)
report['phase_labels'] = ['Before snap-through' if i < jump else 'After snap-through' for i in indices]
report['note'] = 'Labels follow saved equilibrium states; the unstable dynamic transition is not resolved.'
(out / 'phase-labels.json').write_text(json.dumps(report,indent=2))
print('Rendered labeled equilibrium states:', len(frames))
