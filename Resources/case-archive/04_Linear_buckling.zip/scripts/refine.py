from pathlib import Path
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
p=r/'post-buckling-supercritical';p.mkdir(exist_ok=True)
s=(r/'post-buckling/case.cmd').read_text().replace('pfx=0.4<dyn>','pfx=4.0<dyn>').replace('pfz=-0.0002<dyn>','pfz=-0.002<dyn>')
s=s.replace('time=1<s> init=0.02<s> maxstep=0.02<s>','time=1<s> init=0.05<s> maxstep=0.05<s>')
(p/'case.cmd').write_text(s)
