from pathlib import Path
import shutil,h5py,numpy as np
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010/arch-mesh')
shutil.copy(r/'flat_sis.tdr',r/'arch.tdr')
with h5py.File(r/'arch.tdr','r+') as f:
 for name,g in f['collection'].items():
  if not isinstance(g,h5py.Group) or 'vertex' not in g:continue
  a=g['vertex'][:]
  if not a.dtype.names or 'z' not in a.dtype.names:continue
  a['z']+=4e-4*(1-np.cos(2*np.pi*a['x']/0.005))/2
  g['vertex'][:]=a
print('stress-free arch reference mesh: 50 um span, 4 um rise')
