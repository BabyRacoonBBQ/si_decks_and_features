from pathlib import Path
import json, subprocess, platform

root = Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
root.mkdir(exist_ok=True)
common = '''math numThreads=1
math pardiso
line x location=0 spacing=1 tag=top
line x location=50 spacing=1 tag=bottom
line y location=-2 spacing=0.5 tag=left
line y location=2 spacing=0.5 tag=right
line z location=-2 spacing=0.5 tag=back
line z location=2 spacing=0.5 tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
pdbSet Mechanics Save.Step.Displacement 1
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
'''
for name in ['quasistatic', 'linear-buckling', 'post-buckling']:
 (root/name).mkdir(exist_ok=True)
for i in range(1,17):
 p=root/'quasistatic'/('frame-%02d'%i);p.mkdir(exist_ok=True)
 (p/'case.cmd').write_text(common+f'''stressdata bc.location=pointend point.coord= {{0 0 0}} bc.value= {{pfx=0 pfy=0 pfz={-0.03*i/16:.10g}<dyn>}}
mode mechanics
solve info=1
struct tdr=result !Gas
''')
(root/'linear-buckling'/'case.cmd').write_text(common+'''stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=0.03<dyn> pfy=0 pfz=0}
mode buckling=3
pdbSet Math Eigen 3D Max.Iter 2000
pdbSet Math Eigen 3D Tol 1e-8
solve info=2
puts "BUCKLING_EIGENVALUES [stressdata buckling.eigenvalue]"
struct tdr=result !Gas
''')
(root/'post-buckling'/'case.cmd').write_text(common+'''stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=0.4<dyn> pfy=0 pfz=-0.0002<dyn>}
mode mechanics
pdbSetBoolean Mechanics LargeDeformation 1
pdbSetBoolean Mechanics ArcLength 1
pdbSetDouble Mechanics ArcLength.deltaL.init 0.01
pdbSetDouble Mechanics ArcLength.deltaL.max 0.025
pdbSetDouble Mechanics ArcLength.deltaL.min 1e-6
pdbSetDouble Mechanics ArcLength.steps 160
pdbSet Mechanics MaxIterations 50
pdbSet Mechanics Convergence.Info 1
set frame 0
solve time=1<s> init=0.02<s> maxstep=0.02<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "SAVED_FRAME $frame"}
struct tdr=result !Gas
''')
(root/'run.sh').write_text('''#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010
cd "$root/$1"
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 30 9
ulimit -v 6291456
binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
sha256sum "$binary" case.cmd > identities.sha256
set +e
/usr/bin/time -v timeout -k 10 240 taskset -c 4 "$binary" --noSyntaxCheck case.cmd >stdout.log 2>stderr.log
rc=$?
echo "$rc" >exit.txt
tail -8 stdout.log
tail -4 stderr.log
exit "$rc"
''')
(root/'environment.json').write_text(json.dumps({'host':platform.node(),'platform':platform.platform(),'cpu':subprocess.getoutput('lscpu'),'memory':subprocess.getoutput('free -h'),'load':subprocess.getoutput('uptime')},indent=2))
print(root)
