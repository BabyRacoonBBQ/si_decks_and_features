from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
required=[r/'quasistatic'/f'frame-{i:02d}' for i in range(2,17,2)]+[r/'linear-buckling',r/'post-buckling-supercritical']
for p in required:
 assert (p/'exit.txt').read_text().strip()=='0',str(p)
 assert (p/'result_sis.tdr').exists(),str(p)
shutil.copy('/home/mozztcad/tmp/setup-mechanics-examples.py',r/'setup.py')
shutil.copy('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/Applications_Library/GettingStarted/sinterconnect/3D_Cantilever/3D_Cantilever_sis.cmd',r/'vendor-reference-cantilever.cmd')
s=json.loads((r/'results-summary.json').read_text())
u=s['quasistatic']['max_displacement_um'][-1]
pcrit=s['linear-buckling']['critical_load_dyn']
post=s['post-buckling-supercritical']['max_displacement_um'][-1]
(r/'README.md').write_text(f'''# Mechanics demonstration archive

All simulations were run on the user's VM with Sentaurus Interconnect vendor W-2024.09-SP1. These are newly computed results, not downloaded illustrations. This archive does not establish sinterconnect_run execution parity.

## Shared geometry and material
- Solid cantilever: length 50 um, square section 4 x 4 um; fixed at x=50 um, loaded at the centre of x=0.
- 4,131 nodes; 3,200 first-order brick elements.
- Demonstration isotropic elastic material: E=1e10 dyn/cm2 (1 GPa), Poisson ratio 0.2, stored under Silicon. This is a pedagogical material assignment, not calibrated crystalline silicon.
- Single CPU, 6 GiB virtual-memory limit, 240 s execution timeout per solver invocation. See environment.json for VM information.

## 1. Quasistatic bending
- Eight independently solved load states: 12.5%, 25%, ..., 100% of -0.03 dyn transverse tip load.
- Full-load maximum displacement: {u:.8g} um.
- Deformation is displayed x8, while the colour bar reports actual displacement in um.
- This is a sequence of static equilibria, not an inertial transient response. No time-dependent dynamics are claimed.

## 2. Linear buckling
- Axial reference load: +0.03 dyn. Three converged eigenpairs are recorded in stdout.log.
- First eigenvalue: {s['linear-buckling']['eigenvalues'][0]:.8g}; first critical load: {pcrit:.8g} dyn.
- The first two modes are degenerate for the square section. The third is a higher mode.
- Euler cantilever estimate: 2.1055 dyn; the approximately 2.2% difference is a basic consistency check, not a mesh-convergence study.
- GIF scales a normalized computed eigenvector for visualization; amplitude and animation timing are arbitrary, not physical displacement or vibration frequency.
- stressdata buckling.eigenvalue printed no Tcl list in this run; eigenvalues are taken from the solver's converged-eigenpair report.

## 3. Post-buckling
- Active model: large deformation, arc-length method, PARDISO.
- Target axial load: +4 dyn, above the computed critical load. Small transverse bias: -0.002 dyn to select a bending branch.
- 45 saved states; final maximum displacement: {post:.8g} um. The initial zero state is included.
- Original coordinates remain unchanged in TDR; stored total Displacement is added exactly once for rendering. Deformation display x1.
- This is the imperfect/bias-loaded nonlinear equilibrium branch, not a dynamic impact or an ideal perfectly symmetric bifurcation.
- post-buckling/ retains the earlier subcritical 0.4 dyn calibration run. It is NOT the featured post-buckling result.

## Reproduction
Run setup.py, then refine.py. Use bash run.sh linear-buckling, bash run.sh post-buckling-supercritical, bash run-frames.sh, and bash run.sh quasistatic/frame-16. The runner sources the existing geo3d/.env but this archive does not include that environment file or license credentials.
Run PYTHONNOUSERSITE=1 python3 render.py for plots and animations. All images use actual TDR mesh connectivity and field values; undeformed wireframes are reference outlines of the same geometry. Full plots include units and display scaling. Small card images are crops for the slide.

## Archive contents
Inputs, solver logs, binary/input SHA256 identities, TDR results, VM information, visualization scripts, figures/GIFs, and results-summary.json. TDR is retained in its original vendor format; it has not been renamed to GFR. Unrun odd-numbered quasistatic decks are available as optional finer load sampling.
''')
files=[p for p in r.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='manifest.sha256']
(r/'manifest.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\n' for p in sorted(files)))
archive=r.parent/(r.name+'.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=3) as t:
 t.add(r,arcname=r.name,filter=lambda info:None if '__pycache__' in info.name else info)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix(archive.suffix+'.sha256').write_text(digest+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest}))
