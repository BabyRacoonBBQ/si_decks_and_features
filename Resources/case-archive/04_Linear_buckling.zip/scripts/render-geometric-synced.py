from pathlib import Path
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
exec((r/'render-geometric.py').read_text().split('frames=[]')[0])
out=r/'geometric-synced';out.mkdir(exist_ok=True)
raw_times=list(times)
off0=cases['off'][0.0]
off1=cases['off'][1.0]
for t in times:
    # Linear small-deformation elastic response reconstructed at the same
    # load fraction as the nonlinear run; not a saved solver trajectory.
    cases['off'][t]=(off1[0],off1[1],
        (1-t)*off0[2]+t*off1[2],(1-t)*off0[3]+t*off1[3])
frames=[]
for j,t in enumerate(times):
    p=out/f'frame-{j:03d}.png'
    plot(t,p)
    frames.append(Image.open(p).convert('RGB'))
frames[-1].save(out/'geometric-comparison.png')
sequence=[frames[0]]*4+frames[1:]+[frames[-1]]*6
sequence[0].save(out/'geometric-comparison.gif',save_all=True,
    append_images=sequence[1:],duration=140,loop=0)
summary['animation']={
    'common_load_fractions':raw_times,
    'off':'Linear interpolation of zero-load and final displacement/strain fields',
    'on':'Original saved nonlinear equilibrium fields at matching load fractions',
    'deformation_scale':1,
    'logical_frames':len(sequence),
    'frame_duration_ms':140,
    'starts_at_zero':True,
    'first_loaded_off_displacement_um':metrics(cases['off'][times[1]])['max_displacement_um']
}
(out/'results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary['animation'],indent=2))
