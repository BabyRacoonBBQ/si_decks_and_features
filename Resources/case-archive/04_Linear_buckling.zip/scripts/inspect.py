from pathlib import Path
import h5py
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
for p in r.rglob('result*.tdr'):
 print('\nFILE',p)
 with h5py.File(p) as f:
  g=f['collection/geometry_0']
  print('geometry children',list(g))
  print('vertices',g['vertex'].shape if 'vertex' in g else '')
  for k,v in g.items():
   if hasattr(v,'shape'): print(k,v.shape,v.dtype,str(v[:3]))
  print('elements',g['region_0/elements_0'][:27])
  for k,v in g['state_0'].items():
   if 'name' in v.attrs: print(k,v.attrs['name'],[(kk,vv.shape,vv.dtype) for kk,vv in v.items() if hasattr(vv,'shape')])
 break
