from pathlib import Path
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
d=r/'arch-quasistatic';d.mkdir(exist_ok=True)
base=(r/'arch-snap/case.cmd').read_text().split('mode mechanics')[0].replace('pfz=-0.5<dyn>','pfz=-0.05<dyn>')
(d/'case.cmd').write_text(base+'''mode mechanics
pdbSetBoolean Mechanics LargeDeformation 1
pdbSetBoolean Mechanics ArcLength 0
pdbSet Mechanics MaxIterations 50
set frame 0
solve time=1<s> init=0.1<s> maxstep=0.1<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "QUASI_FRAME $frame TIME $time"}
struct tdr=result !Gas
''')
