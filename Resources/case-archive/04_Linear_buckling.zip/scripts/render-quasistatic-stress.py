from pathlib import Path
base=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
source=(base/'render-arch-pair.py').read_text().split("save('linear-buckling-card'")[0]
source=source.replace('mag=np.linalg.norm(v,axis=1)','mag=stress_scalar')
source=source.replace('fig.savefig(p);plt.close(fig)',"fig.text(.5,.88,'Stress distribution',ha='center',va='center',fontsize=40,fontweight='bold',color='#172D43');fig.savefig(p);plt.close(fig)")
exec(source)
out=base/'quasistatic-stress-visuals';out.mkdir(exist_ok=True)
paths=sorted((base/'arch-quasistatic').glob('frame-*_sis.tdr'))
data=[read(p) for p in paths]
print('Available fields:',list(data[0][2]),flush=True)
field='MisesStress'
assert all(field in f for _,_,f in data), 'Actual stress field required'
assert all(np.array_equal(a,x) and np.array_equal(b,e) for a,b,_ in data)
scalars=[f[field].reshape(-1) for _,_,f in data]
assert all(len(s)==len(x) for s in scalars)
vmax=max(float(s.max()) for s in scalars)
indices=[0]*3+list(range(len(data)))+[len(data)-1]*5
frames=[]
for j,i in enumerate(indices):
 stress_scalar=scalars[i]
 p=out/f'frame-{j:03d}.png'
 draw_frame(data[i][2]['Displacement']*1e4,p,vmax)
 frames.append(Image.open(p).convert('RGB'))
frames[-1].save(out/'quasistatic-stress-card.png')
frames[0].save(out/'quasistatic-stress-card.gif',save_all=True,append_images=frames[1:],duration=150,loop=0)
(out/'manifest.json').write_text(json.dumps({'field':field,'source_files':[str(p) for p in paths],'color_range_native':[0,vmax],'deformation_scale':1,'label':'Stress distribution','font':'same Matplotlib font, bold 40 pt, centered at (0.5,0.88) as post-buckling phase labels'},indent=2))
