from pathlib import Path
exec(Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010/render.py').read_text().split('summary={}')[0])
out=root/'buckling-v2-visuals';out.mkdir(exist_ok=True)
def frame(x,e,us,path,limits):
 fig=plt.figure(figsize=(8,3.6),dpi=110,facecolor='#F5F7FA')
 faces=surface(e)
 for j,u in enumerate(us):
  ax=fig.add_axes([j/len(us),0,1/len(us),1],projection='3d',facecolor='#F5F7FA')
  p=x+u;v=np.linalg.norm(u,axis=1);norm=matplotlib.colors.Normalize(0,max(v.max(),1e-15))
  ax.add_collection3d(Poly3DCollection(p[faces],facecolors=plt.cm.viridis(norm(v[faces].mean(axis=1))),edgecolors='none'))
  # Reference mesh outlines on the actual undeformed geometry.
  for yy in [x[:,1].min(),x[:,1].max()]:
   ids=np.where(abs(x[:,1]-yy)<1e-8)[0]
   for zz in [x[ids,2].min(),x[ids,2].max()]:
    if len(us)>1:
     ax.plot([0,50],[yy,yy],[zz,zz],color='#7A8791',lw=.6)
  ax.set_xlim(*limits[0]);ax.set_ylim(*limits[1]);ax.set_zlim(*limits[2]);ax.set_box_aspect([b-a for a,b in limits],zoom=1.35)
  ax.view_init(elev=24,azim=-65);ax.set_proj_type('ortho');ax.set_axis_off()
 fig.savefig(path);plt.close(fig)

summary={}
x,e,f=read(root/'plate-buckling/result_sis.tdr')
modes=[f[f'BucklingMode{j}']/np.linalg.norm(f[f'BucklingMode{j}'],axis=1).max()*5 for j in range(1,4)]
summary['plate']={'nodes':len(x),'elements':len(e),'eigenvalues':re.findall(r'Mode:\s+\d+\s+EigenValue\s*=\s*([\deE+.-]+)',(root/'plate-buckling/stdout.log').read_text())[:3]}
imgs=[]
for i,a in enumerate(np.linspace(0,1,18)):
 p=out/f'plate-{i:03d}.png';frame(x,e,[u*a for u in modes],p,((-3,53),(-12,12),(-7,7)));imgs.append(Image.open(p).convert('RGB'))
imgs[-1].save(out/'linear-buckling-card.png');imgs[-1].save(out/'linear-buckling-card.gif',save_all=True,append_images=imgs+[imgs[-1]]*6,duration=160,loop=0)
paths=sorted((root/'arch-snap').glob('frame-*_sis.tdr'));data=[read(p) for p in paths]
x,e,_=data[0];center=np.argmin(np.linalg.norm(x-np.array([25,0,4]),axis=1));us=[f['Displacement']*1e4 for _,_,f in data]
summary['arch']={'nodes':len(x),'elements':len(e),'frames':len(paths),'center_reference':x[center].tolist(),'center_uz_um':[float(u[center,2]) for u in us],'max_displacement_um':[float(np.linalg.norm(u,axis=1).max()) for u in us]}
imgs=[]
for i,u in enumerate(us):
 p=out/f'arch-{i:03d}.png';frame(x,e,[u],p,((-3,53),(-4,4),(-8,6)));imgs.append(Image.open(p).convert('RGB'))
imgs[-1].save(out/'post-buckling-supercritical-card.png');imgs[-1].save(out/'post-buckling-supercritical-card.gif',save_all=True,append_images=imgs+[imgs[-1]]*6,duration=160,loop=0)
(out/'results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
