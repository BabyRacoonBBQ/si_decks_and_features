from pathlib import Path
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
mat='''pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
math pardiso
math numThreads=1
'''
def mesh(width,thick,dy,dz):
 return f'''line x location=0 spacing=1 tag=top
line x location=25 spacing=1
line x location=50 spacing=1 tag=bottom
line y location={-width/2} spacing={dy} tag=left
line y location=0 spacing={dy}
line y location={width/2} spacing={dy} tag=right
line z location={-thick/2} spacing={dz} tag=back
line z location=0 spacing={dz}
line z location={thick/2} spacing={dz} tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
'''
p=r/'plate-buckling';p.mkdir(exist_ok=True)
(p/'case.cmd').write_text(mat+mesh(20,1,1,.25)+'''stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=Bulk.Top bc.value= {dy=0 dz=0 fx=0.1<dyn>}
mode buckling=3
pdbSet Math Eigen 3D Max.Iter 3000
pdbSet Math Eigen 3D Tol 1e-8
solve info=2
struct tdr=result !Gas
''')
p=r/'arch-mesh';p.mkdir(exist_ok=True)
(p/'case.cmd').write_text(mat+mesh(2,.5,.5,.125)+'struct tdr=flat !Gas\n')
p=r/'arch-snap';p.mkdir(exist_ok=True)
(p/'case.cmd').write_text('''init tdr=../arch-mesh/arch.tdr !load.commands !pdb
'''+mat+'''stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=Bulk.Top bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=centre point.coord= {25 0 4} bc.value= {pfx=0 pfy=0 pfz=-0.5<dyn>}
mode mechanics
pdbSetBoolean Mechanics LargeDeformation 1
pdbSetBoolean Mechanics ArcLength 1
pdbSetDouble Mechanics ArcLength.deltaL.init 0.005
pdbSetDouble Mechanics ArcLength.deltaL.max 0.025
pdbSetDouble Mechanics ArcLength.deltaL.min 1e-7
pdbSetDouble Mechanics ArcLength.steps 300
pdbSet Mechanics MaxIterations 50
pdbSet Mechanics Convergence.Info 1
set frame 0
solve time=1<s> init=0.025<s> maxstep=0.025<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "ARCH_FRAME $frame TIME $time"}
struct tdr=result !Gas
''')
print('created plate-buckling, arch-mesh, arch-snap')
