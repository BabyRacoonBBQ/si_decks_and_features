from pathlib import Path
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
d=r/'arch-linear';d.mkdir(exist_ok=True)
base=(r/'arch-snap/case.cmd').read_text().split('mode mechanics')[0]
(d/'case.cmd').write_text(base+'''mode buckling=3
pdbSet Math Eigen 3D Max.Iter 3000
pdbSet Math Eigen 3D Tol 1e-8
solve info=2
struct tdr=result !Gas
''')
print('Same mesh, material, end restraints and crown reference load as arch-snap')
