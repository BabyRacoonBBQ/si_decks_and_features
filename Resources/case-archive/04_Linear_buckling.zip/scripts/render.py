from pathlib import Path
from collections import Counter
import json,re
import numpy as np
import h5py
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image

root=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
out=root/'visuals';out.mkdir(exist_ok=True)
def read(p):
 with h5py.File(p) as f:
  g=f['collection/geometry_0']; v=g['vertex'][:]
  xyz=np.column_stack([v[k] for k in ['x','y','z']])*1e4
  raw=g['region_0/elements_0'][:].reshape(-1,9)
  assert np.all(raw[:,0]==8)
  elems=raw[:,1:]
  fields={}
  for d in g['state_0'].values():
   if 'values' not in d:continue
   name=d.attrs['name'].decode();a=d['values'][:]
   if len(a)==3*len(xyz):a=a.reshape(-1,3)
   fields[name]=a
  return xyz,elems,fields

def surface(e):
 patterns=[[0,1,2,3],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]]
 faces=[tuple(row[idx] for idx in pat) for row in e for pat in patterns]
 counts=Counter(tuple(sorted(f)) for f in faces)
 return np.asarray([f for f in faces if counts[tuple(sorted(f))]==1])

def draw(xyz,faces,u,scalar,vmax,title,caption,path,scale=1,unit='Displacement (um)',bounds=None):
 pts=xyz+u*scale
 rotation=None
 if unit.startswith('Normalized'):
  transverse=u[np.argmax(np.linalg.norm(u[:,1:],axis=1)),1:]
  if np.linalg.norm(transverse)>0:
   ey,ez=-transverse/np.linalg.norm(transverse)
   rotation=np.array([[ez,ey],[-ey,ez]])
   pts[:,1:]=pts[:,1:]@rotation
 # Place clamp on the left; preserve physical axis lengths.
 pts=pts.copy();pts[:,0]=50-pts[:,0]
 fig=plt.figure(figsize=(8,4.5),dpi=120,facecolor='#F5F7FA')
 ax=fig.add_axes([0.01,0.10,.86,.76],projection='3d',facecolor='#F5F7FA')
 norm=matplotlib.colors.Normalize(0,max(vmax,1e-20))
 coll=Poly3DCollection(pts[faces],facecolors=plt.cm.viridis(norm(scalar[faces].mean(axis=1))),edgecolors='none',linewidths=0)
 ax.add_collection3d(coll)
 corners=np.array([[x,y,z] for x in [0,50] for y in [-2,2] for z in [-2,2]],dtype=float)
 if rotation is not None:corners[:,1:]=corners[:,1:]@rotation
 for a in range(8):
  for bidx in range(a+1,8):
   if (a^bidx) in (1,2,4):
    edge=corners[[a,bidx]]
    ax.plot(edge[:,0],edge[:,1],edge[:,2],color='#718096',linewidth=.6,alpha=.65)
 b=bounds or ((-2,52),(-7,7),(-12,8))
 ax.set_xlim(*b[0]);ax.set_ylim(*b[1]);ax.set_zlim(*b[2]);ax.set_box_aspect([hi-lo for lo,hi in b],zoom=1.45)
 ax.set_proj_type('ortho')
 ax.view_init(elev=18,azim=-82);ax.set_axis_off()
 fig.savefig(path,facecolor=fig.get_facecolor());plt.close(fig)

summary={}
for kind in ['quasistatic','linear-buckling','post-buckling-supercritical']:
 paths=sorted((root/kind).glob('frame-*/result_sis.tdr')) if kind=='quasistatic' else sorted((root/kind).glob('frame-*_sis.tdr'))
 if kind=='linear-buckling': paths=[root/kind/'result_sis.tdr']
 if not paths:continue
 data=[read(p) for p in paths];xyz,elems,fields=data[-1];faces=surface(elems)
 row={'nodes':len(xyz),'elements':len(elems),'snapshots':len(paths),'files':[str(p.relative_to(root)) for p in paths]}
 ulist=[d[2]['Displacement']*1e4 for d in data]
 row['max_displacement_um']=[float(np.linalg.norm(u,axis=1).max()) for u in ulist]
 if kind=='linear-buckling':
  u=fields['BucklingMode1'];u=u/np.linalg.norm(u,axis=1).max()
  vals=re.findall(r'Mode:\s+\d+\s+EigenValue\s*=\s*([\deE+.-]+)',(root/kind/'stdout.log').read_text())
  row['eigenvalues']=[float(v) for v in vals[:3]];row['critical_load_dyn']=row['eigenvalues'][0]*.03
  entries=[(xyz,u*10*a,np.linalg.norm(u,axis=1),f'Mode 1 | normalized shape; display amplitude only ({a:.2f})') for a in np.linspace(0,1,20)]
  vmax=1;scale=1;unit='Normalized mode magnitude';bounds=((-2,52),(-8,8),(-15,9));title='Linear buckling'
  mode_images=[]
  for m in range(1,4):
   mode=fields[f'BucklingMode{m}'];mode=mode/np.linalg.norm(mode,axis=1).max()
   target=out/f'linear-mode-{m}.png'
   draw(xyz,faces,mode*10,np.linalg.norm(mode,axis=1),1,f'Linear buckling | mode {m}',f'Computed eigenmode | load factor {row["eigenvalues"][m-1]:.3f} | amplitude arbitrary',target,1,'Normalized mode magnitude',bounds)
   mode_images.append(Image.open(target).convert('RGB'))
  gallery=Image.new('RGB',(960,540*3),'white')
  for m,im in enumerate(mode_images):gallery.paste(im,(0,540*m))
  gallery.save(out/'linear-buckling-three-modes.png')
 elif kind=='quasistatic':
  vmax=max(row['max_displacement_um']);scale=8;unit='Displacement (um)';title='Quasistatic bending';bounds=None
  entries=[(d[0],u,np.linalg.norm(u,axis=1),f'Load {int(p.parent.name[-2:])/16:.0%} | deformation x8 | independent equilibrium solve') for p,d,u in zip(paths,data,ulist)]
 else:
  vmax=max(row['max_displacement_um']);scale=1;unit='Displacement (um)';title='Post-buckling';bounds=((-2,52),(-8,8),(-48,8))
  entries=[(d[0],u,np.linalg.norm(u,axis=1),f'Converged increment {j+1}/{len(data)} | deformation x1 | large deformation + arc length') for j,(d,u) in enumerate(zip(data,ulist))]
 frames=[]
 for j,(x,u,c,caption) in enumerate(entries):
  p=out/f'{kind}-{j:03d}.png'
  draw(x,faces,u,c,vmax,title,caption,p,scale,unit,bounds)
  frames.append(Image.open(p).convert('RGB'))
 frames[-1].save(out/f'{kind}.png')
 frames[-1].save(out/f'{kind}.gif',save_all=True,append_images=frames+[frames[-1]]*5,duration=160,loop=0)
 # Compact scientific-plot crop for the mechanics capability card.
 mini=[f.crop((100,110,940,475)).resize((672,292)) for f in frames]
 mini[-1].save(out/f'{kind}-card.png')
 mini[-1].save(out/f'{kind}-card.gif',save_all=True,append_images=mini+[mini[-1]]*5,duration=160,loop=0)
 summary[kind]=row
(root/'results-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
