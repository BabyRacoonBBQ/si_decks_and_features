from pathlib import Path
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
exec((r/'render-geometric.py').read_text().split('frames=[]')[0])
for t in times[::5]:
 print(t, {k: metrics(cases[k][t])['max_displacement_um'] for k in cases})
