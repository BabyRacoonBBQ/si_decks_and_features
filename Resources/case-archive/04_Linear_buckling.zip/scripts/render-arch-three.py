from pathlib import Path
exec(Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010/render-arch-pair.py').read_text().split("save('linear-buckling-card'")[0])
out=root/'arch-three-visuals';out.mkdir(exist_ok=True)
gallery=Image.new('RGB',(960,396),'#F5F7FA')
for j in range(1,4):
 mode=f[f'BucklingMode{j}'];mode=mode/np.linalg.norm(mode,axis=1).max()*3
 p=out/f'mode-{j}.png';draw_frame(mode,p,4)
 im=Image.open(p).convert('RGB');gallery.paste(im.crop((0,132,960,264)),(0,(j-1)*132))
gallery.save(out/'linear-buckling-three-static.png')
qpaths=sorted((root/'arch-quasistatic').glob('frame-*_sis.tdr'))
qdata=[read(p) for p in qpaths]
assert len(qdata)>2 and all(np.array_equal(a,x) and np.array_equal(b,e) for a,b,_ in qdata)
qus=[v['Displacement']*1e4 for _,_,v in qdata]
vmax=max(np.linalg.norm(v,axis=1).max() for v in qus)
save('quasistatic-card',[qus[0]]*3+qus+[qus[-1]]*5,vmax)
(out/'results.json').write_text(json.dumps({'same_geometry':True,'nodes':len(x),'elements':len(e),'frames':len(qdata),'quasistatic_max_displacement_um':float(vmax),'quasistatic_force_dyn':0.05,'deformation_scale':1,'linear_modes':[1,2,3]},indent=2))
print((out/'results.json').read_text())
