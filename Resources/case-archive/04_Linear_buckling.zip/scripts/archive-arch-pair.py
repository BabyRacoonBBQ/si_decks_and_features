from pathlib import Path
import tarfile,hashlib
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
a=r.parent/'stressthermal-arch-pair-20261010.tar.gz'
(r/'arch-pair-visuals/README.md').write_text('''# Matching-geometry buckling comparison
Vendor sinterconnect runs. Both cases use identical reference vertices and element connectivity (1275 nodes / 800 bricks), elastic material, fixed ends and crown load pattern; the renderer asserts exact coordinate/connectivity equality. Geometry: shallow arch, 50 um span, 4 um rise, 2 x 0.5 um section. Linear eigenmode 1 is normalized with arbitrary 4 um display amplitude, not physical motion; eigenvalue 0.14760 relative to 0.5 dyn reference load. Post-buckling uses the 43 saved nonlinear equilibrium states, displacement scale 1, with a branch jump at state 11. GIF pacing includes holds and samples the late branch; no intermediate deformation is fabricated. These are not inertial dynamics. Both use identical camera and limits; no colorbars. Source meshes, decks, logs, raw fields, image frames, rendering and setup scripts are archived. Prior plate example remains separately archived.
''')
with tarfile.open(a,'w:gz',compresslevel=3) as t:
 for n in ['arch-linear','arch-snap','arch-mesh','arch-pair-visuals','setup-arch-linear.py','setup-buckling-v2.py','curve-arch.py','render-arch-pair.py','render.py','run.sh','archive-arch-pair.py']:
  t.add(r/n,arcname=n)
h=hashlib.sha256(a.read_bytes()).hexdigest();a.with_suffix('.gz.sha256').write_text(h+'  '+a.name+'\n');print(h)
