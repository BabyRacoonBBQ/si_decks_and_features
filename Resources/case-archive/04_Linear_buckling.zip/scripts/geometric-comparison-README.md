# Geometric nonlinearity: controlled cantilever comparison

Computed on the user's VM with sinterconnect vendor W-2024.09-SP1. These are new vendor runs; local sinterconnect_run equivalence is not asserted.

The accepted inputs differ in exactly one statement: `pdbSetBoolean Mechanics LargeDeformation 0` versus `1`. See geometric-pair.diff. All geometry, mesh, material, loading, boundary conditions, time sampling and requested convergence controls are otherwise byte-identical.

## Model
- Same 50 x 4 x 4 um solid cantilever as the preceding mechanics demonstrations.
- 4,131 nodes and 3,200 first-order bricks, elastic E=1 GPa and Poisson ratio 0.2, assigned to the Silicon material identifier for this pedagogical example.
- Clamp at x=50 um; transverse point load at the centre of the x=0 end. Full load is -1.5 dyn in global z. This is 50 times the preceding small-load bending example, identically increased in BOTH cases to expose large-rotation effects.
- PARDISO, ArcLength off in both cases, requested step 0.025 s over a 1 s quasistatic load ramp. No inertial dynamics.
- Displacement convergence tolerance 1e-6 in both cases. First force-check trial failed and is retained separately in geometric-off/. It is not used in the figures.
- The accepted results are geometric-off-v2/ and geometric-on-v2/, both with exit status 0.

## Results
- Matched saved states: 41.
- OFF: maximum displacement 28.6163 um; deformed centerline length 58.7408 um; extension 17.4816%.
- ON: maximum displacement 23.5901 um; deformed centerline length 50.0188 um; extension 0.0375%.

## Interpretation and visualization
Both plots have identical axes, colour range and deformation scale x1. The outline is the undeformed geometry. All surfaces are built from the saved finite-element connectivity, not an analytic beam shape. GIF frames are paired by the actual logged load-ramp time, not by assuming two runs have identical frame indices.

Centerline extension is computed from the polyline through the actual nodes at y=z=0 after adding total displacement to the original coordinates. It is a geometric diagnostic, not a solver-reported constitutive strain. In the infinitesimal-strain model, large transverse deflections without consistent finite-rotation kinematics can produce artificial elongation/distortion in the displayed shape. Some extension in a loaded elastic beam can be physical; this diagnostic is not a proof that all strain in the OFF run is fictitious.

elastic-strain-comparison.png separately shows saved nodal ElasticStrain XX with a shared signed colour scale. The UG states that elastic strains are derived from stresses; this field should not be reinterpreted as a directly comparable finite-strain invariant. The large-deformation formulation is described by the UG using Euler–Almansi strain. Point-load and clamp stress concentrations are present; peak nodal strain is not a mesh-converged material-failure prediction.

UG evidence: Chapter 2, Large Deformation Analysis, Figure 16 (linear cantilever elongation/end swelling versus large deformation), and Saving Stress and Strain Components.

## Reproduction
Use setup-geometric.py to create the pair, then `bash run.sh geometric-off-v2` and `bash run.sh geometric-on-v2` from the existing VM demo root. Run `PYTHONNOUSERSITE=1 python3 render-geometric.py`. The runner depends on the user's existing geo3d/.env; credentials and license configuration are not included.
