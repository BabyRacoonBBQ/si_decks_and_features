from pathlib import Path
import h5py,numpy as np,json
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
rows=[]
for p in sorted((r/'post-buckling-supercritical').glob('frame-*_sis.tdr')):
 with h5py.File(p) as f:
  g=f['collection/geometry_0'];a=g['vertex'][:];xyz=np.column_stack([a[k] for k in ['x','y','z']])
  if not rows:base=xyz.copy()
  fields={d.attrs['name'].decode():d['values'][:] for d in g['state_0'].values() if 'values' in d}
  u=fields['Displacement'].reshape(-1,3)
  rows.append({'file':p.name,'coordinate_change_um':float(np.linalg.norm(xyz-base,axis=1).max()*1e4),'max_u_um':float(np.linalg.norm(u,axis=1).max()*1e4),'tip_u_um':u[np.argmin(np.linalg.norm(base,axis=1))].tolist()})
print(json.dumps(rows[-3:],indent=2))
