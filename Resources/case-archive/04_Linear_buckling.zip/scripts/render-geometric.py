from pathlib import Path
from collections import Counter
import json,re,hashlib,tarfile
import h5py,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
out=r/'geometric-comparison';out.mkdir(exist_ok=True)
def read(p):
 with h5py.File(p) as f:
  g=f['collection/geometry_0'];v=g['vertex'][:]
  x=np.column_stack([v[k] for k in ('x','y','z')])*1e4
  elems=g['region_0/elements_0'][:].reshape(-1,9);assert np.all(elems[:,0]==8)
  fields={d.attrs['name'].decode():d['values'][:] for d in g['state_0'].values() if 'values' in d}
  return x,elems[:,1:],fields['Displacement'].reshape(-1,3)*1e4,fields['ElasticStrain'].reshape(-1,6)[:,0]
cases={}
for name in ['off','on']:
 d=r/('geometric-'+name+'-v2')
 assert (d/'exit.txt').read_text().strip()=='0'
 times=re.findall(r'PAIR_FRAME\s+(\d+)\s+TIME\s+([\deE+.-]+)',(d/'stdout.log').read_text())
 cases[name]={round(float(t),9):read(d/f'frame-{int(i):03d}_sis.tdr') for i,t in times}
 assert cases[name] and 1.0 in cases[name]
assert set(cases['off'])==set(cases['on']), 'Load sampling must match'
times=sorted(cases['off'])
x,e,_,_=cases['off'][times[0]]
patterns=[[0,1,2,3],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]]
allfaces=[tuple(row[k] for k in p) for row in e for p in patterns]
counts=Counter(tuple(sorted(f)) for f in allfaces)
faces=np.array([f for f in allfaces if counts[tuple(sorted(f))]==1])
centre=np.where((abs(x[:,1])<1e-8)&(abs(x[:,2])<1e-8))[0];centre=centre[np.argsort(x[centre,0])]
def metrics(v):
 xyz,_,u,strain=v;deformed=xyz+u
 length=np.linalg.norm(np.diff(deformed[centre],axis=0),axis=1).sum()
 return {'max_displacement_um':float(np.linalg.norm(u,axis=1).max()),'centreline_length_um':float(length),'centreline_extension_percent':float((length/50-1)*100),'max_abs_stored_elastic_strain_xx':float(abs(strain).max())}
summary={'only_input_difference':'Mechanics LargeDeformation 0 versus 1','nodes':len(x),'elements':len(e),'matched_load_states':len(times),'times':times,'load_dyn':1.5,'deformation_scale':1,'off':metrics(cases['off'][1.0]),'on':metrics(cases['on'][1.0])}
umax=max(metrics(cases[k][1.0])['max_displacement_um'] for k in cases)
emax=max(metrics(cases[k][1.0])['max_abs_stored_elastic_strain_xx'] for k in cases)
corners=np.array([[a,b,c] for a in [0,50] for b in [-2,2] for c in [-2,2]])
def plot(t,p,strain=False):
 fig=plt.figure(figsize=(12,4.1),dpi=110,facecolor='#F5F7FA')
 norm=matplotlib.colors.Normalize(-emax if strain else 0,emax if strain else umax)
 cmap=plt.cm.coolwarm if strain else plt.cm.viridis
 for j,k in enumerate(['off','on']):
  xyz,_,u,eps=cases[k][t];pts=xyz+u;pts=pts.copy();pts[:,0]=50-pts[:,0]
  ax=fig.add_axes([.015+j*.46,.12,.445,.74],projection='3d',facecolor='#F5F7FA')
  val=eps if strain else np.linalg.norm(u,axis=1)
  ax.add_collection3d(Poly3DCollection(pts[faces],facecolors=cmap(norm(val[faces].mean(axis=1))),edgecolors='none'))
  for a in range(8):
   for b in range(a+1,8):
    if (a^b) in (1,2,4):
     v=corners[[a,b]];ax.plot(v[:,0],v[:,1],v[:,2],color='#718096',lw=.65,alpha=.6)
  ax.set_xlim(-3,53);ax.set_ylim(-5,5);ax.set_zlim(-35,6)
  ax.set_box_aspect((56,10,41),zoom=1.35);ax.set_proj_type('ortho');ax.view_init(elev=15,azim=-78);ax.set_axis_off()
  fig.text(.035+j*.46,.91,'OFF' if k=='off' else 'ON',fontsize=32,weight='bold',color='#A13C32' if k=='off' else '#206D65')
  if k=='off':fig.text(.12,.91,'Artificial distortion',fontsize=22,weight='bold',color='#A13C32')
 fig.text(.48,.08,'Same loading',ha='center',fontsize=32,weight='bold',color='#334B5A')
 fig.savefig(p);plt.close(fig)
frames=[]
for i,t in enumerate(times):
 p=out/f'frame-{i:03d}.png';plot(t,p);frames.append(Image.open(p).convert('RGB'))
frames[-1].save(out/'geometric-comparison.png')
frames[-1].save(out/'geometric-comparison.gif',save_all=True,append_images=frames+[frames[-1]]*6,duration=140,loop=0)
plot(1.0,out/'elastic-strain-comparison.png',True)
(out/'results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
