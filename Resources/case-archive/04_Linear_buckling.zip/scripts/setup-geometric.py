from pathlib import Path
import difflib,hashlib,json
r=Path('/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010')
base=(r/'quasistatic/frame-16/case.cmd').read_text().split('stressdata bc.location=pointend')[0]
template=base+'''stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=0 pfy=0 pfz=-1.5<dyn>}
mode mechanics
pdbSetBoolean Mechanics LargeDeformation @SWITCH@
pdbSetBoolean Mechanics ArcLength 0
pdbSetBoolean Mechanics Adjust.Time.Step 0
pdbSet Mechanics MaxIterations 30
pdbSet Mechanics Convergence.Info 1
pdbSet Mechanics Convergence.Force.Check 0
pdbSet Mechanics Convergence.Displacement.Check 1
pdbSet Mechanics Convergence.Displacement.Tolerance 1e-6
pdbSet Mechanics Convergence.Energy.Check 0
pdbSet Mechanics Convergence.Force.Tolerance 1e-6
set frame 0
solve time=1<s> init=0.025<s> maxstep=0.025<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "PAIR_FRAME $frame TIME $time"}
struct tdr=result !Gas
'''
for name,flag in [('geometric-off-v2','0'),('geometric-on-v2','1')]:
 d=r/name;d.mkdir(exist_ok=True)
 (d/'case.cmd').write_text(template.replace('@SWITCH@',flag))
a=(r/'geometric-off-v2/case.cmd').read_text();b=(r/'geometric-on-v2/case.cmd').read_text()
assert a.replace('LargeDeformation 0','LargeDeformation 1')==b
(r/'geometric-pair.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='geometric-off/case.cmd',tofile='geometric-on/case.cmd')))
print((r/'geometric-pair.diff').read_text())
