
line x location= 0.0<um>   spacing= 0.3<um> tag= top
line x location= 50<um>  spacing= 0.3<um>   tag= bottom
line y location= -2.0<um>   spacing= 0.3<um>   tag= left
line y location= 0.0<um> spacing= 0.3<um>
line y location= 2.0<um>   spacing= 0.3<um>   tag= right
line z location= -2.0<um>   spacing= 0.3<um>   tag= back
line z location= 0.0<um> spacing= 0.3<um>
line z location= 2.0<um>   spacing= 0.3<um>   tag= front

pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]

region silicon substrate xlo= top xhi= bottom ylo= left yhi= right zlo= back zhi= front

init !DelayFullD

struct tdr=3D_cantilever_init

stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=Left bc.value= {sx=0 sy=0 sz=0}
stressdata bc.location=Right bc.value= {sx=0 sy=0 sz=0}
stressdata bc.location=Back bc.value= {sx=0 sy=0 sz=0}
stressdata bc.location=Front bc.value= {sx=0 sy=0 sz=0}
stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=0 pfy=0 pfz=-0.03<dyn>}

mode mechanics
solve 

struct tdr=n4
struct tdr=3D_cantilever_def deform deform.scale= 5.0

select z="Displacement_z"
plot.1d y=0 z=0



