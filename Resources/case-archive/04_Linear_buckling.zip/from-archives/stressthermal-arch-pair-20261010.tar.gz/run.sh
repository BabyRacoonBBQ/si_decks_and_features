#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TDR_VERSION=16 PYTHONNOUSERSITE=1
root=/home/mozztcad/tmp/stressthermal-mechanics-examples-20261010
cd "$root/$1"
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 600 9
ulimit -v 6291456
binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
sha256sum "$binary" case.cmd > identities.sha256
set +e
/usr/bin/time -v timeout -k 10 240 taskset -c 4 "$binary" --noSyntaxCheck case.cmd >stdout.log 2>stderr.log
rc=$?
echo "$rc" >exit.txt
tail -8 stdout.log
tail -4 stderr.log
exit "$rc"
