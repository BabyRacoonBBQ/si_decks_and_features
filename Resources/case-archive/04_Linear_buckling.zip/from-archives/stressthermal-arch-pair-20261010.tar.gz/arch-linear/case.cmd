init tdr=../arch-mesh/arch.tdr !load.commands !pdb
pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
math pardiso
math numThreads=1
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=Bulk.Top bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=centre point.coord= {25 0 4} bc.value= {pfx=0 pfy=0 pfz=-0.5<dyn>}
mode buckling=3
pdbSet Math Eigen 3D Max.Iter 3000
pdbSet Math Eigen 3D Tol 1e-8
solve info=2
struct tdr=result !Gas
