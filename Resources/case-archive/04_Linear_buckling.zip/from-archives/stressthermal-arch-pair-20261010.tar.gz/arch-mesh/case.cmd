pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
math pardiso
math numThreads=1
line x location=0 spacing=1 tag=top
line x location=25 spacing=1
line x location=50 spacing=1 tag=bottom
line y location=-1.0 spacing=0.5 tag=left
line y location=0 spacing=0.5
line y location=1.0 spacing=0.5 tag=right
line z location=-0.25 spacing=0.125 tag=back
line z location=0 spacing=0.125
line z location=0.25 spacing=0.125 tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
struct tdr=flat !Gas
