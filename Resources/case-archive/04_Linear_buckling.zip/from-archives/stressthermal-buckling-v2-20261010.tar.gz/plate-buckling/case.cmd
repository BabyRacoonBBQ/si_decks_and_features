pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
math pardiso
math numThreads=1
line x location=0 spacing=1 tag=top
line x location=25 spacing=1
line x location=50 spacing=1 tag=bottom
line y location=-10.0 spacing=1 tag=left
line y location=0 spacing=1
line y location=10.0 spacing=1 tag=right
line z location=-0.5 spacing=0.25 tag=back
line z location=0 spacing=0.25
line z location=0.5 spacing=0.25 tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=Bulk.Top bc.value= {dy=0 dz=0 fx=0.1<dyn>}
mode buckling=3
pdbSet Math Eigen 3D Max.Iter 3000
pdbSet Math Eigen 3D Tol 1e-8
solve info=2
struct tdr=result !Gas
