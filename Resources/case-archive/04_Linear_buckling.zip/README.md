# 04_Linear_buckling

CMD inputs and original provenance. No TDR or bulk field dumps. Historical scripts have not been rerun. Restore original paths or adjust Linux paths; licensed solver and regenerated geometry/meshes are required. Use per-run binary identities, not the newest global build. Missing per-run identity means exact binary unverified.

## CMD
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-linear/case.cmd
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-mesh/case.cmd
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-linear/case.cmd
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-mesh/case.cmd
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/plate-buckling/case.cmd
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/arch-mesh/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/linear-buckling/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/vendor-reference-cantilever.cmd

## Version evidence
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-linear/identities.sha256
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-mesh/identities.sha256
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-linear/identities.sha256
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-mesh/identities.sha256
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/plate-buckling/identities.sha256
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/arch-mesh/identities.sha256
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/environment.json
- from-archives/stressthermal-geometric-comparison-20261010.tar.gz/environment.json
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/environment.json
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/linear-buckling/identities.sha256