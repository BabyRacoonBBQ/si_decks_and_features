math numThreads=1
math pardiso
line x location=0 spacing=1 tag=top
line x location=50 spacing=1 tag=bottom
line y location=-2 spacing=0.5 tag=left
line y location=2 spacing=0.5 tag=right
line z location=-2 spacing=0.5 tag=back
line z location=2 spacing=0.5 tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
pdbSet Mechanics Save.Step.Displacement 1
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=4.0<dyn> pfy=0 pfz=-0.002<dyn>}
mode mechanics
pdbSetBoolean Mechanics LargeDeformation 1
pdbSetBoolean Mechanics ArcLength 1
pdbSetDouble Mechanics ArcLength.deltaL.init 0.01
pdbSetDouble Mechanics ArcLength.deltaL.max 0.025
pdbSetDouble Mechanics ArcLength.deltaL.min 1e-6
pdbSetDouble Mechanics ArcLength.steps 160
pdbSet Mechanics MaxIterations 50
pdbSet Mechanics Convergence.Info 1
set frame 0
solve time=1<s> init=0.05<s> maxstep=0.05<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "SAVED_FRAME $frame"}
struct tdr=result !Gas
