init tdr=../arch-mesh/arch.tdr !load.commands !pdb
pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
math pardiso
math numThreads=1
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=Bulk.Top bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=centre point.coord= {25 0 4} bc.value= {pfx=0 pfy=0 pfz=-0.5<dyn>}
mode mechanics
pdbSetBoolean Mechanics LargeDeformation 1
pdbSetBoolean Mechanics ArcLength 1
pdbSetDouble Mechanics ArcLength.deltaL.init 0.005
pdbSetDouble Mechanics ArcLength.deltaL.max 0.025
pdbSetDouble Mechanics ArcLength.deltaL.min 1e-7
pdbSetDouble Mechanics ArcLength.steps 300
pdbSet Mechanics MaxIterations 50
pdbSet Mechanics Convergence.Info 1
set frame 0
solve time=1<s> init=0.025<s> maxstep=0.025<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "ARCH_FRAME $frame TIME $time"}
struct tdr=result !Gas
