# 03_Quasistatic_equilibrium

CMD inputs and original provenance. No TDR or bulk field dumps. Historical scripts have not been rerun. Restore original paths or adjust Linux paths; licensed solver and regenerated geometry/meshes are required. Use per-run binary identities, not the newest global build. Missing per-run identity means exact binary unverified.

## CMD
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-linear/case.cmd
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-mesh/case.cmd
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-quasistatic/case.cmd
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-linear/case.cmd
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-mesh/case.cmd
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/arch-mesh/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-01/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-02/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-03/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-04/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-05/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-06/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-07/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-08/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-09/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-10/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-11/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-12/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-13/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-14/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-15/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-16/case.cmd
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/vendor-reference-cantilever.cmd

## Version evidence
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-linear/identities.sha256
- from-archives/stressthermal-arch-pair-20261010.tar.gz/arch-mesh/identities.sha256
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-quasistatic/identities.sha256
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-linear/identities.sha256
- from-archives/stressthermal-arch-quasistatic-staticmodes-20261010.tar.gz/arch-mesh/identities.sha256
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/arch-mesh/identities.sha256
- from-archives/stressthermal-buckling-v2-20261010.tar.gz/environment.json
- from-archives/stressthermal-geometric-comparison-20261010.tar.gz/environment.json
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/environment.json
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-02/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-04/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-06/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-08/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-10/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-12/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-14/identities.sha256
- from-archives/stressthermal-mechanics-examples-20261010.tar.gz/stressthermal-mechanics-examples-20261010/quasistatic/frame-16/identities.sha256