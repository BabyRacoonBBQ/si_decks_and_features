math numThreads=1
math pardiso
line x location=0 spacing=1 tag=top
line x location=50 spacing=1 tag=bottom
line y location=-2 spacing=0.5 tag=left
line y location=2 spacing=0.5 tag=right
line z location=-2 spacing=0.5 tag=back
line z location=2 spacing=0.5 tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
pdbSet Mechanics Save.Step.Displacement 1
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=0 pfy=0 pfz=-0.013125<dyn>}
mode mechanics
solve info=1
struct tdr=result !Gas
