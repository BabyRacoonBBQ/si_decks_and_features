# Package Bump analaysis using J-2014.09-DEV
# --------------------------------------------------------

# Set the default output level
# --------------------------------------------------------

pdbSet InfoDefault 1

# Create the global package geometries using Sentaurus Structure Editor
# Here, SDE procedures are used to create the package structure at each assembly step
#  --------------------------------------------------------

sde external {

; This command file creates the global model geometries
; --------------------------------------------------------

(sde:clear)
(sde:set-process-up-direction "-x")
(sde:setrefprops 0.1 5.0)

; Define the dimensions
; --------------------------------------------------------

(define distance_1 @distance@)
(define half_distance_1 (/ distance_1 2.0))

(define height_1 75.0)
(define bump_d_1 (/ (* 4.0 height_1) 3.0))
(define bump_r_1 (/ bump_d_1 2.0))

(define half_pitch_1 (+ bump_r_1 half_distance_1))

(define smear_t_1 5.0)

(define sub_t_1 1000.0)

(define sub_l_1 10000.0)

(define chip_t_1 775.0)

(define chip_l_1 5000.0)

(define sm_t_1 2.0)

(define pad_t_1 2.0)

(define ubm_t_1 2.0)

(define number_b_1 5)

; Define the procedures
; --------------------------------------------------------

; Define the smear material
; --------------------------------------------------------

(define create_smear (lambda (region material region1 material1 distance height smear_t sub_t sub_l chip_t chip_l pad_t sm_t 
ubm_t)
		(begin
		(sdegeo:set-default-boolean "ABA")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (+ bump_r half_distance))
		(sdegeo:create-cuboid 	(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t)) 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t)) chip_l 0.0)
					material
					region
		)
		(sdegeo:create-cuboid 	(position (* -1.0 (+ sub_t height)) 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t)) chip_l 0.0)
					material1
					region1
		)
		(sdegeo:set-default-boolean "BAB")
		(sdegeo:create-cuboid 	(position (* -1.0 (+ sub_t height)) 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t 0.1)) chip_l 0.0)
					"Gas"
					"Gas_A"
		)
		(sdegeo:set-default-boolean "ABA")			
		)
	)
)

; Define the bumps
; --------------------------------------------------------

(define create_bumps (lambda (region material distance height smear_t sub_t sub_l chip_t chip_l num_bumps pad_t sm_t ubm_t)
		(begin
		(sdegeo:set-default-boolean "BAB")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (+ bump_r half_distance))
		(define number num_bumps)
		(let bumps1 ((counter_1 1))
		     (if (<= counter_1 number)
			 (begin
			  (define cent_x (* -1.0 (+ sub_t (* 0.5 height))))
			  (define cent_y (- chip_l (* counter_1 (* 2.0 half_pitch))))
			  (define cent_z 0.0)
			  (define newreg region)
			  (define count1 (number->string counter_1))
			  (define reg1 (string-append newreg "_" count1))
			  (sdegeo:create-sphere 	(position cent_x cent_y cent_z) 
							bump_r
							material reg1
							)			
			  (bumps1 (+ counter_1 1))
			 )
		       )
		)
		(sdegeo:set-default-boolean "BAB")
		(sdegeo:create-cuboid 	(position (* -1.0 sub_t) 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t 0.1)) chip_l 0.0)
					"Gas"
					"Gas_A"
		)
		(sdegeo:set-default-boolean "ABA")
		(sdegeo:body-trim (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t 0.1)) 0.0 (* -1.0 half_pitch)(* -1.0 
sub_t) chip_l 0.0)
		)
	)
)

; Define the substrate
; --------------------------------------------------------

(define create_sub (lambda (region material distance height smear_t sub_t sub_l chip_t chip_l pad_t sm_t ubm_t)
		(begin
		(sdegeo:set-default-boolean "ABA")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (+ bump_r half_distance))
		(sdegeo:create-cuboid 	(position 0.0 0.0 (* -1.0 half_pitch))
					(position (* -1.0 sub_t) sub_l 0.0)
					material
					region
		)
		(sdegeo:set-default-boolean "BAB")
		(sdegeo:create-cuboid 	(position 0.0 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t))  sub_l 0.0)
					"Gas"
					"Gas_A"
		)
		(sdegeo:set-default-boolean "ABA")
		(sdegeo:set-default-boolean "BAB")
		(sdegeo:create-cuboid 	(position (* -1.0 sub_t) 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t 0.1)) sub_l 0.0)
					"Gas"
					"Gas_A"
		)
		(sdegeo:set-default-boolean "ABA")		
		(sdegeo:body-trim  (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t 0.1)) 0.0 (* -1.0 half_pitch) 0.0 
sub_l 0.0)		
		)
	)
)

; Define the underfill
; --------------------------------------------------------

(define create_underfill (lambda (region material region1 material1 distance height smear_t sub_t sub_l chip_t chip_l num_bumps 
pad_t sm_t ubm_t)
		(begin
		(sdegeo:set-default-boolean "BAB")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (+ bump_r half_distance))
		
		(define number num_bumps)
		(sdegeo:create-cuboid (position (* -1.0 sub_t) 0.0 (* -1.0 half_pitch)) 
				      (position (* -1.0 (+ sub_t height)) (- chip_l (* (+ number 1) (* 2.0 half_pitch))) 0.0)
				      material1 region1)
		
		(sdegeo:create-cuboid (position (* -1.0 sub_t) 0.0 (* -1.0 half_pitch)) 
			              (position (* -1.0 (+ sub_t height)) chip_l 0.0)
			              material region
		)
                (sdegeo:create-cuboid (position (* -1.0 sub_t) chip_l (* -1.0 half_pitch)) 
			              (position (* -1.0 (+ sub_t height (* 0.5 chip_t))) (+ chip_l height (* 0.5 chip_t)) 0.0)
			              material region
                )
                (sdegeo:taper-faces 
		 (list (car (find-face-id 
		  (position (* -1.0 (+ sub_t (* 0.5 (+ height (* 0.5 chip_t)))))  
			    (+ chip_l height (* 0.5 chip_t)) 
			    (* -0.5 half_pitch)
		  )
		 )
	         )
		 )
		 (position  (* -1.0 sub_t) (+ chip_l height (* 0.5 chip_t)) (* -0.5 half_pitch)) 
		 (gvector 1 0 0) 
		 -45
		)
		(sdegeo:bool-unite (find-material-id material))
		(sdegeo:set-default-boolean "BAB")
		(sdegeo:create-cuboid 	(position 0.0 0.0 (* -1.0 half_pitch))
					(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t 0.1)) sub_l 0.0)
					"Gas"
					"Gas_A"
		)
		(sdegeo:set-default-boolean "ABA")			
		)
	)
)

; Create the structures for all the steps
; --------------------------------------------------------

; Define the substrate
; --------------------------------------------------------

(sdegeo:create-cuboid 	(position 	(* -1.0 (+ pad_t_1 sm_t_1 ubm_t_1 sub_t_1 height_1 smear_t_1))
 					0.0
					(* -1.0 half_pitch_1)
			) 
			(position 	(* -1.0 (+ pad_t_1 sm_t_1 ubm_t_1 sub_t_1 height_1 smear_t_1 chip_t_1)) 
					chip_l_1 
					0.0
			) 
			"Silicon" "Substrate" 
)

; Create smear material and passiation
; --------------------------------------------------------

(create_smear "region_2" "Smear" "region_2_1" "Pass" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 pad_t_1 
sm_t_1 ubm_t_1 )  

(sde:save-model "n@node@_1_global")

; Create Solder bumps
; --------------------------------------------------------

(entity:delete (find-material-id "Gas"))

(create_bumps "region_3" "BumpMat" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 number_b_1 pad_t_1 sm_t_1 
ubm_t_1 )

(sde:save-model "n@node@_2_global")

; Create Substrate
; --------------------------------------------------------

(entity:delete (find-material-id "Gas"))

(create_sub "region_4" "SubMat" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 pad_t_1 sm_t_1 ubm_t_1 )  

(sde:save-model "n@node@_3_global")

; Create file for underfilling ramp up
; --------------------------------------------------------

(sde:save-model "n@node@_4_global")

; Insert underfill
; -----------------------------

(entity:delete (find-material-id "Gas"))

(create_underfill "region_5" "Epoxy" "region_5_A" "UFSmear" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 
number_b_1 pad_t_1 sm_t_1 ubm_t_1)  

(sde:save-model "n@node@_5_global")

}

sde off

# SDE section ends at the above line 
# SDE is also turned off
# --------------------------------------------------------


# Set SWB Variables
# --------------------------------------------------------

set EUnderfill @EUF@
set LCTEUnderfill @LCTEUF@
set EBump @EBUMP@
set LCTEBump @LCTEBUMP@

# Define the coordinate system
# and define the simulation mode
# --------------------------------------------------------

math coord.ucs

math ils

mode mechanics

# Set the mechanics options
# --------------------------------------------------------

pdbSet Mechanics EtchDepoRelax 0
pdbSet Mechanics StressHistory 0

pdbSetDouble Mechanics RefThExpCoeff 0.0

pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 0
pdbSet Mechanics Save.Step.Displacement 1

pdbSet Mechanics Calculate.Principal.Stress 1
pdbSet Mechanics SaveMaxStress 1

# Set SNMesh options
# --------------------------------------------------------

pdbSetBoolean Grid No3DMerge 1
pdbSetBoolean Grid No3DSwap 1
pdbSetBoolean Grid Adaptive 0
pdbSet Mechanics Merge.Vertices 0

pdbSet Grid sMesh 1

pdbSet Grid SnMesh MaxPoints 5000000

# Add the Material Properties
# --------------------------------------------------------

pdbSet Silicon Mechanics BulkModulus [Enu2K 162.0e10 0.28]
pdbSet Silicon Mechanics ShearModulus [Enu2G 162.0e10 0.28]
pdbSet Silicon Mechanics ThExpCoeff 3.05e-6
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
pdbSetBoolean Silicon Mechanics Anisotropic 1

mater add name= Smear new.like= Nitride
pdbSetDouble Smear   Mechanics BulkModulus  [Enu2K 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ShearModulus [Enu2G 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ThExpCoeff   15.3e-6
pdbSetDouble Smear   Mechanics Vcrit0 1e-30
pdbSetDouble Smear   Mechanics VcritW 0.0
pdbSetDouble Smear   Mechanics Viscosity0 1e40
pdbSetDouble Smear   Mechanics ViscosityW 0.0

# ---------------------------------------------------------------------

mater add name= BumpMat new.like= Copper
pdbSetDouble BumpMat Mechanics BulkModulus [Enu2K $EBump 0.40]
pdbSetDouble BumpMat Mechanics ShearModulus [Enu2G $EBump 0.40]
pdbSetDouble BumpMat Mechanics ThExpCoeff $LCTEBump
		
# ---------------------------------------------------------------------

mater add name= Epoxy new.like= Oxide
pdbSetDouble Epoxy   Mechanics BulkModulus  [Enu2K $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ShearModulus [Enu2G $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ThExpCoeff   $LCTEUnderfill

pdbSetDouble Epoxy   Mechanics Vcrit0 1e-30	   
pdbSetDouble Epoxy   Mechanics VcritW 0.0	  
pdbSetDouble Epoxy   Mechanics Viscosity0 1e40  
pdbSetDouble Epoxy   Mechanics ViscosityW 0.0	
		
# ---------------------------------------------------------------------

mater add name= SubMat new.like= Nitride
pdbSetDouble SubMat   Mechanics BulkModulus  [Enu2K 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ShearModulus [Enu2G 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ThExpCoeff   15.7e-6
pdbSetDouble SubMat   Mechanics Vcrit0 1e-30
pdbSetDouble SubMat   Mechanics VcritW 0.0
pdbSetDouble SubMat   Mechanics Viscosity0 1e40
pdbSetDouble SubMat   Mechanics ViscosityW 0.0

mater add name= Pass new.like= Nitride
pdbSetDouble Pass   Mechanics BulkModulus  [Enu2K 131.0e10 0.22]
pdbSetDouble Pass   Mechanics ShearModulus [Enu2G 131.0e10 0.22]
pdbSetDouble Pass   Mechanics ThExpCoeff   1.9e-6
pdbSetDouble Pass   Mechanics Vcrit0 1e-30
pdbSetDouble Pass   Mechanics VcritW 0.0
pdbSetDouble Pass   Mechanics Viscosity0 1e40
pdbSetDouble Pass   Mechanics ViscosityW 0.0

# Define the dimensions 
# ---------------------------------------------------------

set distance_1 @distance@
set half_distance_1 [expr ($distance_1/2.0)]

set height_1 75.0
set bump_d_1 [expr ((4.0*$height_1)/3.0)]
set bump_r_1 [expr ($bump_d_1/2.0)]

set half_pitch_1 [expr ($bump_r_1+$half_distance_1)]
set neg_half_pitch_1 [expr (-1.0*$half_pitch_1)]

set smear_t_1 5.0

set sub_t_1 1000.0

set sub_l_1 10000.0

set chip_t_1 775.0

set chip_l_1 5000.0

set sold_pad_t 2.0
set sold_msk_t 2.0
set underbump_met_t 2.0

set number_b 5

set xmin [expr (-1.0*($sold_pad_t+$sold_msk_t+$underbump_met_t+$sub_t_1+$height_1+$smear_t_1+$chip_t_1))]
set xmax [expr (-1.0*($sold_pad_t+$sold_msk_t+$underbump_met_t+$sub_t_1+$height_1+$smear_t_1))]
set ymin 0.0
set ymax $chip_l_1
set zmin [expr (-1.0*$half_pitch_1)]
set zmax 0.0

set half_zmin [expr (0.5*$zmin)]

set cont_zmin [expr (-1.0*$half_pitch_1)]
set cont_zmax 0.0

set cont_xmin [expr ($xmin-0.1)]
set cont_xmax [expr ($xmin+0.1)]

# Smeared material property for underfill and bumps
# ----------------------------------------------------------------

set pi1 [expr (4.0*atan(1.0))]

set radius_1 $bump_r_1

set radius_2 [expr ($height_1*(sqrt(7.0/36.0)))]

set height_2 [expr (0.5*$height_1)]

set pitch_1 [expr (2.0*$half_pitch_1)]

set volume [expr ($pitch_1*$pitch_1*$height_1)]

set vol_bump [expr ((($pi1*$height_2)/3.0)*((3.0*$radius_1*$radius_1)+(3.0*$radius_2*$radius_2)+($height_2*$height_2)))]

set frac_bump [expr ($vol_bump/$volume)]

set frac_uf [expr (1.0-$frac_bump)]

set frac_uf1 [expr (($volume-$vol_bump)/$volume)]

set EUFSmear [expr (($EBump*$frac_bump)+($EUnderfill*$frac_uf))]

set NUUFSmear [expr ((0.40*$frac_bump)+(0.35*$frac_uf))]

set CTEUFSmear [expr (($LCTEBump*$frac_bump)+($LCTEUnderfill*$frac_uf))]

mater add name= UFSmear new.like= Oxide
pdbSetDouble UFSmear   Mechanics BulkModulus  [Enu2K $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ShearModulus [Enu2G $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ThExpCoeff   $CTEUFSmear
	
pdbSetDouble UFSmear   Mechanics Vcrit0 1e-30	   
pdbSetDouble UFSmear   Mechanics VcritW 0.0	  
pdbSetDouble UFSmear   Mechanics Viscosity0 1e40  
pdbSetDouble UFSmear   Mechanics ViscosityW 0.0

# Set boundary conditions 
# --------------------------------------------------------

stressdata bc.location=Front bc.value= { dz=0 }
stressdata bc.location=Back bc.value= { dz=0 }
stressdata bc.location=Left bc.value= { dy=0 }
stressdata bc.location= TopPoint point.coord= {$xmin 0.0 0.0} bc.value= {pdx=0.0 pdy=0.0 pdz=0.0}

# Switch on SDE 
# ---------------------------------------------------------

sde on logfile=n@node@_sde.log 

# Import the structure - silicon with smear and passivation 
# --------------------------------------------------------

init tdr=n@node@_1_global_bnd.tdr

# Define the mesh
# ---------------------------------------------------------

pdbSet Grid MGoals accuracy 1.0e-3
pdbSet Grid MGoals resolution 0.3
pdbSet Grid SnMesh min.normal.size 2.5

refinebox name= Refine_PCB materials= SubMat \
     xrefine= { 25.0 50.0 25.0 } \
     yrefine= { 50.0 100.0 50.0 } \
     zrefine= { 25.0 50.0 25.0 } 

refinebox name= Refine_Bump materials= BumpMat \
     xrefine= { 5.0 10.0 5.0 } \
     yrefine= { 5.0 10.0 5.0 } \
     zrefine= { 5.0 10.0 5.0 }
     
refinebox name= Refine_Epoxy materials= Epoxy \
     xrefine= { 25.0 50.0 25.0 } \
     yrefine= { 50.0 100.0 50.0 } \
     zrefine= { 25.0 50.0 25.0 } 
     
refinebox name= Refine_Chip materials= Silicon \
     xrefine= { 25.0 50.0 25.0 } \
     yrefine= { 50.0 100.0 50.0 } \
     zrefine= { 25.0 50.0 25.0 }
     
refinebox name= Refine_Smear materials= Smear \
     xrefine= { 25.0 50.0 25.0 } \
     yrefine= { 50.0 100.0 50.0 } \
     zrefine= { 25.0 50.0 25.0 }
      
refinebox name= Refine_UFSmear materials= UFSmear \
     xrefine= { 25.0 50.0 25.0 } \
     yrefine= { 50.0 100.0 50.0 } \
     zrefine= { 25.0 50.0 25.0 } 

refinebox name= Refine_Pass materials= Pass \
     xrefine= { 25.0 50.0 25.0 } \
     yrefine= { 50.0 100.0 50.0 } \
     zrefine= { 25.0 50.0 25.0 }
     
refinebox name= Refine_BC min= {$cont_xmin -0.1 -0.1} max= {$cont_xmax 0.1 0.1} \
     xrefine= { 0.025 0.050 0.025 } \
     yrefine= { 0.025 0.050 0.025 } \
     zrefine= { 0.025 0.050 0.025 } 
             
grid remesh

SetTemp 25.0

struct tdr=n@node@_out_0

# Ramp up to bump formation 
# --------------------------------------------------------

SetTemp 25.0

solve stress.relax temperature=25.0<C> t.final=200.0<C> delT= 175.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_out_1

# Bumps 
# --------------------------------------------------------

init tdr=n@node@_2_global_bnd.tdr

load tdr=n@node@_out_1_sis.tdr sum

SetTemp 200.0

solve stress.relax temperature=200.0<C> t.final=25.0<C> delNT= 175.0 \
 	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_out_2

# Substrate 
# --------------------------------------------------------

init tdr=n@node@_3_global_bnd.tdr

load tdr=n@node@_out_2_sis.tdr sum

SetTemp 25.0

solve stress.relax temperature=25.0<C> t.final=25.0<C> delT= 0.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_out_3

# Underfill ramp up 
# --------------------------------------------------------

init tdr=n@node@_4_global_bnd.tdr

load tdr=n@node@_out_3_sis.tdr sum

SetTemp 25.0

solve stress.relax temperature=25.0<C> t.final=180.0<C> delT= 155.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_out_4
		
# Underfill 
# --------------------------------------------------------

init tdr=n@node@_5_global_bnd.tdr

load tdr=n@node@_out_4_sis.tdr sum

SetTemp 180.0

solve stress.relax temperature=180.0<C> t.final=25.0<C> delNT= 155.0 \
 	time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_out_5

# Save the results and exit
# --------------------------------------------------------

struct tdr=n@node@_out_final

exit 



