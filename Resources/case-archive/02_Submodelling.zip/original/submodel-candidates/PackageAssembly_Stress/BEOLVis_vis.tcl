# Load fabrication process induced stress
# --------------------------------------------------------------

#setdep @node|LocalFlow@

load_file n@node|LocalProcess@_out_sis.tdr
create_plot -dataset n@node|LocalProcess@_out_sis_geometry_0

# Load packaging/assembly induced stress
# --------------------------------------------------------------

load_file n@node|LocalFlow@_sis.tdr
create_plot -dataset n@node|LocalFlow@_sis_geometry_0

# Load combined stress
# --------------------------------------------------------------

load_file n@node|LocalFlow@_sum_sis.tdr
create_plot -dataset n@node|LocalFlow@_sum_sis_geometry_0

# Manipulate the images
# --------------------------------------------------------------

windows_style -sort {Plot_n@node|LocalProcess@_out_sis_geometry_0 Plot_n@node|LocalFlow@_sis_geometry_0 Plot_n@node|LocalFlow@_sum_sis_geometry_0} \
	-style horizontal -direction right_down -max 3 -aspect_ratio_on

select_plots {Plot_n@node|LocalProcess@_out_sis_geometry_0 Plot_n@node|LocalFlow@_sis_geometry_0 Plot_n@node|LocalFlow@_sum_sis_geometry_0}

link_plots {Plot_n@node|LocalProcess@_out_sis_geometry_0 Plot_n@node|LocalFlow@_sis_geometry_0 Plot_n@node|LocalFlow@_sum_sis_geometry_0} \
	-special {move plot_prop axes_prop legend_prop grid_prop cuts field_sel field_prop matreg curve_prop}

select_plots Plot_n@node|LocalFlow@_sum_sis_geometry_0

set_material_prop {CVDSiOC Interface Copper Gas Nitride Oxide Silicon} -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 -hide_bulk
set_material_prop {CVDSiOC Interface Copper Gas Nitride Oxide Silicon} -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 -hide_field
set_material_prop {CVDSiOC Interface Copper Gas Nitride Oxide Silicon} -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 -hide_border

set_material_prop Copper -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 -show_bulk
set_material_prop Copper -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 -show_field
set_material_prop Copper -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 -show_border

set_plot_prop -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -hide_title
zoom_plot -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -reset

set_field_prop -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 MisesStress -show_bands

# Unlink the plots
# --------------------------------------------------------------

select_plots Plot_n@node|LocalProcess@_out_sis_geometry_0
link_plots Plot_n@node|LocalProcess@_out_sis_geometry_0 -unlink

select_plots Plot_n@node|LocalFlow@_sis_geometry_0
link_plots Plot_n@node|LocalFlow@_sis_geometry_0 -unlink

# Reset the contours
# --------------------------------------------------------------

select_plots Plot_n@node|LocalProcess@_out_sis_geometry_0
set_field_prop -plot Plot_n@node|LocalProcess@_out_sis_geometry_0 -geom n@node|LocalProcess@_out_sis_geometry_0 MisesStress -hide_bands
set_field_prop -plot Plot_n@node|LocalProcess@_out_sis_geometry_0 -geom n@node|LocalProcess@_out_sis_geometry_0 MisesStress -show_bands
set_field_prop -plot Plot_n@node|LocalProcess@_out_sis_geometry_0 -geom n@node|LocalProcess@_out_sis_geometry_0 MisesStress -range {0 4e8}
set_field_prop -plot Plot_n@node|LocalProcess@_out_sis_geometry_0 -geom n@node|LocalProcess@_out_sis_geometry_0 MisesStress -interpolated_values

select_plots Plot_n@node|LocalFlow@_sis_geometry_0
set_field_prop -plot Plot_n@node|LocalFlow@_sis_geometry_0 -geom n@node|LocalFlow@_sis_geometry_0 MisesStress -hide_bands
set_field_prop -plot Plot_n@node|LocalFlow@_sis_geometry_0 -geom n@node|LocalFlow@_sis_geometry_0 MisesStress -show_bands
set_field_prop -plot Plot_n@node|LocalFlow@_sis_geometry_0 -geom n@node|LocalFlow@_sis_geometry_0 MisesStress -range {0 4e8}
set_field_prop -plot Plot_n@node|LocalFlow@_sis_geometry_0 -geom n@node|LocalFlow@_sis_geometry_0 MisesStress -interpolated_values

select_plots Plot_n@node|LocalFlow@_sum_sis_geometry_0
set_field_prop -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 MisesStress -hide_bands
set_field_prop -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 MisesStress -show_bands
set_field_prop -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 MisesStress -range {0 8e8}
set_field_prop -plot Plot_n@node|LocalFlow@_sum_sis_geometry_0 -geom n@node|LocalFlow@_sum_sis_geometry_0 MisesStress -interpolated_values

# Save image 
# ------------------------------------------------------------

export_view n@node@_BEOL_VMS.bmp -format bmp -resolution 1200x800 -overwrite

# Exit SVisual
# ------------------------------------------------------------

exit


