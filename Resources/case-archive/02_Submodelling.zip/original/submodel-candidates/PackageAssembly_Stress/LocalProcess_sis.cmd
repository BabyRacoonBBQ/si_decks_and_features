# Metal line simulation for submodeling using SI F-2011.09
# --------------------------------------------------------

# Set the default output level
# --------------------------------------------------------

pdbSet InfoDefault 1

# Set coordinate system, simulation mode 
# --------------------------------------------------------

math coord.ucs

math ils

mode mechanics

# Set mechanics options
# --------------------------------------------------------

pdbSet Mechanics EtchDepoRelax 1
pdbSet Mechanics StressHistory 1

pdbSetDouble Mechanics RefThExpCoeff 0.0

pdbSetBoolean Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
pdbSet Mechanics Save.Step.Displacement 1

pdbSetBoolean Mechanics Calculate.Principal.Stress 1
pdbSetBoolean Mechanics SaveMaxStress 1

# Add Material properties
# --------------------------------------------------------

pdbSet Silicon Mechanics BulkModulus [Enu2K 162.0e10 0.28]
pdbSet Silicon Mechanics ShearModulus [Enu2G 162.0e10 0.28]
pdbSet Silicon Mechanics ThExpCoeff 3.05e-6
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
pdbSetBoolean Silicon Mechanics Anisotropic 1

pdbSet Copper Mechanics BulkModulus [Enu2K 111.5e10 0.343]
pdbSet Copper Mechanics ShearModulus [Enu2G 111.5e10 0.343]
pdbSet Copper Mechanics ThExpCoeff 17.7e-6

pdbSet Tungsten Mechanics BulkModulus [Enu2K 366.0e10 0.296]
pdbSet Tungsten Mechanics ShearModulus [Enu2G 366.0e10 0.296]
pdbSet Tungsten Mechanics ThExpCoeff 4.6e-6

pdbSet Nitride Mechanics BulkModulus [Enu2K 220.0e10 0.27]
pdbSet Nitride Mechanics ShearModulus [Enu2G 220.0e10 0.27]
pdbSet Nitride Mechanics ThExpCoeff 3.20e-6
pdbSet Nitride Mechanics Vcrit0 1e-30
pdbSet Nitride Mechanics VcritW 0.0
pdbSet Nitride Mechanics Viscosity0 1e40
pdbSet Nitride Mechanics ViscosityW 0.0

pdbSet Oxide Mechanics BulkModulus [Enu2K 59.0e10 0.24]
pdbSet Oxide Mechanics ShearModulus [Enu2G 59.0e10 0.24]
pdbSet Oxide Mechanics ThExpCoeff 1.0e-6
pdbSet Oxide Mechanics Vcrit0 1e-30
pdbSet Oxide Mechanics VcritW 0.0
pdbSet Oxide Mechanics Viscosity0 1e40
pdbSet Oxide Mechanics ViscosityW 0.0

mater add name= Nitride1 new.like= Nitride
pdbSetDouble Nitride1 Mechanics BulkModulus [Enu2K 220.0e10 0.27]
pdbSetDouble Nitride1 Mechanics ShearModulus [Enu2G 220.0e10 0.27]
pdbSetDouble Nitride1 Mechanics ThExpCoeff 3.20e-6
pdbSetDouble Nitride1 Mechanics Vcrit0 1e-30
pdbSetDouble Nitride1 Mechanics VcritW 0.0
pdbSetDouble Nitride1 Mechanics Viscosity0 1e40
pdbSetDouble Nitride1 Mechanics ViscosityW 0.0

mater add name= Oxide1 new.like= Oxide
pdbSetDouble Oxide1 Mechanics BulkModulus [Enu2K 59.0e10 0.24]
pdbSetDouble Oxide1 Mechanics ShearModulus [Enu2G 59.0e10 0.24]
pdbSetDouble Oxide1 Mechanics ThExpCoeff 1.0e-6
pdbSetDouble Oxide1 Mechanics Vcrit0 1e-30
pdbSetDouble Oxide1 Mechanics VcritW 0.0
pdbSetDouble Oxide1 Mechanics Viscosity0 1e40
pdbSetDouble Oxide1 Mechanics ViscosityW 0.0

mater add name= CVDSiOC new.like= Oxide
pdbSetDouble CVDSiOC   Mechanics BulkModulus  [Enu2K 9.5e10 0.3]
pdbSetDouble CVDSiOC   Mechanics ShearModulus [Enu2G 9.5e10 0.3]
pdbSetDouble CVDSiOC   Mechanics ThExpCoeff   20.0e-6
pdbSetDouble CVDSiOC   Mechanics Vcrit0 1e-30
pdbSetDouble CVDSiOC   Mechanics VcritW 0.0
pdbSetDouble CVDSiOC   Mechanics Viscosity0 1e40
pdbSetDouble CVDSiOC   Mechanics ViscosityW 0.0

# Set boundary conditions 
# --------------------------------------------------------

stressdata bc.location=Bottom bc.value= { dx=0 }
stressdata bc.location=Left bc.value= { dy=0 }
stressdata bc.location=Right bc.value= { dy=0 }
stressdata bc.location=Back bc.value= { dz=0 }
stressdata bc.location=Front bc.value= { dz=0 }

# Define the dimensions 
# ---------------------------------------------------------

set distance_1 @distance@
set half_distance_1 [expr ($distance_1/2.0)]

set height_1 75.0
set bump_d_1 [expr ((4.0*$height_1)/3.0)]
set bump_r_1 [expr ($bump_d_1/2.0)]

set half_pitch_1 [expr ($bump_r_1+$half_distance_1)]
set neg_half_pitch_1 [expr (-1.0*$half_pitch_1)]

set smear_t_1 5.0

set sub_t_1 1000.0

set sub_l_1 10000.0

set chip_t_1 775.0

set chip_l_1 5000.0

set sold_pad_t 2.0
set sold_msk_t 2.0
set underbump_met_t 2.0

set number_b 5

set trans_x [expr (0.0-($sub_t_1+$height_1+$smear_t_1+$sold_pad_t+$sold_msk_t+$underbump_met_t+10))]

set trans_y [expr ((($chip_l_1-(2.0*$half_pitch_1)))-((sqrt (7.0/36.0))*$height_1)-0.48)]

set trans_z [expr (-1.0*2.52)]

# Switch off SDE and Set SNMesh options
# --------------------------------------------------------

sde on logfile=n@node@_sde.log

pdbSetBoolean Grid No3DMerge 1
pdbSetBoolean Grid No3DSwap 1
pdbSetBoolean Grid Adaptive 0
pdbSet Mechanics Merge.Vertices 0

pdbSet Grid sMesh 1

pdbSet Grid SnMesh MaxPoints 5000000


# Define Mask 
# --------------------------------------------------------

polygon clear
mask clear
icwb filename= "SRAM6T_4_lyt.mac" scale=1e-3
icwb domain= "SIM3D"

icwb.create.mask layer.name= "active" name= active1 polarity=negative
icwb.create.mask layer.name= "poly" name= poly1 polarity=negative
icwb.create.mask layer.name= "contact" name= contact1 
icwb.create.mask layer.name= "m1" name= m1_2 polarity=negative
icwb.create.mask layer.name= "via1" name= via1_2 polarity=negative
icwb.create.mask layer.name= "m2" name= m2_2 polarity=negative
icwb.create.mask layer.name= "via2" name= via2_2 polarity=negative
icwb.create.mask layer.name= "m3" name= m3_2 polarity=negative 

# Define the structure
# --------------------------------------------------------

fset sim_top    0.0
fset sim_bottom 5.0
fset sim_left   0.0
fset sim_right  0.96
fset sim_back   0.0
fset sim_front  2.52
fset spac_y [expr ($sim_right-$sim_left)/4.0] 
fset spac_z [expr ($sim_front-$sim_back)/8.0] 

line x loc=$sim_top               tag=top
line x loc=0.02                   tag=tSi
line x loc=$sim_bottom            tag=bot
line y loc=$sim_left   tag=left   spac=$spac_y
line y loc=$sim_right  tag=right  spac=$spac_y
line z loc=$sim_back   tag=back  spac=$spac_z
line z loc=$sim_front  tag=front   spac=$spac_z

# Define the substrate, initialize the structure 
# and define the simulation mode
# --------------------------------------------------------

region Silicon  xlo=top xhi=bot ylo=left yhi=right zlo=back zhi=front substrate

init wafer.orient= { 0 0 1 } notch.direction= { 1 1 0 }

# Mesh refinement
# --------------------------------------------------------

pdbSet Grid MGoals accuracy 1.0e-3
pdbSet Grid MGoals resolution 0.3
pdbSet Grid SnMesh normal.growth.ratio.3d 2.0
    
refinebox name= Refine_Si materials= Silicon \
       xrefine= {0.1 0.5 0.1} yrefine= {0.1 0.5 0.1} zrefine= {0.1 0.5 0.1} \
       min.normal.size= 0.1 normal.growth.ratio= 2.0
       
refinebox name= Refine_Ox materials= Oxide \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

refinebox name= Refine_Nitride materials= Nitride \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

refinebox name= Refine_Lowk materials= CVDSiOC \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

refinebox name= Refine_Cu materials= Copper \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

grid FullD

# Process Steps
# --------------------------------------------------------

SetTemp 25.0

# Contact
# -------------------------------------------------------
             
deposit CVDSiOC temperature=400 type=fill coord=-0.17   

deposit Oxide temperature=400 type=fill coord=-0.22

etch type=cmp temperature=25 coord= -0.2

# M1 Layer
# -------------------------------------------------------
 
deposit CVDSiOC temperature=400 type=fill coord=-0.27

deposit Oxide temperature=400 type=fill coord=-0.32
    
etch material= "Oxide CVDSiOC Nitride" temperature=25 type=anisotropic thickness=0.12 mask=m1_2

deposit Copper temperature=200 type=fill coord=-0.32
   
etch temperature=25 type=cmp coord=-0.3

# M2 Layer
# -------------------------------------------------------

deposit Nitride temperature=400 type=fill coord=-0.33
     
deposit CVDSiOC temperature=400 type=fill coord=-0.47

deposit Oxide temperature=400 type=fill coord=-0.52  

etch material= "Oxide CVDSiOC Nitride" temperature=25 type=anisotropic thickness=0.22 mask=via1_2

etch material="Oxide CVDSiOC" temperature=25 thickness=0.14 type=anisotropic mask=m2_2 

deposit Copper temperature=200 type=fill coord=-0.52 

etch temperature=25 type=cmp coord= -0.50

# M3 Layer
# ------------------------------------------------------

deposit Nitride temperature=400 type=fill coord=-0.53

deposit CVDSiOC temperature=400 type=fill coord=-0.67

deposit Oxide temperature=400 type=fill coord=-0.72
    
etch material= "Oxide CVDSiOC Nitride" temperature=25 type=anisotropic thickness=0.22 mask=via2_2

etch material="Oxide CVDSiOC" temperature=25 thickness=0.14 type=anisotropic mask=m3_2
   
deposit Copper temperature=200 type=fill coord=-0.72  
   
etch temperature=25 type=cmp coord= -0.70 

# Passivation
# ------------------------------------------------------

deposit Nitride temperature=400 type=fill coord=-0.75 

deposit Oxide temperature=400 type=fill coord=-1.00 

# Simulate the mechanical stress
# --------------------------------------------------------

solve temperature= 25.0<C> time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_pretrans sat 

struct tdr.bnd=n@node@_pretrans_bnd

# Transform the structure
# --------------------------------------------------------

sde off

transform flip location= 5.0

transform translate= { $trans_x  $trans_y  $trans_z }

# Save the structure 
# --------------------------------------------------------

struct tdr=n@node@_out sat 

exit






