# Load the global geometries and create the global plots
# ------------------------------------------------------------

#setdep @node|RegionalFlow@

load_file n@node|GlobalFlow@_out_1_sis.tdr
create_plot -dataset n@node|GlobalFlow@_out_1_sis_geometry_0

load_file n@node|GlobalFlow@_out_2_sis.tdr
create_plot -dataset n@node|GlobalFlow@_out_2_sis_geometry_0

load_file n@node|GlobalFlow@_out_3_sis.tdr
create_plot -dataset n@node|GlobalFlow@_out_3_sis_geometry_0

load_file n@node|GlobalFlow@_out_4_sis.tdr
create_plot -dataset n@node|GlobalFlow@_out_4_sis_geometry_0

load_file n@node|GlobalFlow@_out_5_sis.tdr
create_plot -dataset n@node|GlobalFlow@_out_5_sis_geometry_0

# Load the regional geometries and create the regional plots
# ------------------------------------------------------------

load_file n@node|RegionalFlow@_1_sis.tdr
create_plot -dataset n@node|RegionalFlow@_1_sis_geometry_0

load_file n@node|RegionalFlow@_2_sis.tdr
create_plot -dataset n@node|RegionalFlow@_2_sis_geometry_0

load_file n@node|RegionalFlow@_3_sis.tdr
create_plot -dataset n@node|RegionalFlow@_3_sis_geometry_0

load_file n@node|RegionalFlow@_4_sis.tdr
create_plot -dataset n@node|RegionalFlow@_4_sis_geometry_0

load_file n@node|RegionalFlow@_5_sis.tdr
create_plot -dataset n@node|RegionalFlow@_5_sis_geometry_0

# Manipulate the images after linking all the images
# ------------------------------------------------------------

windows_style -sort {Plot_n@node|GlobalFlow@_out_1_sis_geometry_0 Plot_n@node|GlobalFlow@_out_2_sis_geometry_0 \
	Plot_n@node|GlobalFlow@_out_3_sis_geometry_0 Plot_n@node|GlobalFlow@_out_4_sis_geometry_0 Plot_n@node|GlobalFlow@_out_5_sis_geometry_0 \
	Plot_n@node|RegionalFlow@_1_sis_geometry_0 Plot_n@node|RegionalFlow@_2_sis_geometry_0 Plot_n@node|RegionalFlow@_3_sis_geometry_0 \
	Plot_n@node|RegionalFlow@_4_sis_geometry_0 Plot_n@node|RegionalFlow@_5_sis_geometry_0} \
	-style custom -direction right_down -max 5 -aspect_ratio_on

select_plots {Plot_n@node|GlobalFlow@_out_1_sis_geometry_0 Plot_n@node|GlobalFlow@_out_2_sis_geometry_0 \
	Plot_n@node|GlobalFlow@_out_3_sis_geometry_0 Plot_n@node|GlobalFlow@_out_4_sis_geometry_0 Plot_n@node|GlobalFlow@_out_5_sis_geometry_0 \
	Plot_n@node|RegionalFlow@_1_sis_geometry_0 Plot_n@node|RegionalFlow@_2_sis_geometry_0 Plot_n@node|RegionalFlow@_3_sis_geometry_0 \
	Plot_n@node|RegionalFlow@_4_sis_geometry_0 Plot_n@node|RegionalFlow@_5_sis_geometry_0}

link_plots {Plot_n@node|GlobalFlow@_out_1_sis_geometry_0 Plot_n@node|GlobalFlow@_out_2_sis_geometry_0 \
	Plot_n@node|GlobalFlow@_out_3_sis_geometry_0 Plot_n@node|GlobalFlow@_out_4_sis_geometry_0 Plot_n@node|GlobalFlow@_out_5_sis_geometry_0 \
	Plot_n@node|RegionalFlow@_1_sis_geometry_0 Plot_n@node|RegionalFlow@_2_sis_geometry_0 Plot_n@node|RegionalFlow@_3_sis_geometry_0 \
	Plot_n@node|RegionalFlow@_4_sis_geometry_0 Plot_n@node|RegionalFlow@_5_sis_geometry_0} \
	-special {move plot_prop axes_prop legend_prop grid_prop cuts field_sel field_prop matreg curve_prop}

select_plots Plot_n@node|RegionalFlow@_5_sis_geometry_0

zoom_plot -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -reset

set_material_prop Interface -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -geom n@node|RegionalFlow@_5_sis_geometry_0 -hide_bulk
set_material_prop Interface -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -geom n@node|RegionalFlow@_5_sis_geometry_0 -hide_field
set_material_prop Interface -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -geom n@node|RegionalFlow@_5_sis_geometry_0 -hide_border

set_plot_prop -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -hide_title
set_plot_prop -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -hide_axes

# Plot Von Mises' Effective stress
# ------------------------------------------------------------

set_field_prop -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -geom n@node|RegionalFlow@_5_sis_geometry_0 MisesStress -show_bands

set_field_prop -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -geom n@node|RegionalFlow@_5_sis_geometry_0 MisesStress -range {0 6e8}

set_field_prop -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -geom n@node|RegionalFlow@_5_sis_geometry_0 MisesStress -interpolated_values

set_plot_prop -plot Plot_n@node|RegionalFlow@_5_sis_geometry_0 -hide_legend

# Unlink the regional model plots
# ------------------------------------------------------------

select_plots Plot_n@node|RegionalFlow@_5_sis_geometry_0
link_plots Plot_n@node|RegionalFlow@_5_sis_geometry_0 -unlink

select_plots Plot_n@node|RegionalFlow@_4_sis_geometry_0
link_plots Plot_n@node|RegionalFlow@_4_sis_geometry_0 -unlink

select_plots Plot_n@node|RegionalFlow@_3_sis_geometry_0
link_plots Plot_n@node|RegionalFlow@_3_sis_geometry_0 -unlink

select_plots Plot_n@node|RegionalFlow@_2_sis_geometry_0
link_plots Plot_n@node|RegionalFlow@_2_sis_geometry_0 -unlink

select_plots Plot_n@node|RegionalFlow@_1_sis_geometry_0
link_plots Plot_n@node|RegionalFlow@_1_sis_geometry_0 -unlink

# Readjust the global view (The global plots are still linked)
# ------------------------------------------------------------

select_plots Plot_n@node|GlobalFlow@_out_5_sis_geometry_0

zoom_plot -plot Plot_n@node|GlobalFlow@_out_5_sis_geometry_0 -reset
zoom_plot -plot Plot_n@node|GlobalFlow@_out_5_sis_geometry_0 -window {60 145 75 135}

# Show legend on the global plot
# ------------------------------------------------------------

select_plots Plot_n@node|GlobalFlow@_out_1_sis_geometry_0
link_plots Plot_n@node|GlobalFlow@_out_1_sis_geometry_0 -unlink

set_plot_prop -plot Plot_n@node|GlobalFlow@_out_1_sis_geometry_0 -show_legend

# Show axes on the global plot
# ------------------------------------------------------------

select_plots Plot_n@node|RegionalFlow@_1_sis_geometry_0

set_plot_prop -plot Plot_n@node|RegionalFlow@_1_sis_geometry_0 -show_axes

# Save image 
# ------------------------------------------------------------

export_view n@node@_Flow_VMS.bmp -format bmp -resolution 1200x800 -overwrite

# Exit SVisual
# ------------------------------------------------------------

exit


