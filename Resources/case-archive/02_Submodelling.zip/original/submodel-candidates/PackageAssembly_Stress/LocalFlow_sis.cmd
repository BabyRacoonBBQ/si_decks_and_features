# Package + BEOL Submodeling analysis using SI J-2014.09-DEV
# --------------------------------------------------------

# Set the default output level
# --------------------------------------------------------

pdbSet InfoDefault 1

# Create the BEOL geometry using Sentaurus Structure Editor
# Remove the BackSide Material and Gas
# --------------------------------------------------------

sde external {

; This file removes the backside material from the flipped BEOL structure
; -------------------------------------------

(sde:clear)

(sde:set-process-up-direction "-x")
(sde:setrefprops 0.1 5.0)

(define distance @distance@)
(define half_distance (/ distance 2.0))

(define height 75.0)
(define bump_d (/ (* 4.0 height) 3.0))
(define bump_r (/ bump_d 2.0))

(define half_pitch (+ bump_r half_distance))

(define smear_t 5.0)

(define sub_t 1000.0)

(define sub_l 10000.0)

(define chip_t 775.0)

(define chip_l 5000.0)

(define sm_t 2.0)

(define pad_t 2.0)

(define ubm_t 2.0)

(define trans_x (* -1.0 (+ sub_t height smear_t pad_t sm_t ubm_t 10.0)))

(define trans_y (- (- (- chip_l (* 2.0 half_pitch)) (* (sqrt (/ 7.0 36.0)) height)) 0.48))

(define trans_z (* -1.0 2.52)) 

(sde:open-model "n@previous@_pretrans_sde.sat")

(sdegeo:delete-region (find-material-id "BackMat"))

(sdegeo:delete-region (find-material-id "Gas"))

(sdegeo:rotate-selected (get-body-list) (transform:rotation (position 5.0 0.48 1.26) (gvector 0 1 0) 180)  #f 0)

(sdegeo:create-cuboid (position 4.9 0.00 0.00) (position 5.0 0.96 2.52) "Gas" "NewGas")

(sdegeo:translate (get-body-list) trans_x trans_y trans_z)

(sde:save-model "n@node@_lines")

}

sde off

# SDE section ends at the above line
# --------------------------------------------------------
# Set SWB Variables
# --------------------------------------------------------

set EUnderfill @EUF@
set LCTEUnderfill @LCTEUF@
set EBump @EBUMP@
set LCTEBump @LCTEBUMP@

# Define the coordinate system
# and define the simulation mode
# --------------------------------------------------------

math coord.ucs

math ils

mode mechanics

# Set the mechanics options
# --------------------------------------------------------

pdbSet Mechanics EtchDepoRelax 0
pdbSet Mechanics StressHistory 0

pdbSetDouble Mechanics RefThExpCoeff 0.0

pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 0
pdbSet Mechanics Save.Step.Displacement 1

pdbSet Mechanics Calculate.Principal.Stress 1
pdbSet Mechanics SaveMaxStress 1

pdbSet Mechanics Submodel.Add.Global.Stress 0

pdbSetBoolean Mechanics Shape.Function.LinTriTet.Distance 1

# Set SNMesh options
# --------------------------------------------------------

pdbSetBoolean Grid No3DMerge 1
pdbSetBoolean Grid No3DSwap 1
pdbSetBoolean Grid Adaptive 0
pdbSet Mechanics Merge.Vertices 0

pdbSet Grid sMesh 1

pdbSet Grid SnMesh MaxPoints 5000000

# Add the Material Properties
# --------------------------------------------------------

pdbSet Silicon Mechanics BulkModulus [Enu2K 162.0e10 0.28]
pdbSet Silicon Mechanics ShearModulus [Enu2G 162.0e10 0.28]
pdbSet Silicon Mechanics ThExpCoeff 3.05e-6
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
pdbSetBoolean Silicon Mechanics Anisotropic 1

pdbSet Nitride Mechanics BulkModulus [Enu2K 220.0e10 0.27]
pdbSet Nitride Mechanics ShearModulus [Enu2G 220.0e10 0.27]
pdbSet Nitride Mechanics ThExpCoeff 3.20e-6
pdbSet Nitride Mechanics Vcrit0 1e-30
pdbSet Nitride Mechanics VcritW 0.0
pdbSet Nitride Mechanics Viscosity0 1e40
pdbSet Nitride Mechanics ViscosityW 0.0

pdbSet Oxide Mechanics BulkModulus [Enu2K 71.7e10 0.16]
pdbSet Oxide Mechanics ShearModulus [Enu2G 71.7e10 0.16]
pdbSet Oxide Mechanics ThExpCoeff 0.51e-6
pdbSet Oxide Mechanics Vcrit0 1e-30
pdbSet Oxide Mechanics VcritW 0.0
pdbSet Oxide Mechanics Viscosity0 1e40
pdbSet Oxide Mechanics ViscosityW 0.0

mater add name= CVDSiOC new.like= Oxide
pdbSetDouble CVDSiOC   Mechanics BulkModulus  [Enu2K 9.5e10 0.3]
pdbSetDouble CVDSiOC   Mechanics ShearModulus [Enu2G 9.5e10 0.3]
pdbSetDouble CVDSiOC   Mechanics ThExpCoeff   20.0e-6
pdbSetDouble CVDSiOC   Mechanics Vcrit0 1e-30
pdbSetDouble CVDSiOC   Mechanics VcritW 0.0
pdbSetDouble CVDSiOC   Mechanics Viscosity0 1e40
pdbSetDouble CVDSiOC   Mechanics ViscosityW 0.0

pdbSet Copper Mechanics BulkModulus [Enu2K 111.5e10 0.343]
pdbSet Copper Mechanics ShearModulus [Enu2G 111.5e10 0.343]
pdbSet Copper Mechanics ThExpCoeff 17.7e-6	

# ---------------------------------------------------------------------

mater add name= Smear new.like= Nitride
pdbSetDouble Smear   Mechanics BulkModulus  [Enu2K 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ShearModulus [Enu2G 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ThExpCoeff   15.3e-6
pdbSetDouble Smear   Mechanics Vcrit0 1e-30
pdbSetDouble Smear   Mechanics VcritW 0.0
pdbSetDouble Smear   Mechanics Viscosity0 1e40
pdbSetDouble Smear   Mechanics ViscosityW 0.0

# ---------------------------------------------------------------------

mater add name= BumpMat new.like= Copper
pdbSetDouble BumpMat Mechanics BulkModulus [Enu2K $EBump 0.40]
pdbSetDouble BumpMat Mechanics ShearModulus [Enu2G $EBump 0.40]
pdbSetDouble BumpMat Mechanics ThExpCoeff $LCTEBump

# ---------------------------------------------------------------------

mater add name= Epoxy new.like= Oxide
pdbSetDouble Epoxy   Mechanics BulkModulus  [Enu2K $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ShearModulus [Enu2G $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ThExpCoeff   $LCTEUnderfill
	
pdbSetDouble Epoxy   Mechanics Vcrit0 1e-30	   
pdbSetDouble Epoxy   Mechanics VcritW 0.0	  
pdbSetDouble Epoxy   Mechanics Viscosity0 1e40  
pdbSetDouble Epoxy   Mechanics ViscosityW 0.0	
		
# ---------------------------------------------------------------------

mater add name= SubMat new.like= Nitride
pdbSetDouble SubMat   Mechanics BulkModulus  [Enu2K 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ShearModulus [Enu2G 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ThExpCoeff   15.7e-6
pdbSetDouble SubMat   Mechanics Vcrit0 1e-30
pdbSetDouble SubMat   Mechanics VcritW 0.0
pdbSetDouble SubMat   Mechanics Viscosity0 1e40
pdbSetDouble SubMat   Mechanics ViscosityW 0.0

# Define the dimensions 
# ---------------------------------------------------------

set distance_1 @distance@
set half_distance_1 [expr ($distance_1/2.0)]

set height_1 75.0
set bump_d_1 [expr ((4.0*$height_1)/3.0)]
set bump_r_1 [expr ($bump_d_1/2.0)]

set half_pitch_1 [expr ($bump_r_1+$half_distance_1)]
set neg_half_pitch_1 [expr (-1.0*$half_pitch_1)]

set smear_t_1 5.0

set sub_t_1 1000.0

set sub_l_1 10000.0

set chip_t_1 775.0

set chip_l_1 5000.0

set sold_pad_t 2.0
set sold_msk_t 2.0
set underbump_met_t 2.0

set number_b 5

set trans_x [expr (0.0-($sub_t_1+$height_1+$smear_t_1+$sold_pad_t+$sold_msk_t+$underbump_met_t+10))]

set trans_y [expr ((($chip_l_1-(2.0*$half_pitch_1)))-((sqrt (7.0/36.0))*$height_1)-0.48)]

set trans_z [expr (-1.0*2.52)]

# Smeared material property for underfill and bumps
# ----------------------------------------------------------------

set pi1 [expr (4.0*atan(1.0))]

set radius_1 $bump_r_1

set radius_2 [expr ($height_1*(sqrt(7.0/36.0)))]

set height_2 [expr (0.5*$height_1)]

set pitch_1 [expr (2.0*$half_pitch_1)]

set volume [expr ($pitch_1*$pitch_1*$height_1)]

set vol_bump [expr ((($pi1*$height_2)/3.0)*((3.0*$radius_1*$radius_1)+(3.0*$radius_2*$radius_2)+($height_2*$height_2)))]

set frac_bump [expr ($vol_bump/$volume)]

set frac_uf [expr (1.0-$frac_bump)]

set frac_uf1 [expr (($volume-$vol_bump)/$volume)]

set EUFSmear [expr (($EBump*$frac_bump)+($EUnderfill*$frac_uf))]

set NUUFSmear [expr ((0.40*$frac_bump)+(0.35*$frac_uf))]

set CTEUFSmear [expr (($LCTEBump*$frac_bump)+($LCTEUnderfill*$frac_uf))]

mater add name= UFSmear new.like= Oxide
pdbSetDouble UFSmear   Mechanics BulkModulus  [Enu2K $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ShearModulus [Enu2G $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ThExpCoeff   $CTEUFSmear
	
pdbSetDouble UFSmear   Mechanics Vcrit0 1e-30	   
pdbSetDouble UFSmear   Mechanics VcritW 0.0	  
pdbSetDouble UFSmear   Mechanics Viscosity0 1e40  
pdbSetDouble UFSmear   Mechanics ViscosityW 0.0

# Switch on SDE
# --------------------------------------------------------

sde on logfile=n@node@_sde.log remesh

# Import the structure 
# --------------------------------------------------------

init tdr=n@node@_lines_bnd.tdr

# Define the submodel domain and global model
# --------------------------------------------------------

refinebox clear

refinebox name= Refine_Si materials= Silicon \
       xrefine= {0.1 0.5 0.1} yrefine= {0.1 0.5 0.1} zrefine= {0.1 0.5 0.1} \
       min.normal.size= 0.1 normal.growth.ratio= 2.0

refinebox name= Refine_Ox materials= Oxide \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

refinebox name= Refine_Nitride materials= Nitride \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

refinebox name= Refine_Lowk materials= CVDSiOC \
       xrefine= {0.01 0.05 0.01} yrefine= {0.01 0.05 0.01} zrefine= {0.01 0.05 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

refinebox name= Refine_Cu materials= Copper \
       xrefine= {0.01 0.025 0.01} yrefine= {0.01 0.025 0.01} zrefine= {0.01 0.025 0.01} \
       min.normal.size= 0.01 normal.growth.ratio= 2.0

grid remesh

SetTemp 25.0

struct tdr=n@node@_0

# Ramp Up to Bump Formation
# --------------------------------------------------------

stressdata global.model=n@previous|-1@_1_sis.tdr

SetTemp 25.0

solve stress.relax temperature=25.0<C> t.final=200.0<C> delT= 175.0 \
 	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>
 	
struct tdr=n@node@_1

# Bumps
# --------------------------------------------------------

init tdr=n@node@_lines_bnd.tdr

load tdr=n@node@_1_sis.tdr sum

stressdata global.model=n@previous|-1@_2_sis.tdr

SetTemp 200.0

solve stress.relax temperature=200.0<C> t.final=25.0<C> delNT= 175.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_2

# Substrate 
# --------------------------------------------------------

init tdr=n@node@_lines_bnd.tdr

load tdr=n@node@_2_sis.tdr sum

stressdata global.model=n@previous|-1@_3_sis.tdr

SetTemp 25.0

solve stress.relax temperature=25.0<C> t.final=25.0<C> delNT= 0.0 \
 	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_3

# Underfill ramp up 
# --------------------------------------------------------

init tdr=n@node@_lines_bnd.tdr

load tdr=n@node@_3_sis.tdr sum

stressdata global.model=n@previous|-1@_4_sis.tdr

SetTemp 25.0

solve stress.relax temperature=25.0<C> t.final=180.0<C> delT= 155.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_4


# Underfill
# --------------------------------------------------------

init tdr=n@node@_lines_bnd.tdr

load tdr=n@node@_4_sis.tdr sum

stressdata global.model=n@previous|-1@_5_sis.tdr

SetTemp 180.0

solve stress.relax temperature=180.0<C> t.final=25.0<C> delNT= 155.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_5

# Add the process stress, save the structures and exit
# --------------------------------------------------------
	
struct tdr=n@node@

load tdr=n@previous@_out_sis.tdr sum

struct tdr=n@node@_sum

exit








