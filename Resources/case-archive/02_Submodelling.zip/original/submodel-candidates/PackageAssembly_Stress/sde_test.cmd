;;
;; (journal:on "/remote/tcad17/adityap/STDB/Package_Sub/Package_Sub57/sde_test.cmd")
;; "/remote/tcad17/adityap/STDB/Package_Sub/Package_ ...
(sde:clear)
;; #t
(sde:open-model "/remote/tcad17/adityap/STDB/Package_Sub/Package_Sub57/n6_5_global_bnd.tdr")
;; ()
;; (journal:off)
