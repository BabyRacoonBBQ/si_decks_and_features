"""Compare vendor and local Release submodel TDR datasets on the VM."""
from pathlib import Path
import hashlib, json, h5py, numpy as np

V = Path('/home/mozztcad/tmp/flipchip-array-20261010')
L = Path('/home/mozztcad/tmp/flipchip-array-local-20261011')

def fields(path):
    with h5py.File(path, 'r') as f:
        g = f['collection/geometry_0']
        out = {'geometry': {}, 'fields': {}}
        for name in ('vertex',):
            out['geometry'][name] = g[name][:]
        for name, obj in g.items():
            if not name.startswith('region_') or 'elements_0' not in obj:
                continue
            out['geometry'][name] = obj['elements_0'][:]
        for obj in g['state_0'].values():
            if 'values' not in obj or 'region' not in obj.attrs or 'name' not in obj.attrs:
                continue
            key = (int(obj.attrs['region']), obj.attrs['name'].decode() if isinstance(obj.attrs['name'], bytes) else str(obj.attrs['name']))
            out['fields'][key] = obj['values'][:]
        return out

def cmp(a, b):
    rows=[]
    for group in ('geometry','fields'):
        for key in sorted(set(a[group]) | set(b[group]), key=str):
            if key not in a[group] or key not in b[group]:
                rows.append({'group':group,'key':str(key),'status':'missing'}); continue
            av,bv=np.asarray(a[group][key]),np.asarray(b[group][key])
            if av.shape != bv.shape:
                rows.append({'group':group,'key':str(key),'status':'shape','vendor_shape':list(av.shape),'local_shape':list(bv.shape)}); continue
            if np.issubdtype(av.dtype, np.number):
                d=np.abs(av.astype(np.float64)-bv.astype(np.float64)); scale=max(float(np.max(np.abs(av))),1e-300)
                rows.append({'group':group,'key':str(key),'status':'exact' if np.array_equal(av,bv) else 'numeric','max_abs':float(np.max(d)),'relative_to_vendor_max':float(np.max(d)/scale)})
            else:
                rows.append({'group':group,'key':str(key),'status':'exact' if np.array_equal(av,bv) else 'different'})
    return rows

report={'binary_sha256':(Path('/home/mozztcad/geo3d/build/sinterconnect_run').read_bytes()).hex() if False else None,'pairs':{}}
for label, vf, lf in [('global','global_sis.tdr','global_sis.tdr'),('unit-fine','unit-fine_sis.tdr','unit-fine_sis.tdr')]:
    a=fields(V/vf); b=fields(L/lf); rows=cmp(a,b)
    report['pairs'][label]={'vendor':str(V/vf),'local':str(L/lf),'vendor_sha256':hashlib.sha256((V/vf).read_bytes()).hexdigest(),'local_sha256':hashlib.sha256((L/lf).read_bytes()).hexdigest(),'rows':rows}
    numeric=[r for r in rows if r['status'] in ('numeric','different','shape','missing')]
    report['pairs'][label]['summary']={'rows':len(rows),'non_exact':len(numeric),'max_abs':max([r.get('max_abs',0) for r in rows],default=0),'max_relative':max([r.get('relative_to_vendor_max',0) for r in rows],default=0)}
Path(L/'compare-local.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v['summary'] for k,v in report['pairs'].items()},indent=2))
