#!/bin/bash
set -eu
export PYTHONNOUSERSITE=1
display_file=$(mktemp)
Xvfb -displayfd 3 -screen 0 1280x900x24 -nolisten tcp 3>"$display_file" >/tmp/flipchip-array-xvfb.log 2>&1 &
xvfb_pid=$!
trap 'kill "$xvfb_pid" 2>/dev/null || true; rm -f "$display_file"' EXIT
for attempt in {1..30}; do [ -s "$display_file" ] && break; sleep .1; done
export DISPLAY=:$(cat "$display_file")
python3 /home/mozztcad/tmp/flipchip-array-20261010/render.py
