from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/flipchip-array-20261010');a=r/'quadratic-global-attempt';a.mkdir(exist_ok=True)
for n in ['global.cmd','global.stdout.log','global.stderr.log']:shutil.copy2(r/n,a/n)
p=r/'global.cmd';s=p.read_text().replace('pdbSet Mechanics FiniteElementOrder 2','pdbSet Mechanics FiniteElementOrder 1');p.write_text(s)
s=s.replace('20.0 20.0 20.0','15.0 15.0 15.0').replace('30.0 30.0 30.0','20.0 20.0 20.0').replace('struct tdr=global','struct tdr=global-refined')
(r/'global-refined.cmd').write_text(s)
print('First-order global; second-order local retained; extra refined global input saved')
