import json, pathlib
p=pathlib.Path('architecture-overview/StressThermal/flipchip-array-verification/local-release/compare-local.json')
d=json.loads(p.read_text())
out={'binary_sha256':pathlib.Path('architecture-overview/StressThermal/flipchip-array-verification/local-release/binary.sha256').read_text().strip().split()[0] if pathlib.Path('architecture-overview/StressThermal/flipchip-array-verification/local-release/binary.sha256').exists() else None,'pairs':{}}
for name,pair in d['pairs'].items():
    rows=pair['rows']
    def get(group, names):
        xs=[r for r in rows if r['group']==group and any(n in r['key'] for n in names)]
        return xs
    geom=[r for r in rows if r['group']=='geometry']
    fields=[r for r in rows if r['group']=='fields']
    def summarize(names):
        xs=[r for r in fields if any(n in r['key'] for n in names)]
        if not xs:return None
        return {'count':len(xs),'exact':sum(r['status']=='exact' for r in xs),'max_abs':max(r.get('max_abs',0) for r in xs),'max_relative':max(r.get('relative_to_vendor_max',0) for r in xs)}
    out['pairs'][name]={
      'vendor_sha256':pair.get('vendor_sha256'),'local_sha256':pair.get('local_sha256'),
      'rows':pair['summary']['rows'],'non_exact':pair['summary']['non_exact'],
      'geometry':{'rows':len(geom),'non_exact':sum(r['status']!='exact' for r in geom)},
      'temperature':summarize(['Temperature']),
      'displacement':summarize(['StepDisplacement']),
      'stress':summarize(['MisesStress','Pressure','PrincipalStress','Stress']),
      'elastic_strain':summarize(['ElasticStrain']),
      'elastic_energy':summarize(['ElasticEnergyDens'])
    }
pathlib.Path('architecture-overview/StressThermal/flipchip-array-verification/local-release/compare-summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
