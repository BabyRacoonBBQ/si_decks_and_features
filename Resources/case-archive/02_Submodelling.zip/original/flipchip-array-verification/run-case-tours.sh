#!/bin/bash
set -eu
export PYTHONNOUSERSITE=1
display_file=$(mktemp)
Xvfb -displayfd 3 -screen 0 1000x680x24 -nolisten tcp 3>"$display_file" >/tmp/case-tours-xvfb.log 2>&1 &
xvfb_pid=$!
trap 'kill "$xvfb_pid" 2>/dev/null || true; rm -f "$display_file"' EXIT
for attempt in {1..30}; do [ -s "$display_file" ] && break; sleep .1; done
export DISPLAY=:$(cat "$display_file")
if [ "${1:-all}" = all ]; then python3 /home/mozztcad/tmp/flipchip-array-20261010/render-case-tours.py package; fi
python3 /home/mozztcad/tmp/flipchip-array-20261010/render-case-tours.py flipchip
