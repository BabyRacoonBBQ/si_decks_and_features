# Local Release flip-chip replay

The figures in `../figures-local` and TDRs in this directory were produced on the VM from `/home/mozztcad/geo3d/build/sinterconnect_run`, SHA-256 `a97a41e59aa4a5533fdc0645a5b11c837580fe11a9d12d5665adced18d931ea5`. The vendor comparison uses the archived vendor TDRs only as a reference; no vendor binary was used to generate these local figures.

`compare-summary.json` is the compact audit. Geometry, temperature, displacement, stress, elastic strain, and elastic energy are exact for the global replay. Geometry and temperature are exact for the unit-fine replay; displacement, stress, elastic strain, and elastic energy differ only at machine precision (maximum relative differences below `1e-11`). The raw TDR bytes differ only in structured run metadata; no field or topology difference remains.

The local renderer uses the bundled Sentaurus Python/VTK runtime with Xvfb. `array-compact.png` and `unit-fine-compact.png` are local stress renders; `pillar-location.gif` is a local camera tour of the local global TDR.
