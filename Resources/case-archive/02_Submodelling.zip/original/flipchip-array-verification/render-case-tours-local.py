"""Presentation camera tours of existing, unmodified vendor TDR meshes."""
from pathlib import Path
import sys, math, json, hashlib
import numpy as np
import vtk, h5py
from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray, vtk_to_numpy
from PIL import Image, ImageSequence

ROOT=Path('/home/mozztcad/tmp/flipchip-array-local-20261011')
OUT=ROOT/'figures-local'
W,H=1000,680
def smooth(t):return (1-math.cos(math.pi*t))/2
def capture(win):
    win.Render(); shot=vtk.vtkWindowToImageFilter();shot.SetInput(win);shot.ReadFrontBufferOff();shot.Update()
    raw=vtk_to_numpy(shot.GetOutput().GetPointData().GetScalars()).reshape(H,W,3)
    return Image.fromarray(np.flipud(raw).copy())
def save(frames,durations,path):
    quant=[im.quantize(colors=256,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE) for im in frames]
    quant[0].save(path,save_all=True,append_images=quant[1:],duration=durations,loop=0,optimize=False,disposal=2)

def package():
    base=Path('/home/mozztcad/tmp/package-benchmark-20261010/demo-thermal-vendor')
    scope={'__file__':str(base/'render-package-exploded.py')}
    exec((base/'render-package-exploded.py').read_text().split("frame(0).save")[0],scope)
    camera,ren,win= [scope[k] for k in ('camera','ren','win')]
    frame=scope['frame'];aim=scope['aim'];span=scope['span']
    source=Image.open(ROOT/'package-original.gif')
    frames=[im.convert('RGB').copy() for im in ImageSequence.Iterator(source)]
    durations=[]
    for i in range(source.n_frames):source.seek(i);durations.append(source.info.get('duration',100))
    prefix=len(frames)
    # Existing frames and timing form an unchanged prefix. Append another expansion and tour.
    for i in range(20):frames.append(frame(smooth(i/19)));durations.append(100)
    scope['caption'].SetVisibility(False)
    for actor,_,_ in scope['labels']:actor.SetVisibility(False)
    label=scope['add_text']('',500,600,76,bold=False)
    label.GetTextProperty().SetJustificationToCentered()
    # Regular Arial matches the slide labels; use a compact caption margin.
    overlay=scope['overlay'];ren.SetViewport(0,.12,1,1)
    anchors={mat:anchor for _,anchor,mat in scope['labels']}
    previous=aim.copy();previous_scale=span*.82
    original_properties=[]
    for actor in scope['actors']:
        prop=vtk.vtkProperty();prop.DeepCopy(actor.GetProperty());original_properties.append(prop)
    stages=[('Copperline','Cu wires'),('Aluminum','Aluminum'),('SmearBeol','BEOL'),('Silicon','Silicon die'),('Solder','Solder'),('Copper','Cu frame')]
    for n,(mat,title) in enumerate(stages):
        target=anchors[mat].copy();scale=span*.27
        label.SetInput(title)
        label.GetTextProperty().SetColor(.68,.32,.03)
        for actor,region in zip(scope['actors'],scope['regions']):
            prop=actor.GetProperty();selected=region['material']==mat
            prop.SetColor(*((1.,.60,.12) if selected else (.80,.83,.85)))
            prop.SetOpacity(1. if selected else .18)
            prop.SetAmbient(.65 if selected else .85)
        for i in range(22):
            t=smooth(min(i/11,1));focus=previous*(1-t)+target*t
            theta=math.radians(35+3*n+3*t);elev=math.radians(25)
            direction=np.array([math.cos(theta)*math.cos(elev),math.sin(theta)*math.cos(elev),math.sin(elev)])
            camera.SetFocalPoint(*focus);camera.SetPosition(*(focus+span*5*direction));camera.SetParallelScale(previous_scale*(1-t)+scale*t)
            ren.ResetCameraClippingRange();frames.append(capture(win));durations.append(120 if i<12 else 220)
        frames[-1].save(OUT/('package-tour-'+mat+'.png'))
        previous,previous_scale=target,scale
    label.SetInput('')
    for actor,prop in zip(scope['actors'],original_properties):actor.GetProperty().DeepCopy(prop)
    for i in range(16):
        t=smooth(i/15);focus=previous*(1-t)+aim*t;theta=math.radians(53-18*t);elev=math.radians(25-2*t)
        direction=np.array([math.cos(theta)*math.cos(elev),math.sin(theta)*math.cos(elev),math.sin(elev)])
        camera.SetFocalPoint(*focus);camera.SetPosition(*(focus+span*5*direction));camera.SetParallelScale(previous_scale*(1-t)+span*.82*t)
        ren.ResetCameraClippingRange();frames.append(capture(win));durations.append(100)
    ren.SetViewport(0,0,1,1)
    for i in range(20):frames.append(frame(1-smooth(i/19)));durations.append(100)
    save(frames,durations,OUT/'package-tour.gif')
    # Pixel-exact preservation of each original decoded frame (palette round-trip is lossless).
    check=Image.open(OUT/'package-tour.gif')
    for i in range(prefix):
        check.seek(i);source.seek(i)
        assert np.array_equal(np.array(check.convert('RGB')),np.array(source.convert('RGB')))
        assert check.info['duration']==source.info['duration']
    (OUT/'package-tour-audit.json').write_text(json.dumps({'preserved_original_frames':prefix,'original_sha256':hashlib.sha256((ROOT/'package-original.gif').read_bytes()).hexdigest(),'prefix_pixels_and_timing_verified':True,'tour':'Original TDR; camera pan/zoom only after repeated expansion; no new geometry.'},indent=2))
    win.Finalize();print('Package tour complete',flush=True)

def flipchip():
    ren=vtk.vtkRenderer();ren.SetBackground(1,1,1);ren.SetViewport(0,.12,1,1)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(W,H);win.SetNumberOfLayers(3)
    back=vtk.vtkRenderer();back.SetBackground(1,1,1);win.AddRenderer(back);ren.SetLayer(1);win.AddRenderer(ren)
    overlay=vtk.vtkRenderer();overlay.SetLayer(2);overlay.InteractiveOff();win.AddRenderer(overlay)
    label=vtk.vtkTextActor();label.SetPosition(500,4);p=label.GetTextProperty();p.SetFontFamilyToArial();p.SetFontSize(76);p.SetBold(False);p.SetJustificationToCentered();p.SetColor(.09,.18,.26);overlay.AddActor2D(label)
    source=ROOT/'global_sis.tdr';actors=[];allpoints=[]
    colors={'Silicon':(.37,.52,.62),'SubMat':(.55,.67,.68),'Smear':(.43,.45,.63),'Pass':(.65,.72,.78),'Epoxy':(.76,.82,.82),'UFSmear':(.68,.77,.73),'BumpMat':(.82,.52,.20)}
    offsets={'Silicon':(0,0,2100),'Smear':(0,0,1550),'Pass':(0,0,1200),'Epoxy':(-4500,0,900),'UFSmear':(-3800,0,300),'SubMat':(0,0,-650),'BumpMat':(0,0,0)}
    with h5py.File(source) as f:
        g=f['collection/geometry_0'];v=g['vertex'][:];pts=np.column_stack([v['y'],v['z'],-v['x']])*1e4
        vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(pts,deep=True))
        for key,r in g.items():
            if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0:continue
            mat=r.attrs['material'];mat=mat.decode() if isinstance(mat,bytes) else str(mat)
            if mat=='Gas':continue
            e=r['elements_0'][:].reshape(-1,5).astype(np.int64);assert np.all(e[:,0]==5);e[:,0]=4
            ca=vtk.vtkCellArray();ca.SetCells(len(e),numpy_to_vtkIdTypeArray(e.ravel(),deep=True))
            grid=vtk.vtkUnstructuredGrid();grid.SetPoints(vp);grid.SetCells(vtk.VTK_TETRA,ca)
            surface=vtk.vtkDataSetSurfaceFilter();surface.SetInputData(grid);surface.Update()
            mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(surface.GetOutput());mapper.ScalarVisibilityOff()
            actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetColor(colors[mat]);actor.GetProperty().SetAmbient(.5);actor.GetProperty().SetDiffuse(.5);ren.AddActor(actor)
            actors.append((actor,mat));allpoints.append(pts[np.unique(e[:,1:])])
    # The locator encloses the true 3x3 pillar coordinates.
    outline=vtk.vtkOutlineSource();outline.SetBounds(2925,3475,2925,3475,990,1085)
    om=vtk.vtkPolyDataMapper();om.SetInputConnection(outline.GetOutputPort());oa=vtk.vtkActor();oa.SetMapper(om);oa.GetProperty().SetColor(.9,.33,.03);oa.GetProperty().SetLineWidth(4);ren.AddActor(oa)
    cam=ren.GetActiveCamera();cam.ParallelProjectionOn();cam.SetViewUp(0,0,1)
    aim=np.array([2500.,3000.,1200.]);close=np.array([3200.,3200.,1040.]);direction=np.array([4.,6.,5.]);direction/=np.linalg.norm(direction)
    def frame(t,zoom):
        for actor,mat in actors:
            actor.SetPosition(*(np.array(offsets[mat])*t))
            if mat=='SubMat':actor.GetProperty().SetOpacity(1-.94*zoom)
        focus=aim*(1-zoom)+close*zoom;cam.SetFocalPoint(*focus);cam.SetPosition(*(focus+25000*direction));cam.SetParallelScale(5600*(1-zoom)+370*zoom)
        label.SetInput('Pillar array' if zoom>.5 else 'Package');ren.ResetCameraClippingRange();return capture(win)
    states=[(0,0)]*8+[(smooth(i/23),0) for i in range(24)]+[(1,0)]*12+[(1,smooth(i/29)) for i in range(30)]+[(1,1)]*30+[(1,1-smooth(i/23)) for i in range(24)]+[(1-smooth(i/19),0) for i in range(20)]
    frames=[frame(*state) for state in states]
    frames[43].save(OUT/'pillar-location.png');frames[85].save(OUT/'pillar-location-close.png')
    save(frames,[120]*len(frames),OUT/'pillar-location.gif')
    (OUT/'pillar-location-audit.json').write_text(json.dumps({'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'regions':len(actors),'geometry':'Original tetrahedral surfaces; rigid translations only; no copied pillars. Camera zoom highlights array at the die corner.','offsets_um':offsets},indent=2))
    win.Finalize();print('Pillar location complete',flush=True)

vtk.vtkMultiThreader.SetGlobalMaximumNumberOfThreads(2)
if sys.argv[-1]=='package':package()
else:flipchip()

