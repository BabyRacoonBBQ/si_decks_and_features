from pathlib import Path
r=Path('/home/mozztcad/tmp/flipchip-array-20261010')
a=r/'direct-solver-attempt';a.mkdir(exist_ok=True)
import shutil
for n in ['global.cmd','global.stdout.log','global.stderr.log']:shutil.copy2(r/n,a/n)
for n in ['global','unit','unit-fine']:
 p=r/(n+'.cmd');s=p.read_text();s=s.replace('math coord.ucs','math coord.ucs\nmath ils\npdbSet InfoDefault 1');p.write_text(s)
print('Switch to vendor iterative solver; second-order elements and geometry unchanged')
