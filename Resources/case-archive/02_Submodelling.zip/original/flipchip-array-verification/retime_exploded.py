"""Shorten exploded-view holds without re-encoding any GIF image data."""
from pathlib import Path
import json, sys

def shorten(path):
    path=Path(path);data=bytearray(path.read_bytes());pos=13
    if data[10]&128:pos+=3*(2**((data[10]&7)+1))
    changes=[];frame=0
    while pos<len(data):
        tag=data[pos];pos+=1
        if tag==0x3b:break
        if tag==0x21:
            label=data[pos];pos+=1
            if label==0xf9:
                delay=int.from_bytes(data[pos+2:pos+4],'little')
                if delay>=200:
                    new=round(delay/3)
                    data[pos+2:pos+4]=new.to_bytes(2,'little')
                    changes.append({'frame':frame,'before_ms':delay*10,'after_ms':new*10})
            while data[pos]:pos+=1+data[pos]
            pos+=1
        elif tag==0x2c:
            packed=data[pos+8];pos+=9
            if packed&128:pos+=3*(2**((packed&7)+1))
            pos+=1
            while data[pos]:pos+=1+data[pos]
            pos+=1;frame+=1
        else:raise ValueError(f'Unexpected GIF block {tag} at {pos-1}')
    path.write_bytes(data)
    path.with_suffix('.timing.json').write_text(json.dumps({'changes':changes,'image_blocks_unchanged':True},indent=2))
    return changes

if __name__=='__main__':print(json.dumps(shorten(sys.argv[1])))
