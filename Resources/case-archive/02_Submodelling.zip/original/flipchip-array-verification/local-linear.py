from pathlib import Path
import shutil
r=Path('/home/mozztcad/tmp/flipchip-array-20261010');a=r/'quadratic-unit-attempt';a.mkdir(exist_ok=True)
for n in ['unit.cmd','unit.stdout.log','unit.stderr.log']:shutil.copy2(r/n,a/n)
for n in ['unit','unit-fine']:
 p=r/(n+'.cmd');p.write_text(p.read_text().replace('FiniteElementOrder 2','FiniteElementOrder 1'))
