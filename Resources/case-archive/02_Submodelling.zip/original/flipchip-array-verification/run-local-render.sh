#!/usr/bin/env bash
set -e
cd /home/mozztcad/tmp/flipchip-array-local-20261011
PY=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/python3
XV=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/Xvfb
rm -f displayfd
$XV -displayfd 3 -screen 0 1000x680x24 -nolisten tcp 3>displayfd >xvfb-local.log 2>&1 &
XPID=$!
for i in $(seq 1 50); do test -s displayfd && break; sleep 0.2; done
test -s displayfd
export DISPLAY=:$(( $(cat displayfd) ))
$PY -s render-local.py
$PY -s render-case-tours-local.py flipchip
kill $XPID || true
wait $XPID || true
sha256sum figures-local/* > figures-local/SHA256SUMS
