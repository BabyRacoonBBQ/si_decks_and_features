from pathlib import Path
import hashlib,json,re
root=Path('/home/mozztcad/tmp/flipchip-array-20261010');root.mkdir(exist_ok=True)
src=Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/Applications_Library/Backend/CopperPillar_FlipChip_Crack/structure_and_globalflow_sis.cmd')
t=src.read_text().replace('@percent@','1.0').replace('@node@','1')
setup=t[:t.index('#-------------------------------------------------------------')]
setup+='\npdbSet Mechanics Save.Displacement.Field 1\npdbSet Mechanics Save.Step.Displacement 1\npdbSet Mechanics Save.Total.Displacement 0\n'
scheme=t.split('sde external {',1)[1].split('\n}\n\nsde off',1)[0]
scheme+='\n(sde:save-model "assembled")\n'
(root/'geometry.cmd').write_text(setup+'\nsde external {\n'+scheme+'\n}\nexit\n')
materials=t[t.index('# Add the Material Properties'):t.index('# Define the neutral point')]
bc=t[t.index('# Define the neutral point'):t.index('# Switch on SDE')]
mesh=t[t.index('pdbSet Grid MGoals accuracy'):t.index('grid remesh')]
# Omit refinement around the unrelated original crack. Preserve pillar refinement.
mesh=mesh[:mesh.index('refinebox min=')]
cool='SetTemp 180.0\nsolve stress.relax temperature=180.0<C> t.final=25.0<C> delNT=155.0 time=1.0<s> init=1.0<s> maxstep=1.0<s>\n'
solver_setup=setup.replace('FiniteElementOrder 2','FiniteElementOrder 1')+'\nmath ils\npdbSet InfoDefault 1\n'
(root/'global.cmd').write_text(solver_setup+materials+bc+'\nsde on\ninit tdr=assembled_bnd.tdr\n'+mesh+'\ngrid remesh\n'+cool+'struct tdr=global\nexit\n')
cut='''
sde external {
(sde:clear)
(sde:set-process-up-direction "-x")
(sde:open-model "assembled.sat")
(sdegeo:body-trim -1200 3300 3300 -900 3500 3500)
(sde:save-model "unit")
}
exit
'''
(root/'unit-geometry.cmd').write_text(setup+cut)
for stage,h in [('unit',12.0),('unit-fine',8.0)]:
 localmesh=f'''refinebox clear
pdbSet Grid SnMesh min.normal.size 2.5
refinebox min= {{-1200 3300 3300}} max= {{-900 3500 3500}} xrefine={h} yrefine={h} zrefine={h}
grid remesh
'''
 text=solver_setup+materials+'\npdbSet Mechanics Submodel.Add.Global.Stress 0\nsde on\ninit tdr=unit_bnd.tdr\n'+localmesh+'stressdata global.model=global_sis.tdr\n'+cool+f'struct tdr={stage}\nexit\n'
 (root/(stage+'.cmd')).write_text(text)
(root/'scope.json').write_text(json.dumps({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'percent':1,'geometry':'Original vendor assembled 3x3 copper pillar array; unchanged dimensions/materials','load':'Stress-free assembled structure at 180 C, one cooling step to 25 C. Not full assembly history.','submodel_bounds_um':[[-1200,3300,3300],[-900,3500,3500]],'selected_pillar_center_um':[-1037.5,3400,3400],'local_mesh_um':[12,8],'finite_element_order':1},indent=2))
print(root)
