from pathlib import Path
import json,hashlib
import h5py,numpy as np,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
root=Path('/home/mozztcad/tmp/flipchip-array-20261010')
def name(x):return x.decode() if isinstance(x,bytes) else str(x)
def read(filename):
 with h5py.File(root/filename) as f:
  g=f['collection/geometry_0'];v=g['vertex'][:];pts=np.column_stack([v[k] for k in ['x','y','z']]);u=np.zeros_like(pts);cells=[];copper=[]
  fields={(int(d.attrs['region']),name(d.attrs['name'])):d['values'][:] for d in g['state_0'].values() if 'region' in d.attrs and 'values' in d}
  for key,r in g.items():
   if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0 or name(r.attrs['material'])=='Gas':continue
   e=r['elements_0'][:].reshape(-1,5).astype(np.int64);assert np.all(e[:,0]==5)
   ids=np.unique(e[:,1:]);rid=int(key[7:]);disp=fields[rid,'StepDisplacement'].reshape(-1,3);a=fields[rid,'MisesStress'].reshape(-1)*1e-7
   assert len(ids)==len(a)==len(disp) and np.isfinite(a).all() and np.isfinite(disp).all()
   u[ids]=disp;e[:,0]=4;cells.append(e)
   if name(r.attrs['material'])=='BumpMat':
    values=np.zeros(len(pts));values[ids]=a
    q=pts[e[:,1:]];vol=np.abs(np.linalg.det(q[:,1:]-q[:,:1]))/6
    mean=values[e[:,1:]].mean(axis=1)
    copper.append({'region':name(r.attrs['name']),'volume_cm3':float(vol.sum()),'mean_MPa':float(np.sum(vol*mean)/vol.sum()),'max_MPa':float(a.max())})
  e=np.concatenate(cells);return pts,u,e,np.unique(e[:,1:]),copper
results={};loaded={}
for stage,file in [('array','global_sis.tdr'),('array-refined','global-refined_sis.tdr'),('unit','unit_sis.tdr'),('unit-fine','unit-fine_sis.tdr')]:
 if not (root/file).exists():continue
 p,u,e,ids,copper=read(file);loaded[stage]=(p,u,e,ids)
 results[stage]={'file':file,'sha256':hashlib.sha256((root/file).read_bytes()).hexdigest(),'vertices':len(ids),'tetrahedra':len(e),'copper':copper,'mean_MPa':sum(r['mean_MPa']*r['volume_cm3'] for r in copper)/sum(r['volume_cm3'] for r in copper)}
assert len(results['array']['copper'])==9,'Expected original nine copper pillars'
mapping=[]
for stage in ['unit','unit-fine']:
 if stage not in loaded:continue
 p,u,e,ids=loaded['array'];q,v,qe,qids=loaded[stage];lo=q[qids].min(0);hi=q[qids].max(0)
 mask=np.any(np.isclose(q[qids],lo,atol=1e-10,rtol=0)|np.isclose(q[qids],hi,atol=1e-10,rtol=0),axis=1);sel=qids[mask]
 vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(p,deep=True));ca=vtk.vtkCellArray();ca.SetCells(len(e),numpy_to_vtkIdTypeArray(e.ravel(),deep=True));grid=vtk.vtkUnstructuredGrid();grid.SetPoints(vp);grid.SetCells(vtk.VTK_TETRA,ca)
 a=numpy_to_vtk(u,deep=True);a.SetName('u');grid.GetPointData().AddArray(a);qp=vtk.vtkPoints();qp.SetData(numpy_to_vtk(q[sel],deep=True));poly=vtk.vtkPolyData();poly.SetPoints(qp)
 probe=vtk.vtkProbeFilter();probe.SetSourceData(grid);probe.SetInputData(poly);probe.Update();out=probe.GetOutput().GetPointData();valid=vtk_to_numpy(out.GetArray('vtkValidPointMask')).astype(bool);mapped=vtk_to_numpy(out.GetArray('u'))
 err=np.linalg.norm(mapped[valid]-v[sel][valid],axis=1);scale=np.linalg.norm(mapped[valid],axis=1).max()
 mapping.append({'stage':stage,'boundary_vertices':len(sel),'located_vertices':int(valid.sum()),'relative_max_error':float(err.max()/scale),'max_error_cm':float(err.max())})
report={'results':results,'mapping':mapping}
if 'array-refined' in loaded and 'unit-fine' in loaded:
 q,_,_,qids=loaded['unit-fine'];lo=q[qids].min(0);hi=q[qids].max(0)
 sel=qids[np.any(np.isclose(q[qids],lo,atol=1e-10,rtol=0)|np.isclose(q[qids],hi,atol=1e-10,rtol=0),axis=1)]
 sampled=[]
 for stage in ['array','array-refined']:
  p,u,e,_=loaded[stage];vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(p,deep=True));ca=vtk.vtkCellArray();ca.SetCells(len(e),numpy_to_vtkIdTypeArray(e.ravel(),deep=True));grid=vtk.vtkUnstructuredGrid();grid.SetPoints(vp);grid.SetCells(vtk.VTK_TETRA,ca)
  a=numpy_to_vtk(u,deep=True);a.SetName('u');grid.GetPointData().AddArray(a);qp=vtk.vtkPoints();qp.SetData(numpy_to_vtk(q[sel],deep=True));poly=vtk.vtkPolyData();poly.SetPoints(qp)
  probe=vtk.vtkProbeFilter();probe.SetSourceData(grid);probe.SetInputData(poly);probe.Update();out=probe.GetOutput().GetPointData();assert vtk_to_numpy(out.GetArray('vtkValidPointMask')).all()
  sampled.append(vtk_to_numpy(out.GetArray('u')).copy())
 delta=np.linalg.norm(sampled[0]-sampled[1],axis=1);scale=np.linalg.norm(sampled[1],axis=1)
 # Also remove rigid translation so a large package displacement cannot hide distortion changes.
 centered=[u-u.mean(0) for u in sampled];dc=np.linalg.norm(centered[0]-centered[1],axis=1);sc=np.linalg.norm(centered[1],axis=1)
 report['global_boundary_sensitivity']={'vertices':len(sel),'relative_rms_change':float(np.linalg.norm(delta)/np.linalg.norm(scale)),'relative_max_change':float(delta.max()/scale.max()),'relative_rms_distortion_change':float(np.linalg.norm(dc)/np.linalg.norm(sc))}
if 'unit-fine' in results:
 report['local_mean_stress_change']=abs(results['unit']['mean_MPa']-results['unit-fine']['mean_MPa'])/results['unit-fine']['mean_MPa']
(root/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
