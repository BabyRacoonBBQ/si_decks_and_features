"""Verify run inputs plus upstream artifacts before reusing a completed stage."""
from pathlib import Path
import hashlib,json,sys
r=Path('/home/mozztcad/tmp/flipchip-array-20261010')
stage,mode=sys.argv[1:]
deps={'geometry':[], 'global':['assembled_bnd.tdr'], 'unit-geometry':['assembled.sat'], 'unit':['unit_bnd.tdr','global_sis.tdr'], 'unit-fine':['unit_bnd.tdr','global_sis.tdr']}
outs={'geometry':['assembled.sat','assembled_bnd.tdr'],'global':['global_sis.tdr'],'unit-geometry':['unit.sat','unit_bnd.tdr'],'unit':['unit_sis.tdr'],'unit-fine':['unit-fine_sis.tdr']}
deps['global-refined']=['assembled_bnd.tdr'];outs['global-refined']=['global-refined_sis.tdr']
def sha(n):return hashlib.sha256((r/n).read_bytes()).hexdigest()
current={'inputs':{n:sha(n) for n in [stage+'.cmd']+deps[stage]},'outputs':{n:sha(n) for n in outs[stage] if (r/n).exists()}}
manifest=r/(stage+'.cache.json')
if mode=='record':
 assert all((r/n).exists() for n in outs[stage])
 assert (r/(stage+'.exit.txt')).read_text().strip()=='0'
 manifest.write_text(json.dumps(current,indent=2))
elif mode=='check':
 if not manifest.exists() or current!=json.loads(manifest.read_text()):sys.exit(1)
else:raise ValueError(mode)
