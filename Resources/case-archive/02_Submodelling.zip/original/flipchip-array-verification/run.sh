#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 TDR_VERSION=16 PYTHONNOUSERSITE=1
export PATH=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin:$PATH
cd /home/mozztcad/tmp/flipchip-array-20261010
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 60 9
ulimit -v 16777216
for stage in geometry global unit-geometry unit unit-fine; do
 input_hash=$(sha256sum "$stage.cmd" | cut -d' ' -f1)
 if [ -f "$stage.exit.txt" ] && [ "$(cat "$stage.exit.txt")" = 0 ] && python3 cache-state.py "$stage" check; then continue; fi
 echo "$stage" > current-stage.txt
 echo "$input_hash" > "$stage.input.sha256"
 set +e
 /usr/bin/time -v timeout -k 15 3600 taskset -c 4,5 sinterconnect --noSyntaxCheck "$stage.cmd" > "$stage.stdout.log" 2> "$stage.stderr.log"
 rc=$?
 set -e
 echo "$rc" > "$stage.exit.txt"
 if [ "$rc" != 0 ]; then echo "FAILED $stage ($rc)"; exit "$rc"; fi
 python3 cache-state.py "$stage" record
done
echo COMPLETE > current-stage.txt
