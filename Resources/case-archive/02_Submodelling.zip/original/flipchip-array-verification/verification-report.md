# Copper pillar array → independent single-pillar submodel

## Provenance and scope

Original geometry and materials: Sentaurus W-2024.09-SP1 Applications Library, Backend/CopperPillar_FlipChip_Crack, percent=1.0. The original 3 × 3 copper pillar array is retained. The local model is adapted from the original crack example: a cuboid surrounding the corner pillar is cut from the assembled vendor geometry and separately meshed and solved. Pillars are not copied during rendering.

Load: assembled structure initially stress-free at 180 °C, cooled to 25 °C in one step. This is a submodelling demonstration, not the full assembly process history or a reliability-life prediction. Native vendor sinterconnect and SDE were used.

Submodel bounds in original UCS, µm: x=[-1200,-900], y=[3300,3500], z=[3300,3500]. It includes the copper pillar, underfill and adjacent substrate/die layers. All six outer boundaries lie inside the global solid domain. StepDisplacement from the global solution supplies boundary conditions. Both models use the same temperature change. Global stress addition is disabled.

## Mesh and checks

First-order tetrahedral elements and vendor ILS solver. Second-order attempts were stopped after excessive memory use; their logs are retained. Global pillar spacings 20/30/30 µm were compared with 15/20/20 µm. Local isotropic spacings 12 and 8 µm were compared, with minimum normal size 2.5 µm.

Local copper volume-averaged equivalent stress changed by 1.0681% after refinement.
Global refinement changed mapped boundary displacement RMS by 0.1113%; after removing rigid translation, the relative distortion RMS change is 0.5031%.

| Model | Nodes | Tetrahedra | Copper average stress (MPa) |
|---|---:|---:|---:|
| array | 43994 | 246681 | 270.22 |
| array-refined | 58073 | 330611 | 254.136 |
| unit | 40749 | 224040 | 247.288 |
| unit-fine | 75969 | 422904 | 244.674 |

## Independent mapping checks

- unit: 6658/6658 boundary vertices located; relative maximum displacement mismatch 1.2519e-07.
- unit-fine: 10754/10754 boundary vertices located; relative maximum displacement mismatch 1.2519e-07.

Checks establish successful execution and measured mesh sensitivity for this demonstration. They do not establish convergence of interface/corner peak stresses or experimental agreement.

## Display

VTK renders the actual MisesStress field, converted from dyn/cm² to MPa by 1e-7. Only copper is visible; substrate, die and underfill are hidden to expose the array. Orange outline shows the selected submodel footprint projected onto the pillar base plane. Right panel is the independently solved finer single-pillar submodel, with the same camera orientation and shared 0–600 MPa color scale; values above the scale saturate as stated on the legends. Geometry is undeformed.

## Reuse

assembled.sat / assembled_bnd.tdr cache the full geometry; unit.sat / unit_bnd.tdr cache the cut submodel. Mesh or solver reruns import those files. Rendering uses saved TDR solutions. Cache manifests verify input, upstream artifact and output hashes before reuse.

All six stages exited 0. Evidence: validation.json, scope.json, stage logs, input hashes and cache manifests in /home/mozztcad/tmp/flipchip-array-20261010.
