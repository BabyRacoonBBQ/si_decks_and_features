# Set Global material Parameters
# --------------------------------------------------------

set EUnderfill 10e10
set LCTEUnderfill 35e-6
set CTESUB 25.0e-6
set EBump 111.5e10
set LCTEBump 17.7e-6

# Define the coordinate system
# and define the simulation mode
# --------------------------------------------------------

math coord.ucs

mode mechanics

# Set the mechanics options
# --------------------------------------------------------

pdbSet Mechanics EtchDepoRelax 0
pdbSet Mechanics StressHistory 0
pdbSet Grid AddGasMesh 0
pdbSetDouble Mechanics RefThExpCoeff 0.0

pdbSet Mechanics Calculate.Principal.Stress 1
pdbSet Mechanics SaveMaxStress 1
pdbSet Mechanics MaxIterations 20
pdbSet Mechanics Convergence.Force.Tolerance 1e-3
pdbSet Mechanics Convergence.Energy.Tolerance 1e-3

# Set SNMesh options
# --------------------------------------------------------

pdbSetBoolean Grid No3DMerge 1
pdbSetBoolean Grid No3DSwap 1
pdbSetBoolean Grid Adaptive 0
pdbSet Mechanics Merge.Vertices 1
pdbSet Mechanics Boundary.Method.Type MatrixReduction

pdbSet Grid sMesh 1
pdbSet Mechanics FiniteElementOrder 2


pdbSet Grid SnMesh MaxPoints 5000000

#-------------------------------------------------------------
#sde interface for structure creation
sde on
sde external {
(sde:clear)
(sde:set-process-up-direction "-x")
; Define the dimensions
; -----------------------------
(define distance_1 100.0)
(define half_distance_1 (/ distance_1 2.0))
(define height_1 75.0)
(define bump_d_1 (/ (* 4.0 height_1) 3.0))
(define bump_r_1 (/ bump_d_1 2.0))
(define half_pitch_1 (* 1.0 (+ bump_r_1 half_distance_1)))

(define smear_t_1 5.0)

(define sub_t_1 1000.0)

(define sub_l_1 7200.0)

(define chip_t_1 (* 1.0 sub_t_1))

(define chip_l_1 (* 0.5 sub_l_1))

(define sm_t_1 (* @percent@ 2.0))

(define pad_t_1 (* @percent@ 2.0))

(define ubm_t_1 (* @percent@ 2.0))

(define number_b_1 3)

; Define the procedures
; -----------------------------

; Define the smear material
; -----------------------------

(define create_smear (lambda (region material region1 material1 distance height smear_t sub_t sub_l chip_t chip_l pad_t sm_t ubm_t)
		(begin
		(sdegeo:set-default-boolean "ABA")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (* 1.0 (+ bump_r half_distance)))
		(sdegeo:create-cuboid 	(position (* -1.0 (+ sub_t height pad_t sm_t ubm_t)) 0.0 0.0)
			                (position (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t)) chip_l chip_l)
					material
					region
		)
		(sdegeo:create-cuboid 	(position (* -1.0 (+ sub_t height)) 0.0 0.0)
			                (position (* -1.0 (+ sub_t height pad_t sm_t ubm_t)) chip_l chip_l)
					material1
					region1
		)				
		)
	)
)

; Define the bumps
; -----------------------------

(define create_bumps (lambda (region material distance height smear_t sub_t sub_l chip_t chip_l num_bumps pad_t sm_t ubm_t)
		(begin
		(sdegeo:set-default-boolean "BAB")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (* 1.0 (+ bump_r half_distance)))
		(define number num_bumps)
                (let bumps1 ((counter_1 1))
		     (if (<= counter_1 number)
			 (begin
			  (define cent_x (* -1.0 (+ sub_t (* 0.5 height))))
			  (define cent_y (- chip_l (* counter_1 (* 2.0 half_pitch))))
			  (define cent_z (- chip_l (* 6.0 half_pitch)))
			  (define newreg region)
			  (define count1 (number->string counter_1))
			  (define reg1 (string-append newreg "_" count1))
			  (sdegeo:create-cylinder 	(position (- cent_x (* 0.5 height)) cent_y cent_z)
				                        (position (+ cent_x (* 0.5 height)) cent_y cent_z)
							bump_r
							material reg1
							)			
			  (bumps1 (+ counter_1 1))
			 )
		       )
		)
		(let bumps1 ((counter_1 1))
		     (if (<= counter_1 number)
			 (begin
		          (define cent_x (* -1.0 (+ sub_t (* 0.5 height))))
			  (define cent_y (- chip_l (* counter_1 (* 2.0 half_pitch))))
			  (define cent_z (- chip_l (* 4.0 half_pitch)))
			  (define newreg region)
			  (define count1 (number->string counter_1))
			  (define reg1 (string-append newreg "_" count1))
			  (sdegeo:create-cylinder 	(position (- cent_x (* 0.5 height)) cent_y cent_z)
				                        (position (+ cent_x (* 0.5 height)) cent_y cent_z)
							bump_r
							material reg1
							)			
			  (bumps1 (+ counter_1 1))
			 )
		       )
		)
		(let bumps1 ((counter_1 1))
		     (if (<= counter_1 number)
			 (begin
			  (define cent_x (* -1.0 (+ sub_t (* 0.5 height))))
			  (define cent_y (- chip_l (* counter_1 (* 2.0 half_pitch))))
			  (define cent_z (- chip_l (* 2.0 half_pitch)))
			  (define newreg region)
			  (define count1 (number->string counter_1))
			  (define reg1 (string-append newreg "_" count1))
			  (sdegeo:create-cylinder 	(position (- cent_x (* 0.5 height)) cent_y cent_z)
				                        (position (+ cent_x (* 0.5 height)) cent_y cent_z)
							bump_r
							material reg1
							)			
			  (bumps1 (+ counter_1 1))
			 )
		       )
		)
                (sdegeo:body-trim (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t)) 0.0 0.0 (* -1.0 sub_t) chip_l chip_l)
		)
	)
)

; Define the substrate
; -----------------------------

(define create_sub (lambda (region material distance height smear_t sub_t sub_l chip_t chip_l pad_t sm_t ubm_t)
		(begin
		(sdegeo:set-default-boolean "ABA")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (* 1.0 (+ bump_r half_distance)))
		(sdegeo:create-cuboid 	(position 0.0 0.0 0.0)
			                (position (* -1.0 sub_t) sub_l sub_l)
					material
					region
		)
                (sdegeo:body-trim (* -1.0 (+ sub_t height pad_t sm_t ubm_t smear_t chip_t)) 0.0 0.0 0.0 sub_l sub_l)
		)
	)
)

; Define the underfill
; -----------------------------

(define create_underfill (lambda (region material region1 material1 distance height smear_t sub_t sub_l chip_t chip_l num_bumps)
		(begin
		(sdegeo:set-default-boolean "BAB")
		(define half_distance (/ distance 2.0))
		(define bump_d (/ (* 4.0 height) 3.0))
		(define bump_r (/ bump_d 2.0))
		(define half_pitch (* 1.0 (+ bump_r half_distance)))
		
		(define number num_bumps)
		(sdegeo:create-cuboid (position (* -1.0 sub_t) 0.0 0.0) 
			              (position (* -1.0 (+ sub_t height)) (- chip_l (* (+ number 1) (* 2.0 half_pitch))) chip_l)
				      material1 region1)
		
                (sdegeo:create-cuboid (position (* -1.0 sub_t) 0.0 0.0) 
			              (position (* -1.0 (+ sub_t height)) chip_l (- chip_l (* 8.0 half_pitch)))
			              material1 region1
		)
	        (sdegeo:create-cuboid (position (* -1.0 sub_t) 0.0 (- chip_l (* 8.0 half_pitch))) 
			              (position (* -1.0 (+ sub_t height)) chip_l chip_l)
			              material region
		)
                (sdegeo:create-cuboid (position (* -1.0 sub_t) chip_l 0.0) 
			              (position (* -1.0 (+ sub_t height (* 0.5 chip_t))) (+ chip_l height (* 0.5 chip_t)) chip_l)
			              material region
                )
		(sdegeo:create-cuboid (position (* -1.0 sub_t) 0.0 chip_l) 
			              (position (* -1.0 (+ sub_t height (* 0.5 chip_t))) chip_l (+ chip_l height (* 0.5 chip_t)))
			              material region
                )
                (sdegeo:taper-faces 
		 (list (car (find-face-id 
		  (position -1287.50
			    4175.0
			    1800.0
		  )
		 )
	         )
		 )
		 (position (* -1.0 sub_t) (+ chip_l height (* 0.5 chip_t)) 0.0)
		 (gvector -1 0 0) 
		 45
		)
		(sdegeo:taper-faces 
		 (list (car (find-face-id 
                  (position -1287.50
			    1800.0
			    4175.0
		  )
		 )
	         )		
		 )
		 (position (* -1.0 sub_t) 0.0 (+ chip_l height (* 0.5 chip_t))) 
		 (gvector -1 0 0) 
		 45
		)
		(define p0 (position (* -1.0 (+ sub_t height (* 0.5 chip_t))) chip_l chip_l))
		(define p1 (position (* -1.0 sub_t) chip_l chip_l))
		(define p2 (position (* -1.0 sub_t) chip_l (+ chip_l height (* 0.5 chip_t))))
		(define p3 (position (* -1.0 sub_t) (+ chip_l height (* 0.5 chip_t)) chip_l))
		(define f0 (sheet:2d (sheet:planar-wire (wire-body:points (list p0 p1 p2 p0)))))
		(define f1 (sheet:2d (sheet:planar-wire (wire-body:points (list p0 p1 p3 p0)))))
		(define f2 (sheet:2d (sheet:planar-wire (wire-body:points (list p1 p2 p3 p1)))))
		(define f3 (sheet:2d (sheet:planar-wire (wire-body:points (list p0 p2 p3 p0)))))
		(define mb (car (entity:stitch (list f0 f1 f2 f3))))
                (sde:addmaterial mb material "mytetrahedron")
		(sdegeo:bool-unite (find-material-id material))		
		)
	)
)

; Create the structures for all the steps
; -----------------------------


; Define the substrate
; -----------------------------

(sdegeo:create-cuboid 	(position 	(* -1.0 (+ pad_t_1 sm_t_1 ubm_t_1 sub_t_1 height_1 smear_t_1))
					0.0
					0.0
			) 
			(position 	(* -1.0 (+ pad_t_1 sm_t_1 ubm_t_1 sub_t_1 height_1 smear_t_1 chip_t_1))
					chip_l_1
					chip_l_1
			) 
			"Silicon" "Substrate" 
)

;Create smear material and passiation
; -----------------------------

(create_smear "region_2" "Smear" "region_2_1" "Pass" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 pad_t_1 sm_t_1 ubm_t_1 )
(sdeio:save-3d-tdr-bnd "all" "n@node@_1_global.tdr")

; Create Solder bumps
; -----------------------------

(create_bumps "region_3" "BumpMat" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 number_b_1 pad_t_1 sm_t_1 ubm_t_1 )
(sdeio:save-3d-tdr-bnd "all" "n@node@_2_global.tdr")

; Create Substrate
; -----------------------------

(create_sub "region_5" "SubMat" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 pad_t_1 sm_t_1 ubm_t_1 )
(sdeio:save-3d-tdr-bnd "all" "n@node@_3_global.tdr")

; Create TDR file for underfilling ramp up
; -----------------------------
(sdeio:save-3d-tdr-bnd "all" "n@node@_4_global.tdr")

; Insert underfill
; -----------------------------

(create_underfill "region_6" "Epoxy" "region_6_A" "UFSmear" distance_1 height_1 smear_t_1 sub_t_1 sub_l_1 chip_t_1 chip_l_1 number_b_1)
(sdeio:save-3d-tdr-bnd "all" "n@node@_5_global.tdr")

}

sde off

# Add the Material Properties
# --------------------------------------------------------
#Define the material parameters for silicon die
pdbSet Silicon Mechanics BulkModulus [Enu2K 162.0e10 0.28]
pdbSet Silicon Mechanics ShearModulus [Enu2G 162.0e10 0.28]
pdbSet Silicon Mechanics ThExpCoeff 3.05e-6
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
pdbSetBoolean Silicon Mechanics Anisotropic 1
#Define the material parameters for back end smear layer
mater add name= Smear new.like= Nitride
pdbSetDouble Smear   Mechanics BulkModulus  [Enu2K 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ShearModulus [Enu2G 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ThExpCoeff   15.3e-6
pdbSetDouble Smear   Mechanics Vcrit0 1e-30
pdbSetDouble Smear   Mechanics VcritW 0.0
pdbSetDouble Smear   Mechanics Viscosity0 1e40
pdbSetDouble Smear   Mechanics ViscosityW 0.0

# ---------------------------------------------------------------------
#Define the material parameters for Copper pillars
mater add name= BumpMat new.like= Copper
pdbSetDouble BumpMat Mechanics BulkModulus [Enu2K $EBump 0.343]
pdbSetDouble BumpMat Mechanics ShearModulus [Enu2G $EBump 0.343]
pdbSetDouble BumpMat Mechanics ThExpCoeff $LCTEBump
		
# ---------------------------------------------------------------------
#Define the materials parameters for underfill
mater add name= Epoxy new.like= Oxide
pdbSetDouble Epoxy   Mechanics BulkModulus  [Enu2K $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ShearModulus [Enu2G $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ThExpCoeff   $LCTEUnderfill
pdbSetDouble Epoxy   Mechanics Vcrit0 1e-30
pdbSetDouble Epoxy   Mechanics VcritW 0.0
pdbSetDouble Epoxy   Mechanics Viscosity0 1e40
pdbSetDouble Epoxy   Mechanics ViscosityW 0.0
# ---------------------------------------------------------------------
#Define the material parameters for substrate
mater add name= SubMat new.like= Nitride
pdbSetDouble SubMat   Mechanics BulkModulus  [Enu2K 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ShearModulus [Enu2G 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ThExpCoeff   $CTESUB
pdbSetDouble SubMat   Mechanics Vcrit0 1e-30
pdbSetDouble SubMat   Mechanics VcritW 0.0
pdbSetDouble SubMat   Mechanics Viscosity0 1e40
pdbSetDouble SubMat   Mechanics ViscosityW 0.0
#Define the material parameters for passivation layer
mater add name= Pass new.like= Nitride
pdbSetDouble Pass   Mechanics BulkModulus  [Enu2K 131.0e10 0.22]
pdbSetDouble Pass   Mechanics ShearModulus [Enu2G 131.0e10 0.22]
pdbSetDouble Pass   Mechanics ThExpCoeff   1.9e-6
pdbSetDouble Pass   Mechanics Vcrit0 1e-30
pdbSetDouble Pass   Mechanics VcritW 0.0
pdbSetDouble Pass   Mechanics Viscosity0 1e40
pdbSetDouble Pass   Mechanics ViscosityW 0.0

# Smeared material property for underfill and bumps
# ----------------------------------------------------------------
set distance_1 100.0
set half_distance_1 [expr ($distance_1/2.0)]

set height_1 75.0
set bump_d_1 [expr ((4.0*$height_1)/3.0)]
set bump_r_1 [expr ($bump_d_1/2.0)]

set half_pitch_1 [expr (1.0 * ($bump_r_1+$half_distance_1))]

set pi1 [expr (4.0*atan(1.0))]

set radius_1 $bump_r_1

set radius_2 [expr ($height_1*(sqrt(7.0/36.0)))]

set height_2 [expr (0.5*$height_1)]

set pitch_1 [expr (2.0*$half_pitch_1)]

set volume [expr ($pitch_1*$pitch_1*$height_1)]

set vol_bump [expr ((($pi1*$height_2)/3.0)*((3.0*$radius_1*$radius_1)+(3.0*$radius_2*$radius_2)+($height_2*$height_2)))]

set ratio [expr ($radius_1/$pitch_1)]

set frac_bump [expr ($pi1*($ratio*$ratio))]

set frac_uf [expr (1.0-$frac_bump)]

set frac_uf1 [expr (($volume-$vol_bump)/$volume)]

set EUFSmear [expr (($EBump*$frac_bump)+($EUnderfill*$frac_uf))]

set NUUFSmear [expr ((0.40*$frac_bump)+(0.35*$frac_uf))]

set CTEUFSmear [expr (($LCTEBump*$frac_bump)+($LCTEUnderfill*$frac_uf))]

mater add name= UFSmear new.like= Oxide
pdbSetDouble UFSmear   Mechanics BulkModulus  [Enu2K $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ShearModulus [Enu2G $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ThExpCoeff   $CTEUFSmear
	
pdbSetDouble UFSmear   Mechanics Vcrit0 1e-30	   
pdbSetDouble UFSmear   Mechanics VcritW 0.0	  
pdbSetDouble UFSmear   Mechanics Viscosity0 1e40  
pdbSetDouble UFSmear   Mechanics ViscosityW 0.0

# Define the neutral point and set boundary conditions 
# --------------------------------------------------------

set smear_t_1 5.0

set sub_t_1 1000.0

set sub_l_1 7200.0

set chip_t_1 [expr (1.0 * $sub_t_1)]

set chip_l_1 [expr (0.5 * $sub_l_1)]

set sold_pad_t [expr (@percent@ * 2.0)]
set sold_msk_t [expr (@percent@ * 2.0)]
set underbump_met_t [expr (@percent@ * 2.0)]


set xmin [expr (-1.0*($sold_pad_t+$sold_msk_t+$underbump_met_t+$sub_t_1+$height_1+$smear_t_1+$chip_t_1))]

stressdata bc.location=Back bc.value= { dz=0 }

stressdata bc.location=Left bc.value= { dy=0 }
stressdata bc.location= TopPoint point.coord= {$xmin 0.0 0.0} bc.value= {pdx=0.0 pdy=0.0 pdz=0.0}

# Switch on SDE 
# ---------------------------------------------------------

sde on logfile=n@node@_sde.log 

# Import the structure - silicon with smear and passivation 
# --------------------------------------------------------

init tdr=n@node@_1_global.tdr

# Define the mesh
# ---------------------------------------------------------
set y_local [expr ($chip_l_1 - $half_pitch_1)]
set z_local [expr ($chip_l_1 - $half_pitch_1)]
set x_local -1120.0
set y_local1 [expr ($y_local + 20.0)]
set z_local1 [expr ($z_local + 20.0)]
set x_local1 -1100.0

pdbSet Grid MGoals accuracy 1.0e-5
pdbSet Grid MGoals resolution 0.3
pdbSet Grid SnMesh min.normal.size 2.5

refinebox name= Refine_PCB materials= SubMat \
     xrefine= { 40.0 60.0 40.0 } \
     yrefine= { 400.0 500.0 400.0 } \
     zrefine= { 400.0 500.0 400.0 } 

refinebox name= Refine_Bump materials= BumpMat \
     xrefine= { 20.0 20.0 20.0 } \
     yrefine= { 30.0 30.0 30.0 } \
     zrefine= { 30.0 30.0 30.0 } 
     
refinebox name= Refine_Epoxy materials= Epoxy \
     xrefine= { 40.0 60.0 40.0 } \
     yrefine= { 400.0 500.0 400.0 } \
     zrefine= { 400.0 500.0 400.0 } 
     
refinebox name= Refine_Chip materials= Silicon \
     xrefine= { 40.0 60.0 40.0 } \
     yrefine= { 400.0 500.0 400.0 } \
     zrefine= { 400.0 500.0 400.0 }
     
refinebox name= Refine_Smear materials= Smear \
     xrefine= { 40.0 60.0 40.0 } \
     yrefine= { 400.0 500.0 400.0 } \
     zrefine= { 400.0 500.0 400.0 }
      
refinebox name= Refine_UFSmear materials= UFSmear \
     xrefine= { 40.0 60.0 40.0 } \
     yrefine= { 400.0 500.0 400.0 } \
     zrefine= { 400.0 500.0 400.0 } 

refinebox name= Refine_Pass materials= Pass \
     xrefine= { 40.0 60.0 40.0 } \
     yrefine= { 400.0 500.0 400.0 } \
     zrefine= { 400.0 500.0 400.0 }
             
refinebox min= {$x_local $y_local $z_local} max= {$x_local1 $y_local1 $z_local1} xrefine= 20.0 yrefine= 20.0 zrefine= 20.0 Silicon
grid remesh

SetTemp 25.0

struct tdr=n@node@_0

# Ramp up to bump formation 
# --------------------------------------------------------

SetTemp 25.0

solve temperature=25.0<C> t.final=200.0<C> delT= 175.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_1

# Bumps 
# --------------------------------------------------------

init tdr=n@node@_2_global.tdr

load tdr=n@node@_1_sis.tdr sum

SetTemp 200.0

solve temperature=200.0<C> t.final=25.0<C> delNT= 175.0 \
 	time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_2

# Substrate 
# --------------------------------------------------------

init tdr=n@node@_3_global.tdr

load tdr=n@node@_2_sis.tdr sum

SetTemp 25.0

solve temperature=25.0<C> time=1.0<s> init= 1.0<s> maxstep= 1.0<s>

struct tdr=n@node@_3

# Underfill ramp up 
# --------------------------------------------------------

init tdr=n@node@_4_global.tdr

load tdr=n@node@_3_sis.tdr sum

SetTemp 25.0

solve temperature=25.0<C> t.final=180.0<C> delT= 155.0 \
	time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_4
		
# Underfill 
# --------------------------------------------------------

init tdr=n@node@_5_global.tdr

load tdr=n@node@_4_sis.tdr sum

SetTemp 180.0

solve temperature=180.0<C> t.final=25.0<C> delNT= 155.0 \
 	time=1.0<s> init= 1.0<s> maxstep= 1.0<s> 

struct tdr=n@node@_5

# exit the simulation
# --------------------------------------------------------
exit

