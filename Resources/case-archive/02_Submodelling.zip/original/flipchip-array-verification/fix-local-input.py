from pathlib import Path
r=Path('/home/mozztcad/tmp/flipchip-array-20261010')
for n in ['unit','unit-fine']:
 p=r/(n+'.cmd');s=p.read_text().replace('min={','min= {').replace('max={','max= {');p.write_text(s)
