from pathlib import Path
import json
r=Path('/home/mozztcad/tmp/flipchip-array-20261010');p=r/'scope.json';v=json.loads(p.read_text());v['finite_element_order']=1;v['solver']='vendor ILS';v['global_mesh_comparison_um']=[[20,30,30],[15,20,20]];v['displayed_result']='global_sis.tdr and unit-fine_sis.tdr';p.write_text(json.dumps(v,indent=2))
