from pathlib import Path
import json,re
root=Path('/home/mozztcad/tmp/package-submodelling-20261010')
audit=json.loads((root/'audit.json').read_text())
assert audit['complete'],'Do not publish incomplete verification as a pass'
mapping=json.loads((root/'mapping-check-step5.json').read_text())
assert len(mapping)==2
figures=json.loads((root/'figures/manifest.json').read_text())
assert len(figures)==3
rows=['# PackageAssembly_Stress: extracted submodelling verification','',
'Scope: vendor GlobalFlow → RegionalFlow → LocalFlow. LocalProcess is retained as the required source of the original BEOL geometry. The displayed LocalFlow result excludes the final addition of fabrication-induced stress. No RUC capability or standalone fabrication-process result is presented.','',
'Source: Sentaurus W-2024.09-SP1 Applications_Library/Backend/PackageAssembly_Stress. Default Workbench parameter values and original geometry, materials, five thermal-loading steps and mapping commands are preserved. Workbench node references were resolved explicitly as 6 / 7 / 8 / 9. LocalFlow mesh spacing was relaxed from 0.01/0.05 to 0.03/0.12 micrometres in dielectric regions and from 0.01/0.025 to 0.03/0.06 in Copper; minimum normal spacing is 0.03 micrometres. Geometry and mapping were unchanged. LocalProcess omits fabrication stress solves.','',
'Execution: native vendor sinterconnect and native vendor SDE, not the reconstructed local solver. Child tools resolve from the versioned linux64/bin directory; the system generic launcher was not used. Initial 8 GiB virtual-memory limit was insufficient for RegionalFlow; resumed with 16 GiB virtual-memory limit and the successful GlobalFlow outputs reused. Failed-attempt logs are retained on the VM.','',
'VM evidence directory: `'+str(root)+'`. Executable/input hashes are in identities.sha256, preparation.json and LocalFlow.coarse.sha256. All four stages exited 0. All 15 stress-output TDRs (five steps at three scales) have finite MisesStress and StepDisplacement fields.','',
'## Displayed result','',
'Step 5: post-underfill cooling from 180 °C to 25 °C, retaining the preceding loading history. Undeformed tetrahedral meshes on the original geometry; the BEOL mesh is coarsened. Gas hidden. The local BEOL panel exposes only the original Copper regions. Each view has its own camera framing; there is no geometric rescaling of parts.','',
'MisesStress is the current equivalent stress, not MisesStressMax. Native dyn/cm² values are multiplied by 1e-7 to display MPa. A common 0–600 MPa color scale follows the vendor example; values above 600 MPa saturate and the caption says so. The complete extrema are recorded below.','',
'| Scale | Solid vertices | Solid tetrahedra | Maximum current von Mises stress (MPa) |','|---|---:|---:|---:|']
for r in figures:rows.append(f"| {r['stage']} | {r['vertices']} | {r['tetrahedra']} | {r['stress_range_MPa'][1]:.6g} |")
rows+=['','## Independent displacement mapping check','',
'VTK probes the upstream tetrahedral solution at downstream outer-box boundary vertices. The comparison uses StepDisplacement in cm. This independently checks the field transfer on located vertices; it is not a mesh-convergence or experimental-validation claim.','',
'| Transfer | Located / boundary vertices | Max error (cm) | Relative max error |','|---|---:|---:|---:|']
for r in mapping:rows.append(f"| {r['source']} → {r['target']} | {r['located_vertices']} / {r['boundary_vertices']} | {r['max_error_cm']:.6g} | {r['relative_max_error']:.6g} |")
rows+=['','## Runtime','']
for stage in ['GlobalFlow','RegionalFlow','LocalProcess','LocalFlow']:
 log=(root/(stage+'.stderr.log')).read_text(errors='replace')
 vals=[line.strip() for line in log.splitlines() if 'Elapsed (wall clock)' in line or 'Maximum resident' in line]
 rows.append('- '+stage+': '+'; '.join(vals))
rows+=['','Verification establishes successful vendor execution, finite outputs and the measured displacement-transfer consistency. It does not establish mesh-independent peaks, calibrated package reliability, or acceptance of any other implementation.','']
(root/'verification-report.md').write_text('\n'.join(rows))
print('Verification report written.')
