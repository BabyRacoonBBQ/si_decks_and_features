from pathlib import Path
import json,hashlib
import h5py,numpy as np
root=Path('/home/mozztcad/tmp/package-submodelling-20261010')
def name(x):return x.decode() if isinstance(x,bytes) else str(x)
rows=[]
for prefix in ['n6_out','n7','n9']:
 for step in range(1,6):
  p=root/f'{prefix}_{step}_sis.tdr'
  if not p.exists():continue
  with h5py.File(p) as f:
   g=f['collection/geometry_0'];fields=[]
   for d in g['state_0'].values():
    if 'values' not in d or name(d.attrs.get('name','')) not in ['MisesStress','StepDisplacement']:continue
    a=d['values'][:];assert np.isfinite(a).all()
    fields.append({'name':name(d.attrs['name']),'region':int(d.attrs.get('region',-1)),'min':float(a.min()),'max':float(a.max()),'attributes':{k:name(v) for k,v in d.attrs.items()}})
   assert fields
   assert any(d['name']=='MisesStress' and d['max']>0 for d in fields),'Stress solution must be nonzero'
   rows.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'vertices':len(g['vertex']),'fields':fields})
exit_codes={p.name:p.read_text().strip() for p in root.glob('*.exit.txt')}
result={'outputs':rows,'exit_codes':exit_codes,'complete':len(rows)==15 and all(exit_codes.get(s+'.exit.txt')=='0' for s in ['GlobalFlow','RegionalFlow','LocalProcess','LocalFlow'])}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'complete':result['complete'],'exit_codes':exit_codes,'outputs':[{k:r[k] for k in ['file','vertices','bytes']} for r in rows]},indent=2))
if rows:print(json.dumps(rows[-1]['fields'][:2],indent=2))
