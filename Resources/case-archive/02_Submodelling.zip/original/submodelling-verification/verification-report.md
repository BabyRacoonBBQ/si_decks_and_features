# PackageAssembly_Stress: extracted submodelling verification

Scope: vendor GlobalFlow → RegionalFlow → LocalFlow. LocalProcess is retained as the required source of the original BEOL geometry. The displayed LocalFlow result excludes the final addition of fabrication-induced stress. No RUC capability or standalone fabrication-process result is presented.

Source: Sentaurus W-2024.09-SP1 Applications_Library/Backend/PackageAssembly_Stress. Default Workbench parameter values and original geometry, materials, five thermal-loading steps and mapping commands are preserved. Workbench node references were resolved explicitly as 6 / 7 / 8 / 9. LocalFlow mesh spacing was relaxed from 0.01/0.05 to 0.03/0.12 micrometres in dielectric regions and from 0.01/0.025 to 0.03/0.06 in Copper; minimum normal spacing is 0.03 micrometres. Geometry and mapping were unchanged. LocalProcess omits fabrication stress solves.

Execution: native vendor sinterconnect and native vendor SDE, not the reconstructed local solver. Child tools resolve from the versioned linux64/bin directory; the system generic launcher was not used. Initial 8 GiB virtual-memory limit was insufficient for RegionalFlow; resumed with 16 GiB virtual-memory limit and the successful GlobalFlow outputs reused. Failed-attempt logs are retained on the VM.

VM evidence directory: `/home/mozztcad/tmp/package-submodelling-20261010`. Executable/input hashes are in identities.sha256, preparation.json and LocalFlow.coarse.sha256. All four stages exited 0. All 15 stress-output TDRs (five steps at three scales) have finite MisesStress and StepDisplacement fields.

## Displayed result

Step 5: post-underfill cooling from 180 °C to 25 °C, retaining the preceding loading history. Undeformed tetrahedral meshes on the original geometry; the BEOL mesh is coarsened. Gas hidden. The local BEOL panel exposes only the original Copper regions. Each view has its own camera framing; there is no geometric rescaling of parts.

MisesStress is the current equivalent stress, not MisesStressMax. Native dyn/cm² values are multiplied by 1e-7 to display MPa. A common 0–600 MPa color scale follows the vendor example; values above 600 MPa saturate and the caption says so. The complete extrema are recorded below.

| Scale | Solid vertices | Solid tetrahedra | Maximum current von Mises stress (MPa) |
|---|---:|---:|---:|
| global | 38116 | 177727 | 2972.97 |
| regional | 107035 | 611795 | 4547.84 |
| local | 25353 | 144960 | 847.648 |

## Independent displacement mapping check

VTK probes the upstream tetrahedral solution at downstream outer-box boundary vertices. The comparison uses StepDisplacement in cm. This independently checks the field transfer on located vertices; it is not a mesh-convergence or experimental-validation claim.

| Transfer | Located / boundary vertices | Max error (cm) | Relative max error |
|---|---:|---:|---:|
| n6_out_5_sis.tdr → n7_5_sis.tdr | 9669 / 9669 | 2.4047e-09 | 1.03513e-06 |
| n7_5_sis.tdr → n9_5_sis.tdr | 2395 / 2395 | 1.038e-13 | 4.70966e-11 |

## Runtime

- GlobalFlow: Elapsed (wall clock) time (h:mm:ss or m:ss): 4:44.93; Maximum resident set size (kbytes): 2860224
- RegionalFlow: Elapsed (wall clock) time (h:mm:ss or m:ss): 22:49.61; Maximum resident set size (kbytes): 9757184
- LocalProcess: Elapsed (wall clock) time (h:mm:ss or m:ss): 16:47.06; Maximum resident set size (kbytes): 1617132
- LocalFlow: Elapsed (wall clock) time (h:mm:ss or m:ss): 5:31.74; Maximum resident set size (kbytes): 3863232

Verification establishes successful vendor execution, finite outputs and the measured displacement-transfer consistency. It does not establish mesh-independent peaks, calibrated package reliability, or acceptance of any other implementation.
