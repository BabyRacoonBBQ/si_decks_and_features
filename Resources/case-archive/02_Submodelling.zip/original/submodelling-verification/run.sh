#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 TDR_VERSION=16 PYTHONNOUSERSITE=1
export PATH=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin:$PATH
cd /home/mozztcad/tmp/package-submodelling-20261010
binary=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin/sinterconnect
sha256sum "$binary" *.cmd > identities.sha256
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 60 9
ulimit -v 16777216
for stage in GlobalFlow RegionalFlow LocalProcess LocalFlow; do
 if [ -f "$stage.exit.txt" ] && [ "$(cat "$stage.exit.txt")" = 0 ]; then continue; fi
 echo "$stage" > current-stage.txt
 date -u > "$stage.started.txt"
 set +e
 /usr/bin/time -v timeout -k 15 3600 taskset -c 4,5 "$binary" --noSyntaxCheck "$stage.cmd" > "$stage.stdout.log" 2> "$stage.stderr.log"
 rc=$?
 set -e
 echo "$rc" > "$stage.exit.txt"
 if [ "$rc" != 0 ]; then echo "FAILED $stage ($rc)"; exit "$rc"; fi
done
echo COMPLETE > current-stage.txt
