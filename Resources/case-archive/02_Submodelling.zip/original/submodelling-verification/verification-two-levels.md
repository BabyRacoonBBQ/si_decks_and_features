# Vendor-run two-level submodelling verification

Scope: GlobalFlow → RegionalFlow from Sentaurus W-2024.09-SP1 Applications Library, Backend/PackageAssembly_Stress. Both stages exited 0. All five thermal-loading steps completed at both scales; ten TDR files contain finite stress and displacement-increment fields and nonzero stress.

Displayed plots: final step 5, post-underfill cooling from 180 °C to 25 °C with preceding assembly history retained. The original geometry and mesh are preserved. These are actual vendor sinterconnect outputs, rendered using VTK. The finer LocalProcess/LocalFlow branch is outside this completed two-level verification and was still running at publication. The audit complete=false flag refers to that larger three-level workflow, not a failure of the two displayed stages.

Visualization: current MisesStress, not MisesStressMax; native dyn/cm² × 1e-7 = MPa. Undeformed solid geometry; Gas hidden. Both plots use 0–600 MPa, with values above 600 saturated (as marked on the legends). Camera orientation is rigid; geometry is not fabricated or stretched.

| Model | Solid vertices | Tetrahedra | Maximum stress (MPa) |
|---|---:|---:|---:|
| global | 38116 | 177727 | 2972.966019 |
| regional | 107035 | 611795 | 4547.839656 |

## Independent mapping check

StepDisplacement is interpolated from upstream tetrahedra at downstream outer boundary vertices using vtkProbeFilter. All boundary vertices are located. This checks field-transfer consistency; it is not a mesh-convergence or experimental-validation result.

- n6_out_5_sis.tdr → n7_5_sis.tdr: 9669/9669 vertices; maximum error 2.4046952916369376e-9 cm; relative maximum error 0.0000010351285571799178.

Evidence: audit.json, mapping-check-step5.json, figures/manifest.json, preparation.json, identities.sha256 and stage exit files. Original input/output/log files remain in /home/mozztcad/tmp/package-submodelling-20261010 on the VM. Thermal submodelling is documented on the slide but was not tested in this mechanics run.
