from pathlib import Path
import re, json, hashlib, shutil
root=Path('/home/mozztcad/tmp/package-submodelling-20261010')
src=Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/Applications_Library/Backend/PackageAssembly_Stress')
root.mkdir(exist_ok=True)
params={'distance':'100.0','EUF':'10.0e10','LCTEUF':'35.0e-6','EBUMP':'60.0e10','LCTEBUMP':'20.0e-6'}
manifest={'source':str(src),'parameters':params,'stages':[]}
for stage,node,previous in [('GlobalFlow','6','5'),('RegionalFlow','7','6'),('LocalProcess','8','7'),('LocalFlow','9','8')]:
 p=src/(stage+'_sis.cmd'); t=p.read_text()
 values={**params,'node':node,'previous':previous,'previous|-1':'7'}
 for k,v in values.items():t=t.replace('@'+k+'@',v)
 assert not re.search(r'@[^@\n]+@',t)
 if stage=='LocalProcess':
  # Geometry-only dependency. UG Chapter 2 explicitly separates rebalancing
  # and fabrication stress-history solves from etch/deposition geometry.
  t=t.replace('pdbSet Mechanics EtchDepoRelax 1','pdbSet Mechanics EtchDepoRelax 0')
  t=t.replace('pdbSet Mechanics StressHistory 1','pdbSet Mechanics StressHistory 0')
  t=re.sub(r'^solve temperature=.*$', '# Fabrication-only final stress solve omitted.',t,flags=re.M)
  t=t.split('# Transform the structure')[0]+'\nexit\n'
 # Retain process-generated BEOL geometry, but do not add fabrication stress to
 # the submodelling result: the presentation concerns package-induced stress.
 if stage=='LocalFlow':t=t.split('# Add the process stress, save the structures and exit')[0]+'\nexit\n'
 (root/(stage+'.cmd')).write_text(t)
 manifest['stages'].append({'stage':stage,'node':node,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(t.encode()).hexdigest(),'scope':'Geometry only; fabrication stress solves omitted' if stage=='LocalProcess' else 'Package-induced stress only' if stage=='LocalFlow' else 'Unchanged except Workbench substitutions'})
for n in ['datexcodes.txt','SRAM6T_4_lyt.mac','SRAM6T_4_mkp.mac','SRAM6T_4.gds']:shutil.copy2(src/n,root/n)
(root/'preparation.json').write_text(json.dumps(manifest,indent=2))
print(root)
