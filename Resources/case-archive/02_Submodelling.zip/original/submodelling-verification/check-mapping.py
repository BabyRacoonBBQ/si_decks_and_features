"""Independent interpolation check at local box-boundary vertices."""
from pathlib import Path
import json,os
import h5py,numpy as np,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
root=Path('/home/mozztcad/tmp/package-submodelling-20261010')
def name(x):return x.decode() if isinstance(x,bytes) else str(x)
def read(file):
 with h5py.File(root/file) as f:
  g=f['collection/geometry_0'];v=g['vertex'][:];pts=np.column_stack([v[a] for a in ('x','y','z')]);u=np.zeros_like(pts);cells=[]
  fields={int(d.attrs['region']):d['values'][:].reshape(-1,3) for d in g['state_0'].values() if name(d.attrs.get('name',''))=='StepDisplacement'}
  for key,r in g.items():
   if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0 or name(r.attrs['material'])=='Gas':continue
   e=r['elements_0'][:].reshape(-1,5).astype(np.int64);ids=np.unique(e[:,1:]);u[ids]=fields[int(key[7:])];e[:,0]=4;cells.append(e)
  e=np.concatenate(cells);ids=np.unique(e[:,1:]);return pts,u,e,ids
results=[]
step=os.environ.get('CHECK_STEP','5')
for source,target in [(f'n6_out_{step}_sis.tdr',f'n7_{step}_sis.tdr'),(f'n7_{step}_sis.tdr',f'n9_{step}_sis.tdr')]:
 if not (root/target).exists():continue
 p,u,e,ids=read(source);q,v,qe,qids=read(target)
 lo=q[qids].min(0);hi=q[qids].max(0)
 boundary=np.any(np.isclose(q[qids],lo,atol=1e-10,rtol=0)|np.isclose(q[qids],hi,atol=1e-10,rtol=0),axis=1);sel=qids[boundary]
 vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(p,deep=True));ca=vtk.vtkCellArray();ca.SetCells(len(e),numpy_to_vtkIdTypeArray(e.ravel(),deep=True));grid=vtk.vtkUnstructuredGrid();grid.SetPoints(vp);grid.SetCells(vtk.VTK_TETRA,ca)
 a=numpy_to_vtk(u,deep=True);a.SetName('StepDisplacement');grid.GetPointData().AddArray(a)
 qp=vtk.vtkPoints();qp.SetData(numpy_to_vtk(q[sel],deep=True));poly=vtk.vtkPolyData();poly.SetPoints(qp)
 probe=vtk.vtkProbeFilter();probe.SetInputData(poly);probe.SetSourceData(grid);probe.Update();out=probe.GetOutput().GetPointData()
 valid=vtk_to_numpy(out.GetArray('vtkValidPointMask')).astype(bool);mapped=vtk_to_numpy(out.GetArray('StepDisplacement'))
 error=np.linalg.norm(mapped[valid]-v[sel][valid],axis=1);scale=np.linalg.norm(mapped[valid],axis=1).max()
 results.append({'source':source,'target':target,'boundary_vertices':len(sel),'located_vertices':int(valid.sum()),'max_error_cm':float(error.max()),'rms_error_cm':float(np.sqrt(np.mean(error**2))),'max_mapped_step_cm':float(scale),'relative_max_error':float(error.max()/max(scale,1e-30))})
(root/f'mapping-check-step{step}.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
