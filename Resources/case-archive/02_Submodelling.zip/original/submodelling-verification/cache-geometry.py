"""Freeze/verify existing vendor geometry; emit an import-only LocalFlow input."""
from pathlib import Path
import hashlib,json,sys
root=Path('/home/mozztcad/tmp/package-submodelling-20261010')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source=(root/'LocalFlow.cmd').read_text()
start=source.index('sde external {')
end=source.index('# Set SWB Variables')
dependencies=['LocalProcess.cmd','SRAM6T_4.gds','SRAM6T_4_lyt.mac','SRAM6T_4_mkp.mac']
assets=['n8_pretrans_sde.sat','n8_pretrans_bnd.tdr','n9_lines.sat','n9_lines_bnd.tdr']
current={'inputs':{n:digest(root/n) for n in dependencies},
 'transform_sha256':hashlib.sha256(source[start:end].encode()).hexdigest(),
 'geometry':{n:digest(root/n) for n in assets}}
cache=root/'geometry-cache.json'
if '--record' in sys.argv:
 if cache.exists(): raise SystemExit('Cache already recorded; verify instead of overwriting provenance.')
 assert (root/'LocalProcess.exit.txt').read_text().strip()=='0'
 cache.write_text(json.dumps(current,indent=2))
else:
 assert cache.exists(),'Generate and record geometry first'
 assert current==json.loads(cache.read_text()),'Geometry inputs or cache changed; rebuild geometry before reuse'
output=source[:start]+'# Reuse verified n9_lines_bnd.tdr; no geometry construction or transformation.\n\n'+source[end:]
(root/'LocalFlow.cached.cmd').write_text(output)
print('Verified cached geometry; wrote LocalFlow.cached.cmd (import only).')
