# Geometry reuse

The original vendor geometry is generated once, then cached as `n8_pretrans_sde.sat` and `n8_pretrans_bnd.tdr`. The transformed BEOL submodel is cached as `n9_lines.sat` and `n9_lines_bnd.tdr`.

On the VM, run `bash /home/mozztcad/tmp/package-submodelling-20261010/run-local-cached.sh` to rerun the local solver using the existing geometry. This skips LocalProcess and the LocalFlow SDE construction/transform block. Meshing and the five displacement-mapped loading steps still run. Rendering alone uses the existing TDR outputs and requires no geometry or solver rerun.

`cache-geometry.py` verifies hashes of the process input, GDS, masks, coordinate transformation and cached geometry before generating `LocalFlow.cached.cmd`. Changed geometry inputs stop reuse instead of silently loading stale geometry. Mesh and solver settings can change independently. A new geometry variant should use a separate run directory and its own cache.

The cached runner uses the same heavy-job lock as the original run, so it cannot overlap the ongoing solver.
