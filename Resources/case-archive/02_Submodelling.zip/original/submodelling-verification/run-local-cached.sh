#!/bin/bash
set -eu
cd /home/mozztcad/geo3d
source .env >/dev/null
unset LD_PRELOAD BREP_RECON_SO HOOK_JS EXTRA_HOOK_JS HOOK_LIST HOOK_SKIP GEO_INIT_MODELS
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 TDR_VERSION=16 PYTHONNOUSERSITE=1
export PATH=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/bin:$PATH
cd /home/mozztcad/tmp/package-submodelling-20261010
exec 9>/tmp/geo3d-sinterconnect-heavy.lock
flock -w 60 9
python3 cache-geometry.py
ulimit -v 16777216
/usr/bin/time -v timeout -k 15 3600 taskset -c 4,5 sinterconnect --noSyntaxCheck LocalFlow.cached.cmd > LocalFlow.cached.stdout.log 2> LocalFlow.cached.stderr.log
