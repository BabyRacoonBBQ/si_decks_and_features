"""Scientific rendering of the completed vendor submodelling chain, from TDR."""
from pathlib import Path
import hashlib,json,os
import numpy as np
import h5py,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
ROOT=Path('/home/mozztcad/tmp/package-submodelling-20261010')
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
def name(x):return x.decode() if isinstance(x,bytes) else str(x)
vtk.vtkMultiThreader.SetGlobalMaximumNumberOfThreads(2)
manifest=[]
for label,filename in [('global','n6_out_5_sis.tdr'),('regional','n7_5_sis.tdr'),('local','n9_5_sis.tdr')]:
 if os.environ.get('RENDER_STAGE') and label!=os.environ['RENDER_STAGE']:continue
 if label=='local' and os.environ.get('LOCAL_STEP'):filename='n9_'+os.environ['LOCAL_STEP']+'_sis.tdr'
 source=ROOT/filename
 if not source.exists():continue
 with h5py.File(source,'r') as f:
  g=f['collection/geometry_0'];v=g['vertex'][:]
  xyz=np.column_stack([v[a] for a in ('x','y','z')])
  pts=np.column_stack([v['y'],v['z'],-v['x']])*1e4
  fields={(int(d.attrs['region']),name(d.attrs['name'])):d for d in g['state_0'].values() if 'values' in d and 'region' in d.attrs}
  regions=[]
  for key,r in g.items():
   if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0 or name(r.attrs['material'])=='Gas':continue
   rid=int(key[7:]);e=r['elements_0'][:].reshape(-1,5);assert np.all(e[:,0]==5)
   ids=np.unique(e[:,1:]);field='MisesStress'
   d=fields[rid,field];a=d['values'][:].reshape(-1)*1e-7 # dyn/cm2 -> MPa
   assert len(a)==len(ids) and np.isfinite(a).all()
   u=fields[rid,'StepDisplacement']['values'][:].reshape(-1,3)
   assert np.isfinite(u).all()
   regions.append(dict(name=name(r.attrs['name']),material=name(r.attrs['material']),ids=ids,e=e,a=a,u=u,units={k:name(val) for k,val in d.attrs.items()}))
  allids=np.unique(np.concatenate([r['ids'] for r in regions]));bounds=[xyz[allids].min(0).tolist(),xyz[allids].max(0).tolist()]
  row={'stage':label,'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'vertices':len(allids),'tetrahedra':sum(len(r['e']) for r in regions),'bounds_cm':bounds,'field':'MisesStress','stress_range_MPa':[min(float(r['a'].min()) for r in regions),max(float(r['a'].max()) for r in regions)],'step_displacement_max_cm':max(float(np.linalg.norm(r['u'],axis=1).max()) for r in regions),'regions':[{'name':r['name'],'material':r['material'],'tetrahedra':len(r['e']),'field_attributes':r['units']} for r in regions]}
  for mode in ['stress','geometry']:
   visible=regions
   # Copper-only local view exposes the actual buried interconnect geometry.
   if label=='local':visible=[r for r in regions if r['material']=='Copper']
   ids=np.unique(np.concatenate([r['ids'] for r in visible]));center=(pts[ids].min(0)+pts[ids].max(0))/2
   vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(pts-center,deep=True))
   ren=vtk.vtkRenderer();ren.SetBackground(1,1,1);ren.SetViewport(0,.2,1,1);ren.SetLayer(1)
   win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1200,720);win.SetMultiSamples(4);win.SetNumberOfLayers(3)
   background=vtk.vtkRenderer();background.SetBackground(1,1,1);win.AddRenderer(background);win.AddRenderer(ren)
   overlay=vtk.vtkRenderer();overlay.SetLayer(2);overlay.InteractiveOff();win.AddRenderer(overlay)
   lut=vtk.vtkLookupTable();lut.SetHueRange(.667,0);lut.SetRange(0,600);lut.Build()
   colors={'Silicon':(.7,.78,.85),'Copper':(.76,.43,.21),'BumpMat':(.65,.72,.78),'SubMat':(.26,.60,.60),'Epoxy':(.56,.74,.69),'Smear':(.45,.51,.65),'Pass':(.75,.65,.44),'UFSmear':(.52,.70,.64)}
   for r in visible:
    e=r['e'].astype(np.int64).copy();e[:,0]=4
    ca=vtk.vtkCellArray();ca.SetCells(len(e),numpy_to_vtkIdTypeArray(e.ravel(),deep=True))
    grid=vtk.vtkUnstructuredGrid();grid.SetPoints(vp);grid.SetCells(vtk.VTK_TETRA,ca)
    values=np.zeros(len(pts));values[r['ids']]=r['a'];grid.GetPointData().SetScalars(numpy_to_vtk(values,deep=True))
    mapper=vtk.vtkDataSetMapper();mapper.SetInputData(grid);mapper.SetLookupTable(lut);mapper.SetScalarRange(0,600)
    if mode=='geometry':mapper.ScalarVisibilityOff()
    actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetColor(colors.get(r['material'],(.72,.73,.77)));actor.GetProperty().SetAmbient(.45);actor.GetProperty().SetDiffuse(.55);ren.AddActor(actor)
   child={'global':'n7_5_sis.tdr','regional':'n9_5_sis.tdr'}.get(label)
   if child and (ROOT/child).exists():
    with h5py.File(ROOT/child) as cf:
     cv=cf['collection/geometry_0/vertex'][:];cp=np.column_stack([cv['y'],cv['z'],-cv['x']])*1e4-center
     low,high=cp.min(0),cp.max(0)
     outline=vtk.vtkOutlineSource();outline.SetBounds(low[0],high[0],low[1],high[1],low[2],high[2]);om=vtk.vtkPolyDataMapper();om.SetInputConnection(outline.GetOutputPort());oa=vtk.vtkActor();oa.SetMapper(om);oa.GetProperty().SetColor(.9,.35,.08);oa.GetProperty().SetLineWidth(3);ren.AddActor(oa)
   if mode=='stress':
    bar=vtk.vtkScalarBarActor();bar.SetLookupTable(lut);bar.SetTitle('Equivalent stress (MPa; capped at 600)');bar.SetOrientationToHorizontal();bar.SetPosition(.24,.035);bar.SetWidth(.52);bar.SetHeight(.12);bar.SetNumberOfLabels(4);bar.SetLabelFormat('%.0f')
    for prop in [bar.GetTitleTextProperty(),bar.GetLabelTextProperty()]:prop.SetColor(.09,.18,.26);prop.SetFontFamilyToArial();prop.SetFontSize(22);prop.ItalicOff();prop.ShadowOff()
    overlay.AddActor2D(bar)
   cam=ren.GetActiveCamera();cam.SetPosition(*( (3,4,3) if label=='local' else (1,3,1.6) ));cam.SetFocalPoint(0,0,0);cam.SetViewUp(0,0,1);cam.ParallelProjectionOn();visible_pts=pts[ids]-center;lo,hi=visible_pts.min(0),visible_pts.max(0);ren.ResetCamera(lo[0],hi[0],lo[1],hi[1],lo[2],hi[2]);cam.Zoom(1.35 if label=='global' else 1.12 if label=='local' else .92)
   ren.ResetCameraClippingRange();win.Render()
   shot=vtk.vtkWindowToImageFilter();shot.SetInput(win);shot.ReadFrontBufferOff();shot.Update()
   writer=vtk.vtkPNGWriter();writer.SetFileName(str(OUT/(label+'-'+mode+'.png')));writer.SetInputConnection(shot.GetOutputPort());writer.Write();win.Finalize()
  row['display']='Undeformed original mesh; Gas hidden; local panel shows Copper regions only; fixed 0–600 MPa color scale.'
  manifest.append(row)
(OUT/('manifest-'+os.environ['RENDER_STAGE']+'.json' if os.environ.get('RENDER_STAGE') else 'manifest.json')).write_text(json.dumps(manifest,indent=2))
print(json.dumps([{k:r[k] for k in ['stage','vertices','tetrahedra','stress_range_MPa']} for r in manifest],indent=2))
