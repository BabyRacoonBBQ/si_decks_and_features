from pathlib import Path
p=Path('/home/mozztcad/tmp/package-submodelling-20261010/LocalFlow.cmd')
s=p.read_text()
p.with_name('LocalFlow.original-mesh.cmd').write_text(s)
s=s.replace('{0.01 0.05 0.01}','{0.03 0.12 0.03}').replace('{0.01 0.025 0.01}','{0.03 0.06 0.03}').replace('min.normal.size= 0.01','min.normal.size= 0.03')
p.write_text(s)
print('LocalFlow mesh spacing relaxed; geometry and all five mapped loading steps unchanged.')
