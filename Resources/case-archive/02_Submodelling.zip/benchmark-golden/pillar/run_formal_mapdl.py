"""Sequential three-repeat MAPDL pipeline; invoked under the host monitor."""
from pathlib import Path
import json,sys,subprocess,time,hashlib
root=Path(__file__).resolve().parent
tag=sys.argv[1]
records=[]
summary=root/'mapdl'/tag
summary.mkdir(parents=True,exist_ok=False)
exe=Path(r'D:/Program Files/ANSYS Inc/v261/ansys/bin/winx64/ANSYS261.exe')
(summary/'identity.json').write_text(json.dumps({'exe':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),
    'threads':1,'mode':'SMP','scope':'One full CMD-to-CDB-and-native-solve invocation per stage; native timers are also retained'},indent=2))
try:
    for rep in (1,2,3):
        rep_tag=f'{tag}-r{rep}'
        for stage,script in [('global','run_mapdl_global.py'),('unit-fine','run_mapdl_local.py')]:
            args=[sys.executable,str(root/script),rep_tag]
            if stage=='unit-fine':args+=['local']
            started=time.time();print('BEGIN',rep,stage,flush=True)
            p=subprocess.run(args,creationflags=subprocess.CREATE_NO_WINDOW)
            row=dict(rep=rep,stage=stage,start_epoch=started,wall_seconds=time.time()-started,exit=p.returncode,
                tag=rep_tag,scope='External conversion + mapping (local only) + CDB + native solve/export wall time')
            records.append(row)
            (summary/f'r{rep}-{stage}.json').write_text(json.dumps(row,indent=2))
            print('END',json.dumps(row),flush=True)
            if p.returncode:raise RuntimeError('Native pipeline failed; no performance score')
    (summary/'exit.json').write_text(json.dumps({'exit':0,'runs':records},indent=2))
except BaseException as error:
    (summary/'exit.json').write_text(json.dumps({'exit':1,'error':str(error),'runs':records},indent=2));raise
