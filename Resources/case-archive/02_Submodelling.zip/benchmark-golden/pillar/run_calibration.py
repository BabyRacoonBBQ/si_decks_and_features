"""Matched native global/local pipeline, calibration only until recovery audited."""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess, time
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011')
tag='calibration-a'
out=root/tag
lock=open('/tmp/geo3d-sinterconnect-heavy.lock','w')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
out.mkdir(exist_ok=False)
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TDR_VERSION='16')
for key in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(key,None)
bins={'vendor':Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect'),
      'stressthermal':Path('/home/mozztcad/geo3d/build/sinterconnect_run')}
try:
    for tool,binary in bins.items():
        d=out/tool;shutil.copytree(root/'prepared',d)
        for stage in ('global','unit-fine'):
            cmd=d/(stage+'.cmd')
            text=cmd.read_text()
            text+='\nputs "BENCH_MISES_CURRENT [select max name=MisesStress]"\n'
            cmd.write_text(text)
            args=['/usr/bin/time','-v','timeout','-k','10','900','taskset','-c','4',str(binary)]
            if tool=='vendor':args+=['--noSyntaxCheck']
            args+=[cmd.name]
            print('BEGIN',tool,stage,flush=True)
            start=time.time()
            with (d/(stage+'-stdout.log')).open('w') as stdout,(d/(stage+'-stderr.log')).open('w') as stderr,(d/(stage+'-load.log')).open('w') as load:
                monitor=subprocess.Popen(['vmstat','1'],stdout=load)
                try:p=subprocess.run(args,cwd=d,env=env,stdout=stdout,stderr=stderr)
                finally:monitor.terminate();monitor.wait()
            row=dict(tool=tool,stage=stage,exit=p.returncode,wall_s=time.time()-start,
                     binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                     deck_sha256=hashlib.sha256(cmd.read_bytes()).hexdigest())
            (d/(stage+'-run.json')).write_text(json.dumps(row,indent=2))
            print('END',json.dumps(row),flush=True)
            if p.returncode:raise RuntimeError('Native calibration failed; inspect logs')
    (out/'exit.json').write_text(json.dumps({'exit':0}))
except BaseException as error:
    (out/'exit.json').write_text(json.dumps({'exit':1,'error':str(error)}))
    raise
