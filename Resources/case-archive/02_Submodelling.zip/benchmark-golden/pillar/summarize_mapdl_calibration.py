"""Compare real global/local native results without assigning performance scores."""
from pathlib import Path
import hashlib,json,sys
import h5py,numpy as np
root=Path(__file__).resolve().parent
tag=sys.argv[1]
local_tag=sys.argv[2] if len(sys.argv)>2 else 'local-b'
result=json.loads((root/'calibration-summary.json').read_text())
rows=[]
for stage,run in [('global',root/'mapdl'/tag/'mechanics'),
                  ('unit-fine',root/'mapdl'/tag/local_tag/'mechanics')]:
    meta=json.loads((run/'run.json').read_text())
    if meta['exit']!=0:raise ValueError('Incomplete native solve')
    recovery=json.loads((run/'regionwise-recovery.json').read_text())
    raw=np.loadtxt(run/'displacement.txt');u={int(row[0]):row[1:] for row in raw}
    errors=[];scale=0
    with h5py.File(root/'calibration-a/vendor'/(stage+'_sis.tdr')) as f:
        g=f['collection/geometry_0']
        for d in g['state_0'].values():
            if d.attrs.get('name')!=b'StepDisplacement':continue
            r=g['region_'+str(int(d.attrs['region']))]
            if int(r.attrs['type'])!=0 or r.attrs.get('material')==b'Gas':continue
            ids=np.unique(r['elements_0'][:].reshape(-1,5)[:,1:])
            ref=d['values'][:].reshape(-1,3)*10
            actual=np.array([u[int(i)+1] for i in ids])
            errors.append(float(np.max(np.abs(actual-ref))))
            scale=max(scale,float(np.max(np.abs(ref))))
    ref=next(r['maximum_mises_MPa'] for r in result['vendor'] if r['stage']==stage)
    stress=recovery['maximum']['maximum_mises_MPa']
    rows.append({'stage':stage,'run':str(run),'maximum_mises_MPa':stress,
        'maximum_mises_difference_MPa':stress-ref,
        'maximum_mises_relative_difference_percent':100*(stress-ref)/ref,
        'maximum_nodal_displacement_difference_mm':max(errors),
        'displacement_relative_component_error':max(errors)/scale,
        'cdb_sha256':meta['cdb_sha256'],'exit':meta['exit']})
result['mapdl']={'status':'global and own-displacement local calibration completed',
    'scope':'Accuracy calibration only; formal repeated load-recorded performance pending',
    'vendor_displacements_used':False,'runs':rows}
(root/'calibration-summary.json').write_text(json.dumps(result,indent=2))
(root/'mapdl'/tag/'accuracy-summary.json').write_text(json.dumps(result['mapdl'],indent=2))
print(json.dumps(result['mapdl'],indent=2))
