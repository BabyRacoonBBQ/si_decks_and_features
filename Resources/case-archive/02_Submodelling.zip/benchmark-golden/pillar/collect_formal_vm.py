"""Collect completed measurement evidence; never alter or restart remote work."""
from pathlib import Path
import json,sys,subprocess
root=Path(__file__).resolve().parent;tag=sys.argv[1]
if not all(c.isalnum() or c in '-_' for c in tag):raise ValueError('Invalid tag')
host=root/'host-vm'/tag
if json.loads((host/'exit.json').read_text())['exit']!=0:raise ValueError('Measurement runner did not complete')
out=root/'vm'/tag;out.mkdir(parents=True,exist_ok=True)
remote=f'mozztcad@192.168.43.128:/home/mozztcad/si-bench/golden-pillar-20261011/{tag}'
for name in ('environment.json','exit.json'):
    subprocess.run(['scp',f'{remote}/{name}',str(out/name)],check=True)
records=json.loads((out/'exit.json').read_text())['runs']
for folder in sorted({f"r{r['rep']}-{r['tool']}" for r in records}):
    d=out/folder;d.mkdir(exist_ok=True)
    for pattern in ('*-run.json','*-stdout.log','*-stderr.log','*-load*.txt','*.cmd'):
        subprocess.run(['scp',f'{remote}/{folder}/{pattern}',str(d)],check=True)
    if folder in ('r1-vendor','r1-stressthermal'):
        for name in ('global_sis.tdr','unit-fine_sis.tdr'):
            subprocess.run(['scp',f'{remote}/{folder}/{name}',str(d/name)],check=True)
print(out)
