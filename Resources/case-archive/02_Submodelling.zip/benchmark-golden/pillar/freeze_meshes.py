"""Run original mesh recipes once, saving BEFORE cooling or displacement mapping.

This is preparation, never a performance sample. Run on the benchmark VM.
"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess, time

source = Path('/home/mozztcad/tmp/flipchip-array-20261010')
target = Path('/home/mozztcad/si-bench/golden-pillar-20261011/freeze')
binary = Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect')
lock = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
target.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TDR_VERSION='16')
for key in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):
    env.pop(key, None)
manifest = {'purpose': 'Pre-solve mesh preparation; not benchmark timing', 'runs': []}
try:
    for name in ('assembled_bnd.tdr', 'unit_bnd.tdr', 'datexcodes.txt'):
        if (source/name).exists():
            shutil.copy2(source/name, target/name)
    for stage in ('global', 'unit-fine'):
        text = (source/(stage+'.cmd')).read_text()
        assert text.count('grid remesh') == 1
        # End immediately after meshing: no imported displacement, temperature,
        # stress state or solve can enter the frozen artifact.
        deck = text.split('grid remesh', 1)[0] + 'grid remesh\n'
        deck += 'struct tdr=' + stage + '-mesh\nexit\n'
        deck = 'math numThreads=1\n' + deck
        (target/(stage+'-freeze.cmd')).write_text(deck)
        start = time.time()
        with (target/(stage+'-stdout.log')).open('w') as out, (target/(stage+'-stderr.log')).open('w') as err:
            p = subprocess.run(['timeout','-k','10','900','taskset','-c','4',str(binary),'--noSyntaxCheck',stage+'-freeze.cmd'], cwd=target, env=env, stdout=out, stderr=err)
        result = dict(stage=stage, exit=p.returncode, preparation_wall_s=time.time()-start,
                      source_sha256=hashlib.sha256((source/(stage+'.cmd')).read_bytes()).hexdigest())
        manifest['runs'].append(result)
        (target/'manifest.json').write_text(json.dumps(manifest, indent=2))
        print(json.dumps(result), flush=True)
        if p.returncode:
            raise RuntimeError('Mesh preparation failed; inspect logs')
        assert (target/(stage+'-mesh_sis.tdr')).is_file()
    (target/'exit.json').write_text(json.dumps({'exit':0}))
except BaseException as error:
    (target/'exit.json').write_text(json.dumps({'exit':1, 'error':str(error)}))
    raise
