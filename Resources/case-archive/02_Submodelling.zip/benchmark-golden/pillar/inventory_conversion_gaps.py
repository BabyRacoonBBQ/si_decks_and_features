"""Diagnostic parser inventory only. Never emits Ix or a target solver deck.

Continue after an unsupported handler to expose later missing declarations;
this is NOT proof that the remaining, unreported semantics are supported.
"""
from pathlib import Path
import json,sys
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from converter_core.cmd_reader.cmd_reader import CmdReader
root=Path(__file__).parent
class DiagnosticReader(CmdReader):
    def __init__(self):super().__init__();self.gaps=[]
    def _command_handlers(self,model):
        handlers=super()._command_handlers(model)
        def wrap(name,handler):
            def record(args):
                try:return handler(args)
                except Exception as e:
                    self.gaps.append({'command':name,'arguments':list(args),'error':str(e)})
                    return ''
            return record
        return {name:wrap(name,handler) for name,handler in handlers.items()}
result={}
for stage in ('global','unit-fine'):
    reader=DiagnosticReader()
    reader._parse_cmd(str(root/'prepared'/(stage+'.cmd')))
    result[stage]=reader.gaps
report={'scope':'Diagnostic only; conversion remains fail-closed. This inventory is not exhaustive target validation.', 'gaps':result}
(root/'conversion-gap-inventory.json').write_text(json.dumps(report,indent=2))
for stage,rows in result.items():
    print(stage)
    for message in dict.fromkeys(row['error'] for row in rows):print(' ',message)
