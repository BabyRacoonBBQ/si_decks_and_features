"""Native global-model calibration using the shared target driver and converter."""
from pathlib import Path
import sys,json,hashlib,time
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent))
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from run_mapdl import run
from converter_core.conversion.deserialize import CmdToIxDeserializer

tag=sys.argv[1]
output=root/'mapdl'/tag
output.mkdir(parents=True,exist_ok=False)
source=root/'prepared/global.cmd'
reader=CmdToIxDeserializer()
started=time.perf_counter();ix=reader.deserialize(source)
conversion_seconds=time.perf_counter()-started
(output/'conversion.json').write_text(json.dumps({'input':str(source),
    'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'warnings':reader.warnings,'conversion_seconds':conversion_seconds,'scope':'CMD-to-neutral-model preparation; native timing recorded separately'},indent=2))
run('mechanics',ix,output)
