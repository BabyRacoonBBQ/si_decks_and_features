"""Affine patch test with an unconstrained interior node and mapped exterior."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
import numpy as np
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from tests.test_submodel_transfer import mesh,XYZ
from converter_core.submodel_transfer import transfer_surface_displacements
from converter_core.input.ix_data import IxData
from converter_core.input.ix_material import IxMaterial
from converter_core.input.ix_elastic import IxIsoElastic,IxCubicElastic
from converter_core.input.ix_section import IxSection,SectionTypeEnum
from converter_core.input.ix_set import IxListedSet
from converter_core.input.ix_step import IxStep
from converter_core.input.ix_procedure import IxStaticProcedure
from converter_core.conversion.serialize import IxDataSerializer
root=Path(__file__).parent/(sys.argv[1] if len(sys.argv)>1 else 'mapped-boundary-native')
root.mkdir(exist_ok=False)
m=mesh();local_xyz=XYZ*.4+.1
for row,x in zip(m.nodes[0]._data,local_xyz):row[1:]=x.tolist()
for row in m.elements[0]._data:
    x=local_xyz[np.array(row[1:])-1]
    if np.linalg.det(x[1:]-x[0])<0:row[1],row[2]=row[2],row[1]
gradient=np.array([[.001,.0002,0],[.0001,-.0003,.0004],[0,.0002,.0005]])
translation=np.array([.002,-.003,.004])
source=XYZ[:4]
sets,bcs=transfer_surface_displacements(m,source,np.array([[0,1,2,3]]),source@gradient.T+translation)
assert len(bcs)==4 and 5 not in {s.data[0] for s in sets}
m.node_sets.extend(sets);m.element_sets.append(IxListedSet('Solid',[1,2,3,4]))
ix=IxData();ix.mesh=m
elastic=IxIsoElastic(1e9,.25)
if len(sys.argv)>2 and sys.argv[2]=='cubic':
    q=2**-.5
    elastic=IxCubicElastic(165.7e9,63.9e9,79.6e9,crystal_to_global=[[0,0,1],[q,q,0],[-q,q,0]])
ix.materials=[IxMaterial('Elastic',elastic=elastic)]
ix.sections=[IxSection(SectionTypeEnum.SOLID,['Solid'],'Elastic','Solid')]
step=IxStep('Patch',IxStaticProcedure());step.boundaries=bcs;ix.steps=[step]
IxDataSerializer.write(ix,root/'model.cdb')
driver=(Path(__file__).parent/'point-spc-host-verified/solve.inp').read_text()
driver=driver.replace('ARRAY,4','ARRAY,5')
start=driver.index('*GET,vx,ELEM,1,ETAB,sx')
end=driver.index('*CFCLOS',start)+len('*CFCLOS')
driver=driver[:start]+'''*CFOPEN,stress,txt
*DO,elemnum,1,4
*GET,vx,ELEM,elemnum,ETAB,sx
*GET,vy,ELEM,elemnum,ETAB,sy
*GET,vz,ELEM,elemnum,ETAB,sz
*GET,vxy,ELEM,elemnum,ETAB,sxy
*GET,vyz,ELEM,elemnum,ETAB,syz
*GET,vxz,ELEM,elemnum,ETAB,sxz
*VWRITE,vx,vy,vz,vxy,vyz,vxz
(6E26.17)
*ENDDO
*CFCLOS'''+driver[end:]
(root/'solve.inp').write_text(driver)
exe=Path(r'D:/Program Files/ANSYS Inc/v261/ansys/bin/winx64/ANSYS261.exe')
started=time.time()
with (root/'launcher.log').open('wb') as launcher:
    p=subprocess.run([str(exe),'-b','-smp','-np','1','-j','verify','-i','solve.inp','-o','solve.out'],cwd=root,
        stdout=launcher,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,timeout=180)
report={'exit':p.returncode,'wall_s':time.time()-started,'cdb_sha256':hashlib.sha256((root/'model.cdb').read_bytes()).hexdigest()}
(root/'run.json').write_text(json.dumps(report,indent=2))
log=(root/'solve.out').read_text(errors='replace')
assert p.returncode==0 and '*** ERROR ***' not in log and '*** FATAL ***' not in log
u=np.loadtxt(root/'displacement.txt');s=np.loadtxt(root/'stress.txt')
assert u.shape==(5,3) and s.shape==(4,6)
strain=(gradient+gradient.T)/2
stress=2*400*strain+400*np.trace(strain)*np.eye(3) # E=1000 MPa, nu=.25
expected=np.array([stress[0,0],stress[1,1],stress[2,2],stress[0,1],stress[1,2],stress[0,2]])
if isinstance(elastic,IxCubicElastic):
    strain_vector=np.array([strain[0,0],strain[1,1],strain[2,2],2*strain[0,1],2*strain[1,2],2*strain[0,2]])
    expected=elastic.stiffness_matrix()@strain_vector*1e-6
uerror=float(np.max(np.abs(u-(local_xyz@gradient.T+translation))))
serror=float(np.max(np.abs(s-expected)))
report.update(status='passed' if uerror<1e-12 and serror<max(1e-7,np.max(np.abs(expected))*1e-7) else 'failed',
    constrained_nodes=4,free_interior_node=5,maximum_displacement_error_mm=uerror,
    expected_stress_MPa=expected.tolist(),maximum_stress_error_MPa=serror)
(root/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
assert report['status']=='passed'
