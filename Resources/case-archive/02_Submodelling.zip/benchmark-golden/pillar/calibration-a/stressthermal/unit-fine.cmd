math numThreads=1
# Set Global material Parameters
# --------------------------------------------------------

set EUnderfill 10e10
set LCTEUnderfill 35e-6
set CTESUB 25.0e-6
set EBump 111.5e10
set LCTEBump 17.7e-6

# Define the coordinate system
# and define the simulation mode
# --------------------------------------------------------

math coord.ucs
math ils
pdbSet InfoDefault 1

mode mechanics

# Set the mechanics options
# --------------------------------------------------------

pdbSet Mechanics EtchDepoRelax 0
pdbSet Mechanics StressHistory 0
pdbSet Grid AddGasMesh 0
pdbSetDouble Mechanics RefThExpCoeff 0.0

pdbSet Mechanics Calculate.Principal.Stress 1
pdbSet Mechanics SaveMaxStress 1
pdbSet Mechanics MaxIterations 20
pdbSet Mechanics Convergence.Force.Tolerance 1e-3
pdbSet Mechanics Convergence.Energy.Tolerance 1e-3

# Set SNMesh options
# --------------------------------------------------------

pdbSetBoolean Grid No3DMerge 1
pdbSetBoolean Grid No3DSwap 1
pdbSetBoolean Grid Adaptive 0
pdbSet Mechanics Merge.Vertices 1
pdbSet Mechanics Boundary.Method.Type MatrixReduction

pdbSet Grid sMesh 1
pdbSet Mechanics FiniteElementOrder 1


pdbSet Grid SnMesh MaxPoints 5000000


pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Step.Displacement 1
pdbSet Mechanics Save.Total.Displacement 0
# Add the Material Properties
# --------------------------------------------------------
#Define the material parameters for silicon die
pdbSet Silicon Mechanics BulkModulus [Enu2K 162.0e10 0.28]
pdbSet Silicon Mechanics ShearModulus [Enu2G 162.0e10 0.28]
pdbSet Silicon Mechanics ThExpCoeff 3.05e-6
pdbSet Silicon Mechanics C11 165.7e10
pdbSet Silicon Mechanics C12 63.9e10
pdbSet Silicon Mechanics C44 79.6e10
pdbSetBoolean Silicon Mechanics Anisotropic 1
#Define the material parameters for back end smear layer
mater add name= Smear new.like= Nitride
pdbSetDouble Smear   Mechanics BulkModulus  [Enu2K 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ShearModulus [Enu2G 66.5e10 0.29]
pdbSetDouble Smear   Mechanics ThExpCoeff   15.3e-6
pdbSetDouble Smear   Mechanics Vcrit0 1e-30
pdbSetDouble Smear   Mechanics VcritW 0.0
pdbSetDouble Smear   Mechanics Viscosity0 1e40
pdbSetDouble Smear   Mechanics ViscosityW 0.0

# ---------------------------------------------------------------------
#Define the material parameters for Copper pillars
mater add name= BumpMat new.like= Copper
pdbSetDouble BumpMat Mechanics BulkModulus [Enu2K $EBump 0.343]
pdbSetDouble BumpMat Mechanics ShearModulus [Enu2G $EBump 0.343]
pdbSetDouble BumpMat Mechanics ThExpCoeff $LCTEBump
		
# ---------------------------------------------------------------------
#Define the materials parameters for underfill
mater add name= Epoxy new.like= Oxide
pdbSetDouble Epoxy   Mechanics BulkModulus  [Enu2K $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ShearModulus [Enu2G $EUnderfill 0.35]
pdbSetDouble Epoxy   Mechanics ThExpCoeff   $LCTEUnderfill
pdbSetDouble Epoxy   Mechanics Vcrit0 1e-30
pdbSetDouble Epoxy   Mechanics VcritW 0.0
pdbSetDouble Epoxy   Mechanics Viscosity0 1e40
pdbSetDouble Epoxy   Mechanics ViscosityW 0.0
# ---------------------------------------------------------------------
#Define the material parameters for substrate
mater add name= SubMat new.like= Nitride
pdbSetDouble SubMat   Mechanics BulkModulus  [Enu2K 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ShearModulus [Enu2G 11.0e10 0.42]
pdbSetDouble SubMat   Mechanics ThExpCoeff   $CTESUB
pdbSetDouble SubMat   Mechanics Vcrit0 1e-30
pdbSetDouble SubMat   Mechanics VcritW 0.0
pdbSetDouble SubMat   Mechanics Viscosity0 1e40
pdbSetDouble SubMat   Mechanics ViscosityW 0.0
#Define the material parameters for passivation layer
mater add name= Pass new.like= Nitride
pdbSetDouble Pass   Mechanics BulkModulus  [Enu2K 131.0e10 0.22]
pdbSetDouble Pass   Mechanics ShearModulus [Enu2G 131.0e10 0.22]
pdbSetDouble Pass   Mechanics ThExpCoeff   1.9e-6
pdbSetDouble Pass   Mechanics Vcrit0 1e-30
pdbSetDouble Pass   Mechanics VcritW 0.0
pdbSetDouble Pass   Mechanics Viscosity0 1e40
pdbSetDouble Pass   Mechanics ViscosityW 0.0

# Smeared material property for underfill and bumps
# ----------------------------------------------------------------
set distance_1 100.0
set half_distance_1 [expr ($distance_1/2.0)]

set height_1 75.0
set bump_d_1 [expr ((4.0*$height_1)/3.0)]
set bump_r_1 [expr ($bump_d_1/2.0)]

set half_pitch_1 [expr (1.0 * ($bump_r_1+$half_distance_1))]

set pi1 [expr (4.0*atan(1.0))]

set radius_1 $bump_r_1

set radius_2 [expr ($height_1*(sqrt(7.0/36.0)))]

set height_2 [expr (0.5*$height_1)]

set pitch_1 [expr (2.0*$half_pitch_1)]

set volume [expr ($pitch_1*$pitch_1*$height_1)]

set vol_bump [expr ((($pi1*$height_2)/3.0)*((3.0*$radius_1*$radius_1)+(3.0*$radius_2*$radius_2)+($height_2*$height_2)))]

set ratio [expr ($radius_1/$pitch_1)]

set frac_bump [expr ($pi1*($ratio*$ratio))]

set frac_uf [expr (1.0-$frac_bump)]

set frac_uf1 [expr (($volume-$vol_bump)/$volume)]

set EUFSmear [expr (($EBump*$frac_bump)+($EUnderfill*$frac_uf))]

set NUUFSmear [expr ((0.40*$frac_bump)+(0.35*$frac_uf))]

set CTEUFSmear [expr (($LCTEBump*$frac_bump)+($LCTEUnderfill*$frac_uf))]

mater add name= UFSmear new.like= Oxide
pdbSetDouble UFSmear   Mechanics BulkModulus  [Enu2K $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ShearModulus [Enu2G $EUFSmear $NUUFSmear]
pdbSetDouble UFSmear   Mechanics ThExpCoeff   $CTEUFSmear
	
pdbSetDouble UFSmear   Mechanics Vcrit0 1e-30	   
pdbSetDouble UFSmear   Mechanics VcritW 0.0	  
pdbSetDouble UFSmear   Mechanics Viscosity0 1e40  
pdbSetDouble UFSmear   Mechanics ViscosityW 0.0


pdbSet Mechanics Submodel.Add.Global.Stress 0
init tdr=unit-fine-mesh_sis.tdr !load.commands !pdb

stressdata global.model=global_sis.tdr
SetTemp 180.0
solve stress.relax temperature=180.0<C> t.final=25.0<C> delNT=155.0 time=1.0<s> init=1.0<s> maxstep=1.0<s>
struct tdr=unit-fine
