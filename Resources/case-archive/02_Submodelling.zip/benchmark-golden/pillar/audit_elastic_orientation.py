from pathlib import Path
import h5py,numpy as np,json,sys
root=Path(__file__).parent
report={}
input_path=Path(sys.argv[1]) if len(sys.argv)>1 else root/'calibration-a/vendor/global_sis.tdr'
with h5py.File(input_path) as f:
    g=f['collection/geometry_0'];fields={}
    for d in g['state_0'].values():
        if 'values' not in d:continue
        name=d.attrs.get('name',b'').decode();rid=int(d.attrs['region'])
        fields[rid,name]=d['values'][:]
    print('FIELDS',sorted({n for r,n in fields}))
    for k,r in g.items():
        if not k.startswith('region_') or r.attrs.get('material')!=b'Silicon' or int(r.attrs['type'])!=0:continue
        rid=int(k[7:])
        if (rid,'ElasticStrainEL') not in fields:continue
        eps=fields[rid,'ElasticStrainEL'].reshape(-1,6)[:,[0,3,5,1,4,2]]
        sigma=fields[rid,'StressEL'].reshape(-1,6)[:,[0,3,5,1,4,2]]*1e-7
        c=np.zeros((6,6));c[:3,:3]=63900;np.fill_diagonal(c[:3,:3],165700);c[3:,3:]=np.eye(3)*79600
        engineering=eps.copy();engineering[:,3:]*=2
        predicted=engineering@c.T
        report[k]={'max_stress_error_MPa':float(np.max(np.abs(predicted-sigma))),
                   'relative_frobenius_error':float(np.linalg.norm(predicted-sigma)/np.linalg.norm(sigma))}
        report[k]['raw_shear_error_MPa']=float(np.max(np.abs(eps@c.T-sigma)))
        report[k]['fit_matrix_MPa']=np.linalg.lstsq(eps,sigma,rcond=None)[0].T.tolist()
        report[k]['fit_relative_residual']=float(np.linalg.norm(eps@np.linalg.lstsq(eps,sigma,rcond=None)[0]-sigma)/np.linalg.norm(sigma))
        for axis in range(3):
            rotated=c.copy();transverse=[a for a in range(3) if a!=axis]
            for a in transverse:rotated[a,a]=(165700+63900+2*79600)/2
            a,b=transverse;rotated[a,b]=rotated[b,a]=(165700+63900-2*79600)/2
            shear_index={(0,1):3,(1,2):4,(0,2):5}[tuple(transverse)]
            rotated[shear_index,shear_index]=(165700-63900)/2
            predicted=engineering@rotated.T
            report[k]['rotation_45_axis_'+str(axis)]={'max_stress_error_MPa':float(np.max(np.abs(predicted-sigma))),
                'relative_frobenius_error':float(np.linalg.norm(predicted-sigma)/np.linalg.norm(sigma)),
                'engineering_shear_error_MPa':float(np.max(np.abs(eps@rotated.T-sigma)))}
    orientations={}
    def visit(name,obj):
        key=obj.attrs.get('key',b'').decode()
        if key in ('Params&wafer.orient.array','Params&flat.orient.array','Params&slice.angle'):
            orientations[key]={'value':str(obj.attrs.get('value','')),
                               'arrays':{k:obj[k][:].tolist() for k in obj}}
    f.visititems(visit)
    print(json.dumps(orientations,indent=2))
output=Path(sys.argv[2]) if len(sys.argv)>2 else root/'elastic-orientation-audit.json'
output.write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
