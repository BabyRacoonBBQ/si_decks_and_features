"""Audit the complete source reader/boundary materialization on the real case."""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from converter_core.tdr_reader import TdrHdf5Reader
from converter_core.tdr_displacement import submodel_boundaries
from converter_core.common.enum.dof_enum import DOFEnum
root=Path(__file__).parent
start=time.perf_counter()
mesh=TdrHdf5Reader().read(root/'freeze/unit-fine-mesh_sis.tdr')
sets,boundaries=submodel_boundaries(root/'calibration-a/vendor/global_sis.tdr',mesh)
reference=np.load(root/'mapped-boundary-diagnostic.npz')
expected={int(n):u for n,u in zip(reference['node_ids'],reference['displacement_mm'])}
actual={s.data[0]:np.array([b.dof_value_map[d] for d in (DOFEnum.Ux,DOFEnum.Uy,DOFEnum.Uz)])
        for s,b in zip(sets,boundaries)}
assert actual.keys()==expected.keys()
maximum=max(float(np.linalg.norm(actual[n]-expected[n])) for n in actual)
assert maximum<1e-12
report=dict(status='passed',boundary_nodes=len(actual),constraints=3*len(actual),
            maximum_difference_from_independent_mapping_mm=maximum,
            preparation_seconds=time.perf_counter()-start,
            scope='Source TDR to neutral boundaries; not yet full material/deck conversion')
(root/'submodel-adapter-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
