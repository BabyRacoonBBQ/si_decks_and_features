from pathlib import Path
import hashlib,json,sys
import h5py,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from native_timers import *
root=Path(__file__).parent
def fields(path):
    with h5py.File(path) as f:
        g=f['collection/geometry_0']; out={}
        for d in g['state_0'].values():
            name=d.attrs.get('name',b'')
            name=name.decode() if isinstance(name,bytes) else str(name)
            if name not in ('MisesStress','StepDisplacement'):continue
            rid=int(d.attrs['region']); r=g['region_'+str(rid)]
            if int(r.attrs['type'])!=0:continue
            out[rid,name]=d['values'][:]
        return out
rows=[]
for stage in ('global','unit-fine'):
    path=root/'calibration-a/vendor'/(stage+'_sis.tdr')
    a=fields(path); b=fields(root/'inputs'/(stage+'_sis.tdr'))
    assert a.keys()==b.keys()
    stress=[v for (r,n),v in a.items() if n=='MisesStress']
    row={'stage':stage,'result_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'maximum_mises_MPa':max(float(np.max(v))*1e-7 for v in stress),
         'archive_comparison':{}}
    for name,scale in [('MisesStress',1e-7),('StepDisplacement',1e4)]:
        error=max(float(np.max(np.abs(v-b[k])))*scale for k,v in a.items() if k[1]==name)
        norm=max(float(np.max(np.abs(v)))*scale for k,v in b.items() if k[1]==name)
        row['archive_comparison'][name]={'max_abs_difference':error,'relative_to_peak':error/norm if norm else error,
                                           'unit':'MPa' if name=='MisesStress' else 'um'}
    rows.append(row)
result={'scope':'Calibration, not formal performance. Temperature prescribed: 180 C to 25 C.',
        'vendor':rows,'stressthermal':{'status':'failed','stage':'global',
        'error':'sinterconnect::siGeneralBoundary::apply_point_disp is not recovered for standalone execution',
        'run':json.loads((root/'calibration-a/stressthermal/global-run.json').read_text())},
        'mapdl':{'status':'converter extension incomplete','probe':'conversion-probe.json'}}
(root/'calibration-summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
