from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent
d=json.loads((root/'pillar-benchmark.json').read_text())
lines=['# Copper-pillar three-tool benchmark','',
'Global flip-chip package and corner-pillar submodel, cooled from 180 to 25 °C. Temperature is prescribed: this case has no solved maximum-temperature accuracy score. Global mesh: 43,994 vertices / 246,681 tetrahedra; local mesh: 75,969 vertices / 422,904 tetrahedra. Both successful tools map their own global displacement to the local exterior; no Vendor boundary displacement substitutes for a MAPDL global result.','',
'## Accuracy and support','',
'Current von Mises is computed after volume-weighted recovery of the element stress tensor within each original region; interface sides remain separate. This is verified against native Vendor StressEL, Stress and MisesStress. MAPDL uses the same recovery of exported components. Silicon uses the independently verified default rotated cubic stiffness. The explicitly declared high-viscosity source materials use the documented elastic limit; this is not a general viscoelastic benchmark.','',
'| Stage | Sentaurus sinterconnect, MPa | MAPDL, MPa | MAPDL minus Vendor, % |','|---|---:|---:|---:|']
for stage in ('global','unit-fine'):
    a=next(s for s in d['summary'] if s['tool']=='vendor' and s['stage']==stage)
    b=next(s for s in d['summary'] if s['tool']=='mapdl' and s['stage']==stage)
    x,y=a['maximum_mises_MPa'][0],b['maximum_mises_MPa'][0]
    lines.append(f'| {stage} | {x:.9f} | {y:.9f} | {100*(y-x)/x:.9f} |')
lines+=['','StressThermal (Release sinterconnect_run) fails at the original global point-displacement constraint. That constraint is essential to the source model and has not been removed. The failed run has no accuracy value, successful local pipeline, or performance score. The actual exit code, binary/deck hashes and error logs are retained.','',
'Formal repetitions retain scalar peaks for every completed run. The first formal Vendor full fields are checked against the audited calibration, and every MAPDL repetition is recovered from native stress exports. Nodal displacement agreement from calibration is retained in the JSON; peak agreement does not establish continuum accuracy or mesh convergence.','',
'## Performance','',
'Medians and ranges of three completed runs. Native total includes native startup/read/solve/postprocessing; Vendor local also includes displacement mapping, whereas MAPDL mapping and CMD-to-CDB conversion occur outside its native process. Therefore full external stage wall time is shown separately. MAPDL diagnostic exports affect total time; native inclusive solve / computing-solution labels are tool-specific scopes. Do not sum nested module timers or infer an unconditional speedup.','',
'| Tool | Stage | Native total median [range], s | Native solve median [range], s | Full external stage median [range], s |','|---|---|---:|---:|---:|']
fmt=lambda v:f"{v['median']:.3f} [{v['min']:.3f}, {v['max']:.3f}]"
for s in d['summary']:
    lines.append(f"| {s['tool']} | {s['stage']} | {fmt(s['native_total_s'])} | {fmt(s['native_solve_s'])} | {fmt(s['pipeline_stage_wall_s'])} |")
lines+=['','## Recorded load and machine','',
'Windows 11 Home Chinese 10.0.26200 host, i7-13700F (16 cores / 24 logical processors), 16 GiB RAM; VMware Rocky Linux 8.10 guest, 10 vCPU / 12.4 GiB RAM. Vendor and StressThermal use guest CPU 4, one thread; MAPDL 2026 R1 / 26.1 uses host SMP, one requested thread. Host and guest are distinct environments. VM and MAPDL benchmark solves run sequentially. Full guest inventory and solver hashes are in the JSON.','',
'Each VM solve starts after idle/no-swap samples. Any swap activity during a solve remains in the evidence and qualifies that observation; no runs are silently discarded.','',
'| Tool / rep | Stage | Host mean / peak CPU, % | Min available GiB | VM swap-in / out pages |','|---|---|---:|---:|---:|']
for r in d['runs']+d['failures']:
    h=r['host_load'];sw=r.get('swap_pages');swap=f"{sw['pswpin']} / {sw['pswpout']}" if sw else 'Host run'
    lines.append(f"| {r['tool']} / {r['rep']} | {r['stage']} | {h['mean_cpu_percent']:.2f} / {h['peak_cpu_percent']:.2f} | {h['minimum_available_GiB']:.2f} | {swap} |")
lines+=['','## MAPDL preparation','', '| Rep | Stage | Measured preparation intervals, s |','|---|---|---|']
for r in d['runs']:
    if r['tool']=='mapdl':lines.append(f"| {r['rep']} | {r['stage']} | "+'; '.join(f'{k}: {v:.3f}' for k,v in r['preparation'].items())+' |')
lines+=['','## Native module timings','', 'CPU and elapsed tables remain separate; medians below retain native labels.']
for tool in ('vendor','mapdl'):
    for stage in ('global','unit-fine'):
        rows=[r for r in d['runs'] if r['tool']==tool and r['stage']==stage]
        for table in (('module_cpu','module_elapsed') if tool=='vendor' else ('native_stages',)):
            lines+=['',f'### {tool}: {stage}, {table}','','| Native label | Median seconds |','|---|---:|']
            names=sorted({t['label'] for r in rows for t in r['native_timers'][table]})
            for name in names:
                vals=[t['seconds'] for r in rows for t in r['native_timers'][table] if t['label']==name]
                lines.append(f'| {name} | {statistics.median(vals):.3f} |')
lines+=['','## Evidence and reproduction','',
'- `pillar-benchmark.json`: complete measured results, machine identities, repeatability, source-field and stress-recovery audits.',
'- `prepared/*.cmd` and frozen meshes: original physical source semantics; converter creates CDB.',
'- `run_formal_vm.py`, `run_formal_mapdl.py`, parent `monitor_vm_run.py`: sequential runners with load recording.',
'- `run_mapdl_global.py`, `run_mapdl_local.py`: source conversion, explicit MAPDL-owned displacement transfer container, native solve.',
'- `mapdl/*/mechanics/` and `mapdl/*/local/mechanics/`: native decks, logs, results, exported stress components and regional recovery.',
'- `vm/formal-pillar-a/` and `host-vm/formal-pillar-a/`: native Vendor/StressThermal logs, hashes, full first-run fields, system swap and host-load records.',
'- `host-mapdl/`: repeated host-load samples. Conversion/mapping time is not hidden in a native-only speedup.',
'- `summarize_formal.py`, parent `recover_mapdl_calibration.py`: offline regeneration and checks.','']
(root/'pillar-benchmark-report.md').write_text('\n'.join(lines),encoding='utf-8')
print(root/'pillar-benchmark-report.md')
