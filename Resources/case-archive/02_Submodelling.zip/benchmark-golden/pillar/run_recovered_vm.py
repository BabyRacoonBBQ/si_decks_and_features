"""Three measured native pipelines per tool after point-constraint recovery."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,time,shutil,fcntl
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011')
tag=sys.argv[1]
out=root/tag;out.mkdir(exist_ok=False)
lock=open('/tmp/geo3d-sinterconnect-heavy.lock','w')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
bins={'vendor':Path('/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect'),
      'stressthermal':Path('/home/mozztcad/geo3d/build/sinterconnect_run')}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TDR_VERSION='16',PYTHONNOUSERSITE='1')
for key in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(key,None)
inventory={k:subprocess.check_output(cmd,text=True) for k,cmd in {
    'os':['cat','/etc/os-release'],'cpu':['lscpu'],'memory':['free','-b'],'kernel':['uname','-a'],
    'source_commit':['git','-C','/home/mozztcad/geo3d','rev-parse','HEAD'],
    'source_dirty':['git','-C','/home/mozztcad/geo3d','status','--short']}.items()}
inventory.update(binary_sha256={k:sha(p) for k,p in bins.items()},affinity_cpu=4,threads=1)
repo=Path('/home/mozztcad/geo3d')
inventory['build_type']=[line for line in (repo/'build/CMakeCache.txt').read_text().splitlines() if line.startswith('CMAKE_BUILD_TYPE:')]
if inventory['build_type']!=['CMAKE_BUILD_TYPE:STRING=Release']:raise RuntimeError('Expected Release build')
inventory['recovery_source_sha256']={str(p.relative_to(repo)):sha(p) for p in [repo/'src/abi/floops/floops/GeneralBoundary.cpp',repo/'src/abi/floops/floops/GeneralBoundary.h',repo/'cmake/geo_libraries.cmake',repo/'cmake/rcfx_standalone.cmake']}

(out/'environment.json').write_text(json.dumps(inventory,indent=2))
def swap():
    return {r.split()[0]:int(r.split()[1]) for r in Path('/proc/vmstat').read_text().splitlines() if r.startswith(('pswpin ','pswpout '))}
def settle(d,stage):
    for attempt in range(12):
        s=subprocess.check_output(['vmstat','1','6'],text=True)
        (d/f'{stage}-load-before-{attempt}.txt').write_text(s)
        rows=[list(map(int,r.split())) for r in s.splitlines() if r.split() and r.split()[0].isdigit()][1:]
        if rows and all(r[6]==0 and r[7]==0 and r[14]>=95 for r in rows):return
    raise RuntimeError('VM not idle; no new solve launched')
records=[]
try:
    for rep in (1,2,3):
        for tool in ('vendor','stressthermal'):
            d=out/f'r{rep}-{tool}';shutil.copytree(root/'prepared',d)
            for stage in ('global','unit-fine'):
                cmd=d/(stage+'.cmd')
                cmd.write_text(cmd.read_text()+'\nputs "BENCH_MISES_CURRENT [select max name=MisesStress]"\n')
                settle(d,stage)
                if sha(bins[tool])!=inventory['binary_sha256'][tool]:raise RuntimeError('Binary changed')
                before=swap();start=time.time()
                args=['/usr/bin/time','-v','timeout','-k','10','900','taskset','-c','4',str(bins[tool])]
                if tool=='vendor':args+=['--noSyntaxCheck']
                args+=[cmd.name]
                print('BEGIN',rep,tool,stage,flush=True)
                with (d/f'{stage}-stdout.log').open('w') as stdout,(d/f'{stage}-stderr.log').open('w') as stderr,(d/f'{stage}-load.txt').open('w') as load:
                    monitor=subprocess.Popen(['vmstat','1'],stdout=load)
                    try:p=subprocess.run(args,cwd=d,env=env,stdout=stdout,stderr=stderr)
                    finally:monitor.terminate();monitor.wait()
                after=swap()
                record=dict(rep=rep,tool=tool,stage=stage,exit=p.returncode,start_epoch=start,
                    wall_seconds=time.time()-start,swap_before=before,swap_after=after,
                    timing_no_vm_swap=before==after,binary_sha256=sha(bins[tool]),deck_sha256=sha(cmd),
                    global_input_sha256=sha(d/'global_sis.tdr') if stage=='unit-fine' else None,
                    result_sha256=sha(d/(stage+'_sis.tdr')) if (d/(stage+'_sis.tdr')).exists() else None,
                    mesh_sha256=sha(d/(stage+'-mesh_sis.tdr')))
                (d/f'{stage}-run.json').write_text(json.dumps(record,indent=2));records.append(record)
                print('END',json.dumps(record),flush=True)
                if p.returncode:
                    raise RuntimeError('Formal pipeline failed: '+tool+' '+stage)
                if not (d/(stage+'_sis.tdr')).exists():raise RuntimeError('Missing native result')
    (out/'exit.json').write_text(json.dumps({'exit':0,'scope':'All twelve native stages completed successfully','runs':records},indent=2))
except BaseException as error:
    (out/'exit.json').write_text(json.dumps({'exit':1,'error':str(error),'runs':records},indent=2));raise
