from pathlib import Path
p=Path('/tmp/run_rate_regression.py');s=p.read_text().replace('rate-regression-b','rate-regression-c').replace("for case in ['node','face']:","for case in ['face']:")
s=s.replace("base.replace('{$xmin 0.0 0.0}','{$xmin 17.0 19.0}')", "base.replace('init tdr=global-mesh_sis.tdr', 'stressdata bc.location=FacePoint point.coord= {$xmin 17.0 19.0} bc.value= {pdx=2e-4<cm/s>}\\ninit tdr=global-mesh_sis.tdr')")
p.write_text(s)
