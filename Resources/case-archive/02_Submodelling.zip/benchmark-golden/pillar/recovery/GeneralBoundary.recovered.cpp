// SPDX-License-Identifier: 0BSD
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <iterator>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "abi/FE/FE/BaseMaterialModel.h"
#include "abi/FE/FE/BeamProbHandler.h"
#include "abi/FE/FE/CompositeSolidShell.h"
#include "abi/FE/FE/FiniteElement.h"
#include "abi/FE/FE/LinearHex.h"
#include "abi/FE/FE/P1Tri.h"
#include "abi/FE/FE/P2Tri.h"
#include "abi/FE/FE/Q1Quad.h"
#include "abi/FE/FE/P2Quad.h"
#include "abi/floops/floops/Matrix.h"
#include "abi/floops/floops/Vector.h"
#include "abi/FE/FE/MechanicsAssembler.h"
#include "abi/TcadBase/TcadBase/Identity.h"
#include "abi/TcadBase/TcadBase/Messages.h"
#include "abi/TcadBase/TcadBase/OutputObject.h"
#include "abi/TcadBase/TcadBase/Seq.h"
#include "abi/floops/floops/BaseData.h"
#include "abi/floops/floops/BasicSingleStiff.h"
#include "abi/floops/floops/Contact.h"
#include "abi/floops/floops/Coordinate.h"
#include "abi/floops/floops/DeviceGlobals.h"
#include "abi/floops/floops/Edge.h"
#include "abi/floops/floops/Element.h"
#include "abi/floops/floops/FLPS.h"
#include "abi/floops/floops/Face.h"
#include "abi/floops/floops/FieldServer.h"
#include "abi/floops/floops/GeneralBoundary.h"
#include "abi/floops/floops/GlobalObject.h"
#include "abi/floops/floops/GlobalSim.h"
#include "abi/floops/floops/IntData.h"
#include "abi/floops/floops/Interpolator.h"
#include "abi/floops/floops/JobInfo.h"
#include "abi/floops/floops/LocationData.h"
#include "abi/floops/floops/Material.h"
#include "abi/floops/floops/MechPDE.h"
#include "abi/floops/floops/MechParams.h"
#include "abi/floops/floops/MechState.h"
#include "abi/floops/floops/Mesh.h"
#include "abi/floops/floops/Node.h"
#include "abi/floops/floops/Node2.h"
#include "abi/floops/floops/OEdge.h"
#include "abi/floops/floops/RealData.h"
#include "abi/floops/floops/SPDDDInterface.h"
#include "abi/floops/floops/StructSpec.h"
#include "abi/floops/floops/StructureManager.h"
#include "abi/floops/floops/StructureWriter.h"
#include "abi/floops/floops/SymTensorData.h"
#include "abi/floops/floops/Tdr_reader.h"
#include "abi/floops/floops/Tee.h"
#include "abi/floops/floops/VelocitySolution.h"
#include "abi/mgoals/mgoals/GeometryPolicy.h"
#include "abi/mgoals/mgoals/Intersects2d.h"
#include "abi/mgoals/mgoals/Intersects3d.h"
#include "abi/mgoals/mgoals/Segment.h"
#include "abi/mgoals/mgoals/Triangle.h"
#include "abi/pdblib/PdbCompat.h"

#include "common/VofString.h"

namespace floops {

namespace {

[[noreturn]] void unrecoveredBoundaryBranch(const char* function) {
    throw std::runtime_error(std::string(function) + VOF_STR(" is not recovered for standalone execution"));
}

// 旧式力学边条的一次性提醒开关：整个进程只提醒一次，初值为真。
bool deprecatedBCWarningPending = true;

/**
 * @brief 把全局模型场服务器上的场改名成 `<原名>__SubModel`，并清掉上一轮的残留。
 *
 * 两处循环都「改一个就从头再扫」——真身如此：deleteme/SetName 会让 dataList 塌陷，
 * 继续用旧下标会漏项。
 */
void renameGlobalDataFields(FieldServer& fieldServer, const std::vector<std::string>& fields) {
    // 三条日志各自重取一次 tee：真身在本函数里对 GlobalSim +0x50 共 7 次访问，
    // ＝ 本助手内联两份 × 3 ＋ 尾部 verbosity() 的 1；缓存成 `Tee&` 会塌成 2。
    *globalSimObject().tee << teeInfoLevelCommand << tendl;
    *globalSimObject().tee << teeInfoLevelCommand << VOF_STR("Renaming global data fields...") << tendl;

    const std::string suffix(VOF_STR("__SubModel"));
    // 真身**一份助手只构造一个** Iter<BaseData>（栈上一处 vtable 写入），两个循环复用它，
    // 「改一个就从头再扫」靠把游标打回起点来表达（真身直接写游标，等价于 reset()）。
    TcadBase::Iter<BaseData> dataIter(fieldServer.dataList);
    while (dataIter++) {
        BaseData* const data = dataIter.current_pointer();
        if (std::string(data->Name()).find(suffix) != std::string::npos) {
            data->deleteme();
            dataIter.reset();
        }
    }

    dataIter.reset();
    while (dataIter++) {
        BaseData* const data = dataIter.current_pointer();
        const std::string name(data->Name());
        if (std::find(fields.begin(), fields.end(), name) == fields.end()) {
            continue;
        }
        *globalSimObject().tee << teeInfoLevelCommand << data->Name() << tendl;
        const std::string renamed = name + suffix;
        data->SetName(renamed.c_str(), 0);
        dataIter.reset();
    }
}
}  // namespace

GeneralBoundary::GeneralBoundary(VelocitySolution& velocity, GrowthType growth, MechState& state)
    : velocitySolution_(&velocity),
      growth_(growth),
      noLateralConstraint_(true),
      dirichletValue_(1.0e12),
      mechState_(&state),
      bcScale_(1.0) {
    GlobalSim& sim = globalSimObject();
    feOrder_ = sim.fieldServer->feSimulationOrder_;

    if (pdblib::pdbIsAvailable(sim.interpreter->interpreter, VOF_STR("Mechanics"), VOF_STR("Use.FE.Library"), pdblib::PDB0)) {
        useFELibrary_ = pdblib::pdbgetBoolean(globalSimObject().interpreter->interpreter, VOF_STR("Mechanics"), VOF_STR("Use.FE.Library"),
                                              pdblib::PDB0) != 0;
    }

    // 维度只认 1/2/3，其余一律归 0。
    switch (globalSimObject().fieldServer->dimension) {
        case 1:
            dimension_ = 1;
            break;
        case 2:
            dimension_ = 2;
            break;
        case 3:
            dimension_ = 3;
            break;
        default:
            dimension_ = 0;
            break;
    }
}

GeneralBoundary::~GeneralBoundary() = default;

void GeneralBoundary::identifyBCs(const std::shared_ptr<FieldServer>& fieldServer, bool flag) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    // 入口先把底面放开标记、四个边界开关与线性位移参数清干净。
    bottomAutoFree_ = false;
    for (bool& active : boundaryActive_) {
        active = false;
    }
    for (auto& displacement : boundaryDisp_) {
        for (double& value : displacement) {
            value = 0.0;
        }
    }
    if (flag) {
        return;
    }

    const int dimension = fieldServer->dimension;

    // 新式写法：每个命名边界一个 BoundaryCondition 开关串。四个都先取出来，
    // 用不用由维度决定。
    const std::string left =
        pdblib::pdbgetSwitchString(interpreter, VOF_STR("Mechanics"), VOF_STR("Left"), VOF_STR("BoundaryCondition"), pdblib::PDB0);
    const std::string right =
        pdblib::pdbgetSwitchString(interpreter, VOF_STR("Mechanics"), VOF_STR("Right"), VOF_STR("BoundaryCondition"), pdblib::PDB0);
    const std::string front =
        pdblib::pdbgetSwitchString(interpreter, VOF_STR("Mechanics"), VOF_STR("Front"), VOF_STR("BoundaryCondition"), pdblib::PDB0);
    const std::string back =
        pdblib::pdbgetSwitchString(interpreter, VOF_STR("Mechanics"), VOF_STR("Back"), VOF_STR("BoundaryCondition"), pdblib::PDB0);

    if (dimension > 1) {
        // 开关串等于 HomNeumann 即该面自由；否则按三个线性位移参数取值。
        boundaryActive_[0] = (left == std::string(VOF_STR("HomNeumann")));
        boundaryActive_[1] = (right == std::string(VOF_STR("HomNeumann")));
        if (!boundaryActive_[0]) {
            boundaryDisp_[0][0] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Left"), VOF_STR("Translation"), pdblib::PDB0);
            boundaryDisp_[0][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Left"), VOF_STR("Rotation"), pdblib::PDB0);
            boundaryDisp_[0][2] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Left"), VOF_STR("AxisLocation"), pdblib::PDB0);
        }
        if (!boundaryActive_[1]) {
            boundaryDisp_[1][0] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Right"), VOF_STR("Translation"), pdblib::PDB0);
            boundaryDisp_[1][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Right"), VOF_STR("Rotation"), pdblib::PDB0);
            boundaryDisp_[1][2] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Right"), VOF_STR("AxisLocation"), pdblib::PDB0);
        }
        if (dimension != 2) {
            boundaryActive_[2] = (front == std::string(VOF_STR("HomNeumann")));
            boundaryActive_[3] = (back == std::string(VOF_STR("HomNeumann")));
            if (!boundaryActive_[2]) {
                boundaryDisp_[2][0] =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Front"), VOF_STR("Translation"), pdblib::PDB0);
                boundaryDisp_[2][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Front"), VOF_STR("Rotation"), pdblib::PDB0);
                boundaryDisp_[2][2] =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Front"), VOF_STR("AxisLocation"), pdblib::PDB0);
            }
            if (!boundaryActive_[3]) {
                boundaryDisp_[3][0] =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Back"), VOF_STR("Translation"), pdblib::PDB0);
                boundaryDisp_[3][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Back"), VOF_STR("Rotation"), pdblib::PDB0);
                boundaryDisp_[3][2] =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Back"), VOF_STR("AxisLocation"), pdblib::PDB0);
            }
        }
    }

    // 旧式写法：deck 里只要还有一处 BC 子树的键在起作用，就整体改走旧式一路。
    // 判据按真身的短路次序排；任一命中即成立。
    const bool legacyBCInUse =
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("NeumannOn"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("NeumannOn"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Neumann"), VOF_STR("Homogeneous"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Neumann"), VOF_STR("Homogeneous"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("NeumannOn"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("NeumannOn"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Neumann"), VOF_STR("Homogeneous"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Neumann"), VOF_STR("Homogeneous"), pdblib::PDB0) ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Dirichlet"), VOF_STR("Translation"), pdblib::PDB0) != 0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Dirichlet"), VOF_STR("Rotation"), pdblib::PDB0) != 0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Dirichlet"), VOF_STR("AxisLocation"), pdblib::PDB0) !=
            0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Dirichlet"), VOF_STR("Translation"), pdblib::PDB0) !=
            0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Dirichlet"), VOF_STR("Rotation"), pdblib::PDB0) != 0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Dirichlet"), VOF_STR("AxisLocation"), pdblib::PDB0) !=
            0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Dirichlet"), VOF_STR("Translation"), pdblib::PDB0) !=
            0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Dirichlet"), VOF_STR("Rotation"), pdblib::PDB0) != 0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Dirichlet"), VOF_STR("AxisLocation"), pdblib::PDB0) !=
            0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Dirichlet"), VOF_STR("Translation"), pdblib::PDB0) != 0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Dirichlet"), VOF_STR("Rotation"), pdblib::PDB0) != 0.0 ||
        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Dirichlet"), VOF_STR("AxisLocation"), pdblib::PDB0) != 0.0;

    if (legacyBCInUse) {
        if (deprecatedBCWarningPending) {
            if (*TcadBase::Messages::vLevel()) {
                std::stringstream message;
                message << VOF_STR("You are using old mechanical BC settings. These settings have been deprecated. "
                           "Please use:\npdbSet Mechanics <Left | Right | Back | Front> BoundaryCondition "
                           "<HomNeumann | PlanarNeumann | Dirichlet>\npdbSet Mechanics <Left | Right | Back | "
                           "Front> <Translation | Rotation | AxisLocation> <n> \ncommands");
                TcadBase::Messages::getOutputObject().t_warn(message.str());
            }
            deprecatedBCWarningPending = false;
        }

        // 旧式一路整体覆盖上面按新式取到的结果。
        if (dimension > 1) {
            boundaryActive_[0] =
                pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("NeumannOn"), pdblib::PDB0) != 0;
            boundaryActive_[1] =
                pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("NeumannOn"), pdblib::PDB0) != 0;
            if (!boundaryActive_[0]) {
                boundaryDisp_[0][0] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Dirichlet"),
                                                           VOF_STR("Translation"), pdblib::PDB0);
                boundaryDisp_[0][1] =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Dirichlet"), VOF_STR("Rotation"), pdblib::PDB0);
                boundaryDisp_[0][2] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Left"), VOF_STR("Dirichlet"),
                                                           VOF_STR("AxisLocation"), pdblib::PDB0);
            }
            if (!boundaryActive_[1]) {
                boundaryDisp_[1][0] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Dirichlet"),
                                                           VOF_STR("Translation"), pdblib::PDB0);
                boundaryDisp_[1][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Dirichlet"),
                                                           VOF_STR("Rotation"), pdblib::PDB0);
                boundaryDisp_[1][2] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Right"), VOF_STR("Dirichlet"),
                                                           VOF_STR("AxisLocation"), pdblib::PDB0);
            }
            if (dimension != 2) {
                boundaryActive_[2] =
                    pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("NeumannOn"), pdblib::PDB0) != 0;
                boundaryActive_[3] =
                    pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("NeumannOn"), pdblib::PDB0) != 0;
                if (!boundaryActive_[2]) {
                    boundaryDisp_[2][0] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Dirichlet"),
                                                               VOF_STR("Translation"), pdblib::PDB0);
                    boundaryDisp_[2][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Dirichlet"),
                                                               VOF_STR("Rotation"), pdblib::PDB0);
                    boundaryDisp_[2][2] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Front"), VOF_STR("Dirichlet"),
                                                               VOF_STR("AxisLocation"), pdblib::PDB0);
                }
                if (!boundaryActive_[3]) {
                    boundaryDisp_[3][0] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Dirichlet"),
                                                               VOF_STR("Translation"), pdblib::PDB0);
                    boundaryDisp_[3][1] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Dirichlet"),
                                                               VOF_STR("Rotation"), pdblib::PDB0);
                    boundaryDisp_[3][2] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), "BC", VOF_STR("Back"), VOF_STR("Dirichlet"),
                                                               VOF_STR("AxisLocation"), pdblib::PDB0);
                }
            }
        }
    }

    // 两个对面全自由就没有 Dirichlet 可用，直接 panic。这两处判维度取的是
    // 全局场服务器，不是本函数的形参。
    if (boundaryActive_[0] && boundaryActive_[1] && globalSimObject().fieldServer->dimension > 1) {
        FLPS_panic(VOF_STR("At least one Y plane should have Dirichlet boundary condition"));
    }
    if (boundaryActive_[2] && boundaryActive_[3] && globalSimObject().fieldServer->dimension > 2) {
        FLPS_panic(VOF_STR("At least one Z plane should have Dirichlet boundary condition"));
    }

    noLateralConstraint_ = false;
    if (globalSimObject().fieldServer->dimension == 2) {
        if (boundaryActive_[0] || boundaryActive_[1]) {
            if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Bottom.Automatic.Free"), pdblib::PDB0) == 1) {
                bottomAutoFree_ = true;
            }
        } else {
            bottomAutoFree_ = false;
            noLateralConstraint_ = true;
        }
    }
    if (globalSimObject().fieldServer->dimension == 3) {
        if (boundaryActive_[0] || boundaryActive_[1] || boundaryActive_[2] || boundaryActive_[3]) {
            if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Bottom.Automatic.Free"), pdblib::PDB0) == 1) {
                bottomAutoFree_ = true;
            }
        } else {
            bottomAutoFree_ = false;
            noLateralConstraint_ = true;
        }
    }

    *globalSimObject().tee << teeInfoLevelMaximum << VOF_STR("Mechanics Boundary Conditions") << tendl;
    *globalSimObject().tee << teeInfoLevelMaximum << VOF_STR("=============================") << tendl;

    // 四个名字定宽 5 字符，后面接 " Boundary:" 才能对齐成一列。
    std::vector<std::string> names(4);
    names[0] = std::string(VOF_STR("Left "));
    names[1] = std::string(VOF_STR("Right"));
    names[2] = std::string(VOF_STR("Front"));
    names[3] = std::string(VOF_STR("Back "));

    if (dimension != 1) {
        const int count = 2 * dimension - 2;
        for (int index = 0; index != count; ++index) {
            names[index] += VOF_STR(" Boundary:");
            if (boundaryActive_[index]) {
                names[index] += VOF_STR("Homogeneous Neumann  ");
                *globalSimObject().tee << teeInfoLevelMaximum << names[index].c_str() << tendl;
            } else {
                names[index] += VOF_STR(" Dirichlet");
                *globalSimObject().tee << teeInfoLevelMaximum << names[index].c_str();
                globalSimObject().tee->form(VOF_STR(" Translation=%10.3e"), boundaryDisp_[index][0]);
                globalSimObject().tee->form(VOF_STR(" Rotation   =%10.3e"), boundaryDisp_[index][1]);
                globalSimObject().tee->form(VOF_STR(" AxisLocn   =%10.3e"), boundaryDisp_[index][2]);
                *globalSimObject().tee << tendl;
            }
        }
    }
}

void GeneralBoundary::Boundary(const std::shared_ptr<FieldServer>& fieldServer, bool flag) {
    identifyBCs(fieldServer, flag);
    identifyBoundaryElements(fieldServer);
    bottomBoundary();
}

void GeneralBoundary::identifyBoundaryElements(const std::shared_ptr<FieldServer>& fieldServer) {
    fieldServer->BoundingBox(true);

    // 全维、非 Gas 的 mesh 才参与；Gas 只有在速度解类型为 0 时才排除。
    TcadBase::Iter<Mesh> meshes(fieldServer->meshes);
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if ((std::strcmp(mesh->material->Name(), VOF_STR("Gas")) == 0 && solverVelocityType_ == 0) ||
            fieldServer->dimension != mesh->elementSize_) {
            continue;
        }

        ElementIter borders = mesh->Borders();
        while (borders++) {
            Element* const border = borders.current_pointer();
            ElementIter lowers = border->lower();
            while (lowers++) {
                Element* const lower = lowers.current_pointer();
                // 只收唯一邻接到实体 mesh 的下阶单元。
                int physicalMatches = 0;
                ElementIter matches = lower->Matches();
                while (matches++) {
                    Element* const match = matches.current_pointer();
                    if (match->mesh->type_ != Mesh::DefaultMesh) {
                        ++physicalMatches;
                    }
                }
                if (physicalMatches != 1) {
                    continue;
                }

                switch (lower->WhichBorder()) {
                    case 1:
                        boundaryElements_[0].push_back(lower);
                        break;
                    case 2:
                        boundaryElements_[1].push_back(lower);
                        break;
                    case 3:
                        boundaryElements_[2].push_back(lower);
                        break;
                    case 4:
                        boundaryElements_[3].push_back(lower);
                        break;
                    case 5:
                        boundaryElements_[4].push_back(lower);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Grid"), VOF_STR("Flip.Location"), pdblib::PDB0) &&
        !pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Fix.BackMat"), pdblib::PDB0)) {
        boundaryElements_[4].clear();
    }
}

void GeneralBoundary::move_pointforce_node(double dt) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0) == 0) {
        return;
    }

    const std::string list = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0);
    std::istringstream stream(list);
    const std::vector<std::string> names{std::istream_iterator<std::string>(stream),
                                         std::istream_iterator<std::string>()};

    for (unsigned int index = 0; index != names.size(); ++index) {
        const Element& element = *pointForceElements_[index];
        const TcadGeom::Location velocity = velocitySolution_->velocity_->get(element);
        const double dz = 10000.0 * velocity.z * dt;
        const double dy = 10000.0 * velocity.y * dt;
        const double dx = 10000.0 * velocity.x * dt;

        // count 由 pdbgetDoubleArray 自己置位，调用方不预置。
        int count;
        double* const values =
            pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), names[index].c_str(), pdblib::PDB0);
        if (count != 6) {
            FLPS_warning(VOF_STR("Inconsistent point force boundary condition data"));
        }
        values[0] = dx + values[0];
        values[2] = dy + values[2];
        values[4] = dz + values[4];
        pdblib::pdbsetDoubleArray(interpreter, values, 6, VOF_STR("Mechanics"), names[index].c_str(), pdblib::PDB0);
        delete[] values;
    }
}

int GeneralBoundary::countFaceBCs(int kind, std::vector<Element*>& elements, std::map<int, Element*>& faces) {
    // 梁单元已建出且该开关置位时，本类别整体不参与计数。两次判定各自取一遍句柄。
    if (_globalPool->beamProbHandler->beamsCreated_ && _globalPool->beamProbHandler->flag189_) {
        return 0;
    }

    // Left/Right 约束 y 方程，Front/Back 约束 z 方程，Bottom 约束 x 方程；其余类别不计数。
    IntData* equationNumber = nullptr;
    if (static_cast<unsigned>(kind) <= 1) {
        equationNumber = velocitySolution_->eqnYVelocity_;
    } else if (static_cast<unsigned>(kind - 2) <= 1) {
        equationNumber = velocitySolution_->eqnZVelocity_;
    } else if (kind != 4) {
        return 0;
    } else {
        equationNumber = velocitySolution_->eqnXVelocity_;
    }

    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    bool automaticBottomFree = false;
    if (kind == 4 && !noLateralConstraint_) {
        automaticBottomFree =
            pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Bottom.Automatic.Free"), pdblib::PDB0) == 1;
    }

    faces.clear();
    for (std::size_t index = 0; index < elements.size(); ++index) {
        Element* const element = elements[index];
        TcadBase::Iter<Node> nodes = element->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const int equation = equationNumber->value(node);
            if (equation <= 0) {
                continue;
            }
            const auto inserted = faces.emplace(equation, node);
            if (!inserted.second && inserted.first->second != node && !automaticBottomFree) {
                equationNumber->set(*node, -equation);
            }
        }
    }

    if (automaticBottomFree) {
        // 底面自动放开：按底面边条类型取包围盒的一个角点，在那里留一个 Dirichlet 支点。
        TcadGeom::Location lower{};
        TcadGeom::Location upper{};
        globalSimObject().fieldServer->BoundingBox(lower, upper, true);

        const double cornerX = globalSimObject().fieldServer->bounding_box_xmax;
        double cornerY = 0.0;
        double cornerZ = 0.0;
        switch (bottomBoundaryKind_) {
            case 1:
                cornerY = globalSimObject().fieldServer->bounding_box_ymin;
                cornerZ = globalSimObject().fieldServer->bounding_box_zmax;
                break;
            case 2:
                cornerY = globalSimObject().fieldServer->bounding_box_ymax;
                cornerZ = globalSimObject().fieldServer->bounding_box_zmax;
                break;
            case 3:
                cornerY = globalSimObject().fieldServer->bounding_box_ymax;
                cornerZ = globalSimObject().fieldServer->bounding_box_zmin;
                break;
            case 4:
                cornerY = globalSimObject().fieldServer->bounding_box_ymin;
                cornerZ = globalSimObject().fieldServer->bounding_box_zmin;
                break;
            default:
                break;
        }

        // 在坐标池里找与该角点重合的坐标；先压实一次表，重编号后再遍历。
        FieldServer& fieldServer = *globalSimObject().fieldServer;
        fieldServer.coordinates.compact();
        Coordinate* corner = nullptr;
        TcadBase::Iter<Coordinate> coordinates(fieldServer.coordinates);
        while (coordinates++) {
            corner = coordinates.current_pointer();
            const double dx = cornerX - corner->x;
            const double dy = cornerY - corner->y;
            const double dz = cornerZ - corner->z;
            if (TcadGeom::Location::epsilon >= std::sqrt(dx * dx + dy * dy + dz * dz)) {
                break;
            }
        }

        // 该坐标上必须恰有一个实体侧节点，否则底面边条无从施加。
        Node* solidNode = nullptr;
        int solidCount = 0;
        TcadBase::Iter<Node> cornerNodes(corner->nodes_);
        while (cornerNodes++) {
            Node* const node = cornerNodes.current_pointer();
            if (node->mesh->type_ != Mesh::DefaultMesh) {
                ++solidCount;
                solidNode = node;
            }
        }
        if (solidCount != 1) {
            FLPS_panic(VOF_STR("Bottom dirichlet boundary condition cannot be applied"));
        }

        bottomElement_ = solidNode;
        if (equationNumber->value(solidNode) > 0) {
            return 1;
        }
    }

    int count = 0;
    for (const auto& entry : faces) {
        if (equationNumber->value(*entry.second) >= 0) {
            ++count;
        }
    }
    return count;
}

void GeneralBoundary::apply_point_force() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0)) {
        return;
    }
    // deck 没给这个开关就先补一个真值。
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Force.Distribute"), pdblib::PDB0)) {
        pdblib::pdbsetBoolean(interpreter, 1, VOF_STR("Mechanics"), VOF_STR("Point.Force.Distribute"), pdblib::PDB0);
    }
    const int dimension = globalSimObject().fieldServer->dimension;

    const std::string list = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0);
    std::istringstream stream(list);
    const std::vector<std::string> names{std::istream_iterator<std::string>(stream),
                                         std::istream_iterator<std::string>()};

    // 四张并行表：到最近节点的距离（先置一个够大的数）、最近节点、作用点、力。
    std::vector<double> distances;
    std::vector<Node*> nearestNodes;
    std::vector<TcadGeom::Location> points;
    std::vector<TcadGeom::Location> forces;
    for (std::size_t index = 0; index != names.size(); ++index) {
        distances.push_back(1e38);
        nearestNodes.push_back(nullptr);

        int count;
        double* values = nullptr;
        // 大变形或位移解时先找 <name>.Rate；取到的是速率，乘本步终了时刻换成量。
        if (globalSimObject().fieldServer->largeDeformationFlag_ ||
            pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0)) {
            std::string rateName = names[index];
            rateName += VOF_STR(".Rate");
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), rateName.c_str(), pdblib::PDB0)) {
                values = pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), rateName.c_str(), pdblib::PDB0);
                values[1] = values[1] * stepEndTime_;
                values[3] = values[3] * stepEndTime_;
                values[5] = values[5] * stepEndTime_;
            }
        }
        if (values == nullptr) {
            values = pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), names[index].c_str(), pdblib::PDB0);
        }
        if (count != 6) {
            FLPS_warning(VOF_STR("Inconsistent point force boundary condition data"));
        }
        // 数组是 [x, fx, y, fy, z, fz]；坐标按 1e-4 折算，力原样收下。
        points.push_back(TcadGeom::Location{values[0] * 0.0001, values[2] * 0.0001, values[4] * 0.0001});
        forces.push_back(TcadGeom::Location{values[1], values[3], values[5]});
        delete[] values;
    }

    // 在所有实体 mesh 的节点里给每个作用点找最近的一个。
    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (mesh->type_ > 1) {
            continue;
        }
        TcadBase::Iter<Node> nodes = mesh->nodes(-1, -1);
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            for (std::size_t index = 0; index != points.size(); ++index) {
                const Coordinate& coordinate = *node->coordinate;
                const double dy = coordinate.y - points[index].y;
                const double distance =
                    std::sqrt((coordinate.x - points[index].x) * (coordinate.x - points[index].x) + dy * dy +
                              (coordinate.z - points[index].z) * (coordinate.z - points[index].z));
                if (distances[index] > distance) {
                    distances[index] = distance;
                    nearestNodes[index] = node;
                }
            }
        }
    }

    const bool snap = pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Force.Snap"), pdblib::PDB0) != 0;
    const double snapDistance = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Snap.Dist"), pdblib::PDB0);

    for (std::size_t index = 0; index != names.size(); ++index) {
        int count;
        double* const values =
            pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), names[index].c_str(), pdblib::PDB0);
        if (count != 6) {
            FLPS_warning(VOF_STR("Inconsistent point force boundary condition data"));
        }

        // 最近节点超出容差：要么把力分摊给包含该点的单元，要么退回最近节点。
        if (distances[index] > snapDistance) {
            if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Force.Distribute"), pdblib::PDB0)) {
                FLPS_warning(
                    VOF_STR("Snapped node is not within the tolerance; distributing force to nodes of the element "
                    "containing the point"));
                // 吸附开着时先把作用点挪到最近节点上，并写回 pdb 与 points[]。
                TcadGeom::Point<double> target;
                if (snap) {
                    Node* const snapped = nearestNodes[index];
                    pointForceElements_.push_back(snapped);
                    const Coordinate& coordinate = *snapped->coordinate;
                    values[0] = coordinate.x * 10000.0;
                    values[2] = coordinate.y * 10000.0;
                    values[4] = coordinate.z * 10000.0;
                    points[index] = TcadGeom::Location{values[0], values[2], values[4]};
                    pdblib::pdbsetDoubleArray(interpreter, values, 6, VOF_STR("Mechanics"), names[index].c_str(), pdblib::PDB0);
                }
                target = TcadGeom::Point<double>(points[index].x, points[index].y, points[index].z);

                // 三个分量各分摊一次；分量为零的跳过。码 3/4/5 依次对应 x/y/z。
                for (int kind = 3; kind != 6; ++kind) {
                    const double force = values[2 * (kind - 3) + 1];
                    if (force == 0.0) {
                        continue;
                    }

                    TcadBase::Seq<Element> matched;
                    nearestNodes[index]->ElementMatch(matched);
                    for (int slot = 0; slot != matched.cur_max; ++slot) {
                        Element* const element = matched.list[slot];
                        if (element->mesh->type_ > 1) {
                            continue;
                        }
                        if (dimension == 2) {
                            // 二维：在骨架边上找包含该点的一条，按线性权重摊给两个端点。
                            OEdgeIter edges = element->edges();
                            while (edges++) {
                                const OEdge oriented = edges.current();
                                Edge& edge = oriented.edge();
                                if (!edge.IsSkeletal()) {
                                    continue;
                                }
                                Node* const head = (oriented.Dir() == OEdgeOrder::Normal) ? edge.firstNode : edge.secondNode;
                                Node* const tail = (oriented.Dir() == OEdgeOrder::Normal) ? edge.secondNode : edge.firstNode;
                                mgoals::Segment<TcadGeom::Point<double>, TcadBase::Identity<TcadGeom::Point<double>>>
                                    segment;
                                segment.first_point = TcadGeom::Point<double>(head->coordinate->x, head->coordinate->y,
                                                                              head->coordinate->z);
                                segment.second_point = TcadGeom::Point<double>(tail->coordinate->x, tail->coordinate->y,
                                                                               tail->coordinate->z);
                                if (!segment.contained(target)) {
                                    continue;
                                }
                                TcadMath::RFloat<double> weights[2];
                                mgoals::GeometryPolicy::getWeights<double>(
                                    target, segment.first_point, segment.second_point, weights[0], weights[1]);
                                bcElements_.push_back(head);
                                bcKinds_.push_back(kind);
                                bcValues_.push_back(weights[0].value() * force);
                                bcElements_.push_back(tail);
                                bcKinds_.push_back(kind);
                                bcValues_.push_back(weights[1].value() * force);
                            }
                        } else if (dimension == 3) {
                            // 三维：在骨架面上找包含该点的一个三角形，按重心权重摊给它的节点。
                            TcadBase::Iter<Face> faces = element->faces();
                            while (faces++) {
                                Face* const face = faces.current_pointer();
                                if (!face->IsSkeletal()) {
                                    continue;
                                }
                                TcadGeom::Point<double> vertices[3];
                                int filled = 0;
                                TcadBase::Iter<Node> faceNodes = face->nodes();
                                while (faceNodes++) {
                                    const Coordinate& coordinate = *faceNodes.current_pointer()->coordinate;
                                    if (filled < 3) {
                                        vertices[filled] =
                                            TcadGeom::Point<double>(coordinate.x, coordinate.y, coordinate.z);
                                    }
                                    ++filled;
                                }

                                mgoals::Triangle<TcadGeom::Point<double>, TcadBase::Identity<TcadGeom::Point<double>>>
                                    triangle(vertices[0], vertices[1], vertices[2]);
                                int location = 0;
                                unsigned long feature = 0;
                                triangle.getPointLocation<double>(target, &location, &feature);
                                if (location == 2) {
                                    continue;
                                }

                                TcadMath::RFloat<double> weights[3];
                                mgoals::GeometryPolicy::getWeights<double>(
                                    target, vertices[0], vertices[1], vertices[2], weights[0], weights[1], weights[2]);
                                int weightIndex = 0;
                                TcadBase::Iter<Node> again = face->nodes();
                                while (again++) {
                                    bcElements_.push_back(again.current_pointer());
                                    bcKinds_.push_back(kind);
                                    bcValues_.push_back(weights[weightIndex].value() * force);
                                    ++weightIndex;
                                }
                            }
                        }
                    }
                }
                delete[] values;
                continue;
            }
            if (distances[index] > snapDistance) {
                FLPS_warning(VOF_STR("Snapped node is not within the tolerance; Use the nearest node"));
            }
        }

        Node* const node = nearestNodes[index];
        if (snap) {
            // 开了吸附就把作用点挪到最近节点上，并写回 pdb。
            pointForceElements_.push_back(node);
            const Coordinate& coordinate = *node->coordinate;
            values[0] = coordinate.x * 10000.0;
            values[2] = coordinate.y * 10000.0;
            values[4] = coordinate.z * 10000.0;
            pdblib::pdbsetDoubleArray(interpreter, values, 6, VOF_STR("Mechanics"), names[index].c_str(), pdblib::PDB0);
        }

        // 三个分量各压一条：码 3/4/5 依次对应 x/y/z。
        bcElements_.push_back(node);
        bcKinds_.push_back(3);
        bcValues_.push_back(forces[index].x);
        bcElements_.push_back(node);
        bcKinds_.push_back(4);
        bcValues_.push_back(forces[index].y);
        bcElements_.push_back(node);
        bcKinds_.push_back(5);
        bcValues_.push_back(forces[index].z);

        delete[] values;
    }
}

void GeneralBoundary::apply_point_disp() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0)) {
        return;
    }
    // deck 没给这个开关就先补一个真值。
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0)) {
        pdblib::pdbsetBoolean(interpreter, 1, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0);
    }
    const int dimension = globalSimObject().fieldServer->dimension;

    const std::string list = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0);
    std::istringstream stream(list);
    const std::vector<std::string> names{std::istream_iterator<std::string>(stream),
                                         std::istream_iterator<std::string>()};

    // 三张并行表：到最近节点的距离、最近节点、作用点。
    std::vector<double> distances;
    std::vector<Node*> nearestNodes;
    std::vector<TcadGeom::Location> points;
    for (std::size_t index = 0; index != names.size(); ++index) {
        distances.push_back(1e38);
        nearestNodes.push_back(nullptr);

        // 作用点存在 <name> Coordinate 下，布局同点力：[x, ?, y, ?, z, ?]，坐标按 1e-4 折算。
        int count;
        double* const values = pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), names[index].c_str(),
                                                         VOF_STR("Coordinate"), pdblib::PDB0);
        if (count != 6) {
            FLPS_warning(VOF_STR("Inconsistent point displacement boundary condition data"));
        }
        points.push_back(TcadGeom::Location{values[0] * 0.0001, values[2] * 0.0001, values[4] * 0.0001});
        delete[] values;
    }

    // 在所有实体 mesh 的节点里给每个作用点找最近的一个。
    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (mesh->type_ > 1) {
            continue;
        }
        TcadBase::Iter<Node> nodes = mesh->nodes(-1, -1);
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            for (std::size_t index = 0; index != points.size(); ++index) {
                const Coordinate& coordinate = *node->coordinate;
                const double dy = coordinate.y - points[index].y;
                const double distance =
                    std::sqrt((coordinate.x - points[index].x) * (coordinate.x - points[index].x) + dy * dy +
                              (coordinate.z - points[index].z) * (coordinate.z - points[index].z));
                if (distances[index] > distance) {
                    distances[index] = distance;
                    nearestNodes[index] = node;
                }
            }
        }
    }

    const double snapDistance = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Snap.Dist"), pdblib::PDB0);
    // 三个自由度各有一个速率键；码 0/1/2 依次对应 x/y/z，与 fix_dof 的判据一致。
    static const char* const axisKeys[3] = {VOF_STATIC_STR("pdx"), VOF_STATIC_STR("pdy"), VOF_STATIC_STR("pdz")};

    for (std::size_t index = 0; index != names.size(); ++index) {
        if (distances[index] > snapDistance &&
            pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0)) {
            // 超出容差且允许分摊：把每个自由度按重心权重摊给包含该点的单元的各节点。
            FLPS_warning(
                VOF_STR("Snapped node is not within the tolerance; distributing displacement rate to nodes of the "
                "element containing the point"));
            const TcadGeom::Point<double> target(points[index].x, points[index].y, points[index].z);
            for (int axis = 0; axis != 3; ++axis) {
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), names[index].c_str(), axisKeys[axis],
                                            pdblib::PDB0)) {
                    continue;
                }
                // 大变形或位移解时，键里放的是速率，乘时间步长换成量。
                const double rate =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), names[index].c_str(), axisKeys[axis], pdblib::PDB0);
                double value = rate;
                if (globalSimObject().fieldServer->largeDeformationFlag_ ||
                    pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0)) {
                    value = getTimeStep() * rate;
                }

                TcadBase::Seq<Element> matched;
                nearestNodes[index]->ElementMatch(matched);
                for (int slot = 0; slot != matched.cur_max; ++slot) {
                    Element* const element = matched.list[slot];
                    if (element->mesh->type_ > 1) {
                        continue;
                    }
                    if (dimension == 2) {
                        OEdgeIter edges = element->edges();
                        while (edges++) {
                            const OEdge oriented = edges.current();
                            Edge& edge = oriented.edge();
                            if (!edge.IsSkeletal()) {
                                continue;
                            }
                            Node* const head = (oriented.Dir() == OEdgeOrder::Normal) ? edge.firstNode : edge.secondNode;
                            Node* const tail = (oriented.Dir() == OEdgeOrder::Normal) ? edge.secondNode : edge.firstNode;
                            mgoals::Segment<TcadGeom::Point<double>, TcadBase::Identity<TcadGeom::Point<double>>>
                                segment;
                            segment.first_point =
                                TcadGeom::Point<double>(head->coordinate->x, head->coordinate->y, head->coordinate->z);
                            segment.second_point =
                                TcadGeom::Point<double>(tail->coordinate->x, tail->coordinate->y, tail->coordinate->z);
                            if (!segment.contained(target)) {
                                continue;
                            }
                            TcadMath::RFloat<double> weights[2];
                            mgoals::GeometryPolicy::getWeights<double>(target, segment.first_point,
                                                                       segment.second_point, weights[0], weights[1]);
                            bcElements_.push_back(head);
                            bcKinds_.push_back(axis);
                            bcValues_.push_back(weights[0].value() * value);
                            bcElements_.push_back(tail);
                            bcKinds_.push_back(axis);
                            bcValues_.push_back(weights[1].value() * value);
                        }
                    } else if (dimension == 3) {
                        TcadBase::Iter<Face> faces = element->faces();
                        while (faces++) {
                            Face* const face = faces.current_pointer();
                            if (!face->IsSkeletal()) {
                                continue;
                            }
                            TcadGeom::Point<double> vertices[3];
                            int filled = 0;
                            TcadBase::Iter<Node> faceNodes = face->nodes();
                            while (faceNodes++) {
                                const Coordinate& coordinate = *faceNodes.current_pointer()->coordinate;
                                if (filled < 3) {
                                    vertices[filled] =
                                        TcadGeom::Point<double>(coordinate.x, coordinate.y, coordinate.z);
                                }
                                ++filled;
                            }

                            mgoals::Triangle<TcadGeom::Point<double>, TcadBase::Identity<TcadGeom::Point<double>>>
                                triangle(vertices[0], vertices[1], vertices[2]);
                            int location = 0;
                            unsigned long feature = 0;
                            triangle.getPointLocation<double>(target, &location, &feature);
                            if (location == 2) {
                                continue;
                            }

                            TcadMath::RFloat<double> weights[3];
                            mgoals::GeometryPolicy::getWeights<double>(target, vertices[0], vertices[1], vertices[2],
                                                                       weights[0], weights[1], weights[2]);
                            int weightIndex = 0;
                            TcadBase::Iter<Node> again = face->nodes();
                            while (again++) {
                                bcElements_.push_back(again.current_pointer());
                                bcKinds_.push_back(axis);
                                bcValues_.push_back(weights[weightIndex].value() * value);
                                ++weightIndex;
                            }
                        }
                    }
                }
            }
            continue;
        }

        if (distances[index] > snapDistance) {
            FLPS_warning(VOF_STR("Snapped node is not within the tolerance; Use the nearest node"));
        }
        // 落在容差内（或不许分摊）：直接固定最近节点所在位置上的所有同位置自由度。
        for (int axis = 0; axis != 3; ++axis) {
            if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), names[index].c_str(), axisKeys[axis], pdblib::PDB0)) {
                continue;
            }
            // 大变形或位移解时，键里放的是速率，乘时间步长换成量。
            const double rate =
                pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), names[index].c_str(), axisKeys[axis], pdblib::PDB0);
            double value = rate;
            if (globalSimObject().fieldServer->largeDeformationFlag_ ||
                pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0)) {
                value = getTimeStep() * rate;
            }

            TcadBase::Seq<Element> matched;
            nearestNodes[index]->ElementMatch(matched);
            for (int slot = 0; slot != matched.cur_max; ++slot) {
                Element* const element = matched.list[slot];
                if (element->mesh->type_ > 1) {
                    continue;
                }
                bcElements_.push_back(element);
                bcKinds_.push_back(axis);
                bcValues_.push_back(value);
            }
        }
    }
}

void GeneralBoundary::apply_body_force() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Apply.Body.Force"), pdblib::PDB0)) {
        return;
    }

    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (mesh->type_ > 1) {
            continue;
        }
        // 材料的质量密度乘重力加速度（cm/s²）得到重度。
        const double weightDensity =
            pdblib::pdbgetDouble(interpreter, mesh->Name(), VOF_STR("MassDensity"), pdblib::PDB0) * 980.665;

        ElementIter elements = mesh->elements(-1, -1);
        while (elements++) {
            Element* const element = elements.current_pointer();
            TcadBase::Iter<Node> nodes = element->nodes();
            if (nodes.isEmpty()) {
                FLPS_panic(VOF_STR("Element has no node"));
            }

            // 单元自重按节点均分：三维四个节点、二维三个节点。
            double share = element->Size() * weightDensity;
            if (globalSimObject().fieldServer->dimension == 3) {
                share = share * 0.25;
            } else if (globalSimObject().fieldServer->dimension == 2) {
                share = share / 3.0;
                // 轴对称时按旋转半径折算成整周：绕 x 轴取节点 y 的均值，绕 y 轴取 x 的均值。
                double radius = 0.0;
                bool axisymmetric = false;
                if (globalSimObject().fieldServer->axisymmetricX_) {
                    double sum = 0.0;
                    while (nodes++) {
                        sum += nodes.current_pointer()->coordinate->y;
                    }
                    radius = sum / static_cast<double>(nodes.Length());
                    axisymmetric = true;
                } else if (globalSimObject().fieldServer->axisymmetric_) {
                    double sum = 0.0;
                    while (nodes++) {
                        sum += nodes.current_pointer()->coordinate->x;
                    }
                    radius = sum / static_cast<double>(nodes.Length());
                    axisymmetric = true;
                }
                if (axisymmetric) {
                    double symmetryAxisOffset = 0.0;
                    std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                                sizeof(symmetryAxisOffset));
                    share = (radius - symmetryAxisOffset) * 6.283185307179586 * share;
                }
            }

            // 体力只作用在 x 分量上，码 3。
            nodes.reset();
            while (nodes++) {
                bcElements_.push_back(nodes.current_pointer());
                bcKinds_.push_back(3);
                bcValues_.push_back(share);
            }
        }
    }
}

std::vector<double> GeneralBoundary::apply_body_force_helper1(FE::FiniteElement* finiteElement) {
    // 复合实体壳单元先按材料层厚把内部积分方案摆好。
    if (finiteElement != nullptr && light_cast<FE::CompositeSolidShell*>(finiteElement) != nullptr) {
        double* const layerThickness = new double[1];
        finiteElement->material_->getLayerThkness(layerThickness);
        finiteElement->InternalIntegrationScheme()->set_up_params(1, layerThickness);
        delete[] layerThickness;
    }

    // 返回向量固定二十个槽，线性／二次 hex 分别只用到前 8／20 个。
    std::vector<double> integrated(20, 0.0);

    FE::IsoparametricElement* const shapeFn = finiteElement->shapeFn_;
    const int gaussPoints = finiteElement->quadrature_->ngp_;
    // 维度取自全局场服务器，不是单元自己的 dim_。
    const int dimension = globalSimObject().fieldServer->dimension;

    // 临时装配器只备雅可比与其行列式两张表，绑到单元上算一遍。
    FE::MechanicsAssembler assembler{};
    if (gaussPoints > 0) {
        assembler.detJ_.resize(static_cast<std::size_t>(gaussPoints));
        assembler.jacobian_.resize(static_cast<std::size_t>(gaussPoints));
        for (int point = 0; point != gaussPoints; ++point) {
            Mechanics::Matrix& jacobian = assembler.jacobian_[static_cast<std::size_t>(point)];
            jacobian.rows_ = dimension;
            jacobian.cols_ = dimension;
            jacobian.data_.resize(static_cast<std::size_t>(dimension) * static_cast<std::size_t>(dimension));
        }
    }

    finiteElement->assembler_ = &assembler;
    assembler.setFEPtr(finiteElement);
    finiteElement->calc_Jacobian();
    finiteElement->calc_detJ();

    const TcadGeom::Location* const points = finiteElement->quadrature_->points_;
    const double* const weights = finiteElement->quadrature_->weights_;
    double shape[20];
    std::memset(shape, 0, sizeof(shape));
    for (int point = 0; point < gaussPoints; ++point) {
        shapeFn->get_shape_fn(points[point], shape);
        for (int node = 0; node != 20; ++node) {
            integrated[static_cast<std::size_t>(node)] =
                shape[node] * weights[point] * assembler.detJ_[static_cast<std::size_t>(point)] +
                integrated[static_cast<std::size_t>(node)];
        }
    }
    return integrated;
}

void GeneralBoundary::apply_displacement(std::vector<Element*>& elements, int axis, char* value) {
    // Tcl 求值结果只在进函数时清一次，之后每个节点覆写一次。
    double evaluated = 0.0;
    // 过程名先整串拷进本地缓冲，后面每个节点都以它作命令前缀。
    char procedure[512];
    std::strcpy(procedure, value);

    // 两张温度场在进循环前各查一次，节点级只做取值。
    const RealData* const temperature = globalSimObject().fieldServer->RealFindMatch(VOF_STR("Temperature"));
    const RealData* const prevTemperature = globalSimObject().fieldServer->RealFindMatch(VOF_STR("PrevTemperature"));

    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const double nodeTemperature = temperature->get(*node);
            const double nodePrevTemperature = prevTemperature->get(*node);

            // 传给过程的四个实参依次是当前温度、上一步温度、时刻与步长，温度按摄氏度送出。
            char command[1024];
            command[0] = '\0';
            const double timeStep = getTimeStep();
            const double time = getTime();
            std::sprintf(command, VOF_STR("%s %2.15e %2.15e %2.15e %2.15e"), procedure, nodeTemperature - 273.156,
                         nodePrevTemperature - 273.156, time, timeStep);

            if (Tcl_Eval(globalSimObject().interpreter->interpreter, command)) {
                FLPS_panic(VOF_STR("Boundary condition procedure failed"));
            }
            const char* const commandResult = Tcl_GetStringResult(globalSimObject().interpreter->interpreter);
            Tcl_ExprDouble(globalSimObject().interpreter->interpreter, commandResult, &evaluated);

            bcElements_.push_back(node);
            bcKinds_.push_back(axis);
            bcValues_.push_back(evaluated);
        }
    }
}

void GeneralBoundary::apply_force(std::vector<Element*>& elements, int axis, char* value) {
    TcadGeom::Location nodePoints[8]{};
    double evaluated = 0.0;
    char procedure[512];
    std::strcpy(procedure, value);

    // 两张温度场在进循环前各查一次，节点级只做取值。
    const RealData* const temperature = globalSimObject().fieldServer->RealFindMatch(VOF_STR("Temperature"));
    const RealData* const prevTemperature = globalSimObject().fieldServer->RealFindMatch(VOF_STR("PrevTemperature"));

    const double total = total_quantity(elements, nullptr, nullptr);
    if (total < 1.0e-30) {
        FLPS_panic(VOF_STR("Total area too small!"));
    }

    // 逐单元把节点上的过程返回值平均成面力密度，再按单元几何量摊到总面积上。
    double accumulated = 0.0;
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        double sum = 0.0;
        int collected = 0;
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const double nodeTemperature = temperature->get(*node);
            const double nodePrevTemperature = prevTemperature->get(*node);

            // 传给过程的四个实参依次是当前温度、上一步温度、时刻与步长，温度按摄氏度送出。
            char command[1024];
            command[0] = '\0';
            const double timeStep = getTimeStep();
            const double time = getTime();
            std::sprintf(command, VOF_STR("%s %2.15e %2.15e %2.15e %2.15e"), procedure, nodeTemperature - 273.156,
                         nodePrevTemperature - 273.156, time, timeStep);

            if (Tcl_Eval(globalSimObject().interpreter->interpreter, command)) {
                FLPS_panic(VOF_STR("Boundary condition procedure failed"));
            }
            const char* const commandResult = Tcl_GetStringResult(globalSimObject().interpreter->interpreter);
            Tcl_ExprDouble(globalSimObject().interpreter->interpreter, commandResult, &evaluated);

            sum = sum + evaluated;
            const Coordinate& coordinate = *node->coordinate;
            nodePoints[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            ++collected;
        }

        double decomposed;
        if (globalSimObject().fieldServer->dimension == 3) {
            decomposed = DecomposedArea(nodePoints, collected);
        } else {
            if (globalSimObject().fieldServer->dimension != 2) {
                FLPS_panic(VOF_STR("Error: Force boundary condition not available for 1-D."));
            }
            decomposed = DecomposedLength(nodePoints);
        }

        if (nodes.isEmpty()) {
            FLPS_panic(VOF_STR("Element has no node"));
        }
        accumulated = sum / nodes.Length() * decomposed / total + accumulated;
    }

    apply_stress(elements, axis, accumulated / total);
}

void GeneralBoundary::apply_stress(std::vector<Element*>& elements, int axis, char* value) {
    TcadGeom::Location points[8]{};
    double evaluated = 0.0;
    char procedure[512];
    std::strcpy(procedure, value);

    // 两张温度场在进循环前各查一次，节点级只做取值。
    const RealData* const temperature = globalSimObject().fieldServer->RealFindMatch(VOF_STR("Temperature"));
    const RealData* const prevTemperature = globalSimObject().fieldServer->RealFindMatch(VOF_STR("PrevTemperature"));

    if (globalSimObject().fieldServer->dimension != 3) {
        if (globalSimObject().fieldServer->dimension != 2) {
            return;
        }
        for (unsigned index = 0; index < elements.size(); ++index) {
            // 二维边单元：轴对称时按回转半径给每个节点算一致质量权，否则两端各半。
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            std::vector<double> radii(nodes.Length());
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                if (globalSimObject().fieldServer->axisymmetricX_) {
                    double symmetryAxisOffset = 0.0;
                    std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                                sizeof(symmetryAxisOffset));
                    radii[collected] = points[collected].y - symmetryAxisOffset;
                } else if (globalSimObject().fieldServer->axisymmetric_) {
                    double symmetryAxisOffset = 0.0;
                    std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                                sizeof(symmetryAxisOffset));
                    radii[collected] = points[collected].x - symmetryAxisOffset;
                }
                ++collected;
            }
            if (collected == 0) {
                FLPS_panic(VOF_STR("Mesh element has no nodes"));
            }
            if (collected > 2) {
                FLPS_panic(VOF_STR("Element has more than 2 nodes!"));
            }

            const double length = DecomposedLength(points);
            std::vector<double> weights(nodes.Length(), 1.0);
            double scale;
            if (globalSimObject().fieldServer->axisymmetricX_ || globalSimObject().fieldServer->axisymmetric_) {
                const double revolve[2][2] = {{1.0 / 3.0, 1.0 / 6.0}, {1.0 / 6.0, 1.0 / 3.0}};
                for (int row = 0; row < collected; ++row) {
                    double weight = 0.0;
                    for (int column = 0; column < collected; ++column) {
                        weight = weight + revolve[row][column] * 6.283185307179586 * radii[column];
                    }
                    weights[row] = weight;
                }
                scale = 1.0;
            } else {
                scale = 0.5;
            }

            nodes.reset();
            int slot = 0;
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                const double nodeTemperature = temperature->get(*node);
                const double nodePrevTemperature = prevTemperature->get(*node);

                char command[1024];
                command[0] = '\0';
                const double timeStep = getTimeStep();
                const double time = getTime();
                std::sprintf(command, VOF_STR("%s %2.15e %2.15e %2.15e %2.15e"), procedure, nodeTemperature - 273.156,
                             nodePrevTemperature - 273.156, time, timeStep);

                if (Tcl_Eval(globalSimObject().interpreter->interpreter, command)) {
                    FLPS_panic(VOF_STR("Boundary condition procedure failed"));
                }
                const char* const commandResult = Tcl_GetStringResult(globalSimObject().interpreter->interpreter);
                Tcl_ExprDouble(globalSimObject().interpreter->interpreter, commandResult, &evaluated);

                bcElements_.push_back(node);
                bcKinds_.push_back(axis + 3);
                bcValues_.push_back(weights[slot] * evaluated * length * scale);
                ++slot;
            }
        }
        return;
    }

    for (unsigned index = 0; index < elements.size(); ++index) {
        // 三维面单元：三节点面每人三分之一、四节点面每人四分之一，其余不摊。
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            ++collected;
        }
        double fraction;
        if (collected == 3) {
            fraction = 1.0 / 3.0;
        } else if (collected == 4) {
            fraction = 0.25;
        } else {
            fraction = 0.0;
        }
        const double area = DecomposedArea(points, collected);

        nodes.reset();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const double nodeTemperature = temperature->get(*node);
            const double nodePrevTemperature = prevTemperature->get(*node);

            char command[1024];
            command[0] = '\0';
            const double timeStep = getTimeStep();
            const double time = getTime();
            std::sprintf(command, VOF_STR("%s %2.15e %2.15e %2.15e %2.15e"), procedure, nodeTemperature - 273.156,
                         nodePrevTemperature - 273.156, time, timeStep);

            if (Tcl_Eval(globalSimObject().interpreter->interpreter, command)) {
                FLPS_panic(VOF_STR("Boundary condition procedure failed"));
            }
            const char* const commandResult = Tcl_GetStringResult(globalSimObject().interpreter->interpreter);
            Tcl_ExprDouble(globalSimObject().interpreter->interpreter, commandResult, &evaluated);

            bcElements_.push_back(node);
            bcKinds_.push_back(axis + 3);
            bcValues_.push_back(area * evaluated * fraction);
        }
    }
}

void GeneralBoundary::apply_displacement_mpc(std::vector<Element*>& elements, int axis, double* rotation,
                                             double* translation, double* center) {
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            TcadGeom::Location location = node->position();

            // 刚体运动：平移量叠上 rotation 与「参考点减节点位置」的叉积。
            double displacement[3];
            displacement[0] =
                rotation[1] * (center[2] - location[2]) - rotation[2] * (center[1] - location[1]) + translation[0];
            displacement[1] =
                rotation[2] * (center[0] - location[0]) - rotation[0] * (center[2] - location[2]) + translation[1];
            displacement[2] =
                rotation[0] * (center[1] - location[1]) - rotation[1] * (center[0] - location[0]) + translation[2];

            bcElements_.push_back(node);
            bcKinds_.push_back(axis);
            bcValues_.push_back(displacement[axis]);
        }
    }
}

void GeneralBoundary::apply_force_mpc(std::vector<Element*>& elements, double* moment, double* force, double*) {
    TcadGeom::Location points[8]{};
    TcadGeom::Location firstAxis{};
    TcadGeom::Location secondAxis{};
    TcadGeom::Location normal{};
    TcadGeom::Location centroid{};
    std::array<double, 3> inertia{};

    const double total = total_quantity(elements, &centroid, &normal);
    if (total < 1.0e-30) {
        FLPS_panic(VOF_STR("Total area too small!"));
    }

    // 截面法向再归一化一次，并要求它与某条坐标轴对齐；梁轴取法向的下一条循环轴。
    const double normalLength = std::sqrt(normal.y * normal.y + normal.x * normal.x + normal.z * normal.z);
    normal.x = normal.x / normalLength;
    normal.z = normal.z / normalLength;
    normal.y = normal.y / normalLength;

    TcadGeom::Location beamAxis{};
    if (std::fabs(normal.x) > 1.0e-12 && std::fabs(normal.y) < 1.0e-12 && std::fabs(normal.z) < 1.0e-12) {
        beamAxis.y = normal.x;
    } else if (std::fabs(normal.y) > 1.0e-12 && std::fabs(normal.x) < 1.0e-12 && std::fabs(normal.z) < 1.0e-12) {
        beamAxis.z = normal.y;
    } else if (std::fabs(normal.z) > 1.0e-12 && std::fabs(normal.x) < 1.0e-12 && std::fabs(normal.y) < 1.0e-12) {
        beamAxis.x = normal.z;
    } else {
        FLPS_panic(VOF_STR("Beam dimensions are not axis-aligned!"));
    }
    const double beamLength = std::sqrt(beamAxis.x * beamAxis.x + beamAxis.y * beamAxis.y + beamAxis.z * beamAxis.z);
    firstAxis.y = beamAxis.y / beamLength;
    firstAxis.z = beamAxis.z / beamLength;
    secondAxis.x = firstAxis.z * normal.y - firstAxis.y * normal.z;
    firstAxis.x = beamAxis.x / beamLength;
    secondAxis.y = normal.z * firstAxis.x - firstAxis.z * normal.x;
    secondAxis.z = firstAxis.y * normal.x - firstAxis.x * normal.y;

    AreaMomentInertia(elements, firstAxis, secondAxis, centroid, inertia);

    if (globalSimObject().fieldServer->dimension == 3) {
        // 力矩先按三条主轴分解成三个共线矢量。
        const double alongFirst = moment[0] * firstAxis.x + moment[1] * firstAxis.y + moment[2] * firstAxis.z;
        const TcadGeom::Location firstMoment(alongFirst * firstAxis.x, firstAxis.y * alongFirst,
                                             firstAxis.z * alongFirst);
        const double alongSecond = moment[1] * secondAxis.y + moment[0] * secondAxis.x + moment[2] * secondAxis.z;
        const TcadGeom::Location secondMoment(secondAxis.x * alongSecond, secondAxis.y * alongSecond,
                                              secondAxis.z * alongSecond);
        const double alongNormal = moment[1] * normal.y + moment[0] * normal.x + moment[2] * normal.z;
        const TcadGeom::Location normalMoment(normal.x * alongNormal, normal.y * alongNormal, normal.z * alongNormal);

        // 三条力臂在整支里只在各自的力矩非零时才刷新，跨节点、跨单元保留上次的值。
        TcadGeom::Location firstArm{};
        TcadGeom::Location secondArm{};
        TcadGeom::Location normalArm{};
        for (unsigned index = 0; index < elements.size(); ++index) {
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                ++collected;
            }
            const double area = DecomposedArea(points, collected);

            nodes.reset();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                TcadGeom::Location location = node->position();
                const double offsetX = location.x - centroid.x;
                const double offsetY = location.y - centroid.y;
                const double offsetZ = location.z - centroid.z;

                if (std::fabs(std::sqrt(firstMoment.x * firstMoment.x + firstMoment.y * firstMoment.y +
                                        firstMoment.z * firstMoment.z)) > 1.0e-12) {
                    const double along = offsetX * secondAxis.x + offsetY * secondAxis.y + offsetZ * secondAxis.z;
                    firstArm.x = secondAxis.x * along;
                    firstArm.y = secondAxis.y * along;
                    firstArm.z = secondAxis.z * along;
                }
                if (std::fabs(std::sqrt(secondMoment.x * secondMoment.x + secondMoment.y * secondMoment.y +
                                        secondMoment.z * secondMoment.z)) > 1.0e-12) {
                    const double along = offsetX * firstAxis.x + offsetY * firstAxis.y + offsetZ * firstAxis.z;
                    secondArm.x = firstAxis.x * along;
                    secondArm.y = firstAxis.y * along;
                    secondArm.z = firstAxis.z * along;
                }
                if (std::fabs(std::sqrt(normalMoment.x * normalMoment.x + normalMoment.y * normalMoment.y +
                                        normalMoment.z * normalMoment.z)) > 1.0e-12) {
                    const double acrossSecond =
                        offsetX * secondAxis.x + offsetY * secondAxis.y + offsetZ * secondAxis.z;
                    const double acrossFirst = offsetX * firstAxis.x + offsetY * firstAxis.y + offsetZ * firstAxis.z;
                    normalArm.x = firstAxis.x * acrossFirst + secondAxis.x * acrossSecond;
                    normalArm.y = firstAxis.y * acrossFirst + secondAxis.y * acrossSecond;
                    normalArm.z = firstAxis.z * acrossFirst + secondAxis.z * acrossSecond;
                }

                // 每条力矩按 M × r / (对应惯性矩 × 节点数) 摊成节点力。
                double bendX = 0.0;
                double bendY = 0.0;
                double bendZ = 0.0;
                const double nodeCount = collected;
                if (std::fabs(std::sqrt(firstArm.x * firstArm.x + firstArm.y * firstArm.y + firstArm.z * firstArm.z)) >
                        1.0e-12 &&
                    std::fabs(std::sqrt(firstMoment.x * firstMoment.x + firstMoment.y * firstMoment.y +
                                        firstMoment.z * firstMoment.z)) > 1.0e-12) {
                    const double share = inertia[0] * nodeCount;
                    bendX = (firstMoment.y * firstArm.z - firstArm.y * firstMoment.z) * area / share + 0.0;
                    bendY = (firstMoment.z * firstArm.x - firstMoment.x * firstArm.z) * area / share + 0.0;
                    bendZ = (firstArm.y * firstMoment.x - firstMoment.y * firstArm.x) * area / share + 0.0;
                }
                if (std::fabs(std::sqrt(secondArm.x * secondArm.x + secondArm.y * secondArm.y +
                                        secondArm.z * secondArm.z)) > 1.0e-12 &&
                    std::fabs(std::sqrt(secondMoment.x * secondMoment.x + secondMoment.y * secondMoment.y +
                                        secondMoment.z * secondMoment.z)) > 1.0e-12) {
                    const double share = inertia[1] * nodeCount;
                    bendX = bendX + (secondArm.z * secondMoment.y - secondArm.y * secondMoment.z) * area / share;
                    bendY = (secondMoment.z * secondArm.x - secondArm.z * secondMoment.x) * area / share + bendY;
                    bendZ = (secondArm.y * secondMoment.x - secondMoment.y * secondArm.x) * area / share + bendZ;
                }
                if (std::fabs(std::sqrt(normalArm.x * normalArm.x + normalArm.y * normalArm.y +
                                        normalArm.z * normalArm.z)) > 1.0e-12 &&
                    std::fabs(std::sqrt(normalMoment.x * normalMoment.x + normalMoment.y * normalMoment.y +
                                        normalMoment.z * normalMoment.z)) > 1.0e-12) {
                    const double share = inertia[2] * nodeCount;
                    bendX = bendX + (normalMoment.y * normalArm.z - normalMoment.z * normalArm.y) * area / share;
                    bendY = (normalArm.x * normalMoment.z - normalMoment.x * normalArm.z) * area / share + bendY;
                    bendZ = (normalMoment.x * normalArm.y - normalArm.x * normalMoment.y) * area / share + bendZ;
                }

                const double denominator = nodeCount * total;
                double value = area * force[0] / denominator + bendX;
                bcElements_.push_back(node);
                bcKinds_.push_back(3);
                bcValues_.push_back(value);

                value = area * force[1] / denominator + bendY;
                bcElements_.push_back(node);
                bcKinds_.push_back(4);
                bcValues_.push_back(value);

                value = area * force[2] / denominator + bendZ;
                bcElements_.push_back(node);
                bcKinds_.push_back(5);
                bcValues_.push_back(value);
            }
        }
        return;
    }

    if (globalSimObject().fieldServer->dimension != 2) {
        return;
    }

    // 二维：原法向挪作第一主轴，法向改取 z 轴，只留绕 z 的一条力矩。
    firstAxis = normal;
    normal.x = 0.0;
    normal.y = 0.0;
    normal.z = 1.0;
    const double alongNormal = moment[0] * normal.x + moment[1] * normal.y + moment[2] * normal.z;
    const TcadGeom::Location normalMoment(normal.x * alongNormal, normal.y * alongNormal, normal.z * alongNormal);

    TcadGeom::Location normalArm{};
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        TcadBase::Iter<Node2> midNodes = elements[index]->node2s();
        std::vector<double> radii(nodes.Length() + midNodes.Length());

        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            if (globalSimObject().fieldServer->axisymmetricX_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].y - symmetryAxisOffset;
            } else if (globalSimObject().fieldServer->axisymmetric_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].x - symmetryAxisOffset;
            }
            ++collected;
        }
        if (collected == 0) {
            FLPS_panic(VOF_STR("Mesh element has no nodes"));
        }
        if (collected > 2) {
            FLPS_panic(VOF_STR("Element has more than 2 nodes!"));
        }
        const double length = DecomposedLength(points);

        // 二阶单元的中边节点接在角节点后面，只在轴对称时需要它们的回转半径。
        while (midNodes++) {
            Node2* const midNode = midNodes.current_pointer();
            if (globalSimObject().fieldServer->axisymmetricX_) {
                TcadGeom::Location midLocation = midNode->position();
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = midLocation.y - symmetryAxisOffset;
            } else if (globalSimObject().fieldServer->axisymmetric_) {
                TcadGeom::Location midLocation = midNode->position();
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = midLocation.x - symmetryAxisOffset;
            }
            ++collected;
        }

        std::vector<double> weights(collected, 1.0);
        double midScale;
        double cornerScale;
        if (!globalSimObject().fieldServer->axisymmetricX_ && !globalSimObject().fieldServer->axisymmetric_) {
            midScale = 0.6666666666666666;
            cornerScale = feOrder_ == 2 ? 1.0 / 6.0 : 0.5;
        } else {
            // 轴对称：一阶用两节点一致质量阵，二阶用三节点一致质量阵。
            const double linear[2][2] = {{1.0 / 3.0, 1.0 / 6.0}, {1.0 / 6.0, 1.0 / 3.0}};
            const double quadratic[3][3] = {{2.0 / 15.0, -1.0 / 30.0, 1.0 / 15.0},
                                            {-1.0 / 30.0, 2.0 / 15.0, 1.0 / 15.0},
                                            {1.0 / 15.0, 1.0 / 15.0, 8.0 / 15.0}};
            for (int row = 0; row < collected; ++row) {
                weights[row] = 0.0;
                if (feOrder_ == 1) {
                    for (int column = 0; column < collected; ++column) {
                        weights[row] = weights[row] + linear[row][column] * 6.283185307179586 * radii[column];
                    }
                } else if (feOrder_ == 2) {
                    for (int column = 0; column < collected; ++column) {
                        weights[row] = weights[row] + quadratic[row][column] * 6.283185307179586 * radii[column];
                    }
                }
            }
            midScale = 1.0;
            cornerScale = 1.0;
        }

        int slot = 0;
        nodes.reset();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            TcadGeom::Location location = node->position();
            double bend[2] = {0.0, 0.0};
            if (std::fabs(std::sqrt(normalMoment.x * normalMoment.x + normalMoment.y * normalMoment.y +
                                    normalMoment.z * normalMoment.z)) > 1.0e-12) {
                const double offsetX = location.x - centroid.x;
                const double offsetY = location.y - centroid.y;
                const double offsetZ = location.z - centroid.z;
                const double acrossSecond = offsetX * secondAxis.x + offsetY * secondAxis.y + offsetZ * secondAxis.z;
                const double acrossFirst = offsetX * firstAxis.x + offsetY * firstAxis.y + offsetZ * firstAxis.z;
                normalArm.x = firstAxis.x * acrossFirst + secondAxis.x * acrossSecond;
                normalArm.y = firstAxis.y * acrossFirst + secondAxis.y * acrossSecond;
                normalArm.z = firstAxis.z * acrossFirst + secondAxis.z * acrossSecond;
            }
            if (std::fabs(std::sqrt(normalArm.x * normalArm.x + normalArm.y * normalArm.y +
                                    normalArm.z * normalArm.z)) > 1.0e-12 &&
                std::fabs(std::sqrt(normalMoment.x * normalMoment.x + normalMoment.y * normalMoment.y +
                                    normalMoment.z * normalMoment.z)) > 1.0e-12) {
                bend[0] = (normalArm.z * normalMoment.y - normalArm.y * normalMoment.z) * length / inertia[2] + 0.0;
                bend[1] = (normalArm.x * normalMoment.z - normalArm.z * normalMoment.y) * length / inertia[2] + 0.0;
            }
            for (int component = 0; component < 2; ++component) {
                const double value = (length * force[component] / total + bend[component]) * weights[slot];
                bcElements_.push_back(node);
                bcKinds_.push_back(component + 3);
                const double scaled = value * cornerScale;
                bcValues_.push_back(scaled);
            }
            ++slot;
        }

        midNodes.reset();
        while (midNodes++) {
            Node2* const midNode = midNodes.current_pointer();
            TcadGeom::Location location = midNode->position();
            double bend[2] = {0.0, 0.0};
            if (std::fabs(std::sqrt(normalMoment.x * normalMoment.x + normalMoment.y * normalMoment.y +
                                    normalMoment.z * normalMoment.z)) > 1.0e-12) {
                const double offsetX = location.x - centroid.x;
                const double offsetY = location.y - centroid.y;
                const double offsetZ = location.z - centroid.z;
                const double acrossSecond = offsetX * secondAxis.x + offsetY * secondAxis.y + offsetZ * secondAxis.z;
                const double acrossFirst = offsetX * firstAxis.x + offsetY * firstAxis.y + offsetZ * firstAxis.z;
                normalArm.x = firstAxis.x * acrossFirst + secondAxis.x * acrossSecond;
                normalArm.y = firstAxis.y * acrossFirst + secondAxis.y * acrossSecond;
                normalArm.z = firstAxis.z * acrossFirst + secondAxis.z * acrossSecond;
            }
            if (std::fabs(std::sqrt(normalArm.x * normalArm.x + normalArm.y * normalArm.y +
                                    normalArm.z * normalArm.z)) > 1.0e-12 &&
                std::fabs(std::sqrt(normalMoment.x * normalMoment.x + normalMoment.y * normalMoment.y +
                                    normalMoment.z * normalMoment.z)) > 1.0e-12) {
                bend[0] = (normalArm.z * normalMoment.y - normalArm.y * normalMoment.z) * length / inertia[2] + 0.0;
                bend[1] = (normalArm.x * normalMoment.z - normalArm.z * normalMoment.y) * length / inertia[2] + 0.0;
            }
            for (int component = 0; component < 2; ++component) {
                const double value = (length * force[component] / total + bend[component]) * weights[slot];
                bcElements_.push_back(midNode);
                bcKinds_.push_back(component + 3);
                const double scaled = value * midScale;
                bcValues_.push_back(scaled);
            }
            ++slot;
        }
    }
}

void GeneralBoundary::apply_force(std::vector<Element*>& elements, int axis, double value) {
    // 集中力先按边界总面积摊成应力，再交给 apply_stress 那一支落到节点上。
    const double total = total_quantity(elements, nullptr, nullptr);
    if (total < 1.0e-30) {
        FLPS_panic(VOF_STR("Total area too small!"));
    }
    apply_stress(elements, axis, value / total);
}

void GeneralBoundary::apply_stress(std::vector<Element*>& elements, int axis, double value) {
    TcadGeom::Location points[8]{};

    if (globalSimObject().fieldServer->dimension == 3) {
        for (unsigned index = 0; index < elements.size(); ++index) {
            // 三维面单元：应力乘单元面积后按三节点均分。
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                ++collected;
            }
            const double area = DecomposedArea(points, collected);

            nodes.reset();
            while (nodes++) {
                bcElements_.push_back(nodes.current_pointer());
                bcKinds_.push_back(axis + 3);
                bcValues_.push_back(value * area / 3.0);
            }
        }
        return;
    }

    if (globalSimObject().fieldServer->dimension != 2) {
        return;
    }

    for (unsigned index = 0; index < elements.size(); ++index) {
        // 二维边单元：轴对称时按回转半径给每个节点算一致质量权，否则两端各半。
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        std::vector<double> radii(nodes.Length());
        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            if (globalSimObject().fieldServer->axisymmetricX_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].y - symmetryAxisOffset;
            } else if (globalSimObject().fieldServer->axisymmetric_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].x - symmetryAxisOffset;
            }
            ++collected;
        }
        if (collected == 0) {
            FLPS_panic(VOF_STR("Mesh element has no nodes"));
        }
        if (collected > 2) {
            FLPS_panic(VOF_STR("Element has more than 2 nodes!"));
        }

        const double length = DecomposedLength(points);
        std::vector<double> weights(nodes.Length(), 1.0);
        double scale;
        if (globalSimObject().fieldServer->axisymmetricX_ || globalSimObject().fieldServer->axisymmetric_) {
            const double revolve[2][2] = {{1.0 / 3.0, 1.0 / 6.0}, {1.0 / 6.0, 1.0 / 3.0}};
            for (int row = 0; row < collected; ++row) {
                double weight = 0.0;
                for (int column = 0; column < collected; ++column) {
                    weight = weight + revolve[row][column] * 6.283185307179586 * radii[column];
                }
                weights[row] = weight;
            }
            scale = 1.0;
        } else {
            scale = 0.5;
        }

        nodes.reset();
        int slot = 0;
        while (nodes++) {
            bcElements_.push_back(nodes.current_pointer());
            bcKinds_.push_back(axis + 3);
            bcValues_.push_back(value * weights[slot] * length * scale);
            ++slot;
        }
    }
}

void GeneralBoundary::apply_pressure(std::vector<Element*>& elements, double value) {
    TcadGeom::Location points[8]{};

    if (globalSimObject().fieldServer->dimension == 3) {
        for (unsigned index = 0; index < elements.size(); ++index) {
            // 压力乘单元面积后取反，沿外法向按三节点均分。
            TcadGeom::Location normal{};
            compute_elem_normal(elements[index], normal);
            const double magnitude = elements[index]->Size() * -value;
            const double alongX = magnitude * normal.x / 3.0;
            const double alongY = magnitude * normal.y / 3.0;
            const double alongZ = magnitude * normal.z / 3.0;

            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                bcElements_.push_back(node);
                bcKinds_.push_back(3);
                bcValues_.push_back(alongX);
                bcElements_.push_back(node);
                bcKinds_.push_back(4);
                bcValues_.push_back(alongY);
                bcElements_.push_back(node);
                bcKinds_.push_back(5);
                bcValues_.push_back(alongZ);
            }
        }
        return;
    }

    if (globalSimObject().fieldServer->dimension != 2) {
        return;
    }

    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        TcadGeom::Location normal{};
        compute_elem_normal(elements[index], normal);

        std::vector<double> radii(nodes.Length());
        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            if (globalSimObject().fieldServer->axisymmetricX_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].y - symmetryAxisOffset;
            } else if (globalSimObject().fieldServer->axisymmetric_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].x - symmetryAxisOffset;
            }
            ++collected;
        }
        if (collected == 0) {
            FLPS_panic(VOF_STR("Mesh element has no nodes"));
        }
        if (collected > 2) {
            FLPS_panic(VOF_STR("Element has more than 2 nodes!"));
        }

        std::vector<double> weights(nodes.Length(), 1.0);
        double scale;
        if (globalSimObject().fieldServer->axisymmetricX_ || globalSimObject().fieldServer->axisymmetric_) {
            const double revolve[2][2] = {{1.0 / 3.0, 1.0 / 6.0}, {1.0 / 6.0, 1.0 / 3.0}};
            for (int row = 0; row < collected; ++row) {
                weights[row] = 0.0;
                for (int column = 0; column < collected; ++column) {
                    weights[row] = weights[row] + revolve[row][column] * 6.283185307179586 * radii[column];
                }
            }
            scale = 1.0;
        } else {
            scale = 0.5;
        }

        // 二维只落 x、y 两个分量；z 分量照样算出来但不入表。
        nodes.reset();
        int slot = 0;
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const double magnitude = elements[index]->Size() * (-weights[slot] * value);
            double distributed[3];
            distributed[0] = magnitude * normal.x * scale;
            distributed[1] = magnitude * normal.y * scale;
            distributed[2] = magnitude * normal.z * scale;
            bcElements_.push_back(node);
            bcKinds_.push_back(3);
            bcValues_.push_back(distributed[0]);
            bcElements_.push_back(node);
            bcKinds_.push_back(4);
            bcValues_.push_back(distributed[1]);
            ++slot;
        }
    }
}

void GeneralBoundary::apply_pressure(std::vector<Element*>& elements, std::vector<double>& values, double scale) {
    TcadGeom::Location points[8]{};

    if (globalSimObject().fieldServer->dimension == 3) {
        for (unsigned index = 0; index < elements.size(); ++index) {
            TcadGeom::Location normal{};
            compute_elem_normal(elements[index], normal);
            const double pressure = -scale * values[index];
            const double magnitude = pressure * elements[index]->Size();
            const double alongX = magnitude * normal.x / 3.0;
            const double alongY = magnitude * normal.y / 3.0;
            const double alongZ = magnitude * normal.z / 3.0;

            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                bcElements_.push_back(node);
                bcKinds_.push_back(3);
                bcValues_.push_back(alongX);
                bcElements_.push_back(node);
                bcKinds_.push_back(4);
                bcValues_.push_back(alongY);
                bcElements_.push_back(node);
                bcKinds_.push_back(5);
                bcValues_.push_back(alongZ);
            }
        }
        return;
    }

    if (globalSimObject().fieldServer->dimension != 2) {
        return;
    }

    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        TcadGeom::Location normal{};
        compute_elem_normal(elements[index], normal);

        std::vector<double> radii(nodes.Length());
        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            if (globalSimObject().fieldServer->axisymmetricX_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].y - symmetryAxisOffset;
            } else if (globalSimObject().fieldServer->axisymmetric_) {
                double symmetryAxisOffset = 0.0;
                std::memcpy(&symmetryAxisOffset, &globalSimObject().fieldServer->symmAxisOffsetBits_,
                            sizeof(symmetryAxisOffset));
                radii[collected] = points[collected].x - symmetryAxisOffset;
            }
            ++collected;
        }
        if (collected == 0) {
            FLPS_panic(VOF_STR("Mesh element has no nodes"));
        }
        if (collected > 2) {
            FLPS_panic(VOF_STR("Element has more than 2 nodes!"));
        }

        std::vector<double> weights(nodes.Length(), 1.0);
        double revolveScale;
        if (globalSimObject().fieldServer->axisymmetricX_ || globalSimObject().fieldServer->axisymmetric_) {
            const double revolve[2][2] = {{1.0 / 3.0, 1.0 / 6.0}, {1.0 / 6.0, 1.0 / 3.0}};
            for (int row = 0; row < collected; ++row) {
                weights[row] = 0.0;
                for (int column = 0; column < collected; ++column) {
                    weights[row] = weights[row] + revolve[row][column] * 6.283185307179586 * radii[column];
                }
            }
            revolveScale = 1.0;
        } else {
            revolveScale = 0.5;
        }

        nodes.reset();
        int slot = 0;
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const double pressure = -weights[slot] * scale * values[index];
            const double magnitude = elements[index]->Size() * pressure;
            double distributed[3];
            distributed[0] = magnitude * normal.x * revolveScale;
            distributed[1] = magnitude * normal.y * revolveScale;
            distributed[2] = magnitude * normal.z * revolveScale;
            bcElements_.push_back(node);
            bcKinds_.push_back(3);
            bcValues_.push_back(distributed[0]);
            bcElements_.push_back(node);
            bcKinds_.push_back(4);
            bcValues_.push_back(distributed[1]);
            ++slot;
        }
    }
}

void GeneralBoundary::box_intersect2D(std::vector<Element*>& elements, std::vector<double>& values,
                                      TcadMath::P2<double> lower, TcadMath::P2<double> upper, std::string first,
                                      std::string second) {
    // 在界面网格里找材料名对得上的那一层，把它的边按盒裁剪，交量记成该边所属体网格单元的权重。
    bool matched = false;
    TcadBase::Iter<Mesh> interfaces(globalSimObject().fieldServer->interfaceMeshes);
    while (interfaces++) {
        Mesh* const interfaceMesh = interfaces.current_pointer();
        if (interfaceMesh->type_ == Mesh::DefaultMesh) {
            continue;
        }
        if (first.compare(interfaceMesh->material->Name()) != 0) {
            continue;
        }

        Mesh* bulkMesh;
        if (second.compare(interfaceMesh->Mesh1()->material->Name()) == 0) {
            bulkMesh = interfaceMesh->Mesh1();
        } else {
            if (second.compare(interfaceMesh->Mesh2()->material->Name()) != 0) {
                FLPS_panic(VOF_STR("Inconsistent definition of interface and bulk material (pressure bc)"));
            }
            bulkMesh = interfaceMesh->Mesh2();
        }

        ElementIter borders = interfaceMesh->elements(-1, -1);
        while (borders++) {
            Element* const border = borders.current_pointer();
            TcadBase::Iter<Node> nodes = border->nodes();
            nodes++;
            const Coordinate& headCoordinate = *nodes.current_pointer()->coordinate;
            const TcadMath::P2<double> head{headCoordinate.x, headCoordinate.y};
            nodes++;
            const Coordinate& tailCoordinate = *nodes.current_pointer()->coordinate;
            const TcadMath::P2<double> tail{tailCoordinate.x, tailCoordinate.y};

            double enter = 0.0;
            double leave = 0.0;
            mgoals::Intersects2d::clipByBox(head, tail, lower, upper, enter, leave);
            if (enter >= 0.0 && enter <= 1.0 && leave >= 0.0 && leave <= 1.0) {
                *globalSimObject().tee << teeInfoLevelDiagnostic << enter << VOF_STR(" and ") << leave;
                *globalSimObject().tee << " (" << head.x << "," << head.y << VOF_STR(") and");
                *globalSimObject().tee << " (" << tail.x << "," << tail.y << ")" << tendl;
                const double fraction = leave - enter;
                if (fraction > 0.0) {
                    values.push_back(fraction);
                    elements.push_back(border->ElementofRegion(*bulkMesh));
                    continue;
                }
                *globalSimObject().tee << teeInfoLevelDiagnostic << VOF_STR("edge may be right on the box (pressure bc)")
                                       << tendl;
            }
        }
        matched = true;
    }
    if (!matched) {
        FLPS_warning(VOF_STR("No interface found for pressure bc"));
    }
}

void GeneralBoundary::box_intersect3D(std::vector<Element*>& elements, std::vector<double>& values,
                                      TcadMath::P3<double> lower, TcadMath::P3<double> upper, std::string first,
                                      std::string second) {
    bool matched = false;
    TcadBase::Iter<Mesh> interfaces(globalSimObject().fieldServer->interfaceMeshes);
    while (interfaces++) {
        Mesh* const interfaceMesh = interfaces.current_pointer();
        if (interfaceMesh->type_ == Mesh::DefaultMesh) {
            continue;
        }
        if (first.compare(interfaceMesh->material->Name()) != 0) {
            continue;
        }

        Mesh* bulkMesh;
        if (second.compare(interfaceMesh->Mesh1()->material->Name()) == 0) {
            bulkMesh = interfaceMesh->Mesh1();
        } else {
            if (second.compare(interfaceMesh->Mesh2()->material->Name()) != 0) {
                FLPS_panic(VOF_STR("Inconsistent definition of interface and bulk material (pressure bc)"));
            }
            bulkMesh = interfaceMesh->Mesh2();
        }

        ElementIter borders = interfaceMesh->elements(-1, -1);
        while (borders++) {
            Element* const border = borders.current_pointer();
            TcadBase::Iter<Node> nodes = border->nodes();
            nodes++;
            const Coordinate& firstCoordinate = *nodes.current_pointer()->coordinate;
            const TcadMath::P3<double> corner0{firstCoordinate.x, firstCoordinate.y, firstCoordinate.z};
            nodes++;
            const Coordinate& secondCoordinate = *nodes.current_pointer()->coordinate;
            const TcadMath::P3<double> corner1{secondCoordinate.x, secondCoordinate.y, secondCoordinate.z};
            nodes++;
            const Coordinate& thirdCoordinate = *nodes.current_pointer()->coordinate;
            const TcadMath::P3<double> corner2{thirdCoordinate.x, thirdCoordinate.y, thirdCoordinate.z};

            int triangleCount = 0;
            std::vector<TcadMath::P3<double>> clipped;
            mgoals::Intersects3d::intersectTriBox(corner0, corner1, corner2, lower, upper, triangleCount, clipped);
            if (triangleCount > 0) {
                // 整块三角形的面积由两条边叉积的模长给出，裁剪后的碎片面积按同样公式累加。
                const double wholeCross = ((corner2.z - corner0.z) * (corner1.y - corner0.y) -
                                           (corner2.y - corner0.y) * (corner1.z - corner0.z)) *
                                              ((corner2.z - corner0.z) * (corner1.y - corner0.y) -
                                               (corner2.y - corner0.y) * (corner1.z - corner0.z)) +
                                          ((corner1.z - corner0.z) * (corner2.x - corner0.x) -
                                           (corner2.z - corner0.z) * (corner1.x - corner0.x)) *
                                              ((corner1.z - corner0.z) * (corner2.x - corner0.x) -
                                               (corner2.z - corner0.z) * (corner1.x - corner0.x)) +
                                          ((corner2.y - corner0.y) * (corner1.x - corner0.x) -
                                           (corner2.x - corner0.x) * (corner1.y - corner0.y)) *
                                              ((corner2.y - corner0.y) * (corner1.x - corner0.x) -
                                               (corner2.x - corner0.x) * (corner1.y - corner0.y));
                const double wholeArea = std::sqrt(wholeCross) * 0.5;

                double clippedArea = 0.0;
                for (int triangle = 0; triangle < triangleCount; ++triangle) {
                    const TcadMath::P3<double>& piece0 = clipped[static_cast<std::size_t>(3 * triangle)];
                    const TcadMath::P3<double>& piece1 = clipped[static_cast<std::size_t>(3 * triangle + 1)];
                    const TcadMath::P3<double>& piece2 = clipped[static_cast<std::size_t>(3 * triangle + 2)];
                    const double pieceCross = ((piece2.z - piece0.z) * (piece1.y - piece0.y) -
                                               (piece2.y - piece0.y) * (piece1.z - piece0.z)) *
                                                  ((piece2.z - piece0.z) * (piece1.y - piece0.y) -
                                                   (piece2.y - piece0.y) * (piece1.z - piece0.z)) +
                                              ((piece1.z - piece0.z) * (piece2.x - piece0.x) -
                                               (piece2.z - piece0.z) * (piece1.x - piece0.x)) *
                                                  ((piece1.z - piece0.z) * (piece2.x - piece0.x) -
                                                   (piece2.z - piece0.z) * (piece1.x - piece0.x)) +
                                              ((piece2.y - piece0.y) * (piece1.x - piece0.x) -
                                               (piece2.x - piece0.x) * (piece1.y - piece0.y)) *
                                                  ((piece2.y - piece0.y) * (piece1.x - piece0.x) -
                                                   (piece2.x - piece0.x) * (piece1.y - piece0.y));
                    clippedArea = clippedArea + std::sqrt(pieceCross) * 0.5;
                }
                const double fraction = clippedArea / wholeArea;

                *globalSimObject().tee << teeInfoLevelDiagnostic << triangleCount << VOF_STR(" triangles with fac==") << fraction
                                       << tendl;
                *globalSimObject().tee << teeInfoLevelDiagnostic << "(" << corner0.x << ", " << corner0.y << ", "
                                       << corner0.z << ") " << "(" << corner1.x << ", " << corner1.y << ", "
                                       << corner1.z << ") " << "(" << corner2.x << ", " << corner2.y << ", "
                                       << corner2.z << ") " << tendl;
                if (fraction > 0.0) {
                    values.push_back(fraction);
                    elements.push_back(border->ElementofRegion(*bulkMesh));
                    continue;
                }
                *globalSimObject().tee << teeInfoLevelDiagnostic << VOF_STR("Intersected triangles are too small (pressure bc)")
                                       << tendl;
            }
        }
        matched = true;
    }
    if (!matched) {
        FLPS_warning(VOF_STR("No interface found for pressure bc"));
    }
}

void GeneralBoundary::apply_box_pressure() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PressureBoxList"), pdblib::PDB0)) {
        return;
    }

    std::vector<Element*> elements;
    std::vector<double> values;
    // PressureBoxList 是一串空白分隔的盒名。
    const std::string list(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PressureBoxList"), pdblib::PDB0));
    std::istringstream stream(list);
    const std::vector<std::string> boxNames{std::istream_iterator<std::string>(stream),
                                            std::istream_iterator<std::string>()};

    for (std::size_t index = 0; index < boxNames.size(); ++index) {
        int count = 0;
        double* const box = pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), boxNames[index].c_str(),
                                                      VOF_STR("PressureBox"), pdblib::PDB0);
        if (count != 6) {
            FLPS_warning(VOF_STR("Inconsistent pressure box boundary condition data"));
        }
        const std::string interfaceMaterial(
            pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), boxNames[index].c_str(), VOF_STR("InterfaceMat"), pdblib::PDB0));
        const std::string pressureMaterial(
            pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), boxNames[index].c_str(), VOF_STR("PressureMat"), pdblib::PDB0));
        elements.clear();
        values.clear();
        // pdb 里的盒按 (xmin, xmax, ymin, ymax, zmin, zmax) 存，微米转厘米。
        if (globalSimObject().fieldServer->dimension == 2) {
            box_intersect2D(elements, values, TcadMath::P2<double>{box[0] * 0.0001, box[2] * 0.0001},
                            TcadMath::P2<double>{box[1] * 0.0001, box[3] * 0.0001}, interfaceMaterial,
                            pressureMaterial);
        } else if (globalSimObject().fieldServer->dimension == 3) {
            box_intersect3D(elements, values, TcadMath::P3<double>{box[0] * 0.0001, box[2] * 0.0001, box[4] * 0.0001},
                            TcadMath::P3<double>{box[1] * 0.0001, box[3] * 0.0001, box[5] * 0.0001}, interfaceMaterial,
                            pressureMaterial);
        }
        const double pressure =
            pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), boxNames[index].c_str(), VOF_STR("pressure"), pdblib::PDB0);
        apply_pressure(elements, values, pressure);
        delete[] box;
    }
}

void GeneralBoundary::apply_fluid_tension() {
    TcadBase::Iter<Mesh> meshes(globalSimObject().fieldServer->meshes);
    bool hasFluid = false;
    while (meshes++) {
        if (meshes.current_pointer()->type_ == Mesh::FluidMesh) {
            hasFluid = true;
            break;
        }
    }
    if (!hasFluid) {
        return;
    }

    // 表面张力场：已有就整场清零，没有就新建一张同名的。
    LocationData* const tensionForce = globalSimObject().fieldServer->VectorFindMatch(VOF_STR("TensionForce"));
    if (tensionForce != nullptr) {
        const TcadGeom::Location zero{0.0, 0.0, 0.0};
        *tensionForce = zero;
    } else {
        LocationData* const created = new LocationData(globalSimObject().fieldServer, NODE);
        created->SetName(VOF_STATIC_STR("TensionForce"));
    }

    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    meshes.reset();
    while (meshes++) {
        Mesh* const interfaceMesh = meshes.current_pointer();
        if (interfaceMesh->type_ != Mesh::InterfaceMesh) {
            continue;
        }
        // 只处理一侧是 Gas、另一侧“像流体”的界面；流体侧材料名是后面所有 pdb 查询的键。
        const std::string interfaceSideOne(interfaceMesh->Mesh1()->material->Name());
        const std::string interfaceSideTwo(interfaceMesh->Mesh2()->material->Name());
        std::string fluidMaterial;
        if (interfaceSideOne.compare(VOF_STR("Gas")) == 0 &&
            pdblib::pdbMaterialIsLike(*globalSimObject().interpreter, interfaceSideTwo.c_str(), VOF_STATIC_STR("Fluid"))) {
            fluidMaterial = interfaceSideTwo;
        } else if (interfaceSideTwo.compare(VOF_STR("Gas")) == 0 &&
                   pdblib::pdbMaterialIsLike(*globalSimObject().interpreter, interfaceSideOne.c_str(), VOF_STATIC_STR("Fluid"))) {
            fluidMaterial = interfaceSideOne;
        } else {
            continue;
        }

        // 两张按壁面材料名索引的表，长度必须逐项对齐。
        std::map<std::string, double> surfaceTension;
        std::map<std::string, double> contactAngle;

        int tensionNameCount = 0;
        std::string* const tensionNames = pdblib::pdbgetDoubleArrayIndex(
            interpreter, &tensionNameCount, fluidMaterial.c_str(), VOF_STR("SurfaceTension"), pdblib::PDB0);
        int tensionValueCount = 0;
        double* const tensionValues = pdblib::pdbgetDoubleArray(interpreter, &tensionValueCount, fluidMaterial.c_str(),
                                                                VOF_STR("SurfaceTension"), pdblib::PDB0);
        if (tensionNameCount != tensionValueCount) {
            FLPS_panic(VOF_STR("Error in PDB definition of surface tension for %s"), fluidMaterial.c_str());
        }
        for (int entry = 0; entry < tensionValueCount; ++entry) {
            surfaceTension[tensionNames[entry]] = tensionValues[entry];
        }
        delete[] tensionNames;
        delete[] tensionValues;

        int angleNameCount = 0;
        std::string* const angleNames = pdblib::pdbgetDoubleArrayIndex(
            interpreter, &angleNameCount, fluidMaterial.c_str(), VOF_STR("ContactAngle"), pdblib::PDB0);
        int angleValueCount = 0;
        double* const angleValues = pdblib::pdbgetDoubleArray(interpreter, &angleValueCount, fluidMaterial.c_str(),
                                                              VOF_STR("ContactAngle"), pdblib::PDB0);
        if (angleNameCount != angleValueCount) {
            FLPS_panic(VOF_STR("Error in PDB definition of contact angle for %s"), fluidMaterial.c_str());
        }
        if (tensionValueCount != angleValueCount) {
            FLPS_panic(VOF_STR("Inconsistent definitions of surface tension and contact angle for %s"), fluidMaterial.c_str());
        }
        for (int entry = 0; entry < angleValueCount; ++entry) {
            contactAngle[angleNames[entry]] = angleValues[entry];
            if (surfaceTension.find(angleNames[entry]) == surfaceTension.end()) {
                FLPS_panic(VOF_STR("Inconsistent definitions of surface tension and contact angle for %s"),
                           fluidMaterial.c_str());
            }
        }
        delete[] angleNames;
        delete[] angleValues;

        // 第一遍：沿气/液界面的边找出压在它上面的壁面区域。
        std::vector<Element*> tensionElements;
        std::vector<Edge*> tensionEdges;
        std::vector<std::string> wallMaterials;
        std::vector<std::vector<double>> tensionForces;

        TcadBase::Iter<Edge> edges = interfaceMesh->edges(-1, -1);
        while (edges++) {
            Edge* const edge = edges.current_pointer();
            static TcadBase::Seq<Element> matched;
            edge->ElementMatch(matched);
            if (matched.Length() > 3) {
                std::vector<std::string> touchingMaterials;
                std::vector<Element*> touchingElements;
                for (int slot = 0; slot != matched.Length(); ++slot) {
                    Element* const candidate = matched.data[slot];
                    if (candidate->mesh->type_ > 1) {
                        continue;
                    }
                    touchingMaterials.push_back(candidate->mesh->material->Name());
                    touchingElements.push_back(candidate);
                }
                std::vector<std::string> wallCandidates;
                std::vector<Element*> wallElements;
                for (std::size_t slot = 0; slot < touchingMaterials.size(); ++slot) {
                    if (surfaceTension.find(touchingMaterials[slot]) != surfaceTension.end()) {
                        wallCandidates.push_back(touchingMaterials[slot]);
                        wallElements.push_back(touchingElements[slot]);
                    }
                }
                if (!wallCandidates.empty()) {
                    if (wallCandidates.size() != 1) {
                        FLPS_warning(
                            VOF_STR("More than one matched wall region found on gas/fluid interface; a random wall "
                            "material is used"));
                    }
                    wallMaterials.push_back(wallCandidates[0]);
                    tensionElements.push_back(wallElements[0]);
                    tensionEdges.push_back(edge);
                }
            }
        }

        // 第二遍：逐条三相接触线算表面张力。
        for (std::size_t line = 0; line != tensionEdges.size(); ++line) {
            Edge* const edge = tensionEdges[line];
            TcadGeom::Location fluidNormal{};
            ElementIter edgeMatches = edge->Matches();
            ElementIter edgeHigher = edge->higher();
            edgeHigher++;
            ElementIter faceMatches = edgeHigher.current_pointer()->Matches();
            while (faceMatches++) {
                Element* const candidate = faceMatches.current_pointer();
                if (candidate->mesh->type_ == Mesh::FluidMesh) {
                    compute_elem_normal(candidate, fluidNormal);
                    break;
                }
            }

            TcadGeom::Location wallNormal{};
            while (edgeMatches++) {
                Element* const candidate = edgeMatches.current_pointer();
                if (candidate->mesh->type_ != Mesh::InterfaceMesh) {
                    continue;
                }
                const std::string sideOne(candidate->mesh->Mesh1()->material->Name());
                const std::string sideTwo(candidate->mesh->Mesh2()->material->Name());
                if (!((sideOne == fluidMaterial && sideTwo == wallMaterials[line]) ||
                      (sideTwo == fluidMaterial && sideOne == wallMaterials[line]))) {
                    continue;
                }
                ElementIter wallHigher = candidate->higher();
                wallHigher++;
                ElementIter wallMatches = wallHigher.current_pointer()->Matches();
                while (wallMatches++) {
                    Element* const wallCandidate = wallMatches.current_pointer();
                    if (wallCandidate->mesh->type_ > 1) {
                        continue;
                    }
                    if (interfaceSideOne.compare(wallCandidate->mesh->material->Name()) == 0) {
                        continue;
                    }
                    if (interfaceSideTwo.compare(wallCandidate->mesh->material->Name()) == 0) {
                        continue;
                    }
                    compute_elem_normal(wallCandidate, wallNormal);
                    break;
                }
            }

            // 壁面方向 = 边方向与壁面法向的叉积，用流体法向定向后归一化。
            const Coordinate& head = *edge->firstNode->coordinate;
            const Coordinate& tail = *edge->secondNode->coordinate;
            const double alongX = head.x - tail.x;
            const double alongY = head.y - tail.y;
            const double alongZ = head.z - tail.z;
            const double acrossX = wallNormal.z * alongY - wallNormal.y * alongZ;
            const double acrossY = alongZ * wallNormal.x - wallNormal.z * alongX;
            const double acrossZ = wallNormal.y * alongX - wallNormal.x * alongY;
            const double outward = fluidNormal.x * acrossX + fluidNormal.y * acrossY + fluidNormal.z * acrossZ;
            const double magnitude =
                std::sqrt(acrossX * outward * (acrossX * outward) + acrossY * outward * (acrossY * outward) +
                          acrossZ * outward * (acrossZ * outward));
            if (magnitude < 0.0) {
                FLPS_warning(VOF_STR("Zero normal detected for wall direction"));
            }
            const double wallX = acrossX * outward / magnitude;
            const double wallY = acrossY * outward / magnitude;
            const double wallZ = acrossZ * outward / magnitude;

            const double tension = surfaceTension[wallMaterials[line]];
            const double angle = contactAngle[wallMaterials[line]];
            double angleSin = 0.0;
            double angleCos = 0.0;
            ::sincos(3.141592653589793 * angle / 180.0, &angleSin, &angleCos);
            const double alongNormal = tension * angleSin;
            const double alongWall = -tension * angleCos;

            std::vector<double> force;
            force.push_back(alongNormal * wallNormal.x + alongWall * wallX);
            force.push_back(alongNormal * wallNormal.y + alongWall * wallY);
            force.push_back(wallNormal.z * alongNormal + wallZ * alongWall);
            tensionForces.push_back(force);
        }

        apply_line_force(tensionElements, tensionForces);
    }
}

void GeneralBoundary::apply_fluid_pressure() {
    TcadBase::Iter<Mesh> meshes(globalSimObject().fieldServer->meshes);
    bool hasFluid = false;
    while (meshes++) {
        if (meshes.current_pointer()->type_ == Mesh::FluidMesh) {
            hasFluid = true;
            break;
        }
    }
    if (!hasFluid) {
        return;
    }

    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    meshes.reset();
    while (meshes++) {
        Mesh* const interfaceMesh = meshes.current_pointer();
        if (interfaceMesh->type_ != Mesh::InterfaceMesh) {
            continue;
        }
        const std::string sideOne(interfaceMesh->Mesh1()->material->Name());
        const std::string sideTwo(interfaceMesh->Mesh2()->material->Name());

        // 取“一侧像流体、另一侧不是气”的界面：流体侧作 pdb 键，另一侧是承压的固体。
        std::string fluidMaterial;
        std::string wallMaterial;
        if (pdblib::pdbMaterialIsLike(*globalSimObject().interpreter, sideOne.c_str(), VOF_STATIC_STR("Fluid")) &&
            sideTwo.compare(VOF_STR("Gas")) != 0) {
            fluidMaterial = sideOne;
            wallMaterial = sideTwo;
        } else if (sideOne.compare(VOF_STR("Gas")) != 0 &&
                   pdblib::pdbMaterialIsLike(*globalSimObject().interpreter, sideTwo.c_str(), VOF_STATIC_STR("Fluid"))) {
            fluidMaterial = sideTwo;
            wallMaterial = sideOne;
        } else {
            continue;
        }

        std::map<std::string, double> averagePressure;
        int nameCount = 0;
        std::string* const names = pdblib::pdbgetDoubleArrayIndex(interpreter, &nameCount, fluidMaterial.c_str(),
                                                                  VOF_STR("AveragePressure"), pdblib::PDB0);
        int valueCount = 0;
        double* const values =
            pdblib::pdbgetDoubleArray(interpreter, &valueCount, fluidMaterial.c_str(), VOF_STR("AveragePressure"), pdblib::PDB0);
        if (nameCount != valueCount) {
            FLPS_panic(VOF_STR("Error in PDB definition of average pressure for %s"), fluidMaterial.c_str());
        }
        for (int entry = 0; entry < valueCount; ++entry) {
            averagePressure[names[entry]] = values[entry];
        }
        delete[] values;
        delete[] names;

        if (averagePressure.find(wallMaterial) != averagePressure.end()) {
            const double pressure = averagePressure[wallMaterial];
            // 收集界面另一侧属于该固体材料的所有单元，压力值一律补成 1.0 由 apply_pressure 缩放。
            std::vector<Element*> pressureElements;
            std::vector<double> pressureValues;
            ElementIter borders = interfaceMesh->elements(-1, -1);
            while (borders++) {
                ElementIter matches = borders.current_pointer()->Matches();
                while (matches++) {
                    Element* const candidate = matches.current_pointer();
                    if (wallMaterial.compare(candidate->mesh->material->Name()) == 0) {
                        pressureElements.push_back(candidate);
                    }
                }
            }
            pressureValues.resize(pressureElements.size(), 1.0);
            apply_pressure(pressureElements, pressureValues, pressure);
        }
    }
}

void GeneralBoundary::apply_reflow2D(Mesh* interfaceMesh, Mesh* materialMesh, double force) {
    TcadBase::Iter<Node> nodes = interfaceMesh->nodes(-1, -1);
    while (nodes++) {
        Node* const node = nodes.current_pointer();
        OEdgeIter edges = node->edges();
        // 只处理恰好挂着两条边的节点。
        if (edges.elements() == nullptr || edges.elements()->Length() != 2) {
            continue;
        }

        // 节点周围属于承力体网格的那个单元；有多个时取最后一个。
        TcadBase::Seq<Element> matched;
        node->ElementMatch(matched);
        Element* owner = nullptr;
        for (int slot = 0; slot != matched.Length(); ++slot) {
            if (matched.data[slot]->mesh == materialMesh) {
                owner = matched.data[slot];
            }
        }

        while (edges++) {
            Edge* const edge = edges.elements()->data[edges.index()];
            Node* head = edge->firstNode;
            Node* tail = edge->secondNode;
            if (edges.elements()->reversed[edges.index()] == 0) {
                Node* const swapped = head;
                head = tail;
                tail = swapped;
            }
            if (node == tail) {
                Node* const swapped = head;
                head = tail;
                tail = swapped;
            }
            const Coordinate& from = *head->coordinate;
            const Coordinate& to = *tail->coordinate;
            double alongZ = to.z - from.z;
            double alongX = to.x - from.x;
            double alongY = to.y - from.y;
            const double length = std::sqrt(alongX * alongX + alongY * alongY + alongZ * alongZ);
            if (length > 0.0) {
                alongZ = alongZ / length;
                alongX = alongX / length;
                alongY = alongY / length;
            }

            // z 分量照样算出来但二维不入表。
            double reflow[3];
            reflow[0] = alongX * force;
            reflow[1] = alongY * force;
            reflow[2] = alongZ * force;
            bcElements_.push_back(owner);
            bcKinds_.push_back(3);
            bcValues_.push_back(reflow[0]);
            bcElements_.push_back(owner);
            bcKinds_.push_back(4);
            bcValues_.push_back(reflow[1]);
        }
    }
}

void GeneralBoundary::apply_reflow3D(Mesh* interfaceMesh, Mesh* materialMesh, double force) {
    TcadBase::Iter<Node> nodes = interfaceMesh->nodes(-1, -1);
    while (nodes++) {
        Node* const node = nodes.current_pointer();

        // 三维要求节点恰好匹配三个单元。
        TcadBase::Seq<Element> matched;
        node->ElementMatch(matched);
        if (matched.Length() != 3) {
            continue;
        }
        Element* owner = nullptr;
        for (int slot = 0; slot != 3; ++slot) {
            if (matched.data[slot]->mesh == materialMesh) {
                owner = matched.data[slot];
            }
        }

        OEdgeIter edges = node->edges();
        while (edges++) {
            Edge* const edge = edges.elements()->data[edges.index()];
            Node* head = edge->firstNode;
            Node* tail = edge->secondNode;
            if (edges.elements()->reversed[edges.index()] == 0) {
                Node* const swapped = head;
                head = tail;
                tail = swapped;
            }
            if (node == tail) {
                Node* const swapped = head;
                head = tail;
                tail = swapped;
            }
            const Coordinate& from = *head->coordinate;
            const Coordinate& to = *tail->coordinate;
            double alongZ = to.z - from.z;
            double alongX = to.x - from.x;
            double alongY = to.y - from.y;
            const double length = std::sqrt(alongX * alongX + alongY * alongY + alongZ * alongZ);
            if (length > 0.0) {
                alongZ = alongZ / length;
                alongX = alongX / length;
                alongY = alongY / length;
            }

            double reflow[3];
            reflow[0] = alongX * force;
            reflow[1] = alongY * force;
            reflow[2] = alongZ * force;
            bcElements_.push_back(owner);
            bcKinds_.push_back(3);
            bcValues_.push_back(reflow[0]);
            bcElements_.push_back(owner);
            bcKinds_.push_back(4);
            bcValues_.push_back(reflow[1]);
            bcElements_.push_back(owner);
            bcKinds_.push_back(5);
            bcValues_.push_back(reflow[2]);
        }
    }
}

void GeneralBoundary::apply_reflow_force() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    // 遍历界面网格：一侧是气就把另一侧当承力材料，pdb 里配了 Reflow.Force 才施加。
    FieldServer& fieldServer = *globalSimObject().fieldServer;
    for (int index = 0; index != fieldServer.interfaceMeshes.count; ++index) {
        Mesh* const interfaceMesh = fieldServer.interfaceMeshes.data[index];
        Mesh* const sideOne = interfaceMesh->Mesh1();
        Mesh* const sideTwo = interfaceMesh->Mesh2();
        Mesh* materialMesh;
        if (sideOne->type_ == Mesh::GasMesh) {
            materialMesh = sideTwo;
        } else if (sideTwo->type_ == Mesh::GasMesh) {
            materialMesh = sideOne;
        } else {
            continue;
        }

        const char* const material = materialMesh->material->Name();
        if (!pdblib::pdbIsAvailable(interpreter, material, VOF_STR("Mechanics"), VOF_STR("Reflow.Force"), pdblib::PDB0)) {
            continue;
        }
        const double force = pdblib::pdbgetDouble(interpreter, material, VOF_STR("Mechanics"), VOF_STR("Reflow.Force"), pdblib::PDB0);
        if (globalSimObject().fieldServer->dimension == 2) {
            apply_reflow2D(interfaceMesh, materialMesh, force);
        } else if (globalSimObject().fieldServer->dimension == 3) {
            apply_reflow3D(interfaceMesh, materialMesh, force);
        }
    }
}

void GeneralBoundary::apply_DDD_traction() {
    // 没装位错动力学接口就整支不做（定值 deck 走的就是这条）。
    SPDDDInterface* const spdddInterface = _globalPool->spdddInterface.get();
    if (spdddInterface == nullptr) {
        return;
    }

    // 真身在这里整表拷一份再消费，不是就地引用。
    const std::map<Element*, std::vector<double>> traction = spdddInterface->elementTraction;
    TcadGeom::Location points[8]{};

    if (globalSimObject().fieldServer->dimension == 3) {
        for (std::map<Element*, std::vector<double>>::const_iterator entry = traction.begin(); entry != traction.end();
             ++entry) {
            TcadBase::Iter<Node> nodes = entry->first->nodes();
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                ++collected;
            }
            const double area = DecomposedArea(points, collected);

            nodes.reset();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                for (int component = 0; component < 3; ++component) {
                    bcElements_.push_back(node);
                    bcKinds_.push_back(component + 3);
                    bcValues_.push_back(area * entry->second[component] / 3.0);
                }
            }
        }
        return;
    }

    if (globalSimObject().fieldServer->dimension != 2) {
        return;
    }
    for (std::map<Element*, std::vector<double>>::const_iterator entry = traction.begin(); entry != traction.end();
         ++entry) {
        TcadBase::Iter<Node> nodes = entry->first->nodes();
        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            ++collected;
        }
        const double length = DecomposedLength(points);

        nodes.reset();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            for (int component = 0; component < 3; ++component) {
                bcElements_.push_back(node);
                bcKinds_.push_back(component + 3);
                bcValues_.push_back(length * entry->second[component] * 0.5);
            }
        }
    }
}

void GeneralBoundary::apply_line_force(std::vector<Element*>& elements, std::vector<std::vector<double>> forces) {
    // 先取场，再判维度——真身的次序如此，维度不对时那次查找已经发生。
    LocationData* const tensionForce = globalSimObject().fieldServer->VectorFindMatch(VOF_STR("TensionForce"));
    if (globalSimObject().fieldServer->dimension != 3) {
        FLPS_panic(VOF_STR("Line force boundary condition is only available in 3D"));
    }

    for (unsigned index = 0; index < elements.size(); ++index) {
        // 线段载荷按长度的一半摊给两端。
        const double length = elements[index]->Size();
        double scaled[3];
        scaled[0] = length * forces[index][0] * 0.5;
        scaled[1] = length * forces[index][1] * 0.5;
        scaled[2] = length * forces[index][2] * 0.5;

        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            bcElements_.push_back(node);
            bcKinds_.push_back(3);
            bcValues_.push_back(scaled[0]);
            bcElements_.push_back(node);
            bcKinds_.push_back(4);
            bcValues_.push_back(scaled[1]);
            bcElements_.push_back(node);
            bcKinds_.push_back(5);
            bcValues_.push_back(scaled[2]);

            // 同一份力还要就地累进 TensionForce 场的对应槽。
            TcadGeom::Location& stored =
                tensionForce->materialData(node->elementKind, node->mesh->material->materialIndex)
                    ->data[node->dataIndex];
            stored.x = stored.x + scaled[0];
            stored.y = stored.y + scaled[1];
            stored.z = stored.z + scaled[2];
        }
    }
}

void GeneralBoundary::apply_zipping_force() {
    // Native floops::GeneralBoundary implementation is a one-byte return;
    // product-specific zipping behavior lives in derived boundary classes.
}

void GeneralBoundary::apply_displacement(std::vector<Element*>& elements, int axis, double value) {
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            bcElements_.push_back(node);
            bcKinds_.push_back(axis);
            bcValues_.push_back(value);
        }
    }
}

void get_boundary_elements(int boundary, std::vector<Element*>& elements) {
    FieldServer& fieldServer = *globalSimObject().fieldServer;
    fieldServer.BoundingBox(true);

    for (int meshIndex = 0; meshIndex != fieldServer.meshes.count; ++meshIndex) {
        Mesh* const mesh = fieldServer.meshes.data[meshIndex];
        if (std::strcmp(mesh->material->Name(), VOF_STR("Gas")) == 0 || mesh->elementSize_ != fieldServer.dimension) {
            continue;
        }

        ElementIter borders = mesh->Borders();
        while (borders++) {
            Element* const border = borders.current_pointer();
            ElementIter lowers = border->lower();
            while (lowers++) {
                Element* const lower = lowers.current_pointer();
                int physicalMatches = 0;
                ElementIter matches = lower->Matches();
                while (matches++) {
                    Element* const match = matches.current_pointer();
                    if (match->mesh->type_ != Mesh::DefaultMesh) {
                        ++physicalMatches;
                    }
                }
                if (physicalMatches == 1 && lower->WhichBorder() == boundary) {
                    elements.push_back(lower);
                }
            }
        }
    }
}

void get_contact_elements(TcadBase::Iter<Mesh>& contactMeshIter, std::vector<Element*>& elements) {
    // 原始实现只取迭代器当前所指的那张 mesh，不推进迭代器。
    Mesh& contactMesh = *contactMeshIter.current_pointer();
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    const bool randomMatch =
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Contact.Random.Match202009"), pdblib::PDB0) != 0;

    std::vector<Material*> contactMaterials;
    TcadBase::List<Contact>* const contacts = _globalPool->globalDeviceGlobals->contacts();
    if (contacts != nullptr) {
        TcadBase::Iter<Contact> iterator(*contacts);
        while (iterator++) {
            Contact* const contact = iterator.current_pointer();
            if (contact->name_ == contactMesh.Name() && contact->material_ != nullptr) {
                contactMaterials.push_back(contact->material_);
            }
        }
    }

    ElementIter contactElements = contactMesh.elements(-1, -1);
    while (contactElements++) {
        Element* const contactElement = contactElements.current_pointer();
        Element* firstMatch = nullptr;
        int matchCount = 0;
        ElementIter matches = contactElement->Matches();
        while (matches++) {
            Element* const candidate = matches.current_pointer();
            if (candidate->mesh == nullptr || candidate->mesh->type_ > 1) {
                continue;
            }

            bool materialMatches = randomMatch;
            if (!materialMatches && candidate->mesh->material != nullptr) {
                for (Material* const material : contactMaterials) {
                    if (material != nullptr && *candidate->mesh->material == *material) {
                        materialMatches = true;
                        break;
                    }
                }
            }
            if (!materialMatches) {
                continue;
            }

            if (firstMatch == nullptr) {
                firstMatch = candidate;
            }
            ++matchCount;
        }

        if (firstMatch != nullptr) {
            elements.push_back(firstMatch);
        }
        if (matchCount == 0) {
            FLPS_warning(VOF_STR("No matching bulk element for contact %s to apply mechanics boundary condition"),
                         contactMesh.Name());
        } else if (matchCount > 1) {
            FLPS_warning(VOF_STR("Multiple bulk elements matched for contact %s to apply mechanics boundary condition"),
                         contactMesh.Name());
        }
    }
}

void get_top_elements(std::vector<Element*>& elements) {
    // 真身这里传的是 false（同族的 get_boundary_elements 传 true），照抄。
    globalSimObject().fieldServer->BoundingBox(false);

    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (std::strcmp(mesh->material->Name(), VOF_STR("Gas")) == 0) {
            continue;
        }
        // 维度每轮现取（真身逐轮重走 GlobalObject<GlobalSim>::operator->）。
        if (globalSimObject().fieldServer->dimension != mesh->elementSize_) {
            continue;
        }

        ElementIter borders = mesh->Borders();
        while (borders++) {
            Element* const border = borders.current_pointer();
            ElementIter lowers = border->lower();
            while (lowers++) {
                Element* const lower = lowers.current_pointer();
                int physicalMatches = 0;
                ElementIter matches = lower->Matches();
                while (matches++) {
                    if (matches.current_pointer()->mesh->type_ != Mesh::DefaultMesh) {
                        ++physicalMatches;
                    }
                }
                // 顶面判据：只贴一片实体、且形心 x 落在包围盒 xmin 上（容差 1e-12）。
                if (physicalMatches == 1 &&
                    std::fabs(lower->position().x - globalSimObject().fieldServer->bounding_box_xmin) < 1.0e-12) {
                    elements.push_back(lower);
                }
            }
        }
    }
}

int GeneralBoundary::is_constrained(const char* name) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    const auto available = [interpreter, name](const char* key) {
        return pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0) != 0;
    };
    const auto value = [interpreter, name](const char* key) {
        return pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0);
    };

    // 五类约束按固定优先级依次短路判定，先命中的那一类决定返回码。
    if (available("dx") || available("dy") || available("dz") || available(VOF_STATIC_STR("dxP")) || available(VOF_STATIC_STR("dyP")) ||
        available(VOF_STATIC_STR("dzP"))) {
        return 1;
    }
    if (available("fx") || available("fy") || available("fz") || available(VOF_STATIC_STR("fxP")) || available(VOF_STATIC_STR("fyP")) ||
        available(VOF_STATIC_STR("fzP")) || available("mx") || available("my") || available("mz")) {
        return 2;
    }
    if (available("sx") || available("sy") || available("sz") || available(VOF_STATIC_STR("pressure")) || available(VOF_STATIC_STR("sxP")) ||
        available(VOF_STATIC_STR("syP")) || available(VOF_STATIC_STR("szP"))) {
        return 3;
    }
    if (value("Cx") > 0.5 || value("Cy") > 0.5 || value("Cz") > 0.5) {
        return 4;
    }
    if (value("Px") > 0.5 || value("Py") > 0.5 || value("Pz") > 0.5) {
        return 5;
    }
    return 0;
}

void GeneralBoundary::print_defined_bc(const char* name) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    const auto available = [interpreter, name](const char* key) {
        return pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0) != 0;
    };
    const auto value = [interpreter, name](const char* key) {
        return pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0);
    };
    const auto text = [interpreter, name](const char* key) {
        return pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0);
    };
    // 每打一行都重新取一次 GlobalSim（真身逐块 operator->），闸门命中后
    // 键值再查一遍，与闸门那一次是两次独立查询。
    const auto printDouble = [&](const char* label, const char* key) {
        *globalSimObject().tee << teeInfoLevelCommand << name << label << value(key) << tendl;
    };
    const auto printText = [&](const char* label, const char* key) {
        *globalSimObject().tee << teeInfoLevelCommand << name << label << text(key) << tendl;
    };

    // 二十五个键按固定顺序逐个过闸：前十项与后九项由 pdbIsAvailable 把关，
    // 中间六项（周期/耦合系数）的闸门是 pdbgetDouble(...) > 0.5。
    if (available("dx")) {
        printDouble(VOF_STATIC_STR("\tdx\t"), "dx");
    }
    if (available("dy")) {
        printDouble(VOF_STATIC_STR("\tdy\t"), "dy");
    }
    if (available("dz")) {
        printDouble(VOF_STATIC_STR("\tdz\t"), "dz");
    }
    if (available("fx")) {
        printDouble(VOF_STATIC_STR("\tfx\t"), "fx");
    }
    if (available("fy")) {
        printDouble(VOF_STATIC_STR("\tfy\t"), "fy");
    }
    if (available("fz")) {
        printDouble(VOF_STATIC_STR("\tfz\t"), "fz");
    }
    if (available("sx")) {
        printDouble(VOF_STATIC_STR("\tsx\t"), "sx");
    }
    if (available("sy")) {
        printDouble(VOF_STATIC_STR("\tsy\t"), "sy");
    }
    if (available("sz")) {
        printDouble(VOF_STATIC_STR("\tsz\t"), "sz");
    }
    if (available(VOF_STATIC_STR("pressure"))) {
        printDouble(VOF_STATIC_STR("\tpressure\t"), VOF_STATIC_STR("pressure"));
    }
    if (value("Cx") > 0.5) {
        printDouble(VOF_STATIC_STR("\tCx\t"), "Cx");
    }
    if (value("Cy") > 0.5) {
        printDouble(VOF_STATIC_STR("\tCy\t"), "Cy");
    }
    if (value("Cz") > 0.5) {
        printDouble(VOF_STATIC_STR("\tCz\t"), "Cz");
    }
    if (value("Px") > 0.5) {
        printDouble(VOF_STATIC_STR("\tPx\t"), "Px");
    }
    if (value("Py") > 0.5) {
        printDouble(VOF_STATIC_STR("\tPy\t"), "Py");
    }
    if (value("Pz") > 0.5) {
        printDouble(VOF_STATIC_STR("\tPz\t"), "Pz");
    }
    // 九个 Tcl 过程名版本打的是串，不是数。
    if (available(VOF_STATIC_STR("dxP"))) {
        printText(VOF_STATIC_STR("\tdxP\t"), VOF_STATIC_STR("dxP"));
    }
    if (available(VOF_STATIC_STR("dyP"))) {
        printText(VOF_STATIC_STR("\tdyP\t"), VOF_STATIC_STR("dyP"));
    }
    if (available(VOF_STATIC_STR("dzP"))) {
        printText(VOF_STATIC_STR("\tdzP\t"), VOF_STATIC_STR("dzP"));
    }
    if (available(VOF_STATIC_STR("fxP"))) {
        printText(VOF_STATIC_STR("\tfxP\t"), VOF_STATIC_STR("fxP"));
    }
    if (available(VOF_STATIC_STR("fyP"))) {
        printText(VOF_STATIC_STR("\tfyP\t"), VOF_STATIC_STR("fyP"));
    }
    if (available(VOF_STATIC_STR("fzP"))) {
        printText(VOF_STATIC_STR("\tfzP\t"), VOF_STATIC_STR("fzP"));
    }
    if (available(VOF_STATIC_STR("sxP"))) {
        printText(VOF_STATIC_STR("\tsxP\t"), VOF_STATIC_STR("sxP"));
    }
    if (available(VOF_STATIC_STR("syP"))) {
        printText(VOF_STATIC_STR("\tsyP\t"), VOF_STATIC_STR("syP"));
    }
    if (available(VOF_STATIC_STR("szP"))) {
        printText(VOF_STATIC_STR("\tszP\t"), VOF_STATIC_STR("szP"));
    }
}
int GeneralBoundary::get_valid_bc_number(const char* name) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    const auto available = [interpreter, name](const char* key) {
        return pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0) != 0;
    };
    const auto value = [interpreter, name](const char* key) {
        return pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0);
    };

    // 三个分量各自数一遍本轴上定义了几种边界条件；同一轴上出现两种即冲突，
    // 报错的那一轴不计入总数。
    int total = 0;
    int count;

    count = 0;
    count += available("dx");
    count += available("fx");
    count += available("sx");
    count += available(VOF_STATIC_STR("pressure"));
    count += value("Cx") > 0.5;
    count += value("Px") > 0.5;
    count += available(VOF_STATIC_STR("dxP"));
    count += available(VOF_STATIC_STR("fxP"));
    count += available(VOF_STATIC_STR("sxP"));
    if (count > 1) {
        FLPS_panic(VOF_STR("Error: conflicted BC definition on %s"), name);
    } else {
        total += count;
    }

    count = 0;
    count += available("dy");
    count += available("fy");
    count += available("sy");
    count += available(VOF_STATIC_STR("pressure"));
    count += value("Cy") > 0.5;
    count += value("Py") > 0.5;
    count += available(VOF_STATIC_STR("dyP"));
    count += available(VOF_STATIC_STR("fyP"));
    count += available(VOF_STATIC_STR("syP"));
    if (count > 1) {
        FLPS_panic(VOF_STR("Error: conflicted BC definition on %s"), name);
    } else {
        total += count;
    }

    count = 0;
    count += available("dz");
    count += available("fz");
    count += available("sz");
    count += available(VOF_STATIC_STR("pressure"));
    count += value("Cz") > 0.5;
    count += value("Pz") > 0.5;
    count += available(VOF_STATIC_STR("dzP"));
    count += available(VOF_STATIC_STR("fzP"));
    count += available(VOF_STATIC_STR("szP"));
    if (count > 1) {
        FLPS_panic(VOF_STR("Error: conflicted BC definition on %s"), name);
    } else {
        total += count;
    }

    return total;
}

void GeneralBoundary::collect_defined_bc() {
    // 真身开工第一件事就是把接触面清单取到手（`operator->` 带惰性补建），
    // 迭代器随即在栈上就位，之后才轮到三张并行表清空。
    TcadBase::Iter<Contact> contactIter(*_globalPool->globalDeviceGlobals->contacts());

    // Native resets the logical ends of these three parallel vectors without
    // releasing their capacities.
    bcElements_.clear();
    bcKinds_.clear();
    bcValues_.clear();

    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    // 维度在真身里是每次现取（两处各一次 GlobalObject<GlobalSim>::operator->），
    // 不缓存进局部量。
    if (globalSimObject().fieldServer->dimension > 1) {
        double leftPeriodic = 0.0;
        if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Left"), VOF_STR("Periodic"), pdblib::PDB0)) {
            leftPeriodic = 1.0;
        }
        pdblib::pdbsetDouble(interpreter, leftPeriodic, VOF_STR("Mechanics"), VOF_STR("Left"), "Px", pdblib::PDB0);
        pdblib::pdbsetDouble(interpreter, leftPeriodic, VOF_STR("Mechanics"), VOF_STR("Left"), "Py", pdblib::PDB0);

        double rightPeriodic = 0.0;
        if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Right"), VOF_STR("Periodic"), pdblib::PDB0)) {
            rightPeriodic = 1.0;
        }
        pdblib::pdbsetDouble(interpreter, rightPeriodic, VOF_STR("Mechanics"), VOF_STR("Right"), "Px", pdblib::PDB0);
        pdblib::pdbsetDouble(interpreter, rightPeriodic, VOF_STR("Mechanics"), VOF_STR("Right"), "Py", pdblib::PDB0);

        if (globalSimObject().fieldServer->dimension > 2) {
            pdblib::pdbsetDouble(interpreter, leftPeriodic, VOF_STR("Mechanics"), VOF_STR("Left"), "Pz", pdblib::PDB0);
            pdblib::pdbsetDouble(interpreter, rightPeriodic, VOF_STR("Mechanics"), VOF_STR("Right"), "Pz", pdblib::PDB0);

            double frontPeriodic = 0.0;
            if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Front"), VOF_STR("Periodic"), pdblib::PDB0)) {
                frontPeriodic = 1.0;
            }
            pdblib::pdbsetDouble(interpreter, frontPeriodic, VOF_STR("Mechanics"), VOF_STR("Front"), "Px", pdblib::PDB0);
            pdblib::pdbsetDouble(interpreter, frontPeriodic, VOF_STR("Mechanics"), VOF_STR("Front"), "Py", pdblib::PDB0);
            pdblib::pdbsetDouble(interpreter, frontPeriodic, VOF_STR("Mechanics"), VOF_STR("Front"), "Pz", pdblib::PDB0);

            double backPeriodic = 0.0;
            if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Back"), VOF_STR("Periodic"), pdblib::PDB0)) {
                backPeriodic = 1.0;
            }
            pdblib::pdbsetDouble(interpreter, backPeriodic, VOF_STR("Mechanics"), VOF_STR("Back"), "Px", pdblib::PDB0);
            pdblib::pdbsetDouble(interpreter, backPeriodic, VOF_STR("Mechanics"), VOF_STR("Back"), "Py", pdblib::PDB0);
            pdblib::pdbsetDouble(interpreter, backPeriodic, VOF_STR("Mechanics"), VOF_STR("Back"), "Pz", pdblib::PDB0);
        }
    }

    // 接触面在前、五个命名边界在后，累加次序照抄二进制。
    int defined = 0;
    while (contactIter++) {
        defined += get_valid_bc_number(contactIter.current_pointer()->name_.c_str());
    }
    defined += get_valid_bc_number(VOF_STATIC_STR("Bottom"));
    defined += get_valid_bc_number(VOF_STATIC_STR("Front"));
    defined += get_valid_bc_number(VOF_STATIC_STR("Back"));
    defined += get_valid_bc_number(VOF_STATIC_STR("Left"));
    defined += get_valid_bc_number(VOF_STATIC_STR("Right"));
    defined += pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0) != 0;
    defined += pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0) != 0;

    if (defined > 0) {
        enhancedBC_ = true;
        *globalSimObject().tee << teeInfoLevelCommand << VOF_STR("List of defined boundary conditions:") << tendl;
        *globalSimObject().tee << teeInfoLevelCommand << VOF_STR("Location\tType\tValue") << tendl;
        print_defined_bc(VOF_STATIC_STR("Bottom"));
        print_defined_bc(VOF_STATIC_STR("Bulk.Top"));
        print_defined_bc(VOF_STATIC_STR("Left"));
        print_defined_bc(VOF_STATIC_STR("Right"));
        print_defined_bc(VOF_STATIC_STR("Front"));
        print_defined_bc(VOF_STATIC_STR("Back"));
        // 同一个迭代器复位后再走一遍（真身只在 -0x40 写回空指针、下标归零）。
        contactIter.reset();
        while (contactIter++) {
            print_defined_bc(contactIter.current_pointer()->name_.c_str());
        }
    }

    // 体力开关与上面的清点各判各的：真身两处 `+0x2C8 = 1` 之间没有短路，
    // 无论 defined 是否为正，Apply.Body.Force 都要查一次。
    if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Apply.Body.Force"), pdblib::PDB0)) {
        enhancedBC_ = true;
    }

    if (globalSimObject().fieldServer->dimension == 3) {
        FieldServer& fieldServer = *globalSimObject().fieldServer;
        for (int index = 0; index != fieldServer.meshes.count; ++index) {
            if (fieldServer.meshes.data[index]->type_ == Mesh::FluidMesh) {
                enhancedBC_ = true;
                break;
            }
        }
    }
}

void GeneralBoundary::validate_defined_bc() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Check.Rigid.Body"), pdblib::PDB0)) {
        *globalSimObject().tee << VOF_STR("Note: checking for rigid body movement was skipped") << tendl;
        return;
    }

    // 六个槽装得下全部分量码；判据只看前三格（x/y/z）。
    int counts[6] = {};
    // 计数轮次取自 bcElements_ 的长度，下标却打在并行的 bcKinds_ 上，真身如此。
    // 闩是 32 位自增＋零扩展、比较走 jb，故下标是 unsigned 而非 size_t。
    for (unsigned index = 0; index < bcElements_.size(); ++index) {
        ++counts[bcKinds_[index]];
    }

    // 三条判据各自重新取一次维度：真身 0x2352354 / 0x235237d / 0x23523a1 是三处
    // 独立的 GlobalObject-> 展开（各带惰性补建段），缓存成一个局部会少两处。
    if (globalSimObject().fieldServer->dimension > 0 && counts[0] == 0) {
        FLPS_panic(VOF_STR("At least one point needs to be fixed along x direction"));
    }
    if (globalSimObject().fieldServer->dimension > 1 && counts[1] == 0) {
        FLPS_panic(VOF_STR("At least one point needs to be fixed along y direction"));
    }
    if (globalSimObject().fieldServer->dimension > 2 && counts[2] == 0) {
        FLPS_panic(VOF_STR("At least one point needs to be fixed along z direction"));
    }
}

void GeneralBoundary::validate_pbc_pair(const char* name, int axis) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    const auto available = [interpreter, name](const char* key) {
        return pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, key, pdblib::PDB0) != 0;
    };

    // 真身按 axis 分三支，三条 pdbIsAvailable 各支自带一份（共九个调用点），
    // 只有 C? 那个键名与随后的 pdbgetDouble 是三支共用的。
    const char* couplingKey;
    int defined;
    if (axis == 0) {
        defined = available("dx");
        defined += available("fx");
        defined += available("sx");
        couplingKey = "Cx";
    } else if (axis == 1) {
        defined = available("dy");
        defined += available("fy");
        defined += available("sy");
        couplingKey = "Cy";
    } else {
        defined = available("dz");
        defined += available("fz");
        defined += available("sz");
        couplingKey = "Cz";
    }

    // 周期系数与该方向上的任一 Dirichlet/力/应力条件互斥。
    if (pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, couplingKey, pdblib::PDB0) > 0.5 || defined != 0) {
        FLPS_panic(VOF_STR("Error: periodic boundary definition conflicts"));
    }
}

void GeneralBoundary::enforce_periodic(std::vector<Element*>& first, std::vector<Element*>& second, int axis, int mode,
                                       double value) {
    if (value < 0.5) {
        return;
    }

    // 临时标记场。BaseData 构造即自挂 dataList，真身建完不释放，照抄。
    IntData* const marks = new IntData(globalSimObject().fieldServer, NODE);

    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    while (meshes++) {
        TcadBase::Iter<Node> nodes = meshes.current_pointer()->nodes();
        while (nodes++) {
            marks->set(nodes.current_pointer(), 0);
        }
    }

    // 从属侧（second）先整体打 1，逐节点消费掉，天然去重。
    for (unsigned index = 0; index < second.size(); ++index) {
        TcadBase::Iter<Node> nodes = second[index]->nodes();
        while (nodes++) {
            marks->set(nodes.current_pointer(), 1);
        }
    }

    for (unsigned index = 0; index < second.size(); ++index) {
        TcadBase::Iter<Node> nodes = second[index]->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            if (marks->value(node) != 1) {
                continue;
            }
            marks->set(node, 0);

            // 权重缓冲在真身里占 32 字节（栈上 -0xb0..-0x91），且不预清零。
            double weights[4];
            const int master = get_master(*node, first, axis, weights);
            if (master < 0) {
                continue;
            }

            enhancedBCNodes_->push_back(node);
            int terms = 0;
            TcadBase::Iter<Node> masterNodes = first[master]->nodes();
            while (masterNodes++) {
                enhancedBCNodes_->push_back(masterNodes.current_pointer());
                enhancedBCValues_->push_back(-weights[terms]);
                ++terms;
            }
            // 项数含从属节点本身，系数表末尾再补一个 0.0。
            ++terms;
            enhancedBCValues_->push_back(0.0);
            enhancedBCPairs_->push_back(terms);
            enhancedBCPairs_->push_back(mode);
        }
    }
}

void GeneralBoundary::enforce_coupling(std::vector<Element*>& elements, int axis, double value) {
    if (_globalPool->jobInfo->getEToolName() != 2) {
        FLPS_warning(VOF_STR("Coupling boundary condition is not supported"));
        return;
    }

    IntData* const marks = new IntData(globalSimObject().fieldServer, NODE);
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (value < 0.5) {
        return;
    }

    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    while (meshes++) {
        TcadBase::Iter<Node> nodes = meshes.current_pointer()->nodes();
        while (nodes++) {
            marks->set(nodes.current_pointer(), 0);
        }
    }
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        while (nodes++) {
            marks->set(nodes.current_pointer(), 1);
        }
    }

    if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Constraint.Loop"), pdblib::PDB0) &&
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Constraint.Loop"), pdblib::PDB0)) {
        // 逐单元把节点串成链：每相邻两节点一条「两项、系数 (−1, 0)」的约束。
        for (unsigned index = 0; index < elements.size(); ++index) {
            Node* previous = nullptr;
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                if (previous != nullptr) {
                    enhancedBCPairs_->push_back(2);
                    enhancedBCPairs_->push_back(axis);
                    enhancedBCValues_->push_back(-1.0);
                    enhancedBCValues_->push_back(0.0);
                    enhancedBCNodes_->push_back(node);
                    enhancedBCNodes_->push_back(previous);
                }
                previous = node;
            }
        }
    } else {
        // 全局第一个带标记的节点当锚点，其余全部与它耦合；锚点跨网格不复位。
        Node* anchor = nullptr;
        meshes.reset();
        while (meshes++) {
            TcadBase::Iter<Node> nodes = meshes.current_pointer()->nodes();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                if (marks->value(node) != 1) {
                    continue;
                }
                if (anchor == nullptr) {
                    anchor = node;
                    continue;
                }
                if (node == anchor) {
                    continue;
                }
                enhancedBCPairs_->push_back(2);
                enhancedBCPairs_->push_back(axis);
                enhancedBCValues_->push_back(-1.0);
                enhancedBCValues_->push_back(0.0);
                enhancedBCNodes_->push_back(node);
                enhancedBCNodes_->push_back(anchor);
                marks->set(node, 0);
            }
        }
    }
}

void GeneralBoundary::apply_boundary_bc() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    const char* const displacementKeys[3] = {"dx", "dy", "dz"};
    const char* const forceKeys[3] = {"fx", "fy", "fz"};
    const char* const momentKeys[3] = {"mx", "my", "mz"};
    const char* const stressKeys[3] = {"sx", "sy", "sz"};
    const char* const rotationKeys[3] = {"rx", "ry", "rz"};
    const char* const axisKeys[3] = {"xa", "ya", "za"};
    const char* const displacementProcKeys[3] = {VOF_STATIC_STR("dxP"), VOF_STATIC_STR("dyP"), VOF_STATIC_STR("dzP")};
    const char* const forceProcKeys[3] = {VOF_STATIC_STR("fxP"), VOF_STATIC_STR("fyP"), VOF_STATIC_STR("fzP")};
    const char* const stressProcKeys[3] = {VOF_STATIC_STR("sxP"), VOF_STATIC_STR("syP"), VOF_STATIC_STR("szP")};
    const char* const couplingKeys[3] = {"Cx", "Cy", "Cz"};
    const char* const periodicKeys[3] = {"Px", "Py", "Pz"};
    const char* const names[6] = {VOF_STATIC_STR("Left"), VOF_STATIC_STR("Right"), VOF_STATIC_STR("Front"), VOF_STATIC_STR("Back"), VOF_STATIC_STR("Bottom"), VOF_STATIC_STR("Bulk.Top")};

    std::vector<Element*> elements;
    std::vector<Element*> partnerElements;

    for (int boundary = 0; boundary != 6; ++boundary) {
        const char* const name = names[boundary];
        if (is_constrained(name) == 0 || is_constrained(name) > 3) {
            continue;
        }

        elements.clear();
        if (boundary == 5) {
            get_top_elements(elements);
        } else {
            get_boundary_elements(boundary + 1, elements);
        }

        bool hasRotation = false;
        for (int axis = 0; axis != 3; ++axis) {
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[axis], pdblib::PDB0) ||
                pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, momentKeys[axis], pdblib::PDB0)) {
                hasRotation = true;
            }
        }

        if (hasRotation) {
            if (globalSimObject().fieldServer->dimension == 2 &&
                (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[0], pdblib::PDB0) ||
                 pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[1], pdblib::PDB0))) {
                FLPS_warning(VOF_STR("Rotations are specified in x and y directions for a 2D problem!!"));
            }
            if (globalSimObject().fieldServer->dimension == 3) {
                // 三条提醒各查「本方向没有平动、却给了另两轴的转角」。
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[0], pdblib::PDB0) &&
                    (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[1], pdblib::PDB0) ||
                     pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[2], pdblib::PDB0))) {
                    FLPS_warning(
                        VOF_STR("Translation not specified in x-direction, yet rotational component present. Rotation will be "
                        "ignored. Please make sure translation and rotational constraints are consistent"));
                }
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[1], pdblib::PDB0) &&
                    (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[0], pdblib::PDB0) ||
                     pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[2], pdblib::PDB0))) {
                    FLPS_warning(
                        VOF_STR("Translation not specified in y-direction, yet rotational component present. Rotation will be "
                        "ignored. Please make sure translation and rotational constraints are consistent"));
                }
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[2], pdblib::PDB0) &&
                    (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[0], pdblib::PDB0) ||
                     pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[1], pdblib::PDB0))) {
                    FLPS_warning(
                        VOF_STR("Translation not specified in z-direction, yet rotational component present. Rotation will be "
                        "ignored. Please make sure translation and rotational constraints are consistent"));
                }
            }

            // 刚体位移多点约束：转轴点 xa/ya/za ＋ 转角 rx/ry/rz ＋ 平动 dx/dy/dz。
            bool applyRigidBody = false;
            double rotation[3] = {};
            double translation[3] = {};
            double axisPoint[3] = {};
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, axisKeys[axis], pdblib::PDB0)) {
                    axisPoint[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, axisKeys[axis], pdblib::PDB0);
                }
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[axis], pdblib::PDB0)) {
                    rotation[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, rotationKeys[axis], pdblib::PDB0);
                    applyRigidBody = hasRotation;
                }
            }
            for (int axis = 0; axis != 3; ++axis) {
                // 有转角时这条闸门一旦开过就一直开着：后续分量沿用上一轮的平动量。
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0)) {
                    translation[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0);
                    apply_displacement_mpc(elements, axis, rotation, translation, axisPoint);
                    applyRigidBody = hasRotation;
                } else if (applyRigidBody) {
                    apply_displacement_mpc(elements, axis, rotation, translation, axisPoint);
                    applyRigidBody = hasRotation;
                }
            }

            // 力矩 mx/my/mz ＋ 力 fx/fy/fz 的刚体多点约束，转轴点与上面共用。
            bool applyForceMpc = false;
            double moments[3] = {};
            double forces[3] = {};
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, momentKeys[axis], pdblib::PDB0)) {
                    moments[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, momentKeys[axis], pdblib::PDB0);
                    applyForceMpc = hasRotation;
                }
            }
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0)) {
                    forces[axis] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0);
                    applyForceMpc = hasRotation;
                }
            }
            if (applyForceMpc) {
                apply_force_mpc(elements, moments, forces, axisPoint);
            }
        }

        for (int axis = 0; axis != 3; ++axis) {
            // 平动：这里不乘时间步长以外的任何量；大变形或位移解时才乘步长。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0) &&
                !hasRotation) {
                const double raw =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0);
                double value = raw;
                if (globalSimObject().fieldServer->largeDeformationFlag_ ||
                    pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0)) {
                    value = getTimeStep() * raw;
                }
                apply_displacement(elements, axis, value);
            }

            // 力与应力都先试 <键>.Rate；命中则按速率乘 stepEndTime_。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0) && !hasRotation) {
                const std::string rateKey = std::string(forceKeys[axis]) + VOF_STR(".Rate");
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0)) {
                    apply_force(elements, axis,
                                pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0) *
                                    stepEndTime_);
                } else {
                    apply_force(elements, axis,
                                pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0));
                }
            }

            // 应力这一支没有 !hasRotation 闸门，真身如此。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, stressKeys[axis], pdblib::PDB0)) {
                const std::string rateKey = std::string(stressKeys[axis]) + VOF_STR(".Rate");
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0)) {
                    apply_stress(elements, axis,
                                 pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0) *
                                     stepEndTime_);
                } else {
                    apply_stress(elements, axis,
                                 pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, stressKeys[axis], pdblib::PDB0));
                }
            }

            // Tcl 过程名版本三条。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementProcKeys[axis], pdblib::PDB0)) {
                apply_displacement(elements, axis,
                                   const_cast<char*>(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name,
                                                                          displacementProcKeys[axis], pdblib::PDB0)));
            }
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, forceProcKeys[axis], pdblib::PDB0)) {
                apply_force(elements, axis,
                            const_cast<char*>(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name, forceProcKeys[axis],
                                                                   pdblib::PDB0)));
            }
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, stressProcKeys[axis], pdblib::PDB0)) {
                apply_stress(elements, axis,
                             const_cast<char*>(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name,
                                                                    stressProcKeys[axis], pdblib::PDB0)));
            }
        }

        if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, VOF_STR("pressure"), pdblib::PDB0)) {
            apply_pressure(elements, pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, VOF_STR("pressure"), pdblib::PDB0));
        }
    }

    // 收尾一：is_constrained == 4 的四个侧面按 Cx/Cy/Cz 调 enforce_coupling。
    for (int boundary = 1; boundary != 5; ++boundary) {
        const char* const name = names[boundary - 1];
        if (is_constrained(name) == 4) {
            elements.clear();
            get_boundary_elements(boundary, elements);
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, couplingKeys[axis], pdblib::PDB0)) {
                    enforce_coupling(
                        elements, axis,
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, couplingKeys[axis], pdblib::PDB0));
                }
            }
        }
    }

    // 收尾二：(Left, Right) / (Front, Back) 两对按 Px/Py/Pz 互相补齐。
    for (int pair = 0; pair != 2; ++pair) {
        const char* const lowerName = names[2 * pair];
        const char* const upperName = names[2 * pair + 1];
        for (int axis = 0; axis != 3; ++axis) {
            if (pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), lowerName, periodicKeys[axis], pdblib::PDB0) > 0.5) {
                validate_pbc_pair(upperName, axis);
                pdblib::pdbsetDouble(interpreter, 1.0, VOF_STR("Mechanics"), upperName, periodicKeys[axis], pdblib::PDB0);
            }
            if (pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), upperName, periodicKeys[axis], pdblib::PDB0) > 0.5) {
                validate_pbc_pair(lowerName, axis);
                pdblib::pdbsetDouble(interpreter, 1.0, VOF_STR("Mechanics"), lowerName, periodicKeys[axis], pdblib::PDB0);
            }
        }
    }

    // 收尾三：is_constrained == 5 的两对各取两侧单元调 enforce_periodic，
    // 循环上界是维度而不是 3。
    for (int pair = 0; pair != 2; ++pair) {
        const char* const name = names[2 * pair];
        if (is_constrained(name) != 5) {
            continue;
        }
        elements.clear();
        get_boundary_elements(2 * pair + 2, elements);
        partnerElements.clear();
        get_boundary_elements(2 * pair + 1, partnerElements);
        for (int mode = 0; mode < globalSimObject().fieldServer->dimension; ++mode) {
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, periodicKeys[mode], pdblib::PDB0)) {
                enforce_periodic(
                    partnerElements, elements, pair, mode,
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, periodicKeys[mode], pdblib::PDB0));
            }
        }
    }
}

void GeneralBoundary::apply_enhanced_bc(std::vector<int>& pairs, std::vector<double>& values,
                                        std::vector<Node*>& nodes) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    const char* const displacementKeys[3] = {"dx", "dy", "dz"};
    const char* const forceKeys[3] = {"fx", "fy", "fz"};
    const char* const momentKeys[3] = {"mx", "my", "mz"};
    const char* const stressKeys[3] = {"sx", "sy", "sz"};
    const char* const rotationKeys[3] = {"rx", "ry", "rz"};
    const char* const axisKeys[3] = {"xa", "ya", "za"};
    const char* const displacementProcKeys[3] = {VOF_STATIC_STR("dxP"), VOF_STATIC_STR("dyP"), VOF_STATIC_STR("dzP")};
    const char* const forceProcKeys[3] = {VOF_STATIC_STR("fxP"), VOF_STATIC_STR("fyP"), VOF_STATIC_STR("fzP")};
    const char* const stressProcKeys[3] = {VOF_STATIC_STR("sxP"), VOF_STATIC_STR("syP"), VOF_STATIC_STR("szP")};

    TcadBase::Iter<Mesh> defaults(globalSimObject().fieldServer->defaultMeshes);

    std::vector<Element*> elements;

    enhancedBCPairs_ = &pairs;
    enhancedBCValues_ = &values;
    enhancedBCNodes_ = &nodes;

    updateStepEndTime();
    apply_point_disp();
    apply_point_force();
    apply_body_force();
    apply_DDD_traction();
    apply_box_pressure();
    apply_fluid_tension();
    apply_fluid_pressure();
    apply_reflow_force();
    apply_zipping_force();
    apply_boundary_bc();

    while (defaults++) {
        const char* const name = defaults.current_pointer()->Name();
        if (is_constrained(name) == 0) {
            continue;
        }

        elements.clear();
        get_contact_elements(defaults, elements);

        bool hasRotation = false;
        for (int axis = 0; axis != 3; ++axis) {
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[axis], pdblib::PDB0) ||
                pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, momentKeys[axis], pdblib::PDB0)) {
                hasRotation = true;
            }
        }

        if (hasRotation) {
            if (globalSimObject().fieldServer->dimension == 2 &&
                (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[0], pdblib::PDB0) ||
                 pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[1], pdblib::PDB0))) {
                FLPS_warning(VOF_STR("Rotations are specified in x and y directions for a 2D problem!!"));
            }
            if (globalSimObject().fieldServer->dimension == 3) {
                // 三条提醒各查「本方向没有平动、却给了另两轴的转角」。
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[0], pdblib::PDB0) &&
                    (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[1], pdblib::PDB0) ||
                     pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[2], pdblib::PDB0))) {
                    FLPS_warning(
                        VOF_STR("Translation not specified in x-direction, yet rotational component present. Rotation will be "
                        "ignored. Please make sure translation and rotational constraints are consistent"));
                }
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[1], pdblib::PDB0) &&
                    (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[0], pdblib::PDB0) ||
                     pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[2], pdblib::PDB0))) {
                    FLPS_warning(
                        VOF_STR("Translation not specified in y-direction, yet rotational component present. Rotation will be "
                        "ignored. Please make sure translation and rotational constraints are consistent"));
                }
                if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[2], pdblib::PDB0) &&
                    (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[0], pdblib::PDB0) ||
                     pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[1], pdblib::PDB0))) {
                    FLPS_warning(
                        VOF_STR("Translation not specified in z-direction, yet rotational component present. Rotation will be "
                        "ignored. Please make sure translation and rotational constraints are consistent"));
                }
            }

            // 刚体位移多点约束：转轴点 xa/ya/za ＋ 转角 rx/ry/rz ＋ 平动 dx/dy/dz。
            bool applyRigidBody = false;
            double rotation[3] = {};
            double translation[3] = {};
            double axisPoint[3] = {};
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, axisKeys[axis], pdblib::PDB0)) {
                    axisPoint[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, axisKeys[axis], pdblib::PDB0);
                }
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rotationKeys[axis], pdblib::PDB0)) {
                    rotation[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, rotationKeys[axis], pdblib::PDB0);
                    applyRigidBody = hasRotation;
                }
            }
            for (int axis = 0; axis != 3; ++axis) {
                // 有转角时这道闸门一旦开过就一直开着：后续分量沿用上一轮的平动量。
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0)) {
                    translation[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0);
                    // 与 apply_boundary_bc 的唯一实质差别：接触面的刚体平动量要乘时间步长
                    if (globalSimObject().fieldServer->largeDeformationFlag_ ||
                        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0)) {
                        translation[axis] = getTimeStep() * translation[axis];
                    }
                    apply_displacement_mpc(elements, axis, rotation, translation, axisPoint);
                    applyRigidBody = hasRotation;
                } else if (applyRigidBody) {
                    apply_displacement_mpc(elements, axis, rotation, translation, axisPoint);
                    applyRigidBody = hasRotation;
                }
            }

            // 力矩 mx/my/mz ＋ 力 fx/fy/fz 的刚体多点约束，转轴点与上面共用。
            bool applyForceMpc = false;
            double moments[3] = {};
            double forces[3] = {};
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, momentKeys[axis], pdblib::PDB0)) {
                    moments[axis] =
                        pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, momentKeys[axis], pdblib::PDB0);
                    applyForceMpc = hasRotation;
                }
            }
            for (int axis = 0; axis != 3; ++axis) {
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0)) {
                    forces[axis] = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0);
                    applyForceMpc = hasRotation;
                }
            }
            if (applyForceMpc) {
                apply_force_mpc(elements, moments, forces, axisPoint);
            }
        }

        for (int axis = 0; axis != 3; ++axis) {
            // 平动：大变形或位移解时乘步长。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0) &&
                !hasRotation) {
                const double raw =
                    pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, displacementKeys[axis], pdblib::PDB0);
                double value = raw;
                if (globalSimObject().fieldServer->largeDeformationFlag_ ||
                    pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0)) {
                    value = getTimeStep() * raw;
                }
                apply_displacement(elements, axis, value);
            }

            // 力与应力都先试 <键>.Rate；命中则按速率乘 stepEndTime_。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0) && !hasRotation) {
                const std::string rateKey = std::string(forceKeys[axis]) + VOF_STR(".Rate");
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0)) {
                    apply_force(elements, axis,
                                pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0) *
                                    stepEndTime_);
                } else {
                    apply_force(elements, axis,
                                pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, forceKeys[axis], pdblib::PDB0));
                }
            }

            // 应力这一支没有 !hasRotation 闸门，真身如此。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, stressKeys[axis], pdblib::PDB0)) {
                const std::string rateKey = std::string(stressKeys[axis]) + VOF_STR(".Rate");
                if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0)) {
                    apply_stress(elements, axis,
                                 pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, rateKey.c_str(), pdblib::PDB0) *
                                     stepEndTime_);
                } else {
                    apply_stress(elements, axis,
                                 pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, stressKeys[axis], pdblib::PDB0));
                }
            }

            // Tcl 过程名版本三条。
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, displacementProcKeys[axis], pdblib::PDB0)) {
                apply_displacement(elements, axis,
                                   const_cast<char*>(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name,
                                                                          displacementProcKeys[axis], pdblib::PDB0)));
            }
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, forceProcKeys[axis], pdblib::PDB0)) {
                apply_force(elements, axis,
                            const_cast<char*>(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name, forceProcKeys[axis],
                                                                   pdblib::PDB0)));
            }
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, stressProcKeys[axis], pdblib::PDB0)) {
                apply_stress(elements, axis,
                             const_cast<char*>(pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), name,
                                                                    stressProcKeys[axis], pdblib::PDB0)));
            }
        }

        if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), name, VOF_STR("pressure"), pdblib::PDB0)) {
            apply_pressure(elements, pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), name, VOF_STR("pressure"), pdblib::PDB0));
        }
    }

    validate_defined_bc();
}

void GeneralBoundary::compute_elem_normal(Element* element, TcadGeom::Location& normal) {
    Node* first = nullptr;
    Node* second = nullptr;
    if (globalSimObject().fieldServer->dimension == 2) {
        // 二维边界单元取前两个节点，边方向与 z 轴叉乘得到面内法向。
        TcadBase::Iter<Node> nodes = element->nodes();
        nodes++;
        first = nodes.current_pointer();
        nodes++;
        second = nodes.current_pointer();
        const Coordinate& head = *first->coordinate;
        const Coordinate& tail = *second->coordinate;
        const double edgeX = tail.x - head.x;
        const double edgeY = tail.y - head.y;
        const double edgeZ = tail.z - head.z;
        normal.x = 0.0 * edgeZ - 1.0 * edgeY;
        normal.y = 1.0 * edgeX - 0.0 * edgeZ;
        normal.z = 0.0 * edgeY - 0.0 * edgeX;
    }

    Node* third = nullptr;
    Node* fourth = nullptr;
    if (globalSimObject().fieldServer->dimension == 3) {
        // 三维面单元取前三个节点做叉乘；四节点面还要记住第四个，供后面排除自身节点。
        TcadBase::Iter<Node> nodes = element->nodes();
        nodes++;
        first = nodes.current_pointer();
        nodes++;
        second = nodes.current_pointer();
        nodes++;
        third = nodes.current_pointer();
        if (nodes.Length() > 3) {
            nodes++;
            fourth = nodes.current_pointer();
        }
        const Coordinate& origin = *first->coordinate;
        const Coordinate& along = *second->coordinate;
        const Coordinate& across = *third->coordinate;
        const double firstEdgeX = along.x - origin.x;
        const double firstEdgeY = along.y - origin.y;
        const double firstEdgeZ = along.z - origin.z;
        const double secondEdgeX = across.x - origin.x;
        const double secondEdgeY = across.y - origin.y;
        const double secondEdgeZ = across.z - origin.z;
        normal.x = firstEdgeY * secondEdgeZ - firstEdgeZ * secondEdgeY;
        normal.y = firstEdgeZ * secondEdgeX - firstEdgeX * secondEdgeZ;
        normal.z = firstEdgeX * secondEdgeY - firstEdgeY * secondEdgeX;
    }

    // 在相邻的高维实体单元里找一个不属于本单元的节点，用它把法向定向到外侧。
    int matches = 0;
    Node* opposite = nullptr;
    ElementIter higher = element->higher();
    while (higher++) {
        Element* const candidate = higher.current_pointer();
        if (candidate->IsSkeletal()) {
            continue;
        }
        const Mesh::MeshType meshType = candidate->mesh->type_;
        if (meshType > 1 && meshType != Mesh::FluidMesh) {
            continue;
        }
        ++matches;
        if (globalSimObject().fieldServer->dimension == 2) {
            TcadBase::Iter<Node> candidateNodes = candidate->nodes();
            while (candidateNodes++) {
                Node* const node = candidateNodes.current_pointer();
                if (node != first && node != second) {
                    opposite = node;
                    break;
                }
            }
        }
        if (globalSimObject().fieldServer->dimension == 3) {
            TcadBase::Iter<Node> candidateNodes = candidate->nodes();
            while (candidateNodes++) {
                Node* const node = candidateNodes.current_pointer();
                if (node != first && node != second && node != third && node != fourth) {
                    opposite = node;
                    break;
                }
            }
        }
    }
    if (matches != 1) {
        FLPS_warning(VOF_STR("No or Multiple match of boundary element"));
    }
    if (opposite == nullptr) {
        FLPS_panic(VOF_STR("Error in computing the normal on interface"));
    }

    // 乘上朝外的投影量再归一化，等价于按投影符号把法向翻到外侧。
    const Coordinate& anchor = *first->coordinate;
    const Coordinate& interior = *opposite->coordinate;
    const double outward =
        (anchor.x - interior.x) * normal.x + (anchor.y - interior.y) * normal.y + (anchor.z - interior.z) * normal.z;
    normal.z = outward * normal.z;
    normal.x = outward * normal.x;
    normal.y = outward * normal.y;

    const double magnitude = std::sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
    if (magnitude < 0.0) {
        FLPS_warning(VOF_STR("Zero normal detected for boundary element normal"));
    }
    normal.z = normal.z / magnitude;
    normal.x = normal.x / magnitude;
    normal.y = normal.y / magnitude;
}

double GeneralBoundary::getTime() const { return mechState_->time_; }

double GeneralBoundary::getTotalTime() const {
    // 纯弹性求解不走时间积分，总时间退化成 1。
    if (MechPDE::getElasticSolve()) {
        return 1.0;
    }
    return mechState_->totalTime_;
}

double GeneralBoundary::getTimeStep() const {
    // 纯弹性求解同理：步长退化成 1，各速率项按单位步长算。
    if (MechPDE::getElasticSolve()) {
        return 1.0;
    }
    return mechState_->dt_;
}

double GeneralBoundary::getCurTemp() const { return mechState_->curTemperature_; }

double GeneralBoundary::getPrevTemp() const { return mechState_->prevTemperature_; }

void GeneralBoundary::AreaMomentInertia(std::vector<Element*>& elements, TcadGeom::Location& firstAxis,
                                        TcadGeom::Location& secondAxis, TcadGeom::Location& centroid,
                                        std::array<double, 3>& inertia) {
    TcadGeom::Location points[8]{};
    inertia[2] = 0.0;
    inertia[0] = 0.0;
    inertia[1] = 0.0;

    if (globalSimObject().fieldServer->dimension == 3) {
        for (unsigned index = 0; index < elements.size(); ++index) {
            // 单元中心相对形心的偏移投到两条主轴上，平方后按面积加权累加。
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            double sumX = 0.0;
            double sumY = 0.0;
            double sumZ = 0.0;
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                sumX = sumX + points[collected].x;
                sumY = sumY + points[collected].y;
                sumZ = sumZ + points[collected].z;
                ++collected;
            }
            if (collected == 0) {
                FLPS_panic(VOF_STR("Mesh element has no nodes"));
            }
            const double area = DecomposedArea(points, collected);
            const double offsetX = sumX / collected - centroid.x;
            const double offsetY = sumY / collected - centroid.y;
            const double offsetZ = sumZ / collected - centroid.z;
            const double first = firstAxis.x * offsetX + firstAxis.y * offsetY + firstAxis.z * offsetZ;
            const double second = secondAxis.x * offsetX + secondAxis.y * offsetY + secondAxis.z * offsetZ;
            inertia[2] = (second * second + first * first) * area + inertia[2];
            inertia[0] = second * second * area + inertia[0];
            inertia[1] = first * first * area + inertia[1];
        }
        return;
    }

    if (globalSimObject().fieldServer->dimension != 2) {
        FLPS_panic(VOF_STR("Unknown 1D settings"));
    }
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        double sumX = 0.0;
        double sumY = 0.0;
        double sumZ = 0.0;
        int collected = 0;
        while (nodes++) {
            const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
            points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
            sumX = sumX + points[collected].x;
            sumY = sumY + points[collected].y;
            sumZ = sumZ + points[collected].z;
            ++collected;
        }
        if (collected == 0) {
            FLPS_panic(VOF_STR("Mesh element has no nodes"));
        }
        if (collected > 2) {
            FLPS_panic(VOF_STR("More than 2 nodes!"));
        }
        const double length = DecomposedLength(points);
        const double offsetX = sumX / collected - centroid.x;
        const double offsetY = sumY / collected - centroid.y;
        const double offsetZ = sumZ / collected - centroid.z;
        const double first = firstAxis.x * offsetX + firstAxis.y * offsetY + firstAxis.z * offsetZ;
        const double second = secondAxis.x * offsetX + secondAxis.y * offsetY + secondAxis.z * offsetZ;
        // 二维只累极惯性矩这一项。
        inertia[2] = (first * first + second * second) * length + inertia[2];
    }
}

double GeneralBoundary::total_quantity(std::vector<Element*>& elements, TcadGeom::Location* centroid,
                                       TcadGeom::Location* normalSum) {
    TcadGeom::Location points[8]{};
    TcadGeom::Location normal{};
    if (centroid != nullptr) {
        centroid->z = 0.0;
        centroid->x = 0.0;
        centroid->y = 0.0;
    }
    if (normalSum != nullptr) {
        normalSum->z = 0.0;
        normalSum->x = 0.0;
        normalSum->y = 0.0;
    }

    double total = 0.0;
    if (globalSimObject().fieldServer->dimension == 3) {
        for (unsigned index = 0; index < elements.size(); ++index) {
            // 先把单元节点坐标抄进本地表，同时累出几何中心。
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            double sumX = 0.0;
            double sumY = 0.0;
            double sumZ = 0.0;
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                sumX = sumX + points[collected].x;
                sumY = sumY + points[collected].y;
                sumZ = sumZ + points[collected].z;
                ++collected;
            }
            if (collected == 0) {
                FLPS_panic(VOF_STR("Mesh element has no nodes"));
            }
            const double centerX = sumX / collected;
            const double centerY = sumY / collected;
            const double centerZ = sumZ / collected;

            compute_elem_normal(elements[index], normal);
            const double area = DecomposedArea(points, collected);
            total = total + area;
            if (centroid != nullptr) {
                centroid->z = area * centerZ + centroid->z;
                centroid->x = centerX * area + centroid->x;
                centroid->y = centerY * area + centroid->y;
            }
            if (normalSum != nullptr) {
                normalSum->x = normalSum->x + normal.x;
                normalSum->y = normalSum->y + normal.y;
                normalSum->z = normalSum->z + normal.z;
            }
        }
    } else {
        if (globalSimObject().fieldServer->dimension != 2) {
            FLPS_panic(VOF_STR("Unknown 1D settings"));
        }
        for (unsigned index = 0; index < elements.size(); ++index) {
            TcadBase::Iter<Node> nodes = elements[index]->nodes();
            double sumX = 0.0;
            double sumY = 0.0;
            double sumZ = 0.0;
            int collected = 0;
            while (nodes++) {
                const Coordinate& coordinate = *nodes.current_pointer()->coordinate;
                points[collected] = TcadGeom::Location(coordinate.x, coordinate.y, coordinate.z);
                sumX = sumX + points[collected].x;
                sumY = sumY + points[collected].y;
                sumZ = sumZ + points[collected].z;
                ++collected;
            }
            if (collected == 0) {
                FLPS_panic(VOF_STR("Mesh element has no nodes"));
            }
            if (collected > 2) {
                FLPS_panic(VOF_STR("More than 2 nodes!"));
            }
            const double centerX = sumX / collected;
            const double centerY = sumY / collected;
            const double centerZ = sumZ / collected;

            compute_elem_normal(elements[index], normal);
            const double length = DecomposedLength(points);
            total = total + length;
            if (centroid != nullptr) {
                centroid->z = length * centerZ + centroid->z;
                centroid->x = centerX * length + centroid->x;
                centroid->y = centerY * length + centroid->y;
            }
            if (normalSum != nullptr) {
                normalSum->x = normalSum->x + normal.x;
                normalSum->y = normalSum->y + normal.y;
                normalSum->z = normalSum->z + normal.z;
            }
        }
    }

    // 加权和除以总量即面积加权重心；法向和归一化成单位向量。
    if (centroid != nullptr) {
        centroid->x = centroid->x / total;
        centroid->y = centroid->y / total;
        centroid->z = centroid->z / total;
    }
    if (normalSum != nullptr) {
        const double magnitude =
            std::sqrt(normalSum->x * normalSum->x + normalSum->y * normalSum->y + normalSum->z * normalSum->z);
        normalSum->z = normalSum->z / magnitude;
        normalSum->x = normalSum->x / magnitude;
        normalSum->y = normalSum->y / magnitude;
    }
    return total;
}

double GeneralBoundary::DecomposedLength(TcadGeom::Location* points) {
    // 两端点间的欧氏距离。
    const double dx = points[0].x - points[1].x;
    const double dy = points[0].y - points[1].y;
    const double dz = points[0].z - points[1].z;
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

int GeneralBoundary::countDirichletBCs() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    int count;
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Grid"), VOF_STR("Flip.Location"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Fix.BackMat"), pdblib::PDB0)) {
        count = countFaceBCs(4, boundaryElements_[4], boundaryFaces_[4]);
    } else {
        count = 1;
    }

    // 其余四面真身是四段直排（零回边、零指针表），且各自取一次维度 ——
    // 短路让维度只在对应 boundaryActive_ 为假时才取，缓存成一个局部会少三处访问点。
    if (!boundaryActive_[0] && globalSimObject().fieldServer->dimension > 1) {
        count += countFaceBCs(0, boundaryElements_[0], boundaryFaces_[0]);
    }
    if (!boundaryActive_[1] && globalSimObject().fieldServer->dimension > 1) {
        count += countFaceBCs(1, boundaryElements_[1], boundaryFaces_[1]);
    }
    if (!boundaryActive_[2] && globalSimObject().fieldServer->dimension > 2) {
        count += countFaceBCs(2, boundaryElements_[2], boundaryFaces_[2]);
    }
    if (!boundaryActive_[3] && globalSimObject().fieldServer->dimension > 2) {
        count += countFaceBCs(3, boundaryElements_[3], boundaryFaces_[3]);
    }

    equationCount_ = count;
    return count;
}

void GeneralBoundary::bottomBoundary() {
    if (noLateralConstraint_) {
        return;
    }

    bottomBoundaryKind_ = 0;
    if (!boundaryActive_[0]) {
        if (!boundaryActive_[2]) {
            bottomBoundaryKind_ = 1;
            return;
        }
        if (boundaryActive_[1]) {
            if (boundaryActive_[3]) {
                FLPS_panic(VOF_STR("Could not figure out boundary condition for the bottom plane"));
                return;
            }
            bottomBoundaryKind_ = 4;
            return;
        }
    } else {
        if (boundaryActive_[1]) {
            FLPS_panic(VOF_STR("Could not figure out boundary condition for the bottom plane"));
            return;
        }
        if (!boundaryActive_[2]) {
            bottomBoundaryKind_ = 2;
            return;
        }
    }
    if (boundaryActive_[3]) {
        FLPS_panic(VOF_STR("Could not figure out boundary condition for the bottom plane"));
        return;
    }
    bottomBoundaryKind_ = 3;
}

bool GeneralBoundary::is_submodel() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    std::string model = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("Global.Model"), pdblib::PDB0);
    if (model.empty()) {
        model = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("Submodel"), pdblib::PDB0);
    }

    bool result;
    if (!model.empty()) {
        result = std::strcmp(model.c_str(), VOF_STR("off")) != 0;
    } else {
        result = globalSimObject().initializationFieldServer != nullptr;
    }

    submodel_ = result;
    return result;
}

void GeneralBoundary::apply_submodel() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    std::string model = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("Global.Model"), pdblib::PDB0);
    if (model.empty()) {
        model = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("Submodel"), pdblib::PDB0);
        if (model.empty() && globalSimObject().initializationFieldServer == nullptr) {
            FLPS_panic(VOF_STR("Error: inconsistent data"));
        }
    }

    interpolate_global(model.c_str());
}

void GeneralBoundary::interpolate_displacement() {
    // 子模型：把全局模型算出来的位移，按结构包围盒边界上的节点当 Dirichlet 值压进来。
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    TcadGeom::Location lower(0.0, 0.0, 0.0);
    TcadGeom::Location upper(0.0, 0.0, 0.0);
    globalSimObject().fieldServer->BoundingBox(lower, upper, false);

    // 包围盒往内缩一个容差，缩完落在盒外的节点才算「边界上的」。
    double precision = 1.0e-10;
    if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Submodel.Bbox.Precision"), pdblib::PDB0)) {
        precision = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Submodel.Bbox.Precision"), pdblib::PDB0);
    }
    lower.x = lower.x + precision;
    lower.y = lower.y + precision;
    lower.z = lower.z + precision;
    upper.x = upper.x - precision;
    upper.y = upper.y - precision;
    upper.z = upper.z - precision;

    // 优先用步位移场；没有就退到总位移场
    LocationData* source = nullptr;
    LocationData* source2 = nullptr;
    LocationData* const step = globalSimObject().fieldServer->VectorFindMatch(VOF_STR("StepDisplacement__SubModel"));
    if (step != nullptr) {
        source = step;
        if (feOrder_ == 2) {
            source2 = globalSimObject().fieldServer->VectorFindMatch(VOF_STR("StepDisplacement2__SubModel"));
            if (source2 == nullptr) {
                // 全局模型是一阶的：现建一张二阶场，再把一阶结果按边中点插上去。
                source2 = new LocationData(globalSimObject().fieldServer, NODE);
                source2->SetName(VOF_STATIC_STR("StepDisplacement2__SubModel"));
                if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Save.Submodel.Fields"), pdblib::PDB0)) {
                    source2->store_ = 0;
                }
                source2->AddElement(NODE2);
                FLPS_warning(
                    VOF_STR(" No displacement2 field was found to submodel. Global model was O(1) FiniteElement "
                    "simulation. Interpolating..."));
                source2->NodetoNode2(*source);
            }
        }
    } else {
        FLPS_warning(VOF_STR("Warning: no step displacement field was found to submodel. Using total displacement field"));
        source = globalSimObject().fieldServer->VectorFindMatch(VOF_STR("Displacement__SubModel"));
        if (feOrder_ == 2) {
            source2 = globalSimObject().fieldServer->VectorFindMatch(VOF_STR("Displacement2__SubModel"));
            if (source2 == nullptr) {
                source2 = new LocationData(globalSimObject().fieldServer, NODE);
                source2->SetName(VOF_STATIC_STR("Displacement2__SubModel"));
                if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Save.Submodel.Fields"), pdblib::PDB0)) {
                    source2->store_ = 0;
                }
                source2->AddElement(NODE2);
                FLPS_warning(
                    VOF_STR(" No displacement2 field was found to submodel. Global model was O(1) FiniteElement "
                    "simulation. Interpolating..."));
                source2->NodetoNode2(*source);
            }
        }
    }

    FieldServer& fieldServer = *globalSimObject().fieldServer;
    for (int index = 0; index != fieldServer.meshes.cur_max; ++index) {
        Mesh* const mesh = fieldServer.meshes.list[index];
        if (mesh->type_ > 1) {
            continue;
        }
        if (globalSimObject().fieldServer->dimension > 2) {
            TcadBase::Iter<Node> nodes = mesh->nodes(-1, -1);
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                const Coordinate& coordinate = *node->coordinate;
                if (lower.x > coordinate.x || lower.y > coordinate.y || lower.z > coordinate.z ||
                    coordinate.x > upper.x || coordinate.y > upper.y || coordinate.z > upper.z) {
                    const TcadGeom::Location value = source->get(*node);
                    bcElements_.push_back(node);
                    bcKinds_.push_back(0);
                    bcElements_.push_back(node);
                    bcKinds_.push_back(1);
                    bcElements_.push_back(node);
                    bcKinds_.push_back(2);
                    bcValues_.push_back(value.x / getTotalTime());
                    bcValues_.push_back(value.y / getTotalTime());
                    bcValues_.push_back(value.z / getTotalTime());
                }
            }
            if (feOrder_ == 2) {
                TcadBase::Iter<Node2> nodes2 = mesh->nodes2();
                while (nodes2++) {
                    Node2* const node2 = nodes2.current_pointer();
                    // 真身每个比较项各调一次 position()（虚表槽 400，本函数共 10 次
                    // ＝ 3D 支 6 项 ＋ 2D 支 4 项），不缓存成临时量。
                    if (lower.x > node2->position().x || lower.y > node2->position().y ||
                        lower.z > node2->position().z || node2->position().x > upper.x ||
                        node2->position().y > upper.y || node2->position().z > upper.z) {
                        const TcadGeom::Location value = source2->get(*node2);
                        bcElements_.push_back(node2);
                        bcKinds_.push_back(0);
                        bcElements_.push_back(node2);
                        bcKinds_.push_back(1);
                        bcElements_.push_back(node2);
                        bcKinds_.push_back(2);
                        bcValues_.push_back(value.x / getTotalTime());
                        bcValues_.push_back(value.y / getTotalTime());
                        bcValues_.push_back(value.z / getTotalTime());
                    }
                }
            }
        } else {
            if (globalSimObject().fieldServer->dimension != 2) {
                FLPS_panic(VOF_STR("Error: 1D submodel not available"));
            }
            TcadBase::Iter<Node> nodes = mesh->nodes(-1, -1);
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                const Coordinate& coordinate = *node->coordinate;
                if (lower.x > coordinate.x || lower.y > coordinate.y || coordinate.x > upper.x ||
                    coordinate.y > upper.y) {
                    const TcadGeom::Location value = source->get(*node);
                    bcElements_.push_back(node);
                    bcKinds_.push_back(0);
                    bcElements_.push_back(node);
                    bcKinds_.push_back(1);
                    bcValues_.push_back(value.x / getTotalTime());
                    bcValues_.push_back(value.y / getTotalTime());
                }
            }
            if (feOrder_ == 2) {
                TcadBase::Iter<Node2> nodes2 = mesh->nodes2();
                while (nodes2++) {
                    Node2* const node2 = nodes2.current_pointer();
                    if (lower.x > node2->position().x || lower.y > node2->position().y ||
                        node2->position().x > upper.x || node2->position().y > upper.y) {
                        const TcadGeom::Location value = source2->get(*node2);
                        bcElements_.push_back(node2);
                        bcKinds_.push_back(0);
                        bcElements_.push_back(node2);
                        bcKinds_.push_back(1);
                        bcValues_.push_back(value.x / getTotalTime());
                        bcValues_.push_back(value.y / getTotalTime());
                    }
                }
            }
        }
    }
}

void GeneralBoundary::interpolate_temperature() {
    // 子模型带进来的温度场要不要并回全局温度，由这个 pdb 开关决定。
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Submodel.Add.Global.Temperature"), pdblib::PDB0)) {
        return;
    }

    RealData* const submodel = globalSimObject().fieldServer->RealFindMatch(VOF_STR("Temperature__SubModel"));
    if (submodel == nullptr) {
        return;
    }
    RealData* const global = globalSimObject().fieldServer->RealFindMatch(VOF_STR("Temperature"));
    if (global == nullptr) {
        // 全局温度还不存在时不做搬运，直接把子模型那张场改名顶上。
        submodel->SetName(VOF_STATIC_STR("Temperature"));
        return;
    }

    // 九种元素类型逐一过，只在全局温度真的定义在该类型上时才搬
    for (int kind = 0; kind != 9; ++kind) {
        const ElementType elementType = static_cast<ElementType>(kind);
        if (!global->DefinedOn(elementType)) {
            continue;
        }

        TcadBase::Iter<Mesh> meshIter(globalSimObject().fieldServer->meshes);
        while (meshIter++) {
            Mesh* const mesh = meshIter.current_pointer();
            if (mesh->type_ > 1) {
                continue;
            }
            ElementIter elements = mesh->elements(elementType, -1, -1);
            while (elements++) {
                Element* const element = elements.current_pointer();
                global->set(*element, submodel->get(*element));
            }
        }
    }
}

void GeneralBoundary::interpolate_stress() {
    // 子模型带进来的应力要不要并回全局应力，由这个 pdb 开关决定。
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Submodel.Add.Global.Stress"), pdblib::PDB0)) {
        return;
    }

    // 走 FE 库时应力挂在高斯点上，否则挂在单元上。真身把这两支**各写一遍**
    // （SymTensorFindMatch 共 6 次 ＝ 两支各 2 ＋ 收尾 2），不抽公共名字变量。
    SymTensorData* submodel = nullptr;
    SymTensorData* target = nullptr;
    if (useFELibrary_) {
        submodel = globalSimObject().fieldServer->SymTensorFindMatch(VOF_STATIC_STR("StressGP__SubModel"));
        if (submodel == nullptr) {
            return;
        }
        target = globalSimObject().fieldServer->SymTensorFindMatch(VOF_STATIC_STR("StressGP_old"));
    } else {
        submodel = globalSimObject().fieldServer->SymTensorFindMatch(VOF_STATIC_STR("StressEL__SubModel"));
        if (submodel == nullptr) {
            return;
        }
        target = globalSimObject().fieldServer->SymTensorFindMatch(VOF_STATIC_STR("StressOldEL"));
    }

    if (target != nullptr) {
        // 目标场已存在：逐元素类型、逐网格把六个分量加上去。
        for (int kind = 0; kind != 9; ++kind) {
            const ElementType elementType = static_cast<ElementType>(kind);
            if (!target->DefinedOn(elementType)) {
                continue;
            }

            TcadBase::Iter<Mesh> meshIter(globalSimObject().fieldServer->meshes);
            while (meshIter++) {
                Mesh* const mesh = meshIter.current_pointer();
                if (mesh->type_ > 1) {
                    continue;
                }
                ElementIter elements = mesh->elements(elementType, -1, -1);
                while (elements++) {
                    Element* const element = elements.current_pointer();
                    SymTensor accumulated = target->get(*element);
                    const SymTensor addend = submodel->get(*element);
                    accumulated.xx = addend.xx + accumulated.xx;
                    accumulated.yy = addend.yy + accumulated.yy;
                    accumulated.zz = accumulated.zz + addend.zz;
                    accumulated.xy = accumulated.xy + addend.xy;
                    accumulated.yz = accumulated.yz + addend.yz;
                    accumulated.zx = accumulated.zx + addend.zx;
                    target->set(*element, accumulated);
                }
            }
        }
    } else {
        if (useFELibrary_) {
            submodel->SetName(VOF_STATIC_STR("StressGP_old"), 1);
        } else {
            submodel->SetName(VOF_STATIC_STR("StressOldEL"), 1);
        }
        target = submodel;
    }

    SymTensorData* elementStress = globalSimObject().fieldServer->SymTensorFindMatch(VOF_STATIC_STR("StressOldEL"));
    if (elementStress == nullptr) {
        elementStress = new SymTensorData(globalSimObject().fieldServer, static_cast<ElementType>(dimension_));
        elementStress->SetName(VOF_STATIC_STR("StressOldEL"));
    }
    elementStress->GaussPoint2Element(*target, false);

    SymTensorData* const nodalStress = globalSimObject().fieldServer->SymTensorFindMatch(VOF_STATIC_STR("StressOld"));
    if (nodalStress != nullptr) {
        nodalStress->Element2Node(useFELibrary_ ? *elementStress : *target, false);
    }
}

void GeneralBoundary::interpolate_global(const char* name) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    GlobalSim& sim = globalSimObject();
    TcadGeom::Location entryLower{};
    TcadGeom::Location entryUpper{};
    sim.fieldServer->BoundingBox(entryLower, entryUpper, true);

    Interpolator::Params params(sim.fieldServer);

    std::vector<std::string> fields;
    fields.push_back(VOF_STATIC_STR("Displacement"));
    fields.push_back(VOF_STATIC_STR("StepDisplacement"));
    fields.push_back(VOF_STATIC_STR("Temperature"));
    if (feOrder_ == 2) {
        fields.push_back(VOF_STATIC_STR("Displacement2"));
        fields.push_back(VOF_STATIC_STR("StepDisplacement2"));
    }
    fields.push_back(VOF_STATIC_STR("StressEL"));
    if (useFELibrary_) {
        fields.push_back(VOF_STATIC_STR("StressGP"));
    }
    for (std::size_t index = 0; index != fields.size(); ++index) {
        params.data_names.insert(fields[index] + std::string(VOF_STR("__SubModel")));
    }

    bool load = false;
    if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Global.Model.Initialize"), pdblib::PDB0)) {
        pdblib::pdbsetBoolean(interpreter, 0, VOF_STR("Mechanics"), VOF_STR("Global.Model.Initialize"), pdblib::PDB0);
        load = true;
    } else {
        load = _globalPool->structureManager.operator->()->fieldServerFlags_[7];
    }

    if (load) {
        if (*name == 0) {
            renameGlobalDataFields(*globalSimObject().initializationFieldServer, fields);
            Interpolator::interpolate(globalSimObject().initializationFieldServer, globalSimObject().fieldServer,
                                      params, false);
            _globalPool->structureManager.operator->()->fieldServerFlags_[7] = false;
        } else {
            // 给了文件名：新开一个场服务器把 .tdr 读进来。
            const std::shared_ptr<FieldServer> globalFieldServer = FieldServer::getInstance();
            globalSimObject().fieldServer->SetNextFS(globalFieldServer.get());
            globalFieldServer->setDefaults();

            TdrReaderHelper::Params readerParams{};
            readerParams.scale = 1.0;
            readerParams.pdb = false;
            readerParams.pdbOnly = false;
            readerParams.loadCommands = false;
            readerParams.readFloopsMaterials = true;
            readerParams.dfise = false;
            readerParams.hasNonSimplexElements = false;
            readerParams.unusedByTdrReader = true;
            readerParams.forceMixedMesh = false;
            readerParams.changeMaterial = false;
            readerParams.material = nullptr;
            readerParams.minimumVolumeMaterial = nullptr;
            readerParams.readRestartData = true;
            readerParams.speciesSpecified = false;
            readerParams.updateExternalTransformation = false;
            globalFieldServer->setLikeEnabled_ = false;

            Tdr_reader reader(globalFieldServer, std::string(name), readerParams);
            if (globalSimObject().fieldServer->mixedMesh_) {
                reader.params().forceMixedMesh = true;
            }
            if (!reader.errorMessage().empty()) {
                FLPS_panic(reader.errorMessage().c_str());
            }
            if (!reader.read(false, false)) {
                FLPS_panic(VOF_STR("Error: failed to load global model"));
            }

            // 子模型必须整个落在全局模型的包围盒里，否则插值取不到值。
            TcadGeom::Location globalLower(0.0, 0.0, 0.0);
            TcadGeom::Location globalUpper(0.0, 0.0, 0.0);
            TcadGeom::Location subLower(0.0, 0.0, 0.0);
            TcadGeom::Location subUpper(0.0, 0.0, 0.0);
            globalFieldServer->BoundingBox(globalLower, globalUpper, false);
            globalSimObject().fieldServer->BoundingBox(subLower, subUpper, false);
            const double epsilon = TcadGeom::Location::epsilon;
            bool outside = false;
            if (globalSimObject().fieldServer->dimension > 2) {
                outside = epsilon + subLower.x < globalLower.x || globalUpper.x < subLower.x - epsilon ||
                          epsilon + subLower.y < globalLower.y || globalUpper.y < subLower.y - epsilon ||
                          epsilon + subLower.z < globalLower.z || globalUpper.z < subLower.z - epsilon ||
                          epsilon + subUpper.x < globalLower.x || globalUpper.x < subUpper.x - epsilon ||
                          epsilon + subUpper.y < globalLower.y || globalUpper.y < subUpper.y - epsilon ||
                          epsilon + subUpper.z < globalLower.z || globalUpper.z < subUpper.z - epsilon;
            } else if (globalSimObject().fieldServer->dimension <= 1) {
                outside = epsilon + subLower.x < globalLower.x || globalUpper.x < subLower.x - epsilon ||
                          epsilon + subUpper.x < globalLower.x || globalUpper.x < subUpper.x - epsilon;
            } else {
                outside = epsilon + subLower.x < globalLower.x || globalUpper.x < subLower.x - epsilon ||
                          epsilon + subLower.y < globalLower.y || globalUpper.y < subLower.y - epsilon ||
                          epsilon + subUpper.x < globalLower.x || globalUpper.x < subUpper.x - epsilon ||
                          epsilon + subUpper.y < globalLower.y || globalUpper.y < subUpper.y - epsilon;
            }
            if (outside) {
                FLPS_panic(VOF_STR("Submodel is not completely inside the global model"));
            }

            renameGlobalDataFields(*globalFieldServer, fields);
            Interpolator::interpolate(globalFieldServer, globalSimObject().fieldServer, params, false);
            _globalPool->structureManager.operator->()->fieldServerFlags_[7] = false;
        }
    }

    // 不保留子模型场时，把带后缀的场标成不落盘。
    if (!pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Save.Submodel.Fields"), pdblib::PDB0)) {
        TcadBase::Iter<BaseData> dataIter(globalSimObject().fieldServer->dataList);
        while (dataIter++) {
            BaseData* const data = dataIter.current_pointer();
            const char* const dataName = data->Name();
            if (dataName == nullptr) {
                continue;
            }
            const std::string text(dataName);
            if (text.size() > 10 && text.substr(text.size() - 10).compare(VOF_STR("__SubModel")) == 0) {
                data->store_ = 0;
            }
        }
    }

    interpolate_displacement();
    interpolate_temperature();
    interpolate_stress();

    if (globalSimObject().tee->verbosity() > 3) {
        StructSpec spec;
        spec.savePdbParameters_ = 0;
        spec.saveRestartData_ = 0;
        spec.outputFileName_ = VOF_STATIC_STR("submodel_interpolated.tdr");
        const mgoals::Brep brep(*_globalPool->structureManager.operator->()->getBrep3D());
        StructureWriter::processAndWriteTdr(spec, globalSimObject().fieldServer, brep, nullptr, nullptr,
                                            std::shared_ptr<Tdr_collection>());
    }
}

double GeneralBoundary::DecomposedArea(TcadGeom::Location* points, int count) {
    if (count == 3) {
        const double toThirdZ = points[0].z - points[2].z;
        const double toThirdY = points[0].y - points[2].y;
        const double toSecondZ = points[0].z - points[1].z;
        const double toSecondY = points[0].y - points[1].y;
        const double toSecondX = points[0].x - points[1].x;
        const double toThirdX = points[0].x - points[2].x;
        const double crossX = toThirdZ * toSecondY - toThirdY * toSecondZ;
        const double crossY = toSecondZ * toThirdX - toThirdZ * toSecondX;
        const double crossZ = toThirdY * toSecondX - toThirdX * toSecondY;
        return std::sqrt(crossX * crossX + crossY * crossY + crossZ * crossZ) * 0.5;
    }

    // 非三角形也非四边形时不计面积。
    if (count != 4) {
        return 0.0;
    }

    // 四边形：两条对角线（p1→p3 与 p2→p0）叉乘，模长折半。
    const double diagonalBD_Z = points[3].z - points[1].z;
    const double diagonalBD_Y = points[3].y - points[1].y;
    const double diagonalCA_Z = points[0].z - points[2].z;
    const double diagonalCA_Y = points[0].y - points[2].y;
    const double diagonalCA_X = points[0].x - points[2].x;
    const double diagonalBD_X = points[3].x - points[1].x;
    const double crossX = diagonalBD_Z * diagonalCA_Y - diagonalBD_Y * diagonalCA_Z;
    const double crossY = diagonalCA_Z * diagonalBD_X - diagonalBD_Z * diagonalCA_X;
    const double crossZ = diagonalBD_Y * diagonalCA_X - diagonalBD_X * diagonalCA_Y;
    return std::sqrt(crossX * crossX + crossY * crossY + crossZ * crossZ) * 0.5;
}

void GeneralBoundary::updateStepEndTime() {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;
    // 纯弹性求解且 deck 给了初始步长时直接用它，否则按当前时刻加一个步长推出来。
    if (MechPDE::getElasticSolve() && pdblib::pdbIsAvailable(interpreter, VOF_STR("Diffuse"), VOF_STR("InitTimeStep"), pdblib::PDB0)) {
        stepEndTime_ = pdblib::pdbgetDouble(interpreter, VOF_STR("Diffuse"), VOF_STR("InitTimeStep"), pdblib::PDB0);
    } else {
        stepEndTime_ = getTime() + getTimeStep();
    }
}

void GeneralBoundary::add_rhs(Vector& rhs, Vector* sol, std::map<int, double>& values) {
    (void)values;
    BasicSingleStiff stiff(1);
    for (unsigned index = 0; index < bcElements_.size(); ++index) {
        // 分量码 3/4/5 依次取 x/y/z 的方程号表，其余码跳过。
        IntData* equationNumber = nullptr;
        switch (bcKinds_[index]) {
            case 3:
                equationNumber = velocitySolution_->eqnXVelocity_;
                break;
            case 4:
                equationNumber = velocitySolution_->eqnYVelocity_;
                break;
            case 5:
                equationNumber = velocitySolution_->eqnZVelocity_;
                break;
            default:
                continue;
        }
        int equation = equationNumber->value(*bcElements_[index]);
        stiff.rowIds_.data_[0] = equation;
        if (equation <= 0) {
            equation = -equation;
        }
        stiff.colIds_.data_[0] = equation;
        // 真身在这里把行数组指针也抄进 SingleDense 的保留槽，照抄。
        stiff.currentRow_ = stiff.rows_;
        stiff.rows_[0].data_[0] = 0.0;
        stiff.ssRhs_.data_[0] = bcValues_[index] * bcScale_;
        stiff.ssScatter(rhs, sol);
        stiff.Clear();
    }
}

bool GeneralBoundary::in_triangle(double x, double y, double* a, double* b, double* c) {
    // a / b 分别是三个顶点的 x、y 数组；c 承接三个面积比权重。
    const double x0 = a[0];
    const double x1 = a[1];
    const double x2 = a[2];
    const double y0 = b[0];
    const double y1 = b[1];
    const double y2 = b[2];

    // 先用重心坐标判点是否落在三角形内，两侧各留 1e-12 的容差。
    const double e0x = x2 - x0;
    const double e0y = y2 - y0;
    const double e1x = x1 - x0;
    const double e1y = y1 - y0;
    const double px = x - x0;
    const double py = y - y0;
    const double dot00 = e0x * e0x + e0y * e0y;
    const double dot01 = e0x * e1x + e0y * e1y;
    const double dot02 = e0x * px + e0y * py;
    const double dot11 = e1x * e1x + e1y * e1y;
    const double dot12 = e1x * px + e1y * py;
    const double denom = dot00 * dot11 - dot01 * dot01;
    const double u = (dot11 * dot02 - dot01 * dot12) / denom;
    if (u < -1.0e-12) {
        return false;
    }
    const double v = (dot00 * dot12 - dot01 * dot02) / denom;
    if (v < -1.0e-12 || u + v > 1.000000000001) {
        return false;
    }

    // 落在内部：三个权重按子三角形与总三角形的面积比给出，小于 1e-3 的直接归零。
    const double total = x0 * y1 + y2 * x1 + x2 * y0 - x0 * y2 - y0 * x1 - x2 * y1;
    double w0 = std::fabs((y2 * x1 + y1 * x + x2 * y - y2 * x - x1 * y - x2 * y1) / total);
    double w1 = std::fabs((y2 * x + x0 * y + x2 * y0 - x0 * y2 - y0 * x - x2 * y) / total);
    double w2 = std::fabs((x0 * y1 + x1 * y + y0 * x - x0 * y - y0 * x1 - y1 * x) / total);
    if (w0 < 0.001) {
        w0 = 0.0;
    }
    c[0] = w0;
    if (w1 < 0.001) {
        w1 = 0.0;
    }
    c[1] = w1;
    if (w2 < 0.001) {
        w2 = 0.0;
    }
    c[2] = w2;

    // 三个权重和须为 1：把最大的那个改成用另外两个补足，抵掉归零带来的误差。
    if (w0 > 0.25) {
        c[0] = 1.0 - w1 - w2;
    } else if (w1 <= 0.25) {
        c[2] = 1.0 - w1 - w0;
    } else {
        c[1] = 1.0 - w0 - w2;
    }
    return true;
}

int GeneralBoundary::get_master(Node& node, std::vector<Element*>& elements, int axis, double* weights) {
    if (globalSimObject().fieldServer->dimension == 3) {
        return get_master_3d(node, elements, axis, weights);
    }
    if (globalSimObject().fieldServer->dimension != 2) {
        FLPS_panic(VOF_STR("Error: inconsistent data"));
        return -1;
    }
    return get_master_2d(node, elements, axis, weights);
}

int GeneralBoundary::get_master_2d(Node& node, std::vector<Element*>& elements, int axis, double* weights) {
    if (axis != 0 && axis != 1) {
        FLPS_panic(VOF_STR("Error: inconsistent data"));
    }
    const double target = (axis == 0) ? node.coordinate->x : node.coordinate->y;
    if (elements.empty()) {
        return -1;
    }

    // 逐个单元取它前两个节点在该分量上的坐标，判目标是否落在两者之间。
    // 两个坐标只在循环外置零：节点不足两个的单元沿用上一个单元留下的值。
    double first = 0.0;
    double second = 0.0;
    unsigned index = 0;
    for (; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        if (nodes++) {
            first = (axis == 0) ? nodes.current_pointer()->coordinate->x : nodes.current_pointer()->coordinate->y;
            if (nodes++) {
                second = (axis == 0) ? nodes.current_pointer()->coordinate->x : nodes.current_pointer()->coordinate->y;
            }
            // 其余节点只把迭代器走完，坐标不参与判定。
            while (nodes++) {
            }
        }
        if ((target <= first || target <= second) && (first <= target || second <= target)) {
            weights[0] = (target - first) / (second - first);
            weights[1] = (second - target) / (second - first);
            return static_cast<int>(index);
        }
    }
    return -1;
}

int GeneralBoundary::get_master_3d(Node& node, std::vector<Element*>& elements, int axis, double* weights) {
    // 3D 下把问题压到一个平面上再判：作用分量为 y 时用 (x, y)，为 x 时用 (x, z)。
    if (axis != 0 && axis != 1) {
        FLPS_panic(VOF_STR("Error: inconsistent data"));
    }
    const bool useY = (axis == 1);
    const double px = node.coordinate->x;
    const double py = useY ? node.coordinate->y : node.coordinate->z;
    if (elements.empty()) {
        return -1;
    }

    double xs[4] = {};
    double ys[4] = {};
    for (unsigned index = 0; index < elements.size(); ++index) {
        TcadBase::Iter<Node> nodes = elements[index]->nodes();
        int slot = 0;
        while (nodes++) {
            if (slot < 4) {
                Node* const current = nodes.current_pointer();
                xs[slot] = current->coordinate->x;
                ys[slot] = useY ? current->coordinate->y : current->coordinate->z;
            }
            ++slot;
        }
        if (in_triangle(px, py, xs, ys, weights)) {
            return static_cast<int>(index);
        }
    }
    return -1;
}

void GeneralBoundary::fix_dof(Vector& rhs, Vector* sol, std::map<int, double>& values) {
    BasicSingleStiff stiff(1);

    // 闩是无符号 `<`（真身 `v5 < (size_t)((end-begin)>>3)`）。
    for (unsigned index = 0; index < bcElements_.size(); ++index) {
        // 码 0/1/2 是固定 x/y/z 自由度；其余码归 add_rhs 管，这里跳过。
        IntData* equationNumber = nullptr;
        switch (bcKinds_[index]) {
            case 0:
                equationNumber = velocitySolution_->eqnXVelocity_;
                break;
            case 1:
                equationNumber = velocitySolution_->eqnYVelocity_;
                break;
            case 2:
                equationNumber = velocitySolution_->eqnZVelocity_;
                break;
            default:
                continue;
        }
        Element* const element = bcElements_[index];
        const int equation = equationNumber->value(*element);
        // 方程号已是负的（别处固定过）时，只有开了弧长法才继续覆盖。
        // 真身把 GlobalSim 的读取放在**这条负号支里**（0x234c0xx 的惰性补建段在
        // `if (v13 >= 0) goto LABEL_9` 之后），不是在函数入口无条件取一次。
        if (equation < 0 && !globalSimObject().fieldServer->arcLengthEnabled_) {
            continue;
        }

        const int magnitude = (equation > 0) ? equation : -equation;
        stiff.rowIds_.data_[0] = magnitude;
        stiff.colIds_.data_[0] = magnitude;
        // 把方程号改写成负值，标记这个自由度已被固定。
        equationNumber->set(*element, -magnitude);
        values[-magnitude] = bcValues_[index] * bcScale_;

        // 对角置成 Dirichlet 的大数，右端项同乘，两者相除即得指定位移。
        stiff.currentRow_ = stiff.rows_;
        stiff.rows_[0].data_[0] = dirichletValue_;
        if (dirichletMethod_ == 0) {
            stiff.ssRhs_.data_[0] = dirichletValue_ * bcValues_[index] * bcScale_;
            stiff.ssScatter(rhs, sol);
        }
        stiff.Clear();
    }
}

void GeneralBoundary::loadDirichletVoid(Vector& rhs, Vector* sol, std::map<int, double>& values,
                                        std::vector<Node*> nodes) {
    const int dimension = globalSimObject().fieldServer->dimension;
    BasicSingleStiff stiff(1);

    // 逐分量走一遍：x 用 eqnXVelocity_，y、z 依次换表。
    for (int axis = 0; axis != dimension; ++axis) {
        IntData* equationNumber = nullptr;
        switch (axis) {
            case 0:
                equationNumber = velocitySolution_->eqnXVelocity_;
                break;
            case 1:
                equationNumber = velocitySolution_->eqnYVelocity_;
                break;
            default:
                equationNumber = velocitySolution_->eqnZVelocity_;
                break;
        }
        for (Node* const node : nodes) {
            const int equation = equationNumber->value(*node);
            if (equation <= 0) {
                continue;
            }
            stiff.rowIds_.data_[0] = equation;
            stiff.colIds_.data_[0] = equation;
            // 空洞侧的自由度一律固定到 0：方程号改负作标记，取值表里也写 0。
            equationNumber->set(*node, -equation);
            values[-equation] = 0.0;

            stiff.currentRow_ = stiff.rows_;
            stiff.rows_[0].data_[0] = dirichletValue_;
            stiff.ssRhs_.data_[0] = 0.0;
            stiff.ssScatter(rhs, sol);
            stiff.Clear();
        }
    }
}

void GeneralBoundary::LoadDirichlet(Vector& rhs, Vector* sol, std::map<int, double>& values) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("cmp.flat.BC"), pdblib::PDB0)) {
        if (pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("cmp.flat.BC"), pdblib::PDB0) != 0.0) {
            fixTop(rhs, sol, values);
        }
    }

    // 与 countDirichletBCs 同一道闸门：`Flip.Location` 有定义**且未**设 Fix.BackMat 时，
    // 走翻转结构那条支，而不是装第 4 面。
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Grid"), VOF_STR("Flip.Location"), pdblib::PDB0) ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Fix.BackMat"), pdblib::PDB0)) {
        loadDirichletBoundary(rhs, sol, 4, boundaryFaces_[4], values);
    } else {
        fixFlippedStructure(rhs, sol, values);
    }

    // 其余四面真身是四段直排，各自取一次维度（短路：只在对应 boundaryActive_ 为假时取）。
    if (!boundaryActive_[0] && globalSimObject().fieldServer->dimension > 1) {
        loadDirichletBoundary(rhs, sol, 0, boundaryFaces_[0], values);
    }
    if (!boundaryActive_[1] && globalSimObject().fieldServer->dimension > 1) {
        loadDirichletBoundary(rhs, sol, 1, boundaryFaces_[1], values);
    }
    if (!boundaryActive_[2] && globalSimObject().fieldServer->dimension > 2) {
        loadDirichletBoundary(rhs, sol, 2, boundaryFaces_[2], values);
    }
    if (!boundaryActive_[3] && globalSimObject().fieldServer->dimension > 2) {
        loadDirichletBoundary(rhs, sol, 3, boundaryFaces_[3], values);
    }
}

void GeneralBoundary::setFlippedSubstrate() {
    FieldServer& fieldServer = *globalSimObject().fieldServer;

    std::vector<double> bottomX(fieldServer.meshes.count);
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    int collected = 0;
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (mesh->type_ > 1) {
            continue;
        }
        bottomX[collected] = -1.0e30;
        TcadBase::Iter<Node> nodes = mesh->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            if (node->coordinate->y == globalSimObject().fieldServer->bounding_box_ymin &&
                node->coordinate->z == globalSimObject().fieldServer->bounding_box_zmin) {
                bottomX[collected] = std::max(node->coordinate->x, bottomX[collected]);
            }
        }
        ++collected;
    }
    bottomX.resize(collected);

    double maximum = bottomX[0];
    for (std::size_t index = 1; index < bottomX.size(); ++index) {
        maximum = bottomX[index] > maximum ? bottomX[index] : maximum;
    }

    // 再走一遍同样的网格序，取到最大值那个就是衬底；多于一个或一个都没有都 panic。
    const double* value = bottomX.data();
    Mesh* substrate = nullptr;
    meshes.reset();
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (mesh->type_ > 1) {
            continue;
        }
        if (maximum == *value) {
            if (substrate != nullptr) {
                FLPS_panic(VOF_STR("More than one mesh touching bottom and no default substrate set"));
            }
            mesh->SetSubstrate();
            *globalSimObject().tee << teeInfoLevelDefault << VOF_STR("Setting region ") << mesh->Name() << VOF_STR(" as substrate")
                                   << tendl;
            substrate = mesh;
        }
        ++value;
    }
    if (substrate == nullptr) {
        FLPS_panic(VOF_STR("No default substrate found?"));
    }
}

void GeneralBoundary::fixFlippedStructure(Vector& rhs, Vector* sol, std::map<int, double>& values) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    // 两个出参在本函数里不再读——真身调它是为了刷新 FieldServer 自己的
    // bounding_box_* 栏位，下面几处相等判据读的都是那两个栏位。
    TcadGeom::Location lower{};
    TcadGeom::Location upper{};
    globalSimObject().fieldServer->BoundingBox(lower, upper, true);

    const double flipLocation = pdblib::pdbgetDouble(interpreter, VOF_STR("Grid"), VOF_STR("Flip.Location"), pdblib::PDB0);
    const double bottomY = globalSimObject().fieldServer->bounding_box_ymin;
    const double bottomZ = globalSimObject().fieldServer->bounding_box_zmin;

    FieldServer& fieldServer = *globalSimObject().fieldServer;
    TcadBase::Iter<Mesh> meshes(fieldServer.meshes);
    bool substrateDefined = false;
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (mesh->type_ == 2) {
            continue;
        }
        if (mesh->IsSubstrate()) {
            substrateDefined = true;
        }
    }

    if (!substrateDefined) {
        *globalSimObject().tee << teeInfoLevelDefault
                               << VOF_STR("No substrate defined.  Setting substrate to mesh with maximum X coordinate (y=")
                               << globalSimObject().fieldServer->bounding_box_ymin
                               << VOF_STR(", z=") << globalSimObject().fieldServer->bounding_box_zmin << ")." << tendl;
        setFlippedSubstrate();
    }

    Node* closest = nullptr;
    bool closestFound = false;
    double closestDistance = 1.0e30;
    meshes.reset();
    while (meshes++) {
        Mesh* const mesh = meshes.current_pointer();
        if (!mesh->IsSubstrate()) {
            continue;
        }
        TcadBase::Iter<Node> nodes = mesh->nodes();
        while (nodes++) {
            Node* const node = nodes.current_pointer();
            const Coordinate& coordinate = *node->coordinate;
            const double offsetX = flipLocation - coordinate.x;
            const double offsetY = bottomY - coordinate.y;
            const double offsetZ = bottomZ - coordinate.z;
            const double distance = std::sqrt(offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ);
            if (closestDistance > distance && coordinate.y == globalSimObject().fieldServer->bounding_box_ymin &&
                coordinate.z == globalSimObject().fieldServer->bounding_box_zmin) {
                closest = node;
                closestFound = true;
                closestDistance = distance;
            }
            if (TcadGeom::Location::epsilon > distance) {
                break;
            }
        }
    }

    if (!closestFound) {
        FLPS_panic(
            VOF_STR("Found no node in the flipped structure to apply Dirichlet boundary condition; please check "
            "flipped.location."));
    }

    // 把这个节点的 x 自由度钉住。
    IntData* const equationNumber = velocitySolution_->eqnXVelocity_;
    BasicSingleStiff stiff(1);
    const int equation = equationNumber->value(*closest);
    if (equation > 0) {
        stiff.rowIds_.data_[0] = equation;
        stiff.colIds_.data_[0] = equation;
        equationNumber->set(*closest, -equation);
        values[-equation] = 0.0;
        stiff.currentRow_ = stiff.rows_;
        stiff.rows_[0].data_[0] = dirichletValue_;
        stiff.ssRhs_.data_[0] = 0.0;
        stiff.ssScatter(rhs, sol);
        stiff.Clear();
    }

    // 该节点周围实体网格里的单元，方程号还是正的就一律取负，标成已固定。
    TcadBase::Seq<Element> matched;
    closest->ElementMatch(matched);
    for (int slot = 0; slot != matched.cur_max; ++slot) {
        Element* const element = matched.list[slot];
        if (element->mesh->type_ > 1) {
            continue;
        }
        const int number = equationNumber->value(*element);
        if (number > 0) {
            equationNumber->set(*element, -number);
        }
    }
}

void GeneralBoundary::Load(Vector& rhs, std::map<int, double>& values, Vector* sol, std::vector<Node*> nodes) {
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    if (std::strcmp(pdblib::pdbgetSwitchString(interpreter, VOF_STR("Mechanics"), VOF_STR("Boundary.Method.Type"), pdblib::PDB0).c_str(),
                    VOF_STR("MatrixReduction")) == 0) {
        dirichletMethod_ = 1;
    } else if (std::strcmp(
                   pdblib::pdbgetSwitchString(interpreter, VOF_STR("Mechanics"), VOF_STR("Boundary.Method.Type"), pdblib::PDB0).c_str(),
                   VOF_STR("PreserveDiagonal")) == 0) {
        dirichletMethod_ = 2;
    } else if (dirichletMethod_ == 0 &&
               pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Boundary.Penalty.Factor"), pdblib::PDB0)) {
        // 罚因子取自 pdb；越界时报一条并钳回默认的 1e12。
        const double penalty = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Boundary.Penalty.Factor"), pdblib::PDB0);
        dirichletValue_ = penalty;
        if (penalty < 1.0e10) {
            FLPS_warning(
                VOF_STR("Boundary.Penalty.Factor must be greater than 1.e10. It is reset to the default value (1.e12)."));
            dirichletValue_ = 1.0e12;
        } else if (penalty > 1.0e18) {
            FLPS_warning(
                VOF_STR("Boundary.Penalty.Factor must be smaller than 1.e18. It is reset to the default value (1.e12)."));
            dirichletValue_ = 1.0e12;
        }
    }

    // 位移解下罚因子直接取 pdb 值覆写，不再钳制。
    if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0) &&
        pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Boundary.Penalty.Factor"), pdblib::PDB0)) {
        dirichletValue_ = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Boundary.Penalty.Factor"), pdblib::PDB0);
    }

    // Native Load resets this scale on every assembly.  The optional PDB
    // leaf is Boolean despite its historical name; an absent leaf means the
    // unscaled value 1.0.
    bcScale_ = 1.0;
    if (pdblib::pdbIsAvailable(
            interpreter, VOF_STR("Mechanics"), VOF_STR("DirichletBCFactor"), pdblib::PDB0)) {
        bcScale_ = pdblib::pdbgetBoolean(
            interpreter, VOF_STR("Mechanics"), VOF_STR("DirichletBCFactor"), pdblib::PDB0)
            ? 1.0
            : 0.0;
    }

    // 增强 BC 与子模型走各自的固定/右端项路径；否则走常规 Dirichlet 装载。
    if (enhancedBC_ || submodel_) {
        fix_dof(rhs, sol, values);
        add_rhs(rhs, sol, values);
        return;
    }

    if (_globalPool->beamProbHandler.operator->()->beamsCreated_) {
        return;
    }
    LoadDirichlet(rhs, sol, values);
    loadDirichletVoid(rhs, sol, values, nodes);
}

void GeneralBoundary::loadDirichletBoundary(Vector& rhs, Vector* sol, int kind, std::map<int, Element*>& faces,
                                            std::map<int, double>& values) {
    // 面号到分量的映射：0/1 面约束 y、2/3 面约束 z、4 面约束 x。
    IntData* equationNumber = nullptr;
    if (kind <= 1) {
        equationNumber = velocitySolution_->eqnYVelocity_;
    } else if (kind - 2 <= 1) {
        equationNumber = velocitySolution_->eqnZVelocity_;
    } else if (kind == 4) {
        equationNumber = velocitySolution_->eqnXVelocity_;
    } else {
        return;
    }

    const double intercept = boundaryDisp_[kind][0];
    const double slopeAngle = boundaryDisp_[kind][1];
    const double reference = boundaryDisp_[kind][2];
    BasicSingleStiff stiff(1);
    Tcl_Interp* const interpreter = globalSimObject().interpreter->interpreter;

    if (noLateralConstraint_ || kind != 4 ||
        pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Bottom.Automatic.Free"), pdblib::PDB0) != 1) {
        // 常规路径：这一面上的每个代表单元都固定住。
        for (auto& entry : faces) {
            Element* const element = entry.second;
            const int equation = equationNumber->value(*element);
            if (equation < 0) {
                continue;
            }
            stiff.rowIds_.data_[0] = equation;
            stiff.colIds_.data_[0] = equation;
            equationNumber->set(*element, -equation);

            // 倾角或截距非零时按倾斜面给位移，否则该自由度固定到 0。
            double displacement = 0.0;
            if (slopeAngle != 0.0 || intercept != 0.0) {
                // 表里存的代表单元实际都是节点，真身按 Node 的 coordinate 取坐标。
                const Node* const vertex = static_cast<const Node*>(element);
                displacement = (vertex->coordinate->x - reference) * std::tan(slopeAngle) + intercept;
                values[-equation] = displacement * bcScale_;
            } else {
                values[-equation] = 0.0;
            }
            stiff.currentRow_ = stiff.rows_;
            stiff.rows_[0].data_[0] = dirichletValue_;
            if (dirichletMethod_ == 0) {
                stiff.ssRhs_.data_[0] = displacement * dirichletValue_ * bcScale_;
                stiff.ssScatter(rhs, sol);
            }
            stiff.Clear();
        }
        return;
    }

    // 底面自动放开时只固定底面那一个代表单元，且一律固定到 0。
    const int equation = equationNumber->value(*bottomElement_);
    if (equation <= 0) {
        return;
    }
    stiff.rowIds_.data_[0] = equation;
    stiff.colIds_.data_[0] = equation;
    equationNumber->set(*bottomElement_, -equation);
    values[-equation] = 0.0;
    stiff.currentRow_ = stiff.rows_;
    stiff.rows_[0].data_[0] = dirichletValue_;
    stiff.ssRhs_.data_[0] = 0.0;
    stiff.ssScatter(rhs, sol);
    stiff.Clear();
}

void GeneralBoundary::fixTop(Vector& rhs, Vector* sol, std::map<int, double>& values) {
    FieldServer& fieldServer = *globalSimObject().fieldServer;
    const bool hasGas = fieldServer.hasGas();

    // 结构包围盒的下角给出「顶面」所在的 x。
    TcadGeom::Location lower{};
    TcadGeom::Location upper{};
    fieldServer.BoundingBox(lower, upper, 0);

    // 收集贴在顶面上的节点：只看有气体一侧、暴露在外的骨架单元。
    std::set<Node*> topNodes;
    for (int meshIndex = 0; meshIndex != fieldServer.materialMeshes.count; ++meshIndex) {
        Mesh* const mesh = fieldServer.materialMeshes.data[meshIndex];
        ElementIter elements = mesh->Borders();
        while (elements++) {
            Element* const element = elements.current_pointer();
            if (!element->IsSkeletal() || element->WhichBorder() != 0 || !hasGas || !element->IsExposed()) {
                continue;
            }
            TcadBase::Iter<Node> nodes = element->nodes();
            while (nodes++) {
                Node* const node = nodes.current_pointer();
                if (node->coordinate->x - lower.x < TcadGeom::Location::epsilon) {
                    topNodes.insert(node);
                    break;
                }
            }
        }
    }

    // 这些节点的位移先清零。
    LocationData* const displacement = fieldServer.VectorFindMatch(VOF_STR("Displacement"));
    for (Node* const node : topNodes) {
        displacement->set(node, TcadGeom::Location{});
    }

    // 再把它们的 x 自由度固定住。
    BasicSingleStiff stiff(1);
    IntData* const equationNumber = velocitySolution_->eqnXVelocity_;
    for (Node* const node : topNodes) {
        const int equation = equationNumber->value(node);
        if (equation <= 0) {
            continue;
        }
        stiff.rowIds_.data_[0] = equation;
        equationNumber->set(*node, -equation);
        values[-equation] = 0.0;
        stiff.currentRow_ = stiff.rows_;
        stiff.rows_[0].data_[0] = dirichletValue_;
        stiff.ssRhs_.data_[0] = 0.0;
        stiff.ssScatter(rhs, sol);
        stiff.Clear();
    }
}

}  // namespace floops

namespace sinterconnect {

namespace {

Tcl_Interp* siBoundaryInterpreter() { return floops::globalSimObject().interpreter->interpreter; }

[[noreturn]] void unrecoveredSiBoundaryBranch(const char* function) {
    throw std::runtime_error(std::string(function) + VOF_STR(" is not recovered for standalone execution"));
}

double averageNodeField(floops::Element& element, const floops::RealData& field) {
    TcadBase::Iter<floops::Node> nodes = element.nodes();
    double sum = 0.0;
    int count = 0;
    while (nodes++) {
        floops::Node* const node = nodes.current_pointer();
        sum += field.get(*node);
        ++count;
    }
    if (count == 0) {
        FLPS_panic(VOF_STR("Element has no nodes"));
    }
    return sum / static_cast<double>(count);
}

}  // namespace

siGeneralBoundary::siGeneralBoundary(floops::VelocitySolution& velocity, floops::GrowthType growth,
                                     floops::MechState& state)
    : floops::GeneralBoundary(velocity, growth, state) {}

siGeneralBoundary::~siGeneralBoundary() = default;

void siGeneralBoundary::apply_point_force() {
    Tcl_Interp* const interpreter = siBoundaryInterpreter();
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0)) {
        return;
    }

    if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Force.Snap"), pdblib::PDB0)) {
        unrecoveredSiBoundaryBranch(
            VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_point_force"
            "(snap)"));
    }

    const char* const listed = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PointForceList"), pdblib::PDB0);
    std::istringstream names(listed != nullptr ? listed : "");
    std::string name;
    while (names >> name) {
        int count = 0;
        std::unique_ptr<double[]> data;
        const bool useRate = floops::globalSimObject().fieldServer->largeDeformationFlag_ ||
            pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Solution.Type.Displacement"), pdblib::PDB0);
        if (useRate) {
            const std::string rateName = name + VOF_STR(".Rate");
            if (pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), rateName.c_str(), pdblib::PDB0)) {
                data.reset(pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"),
                                                     rateName.c_str(), pdblib::PDB0));
                if (data) {
                    data[1] *= stepEndTime_;
                    data[3] *= stepEndTime_;
                    data[5] *= stepEndTime_;
                }
            }
        }
        if (!data) {
            data.reset(pdblib::pdbgetDoubleArray(interpreter, &count, VOF_STR("Mechanics"), name.c_str(), pdblib::PDB0));
        }
        if (count != 6 || !data) {
            throw std::runtime_error(VOF_STR("Inconsistent point force boundary condition data"));
        }

        // Native stores {x,fx,y,fy,z,fz}; coordinates without an explicit
        // unit are micrometres and are converted to the internal cm system.
        constexpr double micrometreToCentimetre = 1.0e-4;
        const double x = data[0] * micrometreToCentimetre;
        const double y = data[2] * micrometreToCentimetre;
        const double z = data[4] * micrometreToCentimetre;

        floops::Node* nearest = nullptr;
        double nearestDistanceSquared = std::numeric_limits<double>::max();
        floops::FieldServer& fields = *floops::globalSimObject().fieldServer;
        for (int meshIndex = 0; meshIndex != fields.meshes.count; ++meshIndex) {
            floops::Mesh* const mesh = fields.meshes.data[meshIndex];
            if (mesh->Type() == floops::Mesh::InterfaceMesh || mesh->Type() == floops::Mesh::GasMesh) {
                continue;
            }
            TcadBase::Iter<floops::Node> nodes = mesh->nodes();
            while (nodes++) {
                floops::Node* const node = nodes.current_pointer();
                const double dx = node->coordinate->x - x;
                const double dy = node->coordinate->y - y;
                const double dz = node->coordinate->z - z;
                const double distanceSquared = dx * dx + dy * dy + dz * dz;
                if (distanceSquared < nearestDistanceSquared) {
                    nearestDistanceSquared = distanceSquared;
                    nearest = node;
                }
            }
        }
        if (!nearest) {
            throw std::runtime_error(VOF_STR("No node found for point force ") + name);
        }

        const double snapDistance = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Snap.Dist"), pdblib::PDB0);
        if (std::sqrt(nearestDistanceSquared) > snapDistance) {
            if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Force.Distribute"), pdblib::PDB0)) {
                unrecoveredSiBoundaryBranch(
                    VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_point_force"
                    "(distributed)"));
            }
            throw std::runtime_error(VOF_STR("Point force is outside Point.Snap.Dist: ") + name);
        }

        for (int axis = 0; axis != 3; ++axis) {
            bcElements_.push_back(nearest);
            bcKinds_.push_back(axis + 3);
            bcValues_.push_back(data[axis * 2 + 1]);
        }
    }
}

void siGeneralBoundary::apply_point_disp() {
    // W-2024.09-SP1 @0x12a50f0: unlike the process base, store the
    // nearest DOF itself, and defer 3D off-node constraints to face assembly.
    Tcl_Interp* const interpreter = siBoundaryInterpreter();
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0)) return;
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0))
        pdblib::pdbsetBoolean(interpreter, 1, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0);
    floops::FieldServer& fields = *floops::globalSimObject().fieldServer;
    const char* listed = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0);
    std::istringstream names(listed ? listed : "");
    static const char* const keys[] = {VOF_STATIC_STR("pdx"), VOF_STATIC_STR("pdy"), VOF_STATIC_STR("pdz")};
    const double tolerance = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Snap.Dist"), pdblib::PDB0);
    std::string name;
    while (names >> name) {
        int count = 0;
        std::unique_ptr<double[]> coordinates(pdblib::pdbgetDoubleArray(interpreter, &count,
            VOF_STR("Mechanics"), name.c_str(), VOF_STR("Coordinate"), pdblib::PDB0));
        if (!coordinates || count != 6) throw std::runtime_error(VOF_STR("Inconsistent point displacement boundary condition data"));
        const TcadGeom::Location point{coordinates[0]*1e-4, coordinates[2]*1e-4, coordinates[4]*1e-4};
        floops::Element* nearest = nullptr;
        floops::Node* nearestCorner = nullptr;
        double distance = 1e38;
        auto closer = [&](const TcadGeom::Location& pos) {
            const double dx=pos.x-point.x, dy=pos.y-point.y, dz=pos.z-point.z;
            const double candidate=std::sqrt(dx*dx+dy*dy+dz*dz);
            if (candidate >= distance) return false;
            distance=candidate; return true;
        };
        for (int m=0; m<fields.meshes.count; ++m) {
            floops::Mesh* mesh=fields.meshes.data[m];
            if (mesh->Type()==floops::Mesh::InterfaceMesh || mesh->Type()==floops::Mesh::GasMesh) continue;
            auto nodes=mesh->nodes();
            while(nodes++) {
                auto* node=nodes.current_pointer();
                const auto& c=*node->coordinate;
                if(closer(TcadGeom::Location{c.x,c.y,c.z})) { nearest=node; nearestCorner=node; }
            }
            auto mids=mesh->nodes2();
            while(mids++) { auto* node=mids.current_pointer(); if(closer(node->position())) nearest=node; }
        }
        if (!nearest || !nearestCorner) throw std::runtime_error(VOF_STR("No node found for point displacement ")+name);
        const bool distribute=distance>tolerance && pdblib::pdbgetBoolean(interpreter,
            VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0);
        if(distance>tolerance) FLPS_warning(distribute ?
            VOF_STR("Snapped node is not within the tolerance; distributing displacement rate to nodes of the element containing the point") :
            VOF_STR("Snapped node is not within the tolerance; Use the nearest node"));
        for(int axis=0;axis<3;++axis) {
            if(!pdblib::pdbIsAvailable(interpreter,VOF_STR("Mechanics"),name.c_str(),keys[axis],pdblib::PDB0)) continue;
            double value=pdblib::pdbgetDouble(interpreter,VOF_STR("Mechanics"),name.c_str(),keys[axis],pdblib::PDB0);
            if(fields.largeDeformationFlag_ || pdblib::pdbgetBoolean(interpreter,VOF_STR("Mechanics"),
                VOF_STR("Solution.Type.Displacement"),pdblib::PDB0)) value*=getTimeStep();
            if(!distribute) { bcElements_.push_back(nearest);bcKinds_.push_back(axis);bcValues_.push_back(value);continue; }
            TcadBase::Seq<floops::Element> matched;nearestCorner->ElementMatch(matched);
            for(int j=0;j<matched.cur_max;++j) {
                auto* element=matched.list[j];
                if(static_cast<unsigned>(element->mesh->Type())>1U) continue;
                if(fields.dimension==3) {
                    auto faces=element->faces();while(faces++) {auto* face=faces.current_pointer();if(!face->IsSkeletal())continue;
                        elementsJ_.push_back(face);elementsK_.push_back(point);elementsL_.push_back(value);elementsM_.push_back(axis);
                    }
                } else if(fields.dimension==2) {
                    auto edges=element->edges();while(edges++) {
                        const auto oriented=edges.current();auto& edge=oriented.edge();if(!edge.IsSkeletal())continue;
                        auto* head=oriented.Dir()==floops::OEdgeOrder::Normal?edge.firstNode:edge.secondNode;
                        auto* tail=oriented.Dir()==floops::OEdgeOrder::Normal?edge.secondNode:edge.firstNode;
                        const TcadGeom::Point<double> target(point.x,point.y,point.z);
                        mgoals::Segment<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>> segment;
                        segment.first_point={head->coordinate->x,head->coordinate->y,head->coordinate->z};
                        segment.second_point={tail->coordinate->x,tail->coordinate->y,tail->coordinate->z};
                        if(!segment.contained(target))continue;
                        TcadMath::RFloat<double> weights[2];
                        mgoals::GeometryPolicy::getWeights<double>(target,segment.first_point,segment.second_point,weights[0],weights[1]);
                        bcElements_.push_back(head);bcKinds_.push_back(axis);bcValues_.push_back(weights[0].value()*value);
                        bcElements_.push_back(tail);bcKinds_.push_back(axis);bcValues_.push_back(weights[1].value()*value);
                    }
                }
            }
        }
    }
}

void siGeneralBoundary::apply_body_force() {
    Tcl_Interp* const interpreter = siBoundaryInterpreter();
    if (pdblib::pdbgetBoolean(interpreter, VOF_STR("Mechanics"), VOF_STR("Apply.Body.Force"), pdblib::PDB0)) {
        apply_gravity();
    }

    // Native @0x12a2890 keeps parallel PDB and FieldServer names for the three
    // components and maps them to BC kinds 3/4/5.  Expression data takes
    // precedence over a constant and is averaged over each element's nodes.
    static const char* const components[] = {VOF_STATIC_STR("Body.Force.X"), VOF_STATIC_STR("Body.Force.Y"), VOF_STATIC_STR("Body.Force.Z")};
    static const char* const fieldNames[] = {VOF_STATIC_STR("BodyForceXField"), VOF_STATIC_STR("BodyForceYField"), VOF_STATIC_STR("BodyForceZField")};
    floops::FieldServer& fieldServer = *floops::globalSimObject().fieldServer;
    for (int meshIndex = 0; meshIndex != fieldServer.meshes.count; ++meshIndex) {
        floops::Mesh* const mesh = fieldServer.meshes.data[meshIndex];
        if (static_cast<unsigned int>(mesh->type_) > 1U) {
            continue;
        }
        for (int componentIndex = 0; componentIndex != 3; ++componentIndex) {
            const char* const component = components[componentIndex];
            const bool expression = pdblib::pdbIsAvailable(interpreter, mesh->Name(), VOF_STR("Mechanics"), VOF_STR("Equation"),
                                                           component, pdblib::PDB0) != 0;
            floops::RealData* field = nullptr;
            double value = 0.0;
            if (expression) {
                floops::MechParams parameters;
                floops::Expr* const parsed = parameters.parseString(interpreter, *mesh, component);
                field = static_cast<floops::RealData*>(parameters.evalExpr(*mesh, fieldNames[componentIndex], parsed));
            }

            const bool constant =
                pdblib::pdbIsAvailable(interpreter, mesh->Name(), VOF_STR("Mechanics"), component, pdblib::PDB0) != 0;
            if (!expression && constant) {
                value = pdblib::pdbgetDouble(interpreter, mesh->Name(), VOF_STR("Mechanics"), component, pdblib::PDB0);
            } else if (!expression) {
                continue;
            }

            floops::ElementIter elements = mesh->elements(-1, -1);
            while (elements++) {
                floops::Element* const element = elements.current_pointer();
                const double elementValue = field ? averageNodeField(*element, *field) : value;
                apply_bforce(element, elementValue, componentIndex + 3);
            }
        }
    }
}

void siGeneralBoundary::apply_gravity() {
    constexpr double kGravityAcceleration = 980.665;
    Tcl_Interp* const interpreter = siBoundaryInterpreter();
    floops::FieldServer& fieldServer = *floops::globalSimObject().fieldServer;

    for (int meshIndex = 0; meshIndex != fieldServer.meshes.count; ++meshIndex) {
        floops::Mesh* const mesh = fieldServer.meshes.data[meshIndex];
        if (static_cast<unsigned int>(mesh->type_) > 1U) {
            continue;
        }

        const double constantGravityLoad =
            pdblib::pdbgetDouble(interpreter, mesh->Name(), VOF_STR("MassDensity"), pdblib::PDB0) * kGravityAcceleration;
        floops::RealData* field = nullptr;
        const bool expression = pdblib::pdbIsAvailable(interpreter, mesh->Name(), VOF_STR("Mechanics"), VOF_STR("Equation"),
                                                       VOF_STR("MassDensity"), pdblib::PDB0) != 0;
        if (expression) {
            floops::MechParams parameters;
            floops::Expr* const parsed = parameters.parseString(interpreter, *mesh, VOF_STATIC_STR("MassDensity"));
            field = static_cast<floops::RealData*>(parameters.evalExpr(*mesh, VOF_STATIC_STR("MassDensityField"), parsed));
        }

        floops::ElementIter elements = mesh->elements(-1, -1);
        while (elements++) {
            floops::Element* const element = elements.current_pointer();
            const double gravityLoad =
                field ? averageNodeField(*element, *field) * kGravityAcceleration : constantGravityLoad;
            apply_bforce(element, gravityLoad, 3);
        }
    }
}

void siGeneralBoundary::apply_bforce(floops::Element* element, double value, int axis) {
    if (!element || !element->mesh) {
        FLPS_panic(VOF_STR("siGeneralBoundary::apply_bforce missing element mesh"));
    }
    floops::FieldServer& fieldServer = *floops::globalSimObject().fieldServer;
    FE::FiniteElement* const finiteElement = fieldServer.getFE(element->mesh->meshIndex_, element->Index());
    if (!finiteElement || !finiteElement->shapeFn_) {
        FLPS_panic(VOF_STR("siGeneralBoundary::apply_bforce missing finite element"));
    }

    // Native selects helper1 for LinearHex/QuadraticHex shape RTTI.  This phase
    // recovers the LinearHex path exercised by the CSSE body-force benchmark;
    // keep the unrecovered QuadraticHex path fail-loud instead of changing the
    // product source list merely to make its RTTI available.
    if (!light_cast<FE::LinearHex*>(finiteElement->shapeFn_)) {
        unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_bforce(non-hex)"));
    }

    const std::vector<double> weights = apply_body_force_helper1(finiteElement);
    floops::ElementIter dofs = element->dofs();
    std::size_t node = 0;
    while (dofs++) {
        floops::Element* const dof = dofs.current_pointer();
        if (node == weights.size()) {
            FLPS_panic(VOF_STR("siGeneralBoundary::apply_bforce too many element dofs"));
        }
        bcElements_.push_back(dof);
        bcKinds_.push_back(axis);
        bcValues_.push_back(value * weights[node]);
        ++node;
    }
}

void siGeneralBoundary::apply_displacement(std::vector<floops::Element*>&, int, char*) {
    unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_displacement(expression)"));
}

void siGeneralBoundary::apply_stress(std::vector<floops::Element*>&, int, double value) {
    if (value == 0.0) {
        return;
    }
    unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_stress"));
}

void siGeneralBoundary::apply_pressure(std::vector<floops::Element*>& elements, double value) {
    if (value == 0.0) {
        return;
    }
    if (dimension_ != 3 || feOrder_ != 1) {
        unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_pressure(non-linear triangle)"));
    }

    for (std::size_t index = 0; index < elements.size(); ++index) {
        floops::Element* const element = elements[index];
        TcadGeom::Location normal{};
        compute_elem_normal(element, normal);

        floops::Node* corners[3] = {nullptr, nullptr, nullptr};
        int nodeCount = 0;
        TcadBase::Iter<floops::Node> nodes = element->nodes();
        while (nodes++) {
            floops::Node* const node = nodes.current_pointer();
            if (nodeCount == 3) {
                unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_pressure(non-triangle)"));
            }
            corners[nodeCount++] = node;
        }
        if (nodeCount != 3) {
            unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_pressure(invalid triangle)"));
        }

        // Native multiplies in this order: Size * -value, then each normal
        // component, then the stored 1/3 constant. Preserve the rounding.
        const double scale = element->Size() * -value;
        constexpr double oneThird = 1.0 / 3.0;
        const double components[3] = {scale * normal.x * oneThird, scale * normal.y * oneThird,
                                      scale * normal.z * oneThird};
        for (floops::Node* const node : corners) {
            for (int axis = 0; axis != 3; ++axis) {
                bcElements_.push_back(node);
                bcKinds_.push_back(axis + 3);
                bcValues_.push_back(components[axis]);
            }
        }
    }
}

void siGeneralBoundary::apply_pressure(std::vector<floops::Element*>&, std::vector<double>&, double) {
    unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_pressure(distributed)"));
}

void siGeneralBoundary::apply_zipping_force() {
    if (!pdblib::pdbgetBoolean(siBoundaryInterpreter(), VOF_STR("Mechanics"), VOF_STR("Zipping.Effect"), pdblib::PDB0)) {
        return;
    }
    unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::apply_zipping_force"));
}

void siGeneralBoundary::processPointDispBCs(floops::Matrix* matrix, floops::Vector* rhs) {
    // W-2024.09-SP1 @0x12a6770: penalty * N N^T and penalty * value * N.
    auto& fields=*floops::globalSimObject().fieldServer;
    if(fields.dimension!=3 || !matrix || !rhs || elementsJ_.empty()) return;
    const double penalty=pdblib::pdbgetDouble(siBoundaryInterpreter(),VOF_STR("Mechanics"),
        VOF_STR("Displacement.Penalty.Factor"),pdblib::PDB0);
    FE::P1Tri tri1;FE::P2Tri tri2;FE::Q1Quad quad1;FE::P2Quad quad2;
    for(std::size_t k=0;k<elementsJ_.size();++k) {
        auto* face=elementsJ_[k];if(!face->IsSkeletal())continue;
        floops::IntData* eq=elementsM_[k]==0?velocitySolution_->eqnXVelocity_:
            (elementsM_[k]==1?velocitySolution_->eqnYVelocity_:velocitySolution_->eqnZVelocity_);
        std::vector<TcadGeom::Point<double>> vertices;
        auto nodes=face->nodes();while(nodes++){auto& c=*nodes.current_pointer()->coordinate;vertices.emplace_back(c.x,c.y,c.z);}
        FE::FiniteElement* fe=nullptr;
        if(vertices.size()==3)fe=feOrder_==1?static_cast<FE::FiniteElement*>(&tri1):static_cast<FE::FiniteElement*>(&tri2);
        if(vertices.size()==4)fe=feOrder_==1?static_cast<FE::FiniteElement*>(&quad1):static_cast<FE::FiniteElement*>(&quad2);
        if(!fe || (feOrder_!=1 && feOrder_!=2))throw std::runtime_error(VOF_STR("Could not find element"));
        const auto& p=elementsK_[k];const TcadGeom::Point<double> target(p.x,p.y,p.z);
        auto contains=[&](int a,int b,int c){
            mgoals::Triangle<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>> triangle(vertices[a],vertices[b],vertices[c]);
            int location=0;unsigned long feature=0;triangle.getPointLocation<double>(target,&location,&feature);return location!=2;
        };
        if(!contains(0,1,2) && !(vertices.size()==4 && contains(0,2,3)))continue;
        fe->element_=face;fe->setup_element();
        std::vector<floops::Element*> dofs;auto iter=face->dofs();while(iter++)dofs.push_back(iter.current_pointer());
        std::vector<double> shape(dofs.size());fe->get_shape_fn_phy(p,shape.data());
        floops::BasicSingleStiff entry(1);
        // Native advances dense coefficient cursors only for nonnegative
        // equation IDs (0x12a717f..0x12a7339); preserve that order even when
        // an earlier face DOF has already been eliminated by a direct BC.
        std::size_t activeRow=0;
        for(std::size_t i=0;i<dofs.size();++i){
            const int row=eq->value(*dofs[i]);if(row<0)continue;
            if(row==0)throw std::runtime_error(VOF_STR("Invalid point displacement equation number"));
            entry.rowIds_.data_[0]=row;entry.currentRow_=entry.rows_;
            std::size_t activeCol=0;
            for(std::size_t j=0;j<dofs.size();++j){const int col=eq->value(*dofs[j]);if(col<0)continue;
                entry.colIds_.data_[0]=col;entry.rows_[0].data_[0]=penalty*(shape[activeRow]*shape[activeCol++]);matrix->AddElement(entry);
            }
            rhs->data_[row-1]+=penalty*elementsL_[k]*shape[activeRow++];
        }
    }
}

void siGeneralBoundary::apply_displacement(std::vector<floops::Element*>& elements, int axis, double value) {
    for (std::size_t index = 0; index < elements.size(); ++index) {
        floops::ElementIter dofs = elements[index]->dofs();
        while (dofs++) {
            floops::Element* const dof = dofs.current_pointer();
            bcElements_.push_back(dof);
            bcKinds_.push_back(axis);
            bcValues_.push_back(value);
        }
    }
}

int siGeneralBoundary::countFaceBCs(int, std::vector<floops::Element*>&, std::map<int, floops::Element*>&) {
    // Native fixed CSSE decks use defined/enhanced BCs and do not enter this
    // ordinary face-enumeration branch (confirmed by the SI symbol coverage
    // trace).  Keep the vtable complete but fail loudly if a future deck does.
    unrecoveredSiBoundaryBranch(VOF_STATIC_STR("sinterconnect::siGeneralBoundary::countFaceBCs"));
}

}  // namespace sinterconnect
