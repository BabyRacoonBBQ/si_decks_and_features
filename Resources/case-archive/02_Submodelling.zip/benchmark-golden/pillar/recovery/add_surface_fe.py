from pathlib import Path
root=Path('/home/mozztcad/geo3d')
for f in ['cmake/geo_libraries.cmake','cmake/rcfx_standalone.cmake']:
 p=root/f;s=p.read_text();anchor='        src/abi/FE/FE/Q1Quad.cpp';names=['P1Tri','P2Tri','P2Quad','LinearTriangle','QuadraticTriangle','QuadraticQuad','TwoDTri_1pt_gauss','TwoDTri_3pt_gauss','TwoDQuad_4x4_gauss'];extra=''.join('\n        src/abi/FE/FE/'+n+'.cpp' for n in names if ('src/abi/FE/FE/'+n+'.cpp') not in s);assert anchor in s;s=s.replace(anchor,anchor+extra,1);p.write_text(s)
