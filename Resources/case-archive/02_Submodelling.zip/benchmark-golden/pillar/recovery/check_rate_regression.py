from pathlib import Path
import numpy as np,h5py,json
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011/point-recovery/rate-regression-b')
def fields(p):
 with h5py.File(p) as f:
  return {(int(d.attrs['region']),d.attrs['name']):d['values'][:] for d in f['collection/geometry_0/state_0'].values() if d.attrs.get('name') in (b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress')}
report={}
for case in ('node','face'):
 paths=[root/(case+'-'+tool)/'global_sis.tdr' for tool in ('vendor','local')]
 if not all(p.exists() for p in paths):continue
 a,b=map(fields,paths);assert a.keys()==b.keys()
 delta={name.decode():max(float(np.max(abs(a[k]-b[k]))) for k in a if k[1]==name) for name in (b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress')}
 translation=[]
 for table in (a,b):
  u=np.concatenate([x.reshape(-1,3) for k,x in table.items() if k[1]==b'StepDisplacement'])
  translation.append(dict(min=u.min(axis=0).tolist(),max=u.max(axis=0).tolist(),maximum_error_cm=float(np.max(abs(u-np.array([4e-4,0,0]))))))
 report[case]=dict(differences_native_units=delta,translation=translation)
(root/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
