from pathlib import Path
import json, zipfile, xml.etree.ElementTree as ET, hashlib
r=Path('benchmark-golden/pillar'); d=Path('architecture-overview/StressThermal')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
b=read(r/'pillar-benchmark.json'); a=read(r/'vm/formal-pillar-recovered-a/all-repetitions-field-audit.json'); p=read(r/'recovery/source-provenance.json')
s=read(d/'scene.json'); before=read(d/'case2-before-recovered-results.json'); checks=[]
def check(name,ok):
    checks.append({'requirement':name,'passed':bool(ok)})
    assert ok,name
check('Release source and binary provenance verified',p['source_hashes_match_measured_build'] and p['build_type']==['CMAKE_BUILD_TYPE:STRING=Release'] and p['binary_sha256']==b['vm_environment']['binary_sha256']['stressthermal'])
check('Final build succeeds','Built target sinterconnect_run' in (r/'recovery/build-5.log').read_text(encoding='utf-8'))
check('Source diff formatting check',p['diff_check_exit']==0)
check('Nonzero nodal rate reproduces vendor',all(x==0 for x in read(r/'recovery/node-rate-verification.json')['node']['differences_native_units'].values()))
check('Nodal rate matches analytic translation',all(x['maximum_error_cm']<1e-10 for x in read(r/'recovery/node-rate-verification.json')['node']['translation']))
check('Face point regression reproduces vendor',read(r/'recovery/face-cursor-verification.json')['passed'])
check('All twelve native full fields audited',a['passed'] and a['runs_checked']==12)
check('Three repetitions for all three tools/stages',len(b['summary'])==6 and all(x['runs']==3 and x['identical_peaks'] for x in b['summary']) and not b['failures'])
for tool in ['vendor','stressthermal']:
    for rep in [1,2,3]:
        rows=[x['meta'] for x in b['runs'] if x['tool']==tool and x['rep']==rep]
        g=next(x for x in rows if x['stage']=='global'); l=next(x for x in rows if x['stage']=='unit-fine')
        check(f'{tool} repetition {rep}: own-global mapping',l['global_input_sha256']==g['result_sha256'])
check('Equivalent regional stress recovery verified',all(x['regional_recovery'] for x in b['field_audits'] if 'regional_recovery' in x))
check('MAPDL uses its own global displacement',b['accuracy_calibration']['mapdl']['vendor_displacements_used'] is False)
check('Every native measurement has load evidence and timers',len(b['runs'])==18 and all(x['host_load']['samples']>0 and x['native_solve_s']>0 and x['native_total_s']>0 for x in b['runs']))
check('Latest other six slides preserved through final export',[x for x in s if x['id']!='benchmark']==read(d/'other-slides-before-recovery-final-export.json'))
check('Original five other slides unchanged; concurrent Future Plan retained',[x for x in s if x['id'] not in ('benchmark','future-plans')]==[x for x in before if x['id'] not in ('benchmark','future-plans')])
case=next(x for x in s if x['id']=='benchmark'); prev=next(x for x in before if x['id']=='benchmark')
check('Case 2 visuals preserved',[i for i in case['items'] if i.get('x',0)<970]==[i for i in prev['items'] if i.get('x',0)<970])
values=[]
for tool,x in [('stressthermal',1234),('vendor',1436),('mapdl',1638)]:
    for stage,y,key,precision in [('global',335,'maximum_mises_MPa',3),('unit-fine',391,'maximum_mises_MPa',3),('global',666,'native_solve_s',2),('unit-fine',714,'native_solve_s',2)]:
        row=next(v for v in b['summary'] if v['tool']==tool and v['stage']==stage)
        val=row[key][0] if key=='maximum_mises_MPa' else row[key]['median']; target=f'{val:.{precision}f}'
        cells=[i for i in case['items'] if i['type']=='text' and i['x']==x and i['y']==y]
        check(f'Slide value: {tool} {stage} {key}',len(cells)==1 and cells[0]['text']==target); values.append(target)
check('Current render fits slide',not read(d/'recovered-case2-layout-check.json')['outside'])
with zipfile.ZipFile(d/'StressThermal-physics.pptx') as z:
    files=[n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
    check('PPTX seven editable slides',len(files)==7)
    doc=ET.fromstring(z.read('ppt/slides/slide5.xml')); texts=[t.text for t in doc.iter() if t.tag.endswith('}t')]
    check('PPTX Case 2 title and current data',case['title'] in texts and all(v in texts for v in values))
mx=ET.parse(d/'StressThermal-physics.drawio').getroot(); check('Drawio seven editable pages',len(mx.findall('diagram'))==7)
for ext in ['html','drawio']:
    text=(d/f'StressThermal-physics.{ext}').read_text(encoding='utf-8')
    check(ext+' contains updated Case 2 data',case['title'] in text and all(v in text for v in values))
result={'status':'passed','checks':checks,'measured_data':'pillar-benchmark.json','all_repetitions':'vm/formal-pillar-recovered-a/all-repetitions-field-audit.json','scene_sha256':hashlib.sha256((d/'scene.json').read_bytes()).hexdigest()}
(r/'recovery/completion-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(str(len(checks))+' recovery completion checks passed')
