# Point displacement recovery — implementation notes

The product overrides live in src/abi/floops/floops/GeneralBoundary.cpp.
The point-face member vectors at offsets 0x358, 0x370, 0x388 and 0x3a0
are now typed as face pointers, physical locations, values and axes. Class
size and member offsets remain ABI-compatible. Existing worktree changes
were retained.

Evidence: W-2024.09-SP1 sinterconnect apply_point_disp at 0x12a50f0,
processPointDispBCs at 0x12a6770, existing IDA decompilation and matching
live binary disassembly. Nearest-node search includes corner and second-order
nodes. Coordinates use micrometres converted to internal centimetres;
nonzero displacement rates use getTimeStep where the native solution mode
requires it. Direct constraints use the nearest DOF itself, not its incident
volume elements. Off-node 2D constraints retain the native edge weighting;
3D constraints collect skeletal faces and apply the product penalty assembly
with P1/P2 triangle and quadrilateral shape functions.

Native assembly advances dense coefficient cursors only for nonnegative
equation numbers. Preserving this ordering is necessary for vendor parity
when an earlier face DOF was fixed directly. The first mathematically indexed
implementation did not reproduce that case and was corrected using the
0x12a717f..0x12a7339 disassembly and a native face-point regression.

Original copper-pillar global and local cases completed using their original
constraints and the local tool's own global TDR. Global StepDisplacement,
StressEL, Stress and MisesStress matched the vendor arrays exactly. Local
maximum Mises was 703.7011053179519 MPa; maximum pointwise Mises difference
was 8.140087127685547e-10 MPa. These are functional checks, not formal timing.
A nonzero nodal rate test (2e-4 cm/s over 2 s) matched vendor arrays exactly;
maximum departure from the analytic rigid translation was 2.88114e-11 cm.

Raw evidence and executable provenance are retained under
/home/mozztcad/si-bench/golden-pillar-20261011/point-recovery.
Formal measured repetitions and artifact updates are complete; see STATUS.md and completion-audit.json.
