from pathlib import Path
import subprocess, difflib, hashlib, json
root=Path('benchmark-golden/pillar/recovery'); host='mozztcad@192.168.43.128'; remote='/home/mozztcad/si-bench/golden-pillar-20261011/point-recovery'
for name in ['GeneralBoundary.cpp.before','GeneralBoundary.h.before','build-5.log','native-point-disassembly.txt']:
    subprocess.run(['scp',host+':'+remote+'/'+name,str(root/name)],check=True)
for name in ['geo_libraries.cmake','rcfx_standalone.cmake']:
    subprocess.run(['scp',host+':/home/mozztcad/geo3d/cmake/'+name,str(root/name)],check=True)
patch=''
for name in ['GeneralBoundary.cpp','GeneralBoundary.h']:
    old=(root/(name+'.before')).read_text(encoding='utf-8').splitlines(True)
    new=(root/name.replace('.', '.recovered.',1)).read_text(encoding='utf-8').splitlines(True)
    patch+=''.join(difflib.unified_diff(old,new,fromfile='a/src/abi/floops/floops/'+name,tofile='b/src/abi/floops/floops/'+name))
(root/'point-recovery-final.patch').write_text(patch,encoding='utf-8')
result=subprocess.run(['ssh',host,'git -C /home/mozztcad/geo3d diff --check -- src/abi/floops/floops/GeneralBoundary.cpp src/abi/floops/floops/GeneralBoundary.h cmake/geo_libraries.cmake cmake/rcfx_standalone.cmake'],capture_output=True,text=True)
assert result.returncode==0,result.stdout+result.stderr
env=json.loads(Path('benchmark-golden/pillar/vm/formal-pillar-recovered-a/environment.json').read_text(encoding='utf-8'))
verified={}
for remote_name,digest in env['recovery_source_sha256'].items():
    name=Path(remote_name).name
    local=root/(name.replace('.', '.recovered.',1) if name.startswith('GeneralBoundary') else name)
    assert hashlib.sha256(local.read_bytes()).hexdigest()==digest,(name,'source mismatch')
    verified[remote_name]=digest
(root/'source-provenance.json').write_text(json.dumps({'source_hashes_match_measured_build':True,'diff_check_exit':result.returncode,'build_type':env['build_type'],'binary_sha256':env['binary_sha256']['stressthermal'],'source_sha256':verified},indent=2))
print('Final source hashes match measured Release build; diff check passed.')

