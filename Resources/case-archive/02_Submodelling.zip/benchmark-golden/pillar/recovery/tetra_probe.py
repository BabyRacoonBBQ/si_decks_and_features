from pathlib import Path
import subprocess,os,json
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011/point-recovery')
bin='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect'
d=root/'tetra-probe';d.mkdir(exist_ok=True)
(d/'probe.cmd').write_text('mode mechanics\ninit tdr=../tetra.tdr !load.commands !pdb\nstruct tdr=mesh\n')
with (d/'stdout.log').open('w') as f:
 r=subprocess.run([bin,'--noSyntaxCheck','probe.cmd'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=60)
print('exit',r.returncode);print((d/'stdout.log').read_text()[-2000:])
