from pathlib import Path
import subprocess,os,json,shutil,time
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011');out=root/'point-recovery/rate-regression-a';out.mkdir(exist_ok=False)
base=(root/'prepared/global.cmd').read_text()
base=base.replace('pdx=0.0 pdy=0.0 pdz=0.0','pdx=2<um/s> pdy=0.0 pdz=0.0').replace('t.final=25.0<C>','t.final=180.0<C>').replace('time=1.0<s> init=1.0<s> maxstep=1.0<s>','time=2.0<s> init=2.0<s> maxstep=2.0<s>')
bins={'vendor':'/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect','local':'/home/mozztcad/geo3d/build/sinterconnect_run'}
records=[]
for case in ['node','face']:
 for tool,binary in bins.items():
  d=out/(case+'-'+tool);d.mkdir();shutil.copy2(root/'prepared/global-mesh_sis.tdr',d/'global-mesh_sis.tdr')
  deck=base if case=='node' else base.replace('{$xmin 0.0 0.0}','{$xmin 17.0 19.0}')
  (d/'case.cmd').write_text(deck)
  args=[binary]+(['--noSyntaxCheck'] if tool=='vendor' else [])+['case.cmd']
  print('BEGIN',case,tool,flush=True);start=time.time()
  with (d/'stdout.log').open('w') as f:
   r=subprocess.run(args,cwd=d,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'),timeout=600)
  record=dict(case=case,tool=tool,exit=r.returncode,wall=time.time()-start);records.append(record);(out/'runs.json').write_text(json.dumps(records,indent=2));print(record,flush=True)
  if r.returncode:raise RuntimeError(str(record))
