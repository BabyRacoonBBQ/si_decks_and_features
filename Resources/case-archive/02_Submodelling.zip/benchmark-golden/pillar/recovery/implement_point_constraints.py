from pathlib import Path
p=Path('/home/mozztcad/geo3d/src/abi/floops/floops/GeneralBoundary.cpp')
s=p.read_text(); backup=Path('/home/mozztcad/si-bench/golden-pillar-20261011/point-recovery');backup.mkdir(exist_ok=True)
(backup/'GeneralBoundary.cpp.before').write_text(s)
h=p.with_suffix('.h');hs=h.read_text();(backup/'GeneralBoundary.h.before').write_text(hs)
start=hs.index('    std::vector<Element*> elementsJ_{};');end=hs.index('\n};',start)
hs=hs[:start]+'''    // Product point displacement face constraints, sinterconnect @0x12a50f0.
    std::vector<Element*> elementsJ_{};                 // +0x358: skeletal faces
    std::vector<TcadGeom::Location> elementsK_{};        // +0x370: physical points
    std::vector<double> elementsL_{};                   // +0x388: prescribed values
    std::vector<int> elementsM_{};                      // +0x3a0: component indices
'''+hs[end:];h.write_text(hs)
s=s.replace('#include "abi/FE/FE/LinearHex.h"','#include "abi/FE/FE/LinearHex.h"\n#include "abi/FE/FE/P1Tri.h"\n#include "abi/FE/FE/P2Tri.h"\n#include "abi/FE/FE/Q1Quad.h"\n#include "abi/FE/FE/P2Quad.h"\n#include "abi/floops/floops/Matrix.h"\n#include "abi/floops/floops/Vector.h"')
a=s.index('void siGeneralBoundary::apply_point_disp() {');b=s.index('\nvoid siGeneralBoundary::apply_body_force()',a)
s=s[:a]+'''void siGeneralBoundary::apply_point_disp() {
    // W-2024.09-SP1 @0x12a50f0: unlike the process base, store the
    // nearest DOF itself, and defer 3D off-node constraints to face assembly.
    Tcl_Interp* const interpreter = siBoundaryInterpreter();
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0)) return;
    if (!pdblib::pdbIsAvailable(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0))
        pdblib::pdbsetBoolean(interpreter, 1, VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0);
    floops::FieldServer& fields = *floops::globalSimObject().fieldServer;
    const char* listed = pdblib::pdbgetString(interpreter, VOF_STR("Mechanics"), VOF_STR("PointDispList"), pdblib::PDB0);
    std::istringstream names(listed ? listed : "");
    static const char* const keys[] = {VOF_STATIC_STR("pdx"), VOF_STATIC_STR("pdy"), VOF_STATIC_STR("pdz")};
    const double tolerance = pdblib::pdbgetDouble(interpreter, VOF_STR("Mechanics"), VOF_STR("Point.Snap.Dist"), pdblib::PDB0);
    std::string name;
    while (names >> name) {
        int count = 0;
        std::unique_ptr<double[]> coordinates(pdblib::pdbgetDoubleArray(interpreter, &count,
            VOF_STR("Mechanics"), name.c_str(), VOF_STR("Coordinate"), pdblib::PDB0));
        if (!coordinates || count != 6) throw std::runtime_error(VOF_STR("Inconsistent point displacement boundary condition data"));
        const TcadGeom::Location point{coordinates[0]*1e-4, coordinates[2]*1e-4, coordinates[4]*1e-4};
        floops::Element* nearest = nullptr;
        floops::Node* nearestCorner = nullptr;
        double distance = 1e38;
        auto closer = [&](const TcadGeom::Location& pos) {
            const double dx=pos.x-point.x, dy=pos.y-point.y, dz=pos.z-point.z;
            const double candidate=std::sqrt(dx*dx+dy*dy+dz*dz);
            if (candidate >= distance) return false;
            distance=candidate; return true;
        };
        for (int m=0; m<fields.meshes.count; ++m) {
            floops::Mesh* mesh=fields.meshes.data[m];
            if (mesh->Type()==floops::Mesh::InterfaceMesh || mesh->Type()==floops::Mesh::GasMesh) continue;
            auto nodes=mesh->nodes();
            while(nodes++) {
                auto* node=nodes.current_pointer();
                const auto& c=*node->coordinate;
                if(closer(TcadGeom::Location{c.x,c.y,c.z})) { nearest=node; nearestCorner=node; }
            }
            auto mids=mesh->nodes2();
            while(mids++) { auto* node=mids.current_pointer(); if(closer(node->position())) nearest=node; }
        }
        if (!nearest || !nearestCorner) throw std::runtime_error(VOF_STR("No node found for point displacement ")+name);
        const bool distribute=distance>tolerance && pdblib::pdbgetBoolean(interpreter,
            VOF_STR("Mechanics"), VOF_STR("Point.DispRate.Distribute"), pdblib::PDB0);
        if(distance>tolerance) floops::FLPS_warning(distribute ?
            VOF_STR("Snapped node is not within the tolerance; distributing displacement rate to nodes of the element containing the point") :
            VOF_STR("Snapped node is not within the tolerance; Use the nearest node"));
        for(int axis=0;axis<3;++axis) {
            if(!pdblib::pdbIsAvailable(interpreter,VOF_STR("Mechanics"),name.c_str(),keys[axis],pdblib::PDB0)) continue;
            double value=pdblib::pdbgetDouble(interpreter,VOF_STR("Mechanics"),name.c_str(),keys[axis],pdblib::PDB0);
            if(fields.largeDeformationFlag_ || pdblib::pdbgetBoolean(interpreter,VOF_STR("Mechanics"),
                VOF_STR("Solution.Type.Displacement"),pdblib::PDB0)) value*=getTimeStep();
            if(!distribute) { bcElements_.push_back(nearest);bcKinds_.push_back(axis);bcValues_.push_back(value);continue; }
            TcadBase::Seq<floops::Element> matched;nearestCorner->ElementMatch(matched);
            for(int j=0;j<matched.cur_max;++j) {
                auto* element=matched.list[j];
                if(element->mesh->Type()==floops::Mesh::GasMesh || element->mesh->Type()==floops::Mesh::InterfaceMesh) continue;
                if(fields.dimension==3) {
                    auto faces=element->faces();while(faces++) {auto* face=faces.current_pointer();if(!face->IsSkeletal())continue;
                        elementsJ_.push_back(face);elementsK_.push_back(point);elementsL_.push_back(value);elementsM_.push_back(axis);
                    }
                } else if(fields.dimension==2) {
                    auto edges=element->edges();while(edges++) {
                        const auto oriented=edges.current();auto& edge=oriented.edge();if(!edge.IsSkeletal())continue;
                        auto* head=oriented.Dir()==floops::OEdgeOrder::Normal?edge.firstNode:edge.secondNode;
                        auto* tail=oriented.Dir()==floops::OEdgeOrder::Normal?edge.secondNode:edge.firstNode;
                        const TcadGeom::Point<double> target(point.x,point.y,point.z);
                        mgoals::Segment<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>> segment;
                        segment.first_point={head->coordinate->x,head->coordinate->y,head->coordinate->z};
                        segment.second_point={tail->coordinate->x,tail->coordinate->y,tail->coordinate->z};
                        if(!segment.contained(target))continue;
                        TcadMath::RFloat<double> weights[2];
                        mgoals::GeometryPolicy::getWeights<double>(target,segment.first_point,segment.second_point,weights[0],weights[1]);
                        bcElements_.push_back(head);bcKinds_.push_back(axis);bcValues_.push_back(weights[0].value()*value);
                        bcElements_.push_back(tail);bcKinds_.push_back(axis);bcValues_.push_back(weights[1].value()*value);
                    }
                }
            }
        }
    }
}
'''+s[b:]
a=s.index('void siGeneralBoundary::processPointDispBCs(');b=s.index('\nvoid siGeneralBoundary::apply_displacement',a)
s=s[:a]+'''void siGeneralBoundary::processPointDispBCs(floops::Matrix* matrix, floops::Vector* rhs) {
    // W-2024.09-SP1 @0x12a6770: penalty * N N^T and penalty * value * N.
    auto& fields=*floops::globalSimObject().fieldServer;
    if(fields.dimension!=3 || !matrix || !rhs || elementsJ_.empty()) return;
    const double penalty=pdblib::pdbgetDouble(siBoundaryInterpreter(),VOF_STR("Mechanics"),
        VOF_STR("Displacement.Penalty.Factor"),pdblib::PDB0);
    FE::P1Tri tri1;FE::P2Tri tri2;FE::Q1Quad quad1;FE::P2Quad quad2;
    for(std::size_t k=0;k<elementsJ_.size();++k) {
        auto* face=elementsJ_[k];if(!face->IsSkeletal())continue;
        floops::IntData* eq=elementsM_[k]==0?velocitySolution_->eqnXVelocity_:
            (elementsM_[k]==1?velocitySolution_->eqnYVelocity_:velocitySolution_->eqnZVelocity_);
        std::vector<TcadGeom::Point<double>> vertices;
        auto nodes=face->nodes();while(nodes++){auto& c=*nodes.current_pointer()->coordinate;vertices.emplace_back(c.x,c.y,c.z);}
        FE::FiniteElement* fe=nullptr;
        if(vertices.size()==3)fe=feOrder_==1?static_cast<FE::FiniteElement*>(&tri1):static_cast<FE::FiniteElement*>(&tri2);
        if(vertices.size()==4)fe=feOrder_==1?static_cast<FE::FiniteElement*>(&quad1):static_cast<FE::FiniteElement*>(&quad2);
        if(!fe || (feOrder_!=1 && feOrder_!=2))throw std::runtime_error(VOF_STR("Could not find element"));
        const auto& p=elementsK_[k];const TcadGeom::Point<double> target(p.x,p.y,p.z);
        auto contains=[&](int a,int b,int c){
            mgoals::Triangle<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>> triangle(vertices[a],vertices[b],vertices[c]);
            int location=0;unsigned long feature=0;triangle.getPointLocation<double>(target,&location,&feature);return location!=2;
        };
        if(!contains(0,1,2) && !(vertices.size()==4 && contains(0,2,3)))continue;
        fe->element_=face;fe->setup_element();
        std::vector<floops::Element*> dofs;auto iter=face->dofs();while(iter++)dofs.push_back(iter.current_pointer());
        std::vector<double> shape(dofs.size());fe->get_shape_fn_phy(p,shape.data());
        floops::BasicSingleStiff entry(1);
        for(std::size_t i=0;i<dofs.size();++i){
            const int row=eq->value(*dofs[i]);if(row<0)continue;
            if(row==0)throw std::runtime_error(VOF_STR("Invalid point displacement equation number"));
            entry.rowIds_.data_[0]=row;entry.currentRow_=entry.rows_;
            for(std::size_t j=0;j<dofs.size();++j){const int col=eq->value(*dofs[j]);if(col<0)continue;
                entry.colIds_.data_[0]=col;entry.rows_[0].data_[0]=penalty*(shape[i]*shape[j]);matrix->AddElement(entry);
            }
            rhs->data_[row-1]+=penalty*elementsL_[k]*shape[i];
        }
    }
}
'''+s[b:]
p.write_text(s)
print('Recovered product point displacement branches; original source saved in',backup)
