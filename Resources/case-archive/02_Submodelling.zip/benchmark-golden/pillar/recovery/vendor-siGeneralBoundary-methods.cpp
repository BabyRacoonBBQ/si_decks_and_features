// sinterconnect::siGeneralBoundary - Other
// Auto-generated: 2026-01-16 02:10:31
// Total functions: 15
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_pressure(std::vector<floops::Element *,std::allocator<floops::Element *>> &,std::vector&<double,std::allocator<double>>,double)
// Address:  0x129E250
// Size:     5941 bytes
//////////////////////////////////////////////////////////////////////

unsigned __int64 __fastcall sinterconnect::siGeneralBoundary::apply_pressure(
        #372 *this,
        __int64 *a2,
        _QWORD *a3,
        double a4,
        __m128d a5,
        __m128d a6)
{
  unsigned __int64 result; // rax
  __int64 v9; // rdx
  __int64 v10; // r13
  #148 *v11; // rsi
  __int64 v12; // r14
  int v13; // r13d
  int v14; // eax
  __m128d v15; // xmm2
  __m128d v16; // xmm1
  __int64 v17; // rax
  __m128d v18; // xmm0
  __int64 v19; // rdx
  int k; // eax
  _DWORD *v21; // rsi
  __int64 v22; // rsi
  __int64 v23; // rsi
  _DWORD *v24; // rsi
  __int64 v25; // rsi
  __int64 v26; // rsi
  _DWORD *v27; // rsi
  __int64 v28; // rsi
  __int64 v29; // rsi
  double v30; // xmm0_8
  _QWORD *v31; // r13
  int v32; // eax
  __m128d v33; // xmm0
  __m128d v34; // xmm0
  _DWORD *v35; // rsi
  __int64 v36; // rsi
  __int64 v37; // rsi
  _DWORD *v38; // rsi
  __int64 v39; // rsi
  __int64 v40; // rsi
  _DWORD *v41; // rsi
  __int64 v42; // rsi
  __int64 v43; // rsi
  __int64 (__fastcall *v44)(void *); // rax
  void *v45; // rdi
  int v46; // eax
  __int64 v47; // rdx
  __int64 v48; // r12
  __int64 v49; // rax
  #148 *v50; // rsi
  double v51; // rdx
  int v52; // eax
  int v53; // eax
  __m128i *v54; // r13
  unsigned int v55; // r12d
  __m128i v56; // xmm6
  __int64 v57; // rax
  __int64 v58; // rax
  __int64 v59; // rdi
  __int64 v60; // rax
  _QWORD *v61; // rdx
  int v62; // eax
  void *v63; // r13
  __int64 v64; // rax
  unsigned __int64 v65; // r12
  double v66; // rdx
  int v67; // eax
  int v68; // r13d
  __m128d v69; // xmm0
  _DWORD *v70; // rsi
  __int64 v71; // rsi
  __int64 v72; // rsi
  _DWORD *v73; // rsi
  __int64 v74; // rsi
  __int64 v75; // rsi
  _DWORD *v76; // rdx
  int v77; // eax
  __m128d v78; // xmm0
  _DWORD *v79; // rsi
  __int64 v80; // rsi
  __int64 v81; // rsi
  _DWORD *v82; // rsi
  __int64 v83; // rsi
  __int64 v84; // rsi
  void *v85; // r12
  __int64 (__fastcall *v86)(void *); // rax
  void *v87; // rdi
  __int128 *v88; // rdx
  int v89; // esi
  double *v90; // rax
  void **v91; // rcx
  double v92; // xmm0_8
  double v93; // xmm0_8
  double v94; // xmm0_8
  __int64 i; // r9
  double v96; // xmm0_8
  double v97; // xmm0_8
  __int64 j; // r9
  __m128d *v99; // rax
  unsigned __int64 v100; // rcx
  __m128d v101; // xmm0
  __m128d *v102; // rdx
  double v103; // [rsp+38h] [rbp-228h]
  double v104; // [rsp+40h] [rbp-220h]
  char *v105; // [rsp+50h] [rbp-210h]
  char *v106; // [rsp+50h] [rbp-210h]
  unsigned int v107; // [rsp+50h] [rbp-210h]
  double v108; // [rsp+58h] [rbp-208h]
  double v109; // [rsp+58h] [rbp-208h]
  char *v110; // [rsp+60h] [rbp-200h]
  __int64 v111; // [rsp+60h] [rbp-200h]
  char *v112; // [rsp+68h] [rbp-1F8h]
  double v113; // [rsp+68h] [rbp-1F8h]
  unsigned __int64 v114; // [rsp+68h] [rbp-1F8h]
  __int64 v115; // [rsp+70h] [rbp-1F0h]
  unsigned __int64 v117; // [rsp+80h] [rbp-1E0h]
  double v118; // [rsp+80h] [rbp-1E0h]
  unsigned __int64 v119; // [rsp+80h] [rbp-1E0h]
  double v120; // [rsp+88h] [rbp-1D8h]
  void *v121; // [rsp+88h] [rbp-1D8h]
  double *v122; // [rsp+88h] [rbp-1D8h]
  unsigned int v124; // [rsp+98h] [rbp-1C8h]
  double *v125; // [rsp+98h] [rbp-1C8h]
  __m128d v126; // [rsp+A0h] [rbp-1C0h] BYREF
  double v127; // [rsp+B0h] [rbp-1B0h]
  __m128d v128; // [rsp+C0h] [rbp-1A0h] BYREF
  double v129; // [rsp+D0h] [rbp-190h]
  int v130; // [rsp+D8h] [rbp-188h]
  int v131; // [rsp+DCh] [rbp-184h]
  void *v132[2]; // [rsp+E0h] [rbp-180h] BYREF
  double v133; // [rsp+F0h] [rbp-170h] BYREF
  int v134; // [rsp+F8h] [rbp-168h]
  int v135; // [rsp+FCh] [rbp-164h]
  __int128 v136; // [rsp+100h] [rbp-160h] BYREF
  __int128 v137; // [rsp+110h] [rbp-150h]
  void *v138[2]; // [rsp+120h] [rbp-140h] BYREF
  __int128 v139; // [rsp+130h] [rbp-130h]
  __int128 v140; // [rsp+140h] [rbp-120h]
  __m128d v141; // [rsp+150h] [rbp-110h]
  __int64 v142; // [rsp+160h] [rbp-100h]
  _OWORD v143[15]; // [rsp+170h] [rbp-F0h] BYREF

  memset(v143, 0, 192);
  result = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  if ( *(_DWORD *)(result + 96) != 3 )
  {
    result = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
    if ( *(_DWORD *)(result + 96) != 2 )
      return result;
    v47 = *a2;
    if ( a2[1] == *a2 )
      return result;
    v48 = 0;
    v107 = 0;
    while ( 1 )
    {
      v115 = 8 * v48;
      (*(void (__fastcall **)(__m128d *))(**(_QWORD **)(v47 + 8 * v48) + 192LL))(&v128);
      (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + 8 * v48) + 256LL))(v132);
      v49 = *a2;
      v127 = 0.0;
      v50 = *(#148 **)(v49 + 8 * v48);
      v126 = 0;
      floops::GeneralBoundary::compute_elem_normal(this, v50, (#1602 *)&v126, (__m128)0LL, a5, a6);
      v51 = v128.m128d_f64[1];
      if ( !*(_QWORD *)&v128.m128d_f64[1] )
        break;
      v52 = *(_DWORD *)(*(_QWORD *)&v128.m128d_f64[1] + 20LL);
      if ( v132[1] )
        goto LABEL_74;
LABEL_75:
      v111 = v52;
      if ( (unsigned __int64)v52 >> 60 )
        std::__throw_length_error("cannot create std::vector larger than max_size()");
      if ( v52 )
      {
        v111 = 8LL * v52;
        v125 = (double *)operator new(v111);
        memset(v125, 0, v111);
        v51 = v128.m128d_f64[1];
      }
      else
      {
        v125 = 0;
      }
      v53 = ++v130;
      if ( v51 == 0.0 )
        goto LABEL_140;
      v121 = 0;
      v54 = (__m128i *)v143;
      while ( 1 )
      {
        v55 = (unsigned int)v121;
        if ( *(_DWORD *)(*(_QWORD *)&v51 + 20LL) == v53 )
          break;
        v129 = *(double *)(*(_QWORD *)(*(_QWORD *)&v51 + 8LL) + 8LL * v53);
        v56 = _mm_loadu_si128((const __m128i *)*(_QWORD *)(*(_QWORD *)&v129 + 56LL));
        v54[1].m128i_i64[0] = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)&v129 + 56LL) + 16LL);
        v57 = floops::_globalPool[0];
        *v54 = v56;
        v58 = floops::GlobalObject<floops::GlobalSim>::operator->(v57 + 496);
        v59 = floops::_globalPool[0] + 496LL;
        if ( *(_BYTE *)(*(_QWORD *)v58 + 912LL) )
        {
          v113 = *(double *)&v54->m128i_i64[1];
          v60 = floops::GlobalObject<floops::GlobalSim>::operator->(v59);
        }
        else
        {
          if ( !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v59) + 913LL) )
            goto LABEL_84;
          v113 = *(double *)v54->m128i_i64;
          v60 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
        }
        v125[(_QWORD)v121] = v113 - *(double *)(*(_QWORD *)v60 + 920LL);
LABEL_84:
        v51 = v128.m128d_f64[1];
        v54 = (__m128i *)((char *)v54 + 24);
        v121 = (char *)v121 + 1;
        v53 = ++v130;
        if ( !*(_QWORD *)&v128.m128d_f64[1] )
        {
          ++v55;
          goto LABEL_86;
        }
      }
      if ( !(_DWORD)v121 )
        goto LABEL_140;
LABEL_86:
      if ( v55 > 2 )
        FLPS_panic("Element has more than 2 nodes!");
      v61 = v132[1];
      v62 = ++v134;
      if ( !v132[1] )
      {
        v114 = v55;
LABEL_162:
        v99 = (__m128d *)operator new(8 * v114);
        v122 = (double *)v99;
        v100 = ((8 * v114 - 8) >> 3) + 1;
        if ( 8 * v114 == 8 )
        {
LABEL_167:
          v99->m128d_f64[0] = 1.0;
        }
        else
        {
          v101 = _mm_unpacklo_pd((__m128d)0x3FF0000000000000uLL, (__m128d)0x3FF0000000000000uLL);
          v102 = &v99[v100 >> 1];
          do
            *v99++ = v101;
          while ( v99 != v102 );
          if ( (v100 & 1) != 0 )
          {
            v99 = (__m128d *)&v122[v100 & 0xFFFFFFFFFFFFFFFELL];
            goto LABEL_167;
          }
        }
        v65 = v114;
        v114 *= 8LL;
        goto LABEL_95;
      }
      while ( 2 )
      {
        if ( *((_DWORD *)v61 + 5) != v62 )
        {
          v133 = *(double *)(v61[1] + 8LL * v62);
          if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                        + 912LL) )
          {
            (*(void (__fastcall **)(void **))(**(_QWORD **)&v133 + 400LL))(v138);
            v63 = v138[1];
            v64 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
            goto LABEL_91;
          }
          if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                        + 913LL) )
          {
            (*(void (__fastcall **)(void **))(**(_QWORD **)&v133 + 400LL))(v138);
            v63 = v138[0];
            v64 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
LABEL_91:
            v125[v55] = *(double *)&v63 - *(double *)(*(_QWORD *)v64 + 920LL);
          }
          ++v55;
          v61 = v132[1];
          v62 = ++v134;
          if ( !v132[1] )
            break;
          continue;
        }
        break;
      }
      v114 = v55;
      if ( v55 )
        goto LABEL_162;
      v122 = 0;
      v65 = 0;
LABEL_95:
      if ( !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                     + 912LL)
        && !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                     + 913LL) )
      {
        v103 = 0.6666666666666666;
        if ( *((_DWORD *)this + 204) == 2 )
          v104 = 0.1666666666666667;
        else
          v104 = 0.5;
        goto LABEL_99;
      }
      *(_OWORD *)v138 = xmmword_7020A00;
      v142 = 0x3FE1111111111111LL;
      v139 = xmmword_7020A10;
      v136 = xmmword_70209E0;
      v140 = xmmword_7020A20;
      v137 = xmmword_70209F0;
      v141 = _mm_unpacklo_pd((__m128d)0x3FB1111111111111uLL, (__m128d)0x3FB1111111111111uLL);
      if ( v65 )
      {
        v88 = &v136;
        v89 = *((_DWORD *)this + 204);
        v90 = v122;
        a6 = (__m128d)0x401921FB54442D18uLL;
        v91 = v138;
        do
        {
          *v90 = 0.0;
          if ( v89 == 1 )
          {
            v92 = *(double *)v88 * 6.283185307179586 * *v125 + 0.0;
            *v90 = v92;
            if ( v65 == 1 )
              goto LABEL_147;
            a5 = (__m128d)*((unsigned __int64 *)v88 + 1);
            a5.m128d_f64[0] = a5.m128d_f64[0] * 6.283185307179586 * v125[1];
            v93 = v92 + a5.m128d_f64[0];
            *v90 = v93;
            if ( v65 == 2 )
              goto LABEL_147;
            a5 = (__m128d)*((unsigned __int64 *)v88 + 2);
            a5.m128d_f64[0] = a5.m128d_f64[0] * 6.283185307179586 * v125[2];
            v94 = v93 + a5.m128d_f64[0];
            *v90 = v94;
            if ( v65 == 3 )
              goto LABEL_147;
            for ( i = 3; i != v65; ++i )
            {
              a5 = (__m128d)*((unsigned __int64 *)v88 + i);
              a5.m128d_f64[0] = a5.m128d_f64[0] * 6.283185307179586 * v125[i];
              v94 = v94 + a5.m128d_f64[0];
            }
          }
          else
          {
            if ( v89 != 2 )
              goto LABEL_147;
            v96 = *(double *)v91 * 6.283185307179586 * *v125 + 0.0;
            *v90 = v96;
            if ( v65 == 1 )
              goto LABEL_147;
            a5 = (__m128d)(unsigned __int64)v91[1];
            a5.m128d_f64[0] = a5.m128d_f64[0] * 6.283185307179586 * v125[1];
            v97 = v96 + a5.m128d_f64[0];
            *v90 = v97;
            if ( v65 == 2 )
              goto LABEL_147;
            a5 = (__m128d)(unsigned __int64)v91[2];
            a5.m128d_f64[0] = a5.m128d_f64[0] * 6.283185307179586 * v125[2];
            v94 = v97 + a5.m128d_f64[0];
            *v90 = v94;
            if ( v65 == 3 )
              goto LABEL_147;
            for ( j = 3; j != v65; ++j )
            {
              a5 = (__m128d)(unsigned __int64)v91[j];
              a5.m128d_f64[0] = a5.m128d_f64[0] * 6.283185307179586 * v125[j];
              v94 = v94 + a5.m128d_f64[0];
            }
          }
          *v90 = v94;
LABEL_147:
          ++v88;
          ++v90;
          v91 += 3;
        }
        while ( &v136 + v65 != v88 );
      }
      v103 = 1.0;
      v104 = 1.0;
LABEL_99:
      v66 = v128.m128d_f64[1];
      *(_QWORD *)&v139 = 0;
      v129 = 0.0;
      v130 = 0;
      *(_OWORD *)v138 = 0;
      if ( *(_QWORD *)&v128.m128d_f64[1] )
      {
        v67 = 0;
        v68 = 0;
        do
        {
          if ( *(_DWORD *)(*(_QWORD *)&v66 + 20LL) == v67 )
            break;
          v129 = *(double *)(*(_QWORD *)(*(_QWORD *)&v66 + 8LL) + 8LL * v67);
          v69 = _mm_xor_pd((__m128d)*(unsigned __int64 *)&v122[v68], (__m128d)xmmword_7020870);
          v108 = v69.m128d_f64[0] * a4 * *(double *)(*a3 + v115);
          v69.m128d_f64[0] = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v115) + 344LL))(*(_QWORD *)(*a2 + v115))
                           * v108;
          a6 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&v104, (__m128d)*(unsigned __int64 *)&v104);
          *(double *)&v136 = v129;
          a5 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v69, v69), v126), a6);
          *(double *)&v139 = v69.m128d_f64[0] * v127 * v104;
          *(__m128d *)v138 = a5;
          sub_129E220((char *)this + 720, &v136);
          v70 = (_DWORD *)*((_QWORD *)this + 94);
          LODWORD(v136) = 3;
          if ( v70 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v70, &v136);
          }
          else
          {
            *v70 = 3;
            *((_QWORD *)this + 94) = v70 + 1;
          }
          v71 = *((_QWORD *)this + 97);
          if ( v71 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v71, v138);
          }
          else
          {
            v72 = v71 + 8;
            *(double *)(v72 - 8) = a5.m128d_f64[0];
            *((_QWORD *)this + 97) = v72;
          }
          *(double *)&v136 = v129;
          sub_129E220((char *)this + 720, &v136);
          LODWORD(v136) = 4;
          v73 = (_DWORD *)*((_QWORD *)this + 94);
          if ( v73 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v73, &v136);
          }
          else
          {
            *v73 = 4;
            *((_QWORD *)this + 94) = v73 + 1;
          }
          v74 = *((_QWORD *)this + 97);
          if ( v74 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v74, &v138[1]);
          }
          else
          {
            v75 = v74 + 8;
            *(double *)(v75 - 8) = a5.m128d_f64[1];
            *((_QWORD *)this + 97) = v75;
          }
          v66 = v128.m128d_f64[1];
          ++v68;
          v67 = ++v130;
        }
        while ( *(_QWORD *)&v128.m128d_f64[1] );
      }
      else
      {
        v68 = 0;
      }
      v76 = v132[1];
      v133 = 0.0;
      v134 = 0;
      if ( v132[1] )
      {
        v77 = 0;
        do
        {
          if ( v76[5] == v77 )
            break;
          v133 = *(double *)(*((_QWORD *)v76 + 1) + 8LL * v77);
          v78 = _mm_xor_pd((__m128d)*(unsigned __int64 *)&v122[v68], (__m128d)xmmword_7020870);
          v109 = v78.m128d_f64[0] * a4 * *(double *)(*a3 + v115);
          v78.m128d_f64[0] = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v115) + 344LL))(*(_QWORD *)(*a2 + v115))
                           * v109;
          a6 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&v103, (__m128d)*(unsigned __int64 *)&v103);
          *(double *)&v136 = v133;
          a5 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v78, v78), v126), a6);
          *(double *)&v139 = v78.m128d_f64[0] * v127 * v103;
          *(__m128d *)v138 = a5;
          sub_129E220((char *)this + 720, &v136);
          v79 = (_DWORD *)*((_QWORD *)this + 94);
          LODWORD(v136) = 3;
          if ( v79 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v79, &v136);
          }
          else
          {
            *v79 = 3;
            *((_QWORD *)this + 94) = v79 + 1;
          }
          v80 = *((_QWORD *)this + 97);
          if ( v80 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v80, v138);
          }
          else
          {
            v81 = v80 + 8;
            *(double *)(v81 - 8) = a5.m128d_f64[0];
            *((_QWORD *)this + 97) = v81;
          }
          *(double *)&v136 = v133;
          sub_129E220((char *)this + 720, &v136);
          LODWORD(v136) = 4;
          v82 = (_DWORD *)*((_QWORD *)this + 94);
          if ( v82 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v82, &v136);
          }
          else
          {
            *v82 = 4;
            *((_QWORD *)this + 94) = v82 + 1;
          }
          v83 = *((_QWORD *)this + 97);
          if ( v83 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v83, &v138[1]);
          }
          else
          {
            v84 = v83 + 8;
            *(double *)(v84 - 8) = a5.m128d_f64[1];
            *((_QWORD *)this + 97) = v84;
          }
          v76 = v132[1];
          ++v68;
          v77 = ++v134;
        }
        while ( v132[1] );
      }
      if ( v122 )
        operator delete(v122, v114);
      if ( v125 )
        operator delete(v125, v111);
      v132[0] = &off_7A76A28;
      if ( v135 )
      {
        v85 = v132[1];
        if ( v132[1] )
        {
          v86 = *(__int64 (__fastcall **)(void *))(*(_QWORD *)v132[1] + 8LL);
          if ( v86 == TcadBase::Bag<floops::Node2>::~Bag )
          {
            v87 = (void *)*((_QWORD *)v132[1] + 1);
            *(_QWORD *)v132[1] = &off_7A76A08;
            if ( v87 )
              operator delete[](v87);
            operator delete(v85, 0x18u);
          }
          else
          {
            v86(v132[1]);
          }
        }
      }
      *(_QWORD *)&v128.m128d_f64[0] = &off_7A757D0;
      if ( v131 && *(_QWORD *)&v128.m128d_f64[1] )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v128.m128d_f64[1] + 8LL))(*(_QWORD *)&v128.m128d_f64[1]);
      v47 = *a2;
      v48 = ++v107;
      result = (a2[1] - *a2) >> 3;
      if ( v107 >= result )
        return result;
    }
    if ( !v132[1] )
    {
      ++v130;
LABEL_140:
      FLPS_panic("Mesh element has no nodes");
    }
    v52 = 0;
LABEL_74:
    v52 += *((_DWORD *)v132[1] + 5);
    goto LABEL_75;
  }
  v9 = *a2;
  if ( a2[1] == *a2 )
    return result;
  v10 = 0;
  v124 = 0;
  v120 = -a4;
  do
  {
    v11 = *(#148 **)(v9 + 8 * v10);
    v128 = 0;
    v12 = 8 * v10;
    v129 = 0.0;
    floops::GeneralBoundary::compute_elem_normal(this, v11, (#1602 *)&v128, (__m128)0LL, a5, a6);
    (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + 8 * v10) + 192LL))(v138);
    if ( !v138[1] )
    {
      v46 = *((_DWORD *)this + 204);
      if ( v46 == 1 || v46 == 2 )
        goto LABEL_10;
LABEL_53:
      v15 = (__m128d)0x3FD5555555555555uLL;
      goto LABEL_11;
    }
    v13 = *((_DWORD *)v138[1] + 5);
    v138[0] = &off_7A757D0;
    if ( HIDWORD(v139) )
      (*(void (**)(void))(*(_QWORD *)v138[1] + 8LL))();
    v14 = *((_DWORD *)this + 204);
    if ( v14 != 1 )
    {
      if ( v14 == 2 )
      {
        v15 = (__m128d)0xBFB5555555555555LL;
        if ( v13 == 4 )
          goto LABEL_11;
LABEL_10:
        v15 = 0;
        goto LABEL_11;
      }
      goto LABEL_53;
    }
    if ( v13 == 3 )
      goto LABEL_53;
    v15 = (__m128d)0x3FD0000000000000uLL;
    if ( v13 != 4 )
      goto LABEL_10;
LABEL_11:
    *(double *)&v117 = v120 * *(double *)(*a3 + v12);
    v16 = (__m128d)v117;
    v16.m128d_f64[0] = *(double *)&v117
                     * (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v12) + 344LL))(*(_QWORD *)(*a2 + v12));
    v17 = **(_QWORD **)(*a2 + v12);
    v18 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v16, v16), v128), _mm_unpacklo_pd(v15, v15));
    *(__m128d *)v132 = v18;
    v118 = v16.m128d_f64[0] * v129 * v15.m128d_f64[0];
    v133 = v118;
    (*(void (__fastcall **)(__int128 *))(v17 + 192))(&v136);
    v19 = *((_QWORD *)&v136 + 1);
    for ( k = ++DWORD2(v137); *((_QWORD *)&v136 + 1); k = ++DWORD2(v137) )
    {
      if ( *(_DWORD *)(v19 + 20) == k )
        break;
      *(_QWORD *)&v137 = *(_QWORD *)(*(_QWORD *)(v19 + 8) + 8LL * k);
      v138[0] = (void *)v137;
      sub_129E220((char *)this + 720, v138);
      v21 = (_DWORD *)*((_QWORD *)this + 94);
      LODWORD(v138[0]) = 3;
      v112 = (char *)this + 744;
      if ( v21 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v21, v138);
      }
      else
      {
        *v21 = 3;
        *((_QWORD *)this + 94) = v21 + 1;
      }
      v22 = *((_QWORD *)this + 97);
      v105 = (char *)this + 768;
      if ( v22 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v22, v132);
      }
      else
      {
        v23 = v22 + 8;
        *(double *)(v23 - 8) = v18.m128d_f64[0];
        *((_QWORD *)this + 97) = v23;
      }
      v138[0] = (void *)v137;
      sub_129E220((char *)this + 720, v138);
      LODWORD(v138[0]) = 4;
      v24 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v24 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v112, v24, v138);
      }
      else
      {
        *v24 = 4;
        *((_QWORD *)this + 94) = v24 + 1;
      }
      v25 = *((_QWORD *)this + 97);
      if ( v25 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v105, v25, &v132[1]);
      }
      else
      {
        v26 = v25 + 8;
        *(double *)(v26 - 8) = v18.m128d_f64[1];
        *((_QWORD *)this + 97) = v26;
      }
      v138[0] = (void *)v137;
      sub_129E220((char *)this + 720, v138);
      LODWORD(v138[0]) = 5;
      v27 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v27 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v112, v27, v138);
      }
      else
      {
        *v27 = 5;
        *((_QWORD *)this + 94) = v27 + 1;
      }
      v28 = *((_QWORD *)this + 97);
      if ( v28 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v105, v28, &v133);
      }
      else
      {
        v29 = v28 + 8;
        *(double *)(v29 - 8) = v118;
        *((_QWORD *)this + 97) = v29;
      }
      v19 = *((_QWORD *)&v136 + 1);
    }
    (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + v12) + 256LL))(v138);
    *(double *)&v119 = v120 * *(double *)(*a3 + v12);
    v30 = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v12) + 344LL))(*(_QWORD *)(*a2 + v12));
    a5 = (__m128d)v119;
    v31 = v138[1];
    a5.m128d_f64[0] = *(double *)&v119 * v30;
    a6 = _mm_unpacklo_pd((__m128d)0x3FD5555555555555uLL, (__m128d)0x3FD5555555555555uLL);
    v32 = ++DWORD2(v139);
    v33 = _mm_mul_pd(_mm_unpacklo_pd(a5, a5), v128);
    a5.m128d_f64[0] = a5.m128d_f64[0] * v129 * 0.3333333333333333;
    v34 = _mm_mul_pd(v33, a6);
    v133 = a5.m128d_f64[0];
    *(__m128d *)v132 = v34;
    if ( !v138[1] )
    {
LABEL_40:
      v138[0] = &off_7A76A28;
      goto LABEL_41;
    }
    while ( v32 != *((_DWORD *)v31 + 5) )
    {
      *(_QWORD *)&v139 = *(_QWORD *)(v31[1] + 8LL * v32);
      *(_QWORD *)&v126.m128d_f64[0] = v139;
      sub_129E220((char *)this + 720, &v126);
      v35 = (_DWORD *)*((_QWORD *)this + 94);
      LODWORD(v126.m128d_f64[0]) = 3;
      v110 = (char *)this + 744;
      if ( v35 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v35, &v126);
      }
      else
      {
        *v35 = 3;
        *((_QWORD *)this + 94) = v35 + 1;
      }
      v36 = *((_QWORD *)this + 97);
      v106 = (char *)this + 768;
      if ( v36 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v36, v132);
      }
      else
      {
        v37 = v36 + 8;
        *(double *)(v37 - 8) = v34.m128d_f64[0];
        *((_QWORD *)this + 97) = v37;
      }
      *(_QWORD *)&v126.m128d_f64[0] = v139;
      sub_129E220((char *)this + 720, &v126);
      LODWORD(v126.m128d_f64[0]) = 4;
      v38 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v38 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v110, v38, &v126);
        v39 = *((_QWORD *)this + 97);
        if ( v39 == *((_QWORD *)this + 98) )
        {
LABEL_64:
          std::vector<double>::_M_realloc_insert<double const&>(v106, v39, &v132[1]);
          goto LABEL_35;
        }
      }
      else
      {
        *v38 = 4;
        *((_QWORD *)this + 94) = v38 + 1;
        v39 = *((_QWORD *)this + 97);
        if ( v39 == *((_QWORD *)this + 98) )
          goto LABEL_64;
      }
      v40 = v39 + 8;
      *(double *)(v40 - 8) = v34.m128d_f64[1];
      *((_QWORD *)this + 97) = v40;
LABEL_35:
      *(_QWORD *)&v126.m128d_f64[0] = v139;
      sub_129E220((char *)this + 720, &v126);
      LODWORD(v126.m128d_f64[0]) = 5;
      v41 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v41 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v110, v41, &v126);
      }
      else
      {
        *v41 = 5;
        *((_QWORD *)this + 94) = v41 + 1;
      }
      v42 = *((_QWORD *)this + 97);
      if ( v42 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v106, v42, &v133);
      }
      else
      {
        v43 = v42 + 8;
        *(double *)(v43 - 8) = a5.m128d_f64[0];
        *((_QWORD *)this + 97) = v43;
      }
      v31 = v138[1];
      v32 = ++DWORD2(v139);
      if ( !v138[1] )
        goto LABEL_40;
    }
    v138[0] = &off_7A76A28;
    if ( HIDWORD(v139) )
    {
      v44 = *(__int64 (__fastcall **)(void *))(*v31 + 8LL);
      if ( v44 == TcadBase::Bag<floops::Node2>::~Bag )
      {
        v45 = (void *)v31[1];
        *v31 = &off_7A76A08;
        if ( v45 )
          operator delete[](v45);
        operator delete(v31, 0x18u);
      }
      else
      {
        v44(v31);
      }
    }
LABEL_41:
    *(_QWORD *)&v136 = &off_7A757D0;
    if ( HIDWORD(v137) )
    {
      if ( *((_QWORD *)&v136 + 1) )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v136 + 1) + 8LL))(*((_QWORD *)&v136 + 1));
    }
    v9 = *a2;
    v10 = ++v124;
    result = (a2[1] - *a2) >> 3;
  }
  while ( v124 < result );
  return result;
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_pressure(std::vector<floops::Element *,std::allocator<floops::Element *>> &,double)
// Address:  0x129F990
// Size:     5829 bytes
//////////////////////////////////////////////////////////////////////

unsigned __int64 __fastcall sinterconnect::siGeneralBoundary::apply_pressure(
        #372 *this,
        __int64 *a2,
        double a3,
        __m128d a4,
        __m128d a5)
{
  unsigned __int64 result; // rax
  __int64 v8; // rdx
  __int64 v9; // r13
  #148 *v10; // rsi
  __m128d v11; // xmm0
  __int64 v12; // r12
  int v13; // r13d
  int v14; // eax
  __m128d v15; // xmm2
  __int64 v16; // rax
  __m128d v17; // xmm1
  __int64 v18; // rdx
  int k; // eax
  _DWORD *v20; // rsi
  __int64 v21; // rsi
  __int64 v22; // rsi
  _DWORD *v23; // rsi
  __int64 v24; // rsi
  __int64 v25; // rsi
  _DWORD *v26; // rsi
  __int64 v27; // rsi
  __int64 v28; // rsi
  _QWORD *v29; // r13
  int v30; // eax
  _DWORD *v31; // rsi
  __int64 v32; // rsi
  __int64 v33; // rsi
  _DWORD *v34; // rsi
  __int64 v35; // rsi
  __int64 v36; // rsi
  _DWORD *v37; // rsi
  __int64 v38; // rsi
  __int64 v39; // rsi
  __int64 (__fastcall *v40)(void *); // rax
  void *v41; // rdi
  int v42; // eax
  __int64 v43; // rdx
  __int64 v44; // rbx
  __int64 v45; // rax
  #148 *v46; // rsi
  double v47; // rdx
  int v48; // eax
  int v49; // eax
  __m128i *v50; // r12
  unsigned int v51; // ebx
  __m128i v52; // xmm3
  __int64 v53; // rax
  __int64 v54; // rax
  __int64 v55; // rdi
  __int64 v56; // rax
  _QWORD *v57; // rdx
  int v58; // eax
  void *v59; // r12
  __int64 v60; // rax
  unsigned __int64 v61; // rbx
  double v62; // rdx
  int v63; // eax
  int v64; // r12d
  __m128d v65; // xmm0
  _DWORD *v66; // rsi
  __int64 v67; // rsi
  __int64 v68; // rsi
  _DWORD *v69; // rsi
  __int64 v70; // rsi
  __int64 v71; // rsi
  _DWORD *v72; // rdx
  int v73; // eax
  __m128d v74; // xmm0
  _DWORD *v75; // rsi
  __int64 v76; // rsi
  __int64 v77; // rsi
  _DWORD *v78; // rsi
  __int64 v79; // rsi
  __int64 v80; // rsi
  void *v81; // rbx
  __int64 (__fastcall *v82)(void *); // rax
  void *v83; // rdi
  __int128 *v84; // rdx
  int v85; // esi
  double *v86; // rax
  void **v87; // rcx
  double v88; // xmm0_8
  double v89; // xmm0_8
  double v90; // xmm0_8
  __int64 i; // r9
  double v92; // xmm0_8
  double v93; // xmm0_8
  __int64 j; // r9
  __m128d *v95; // rax
  unsigned __int64 v96; // rcx
  __m128d v97; // xmm0
  __m128d *v98; // rdx
  double v99; // [rsp+30h] [rbp-220h]
  double v100; // [rsp+38h] [rbp-218h]
  char *v101; // [rsp+48h] [rbp-208h]
  char *v102; // [rsp+48h] [rbp-208h]
  unsigned int v103; // [rsp+48h] [rbp-208h]
  char *v104; // [rsp+58h] [rbp-1F8h]
  __int64 v105; // [rsp+58h] [rbp-1F8h]
  double v106; // [rsp+60h] [rbp-1F0h]
  unsigned __int64 v107; // [rsp+60h] [rbp-1F0h]
  char *v108; // [rsp+68h] [rbp-1E8h]
  __int64 v109; // [rsp+68h] [rbp-1E8h]
  double v111; // [rsp+70h] [rbp-1E0h]
  double v112; // [rsp+70h] [rbp-1E0h]
  double v113; // [rsp+80h] [rbp-1D0h]
  void *v114; // [rsp+80h] [rbp-1D0h]
  double *v115; // [rsp+80h] [rbp-1D0h]
  unsigned int v116; // [rsp+88h] [rbp-1C8h]
  double *v117; // [rsp+88h] [rbp-1C8h]
  __m128d v118; // [rsp+90h] [rbp-1C0h] BYREF
  double v119; // [rsp+A0h] [rbp-1B0h]
  __m128d v120; // [rsp+B0h] [rbp-1A0h] BYREF
  double v121; // [rsp+C0h] [rbp-190h]
  int v122; // [rsp+C8h] [rbp-188h]
  int v123; // [rsp+CCh] [rbp-184h]
  void *v124[2]; // [rsp+D0h] [rbp-180h] BYREF
  double v125; // [rsp+E0h] [rbp-170h] BYREF
  int v126; // [rsp+E8h] [rbp-168h]
  int v127; // [rsp+ECh] [rbp-164h]
  __int128 v128; // [rsp+F0h] [rbp-160h] BYREF
  __int128 v129; // [rsp+100h] [rbp-150h]
  void *v130[2]; // [rsp+110h] [rbp-140h] BYREF
  __int128 v131; // [rsp+120h] [rbp-130h]
  __int128 v132; // [rsp+130h] [rbp-120h]
  __m128d v133; // [rsp+140h] [rbp-110h]
  __int64 v134; // [rsp+150h] [rbp-100h]
  _OWORD v135[15]; // [rsp+160h] [rbp-F0h] BYREF

  memset(v135, 0, 192);
  result = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  if ( *(_DWORD *)(result + 96) != 3 )
  {
    result = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
    if ( *(_DWORD *)(result + 96) != 2 )
      return result;
    v43 = *a2;
    if ( a2[1] == *a2 )
      return result;
    v44 = 0;
    v103 = 0;
    while ( 1 )
    {
      v109 = 8 * v44;
      (*(void (__fastcall **)(__m128d *))(**(_QWORD **)(v43 + 8 * v44) + 192LL))(&v120);
      (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + 8 * v44) + 256LL))(v124);
      v45 = *a2;
      v119 = 0.0;
      v46 = *(#148 **)(v45 + 8 * v44);
      v118 = 0;
      floops::GeneralBoundary::compute_elem_normal(this, v46, (#1602 *)&v118, (__m128)0LL, a4, a5);
      v47 = v120.m128d_f64[1];
      if ( !*(_QWORD *)&v120.m128d_f64[1] )
        break;
      v48 = *(_DWORD *)(*(_QWORD *)&v120.m128d_f64[1] + 20LL);
      if ( v124[1] )
        goto LABEL_74;
LABEL_75:
      v105 = v48;
      if ( (unsigned __int64)v48 >> 60 )
        std::__throw_length_error("cannot create std::vector larger than max_size()");
      if ( v48 )
      {
        v105 = 8LL * v48;
        v117 = (double *)operator new(v105);
        memset(v117, 0, v105);
        v47 = v120.m128d_f64[1];
      }
      else
      {
        v117 = 0;
      }
      v49 = ++v122;
      if ( v47 == 0.0 )
        goto LABEL_140;
      v114 = 0;
      v50 = (__m128i *)v135;
      while ( 1 )
      {
        v51 = (unsigned int)v114;
        if ( v49 == *(_DWORD *)(*(_QWORD *)&v47 + 20LL) )
          break;
        v121 = *(double *)(*(_QWORD *)(*(_QWORD *)&v47 + 8LL) + 8LL * v49);
        v52 = _mm_loadu_si128((const __m128i *)*(_QWORD *)(*(_QWORD *)&v121 + 56LL));
        v50[1].m128i_i64[0] = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)&v121 + 56LL) + 16LL);
        v53 = floops::_globalPool[0];
        *v50 = v52;
        v54 = floops::GlobalObject<floops::GlobalSim>::operator->(v53 + 496);
        v55 = floops::_globalPool[0] + 496LL;
        if ( *(_BYTE *)(*(_QWORD *)v54 + 912LL) )
        {
          v106 = *(double *)&v50->m128i_i64[1];
          v56 = floops::GlobalObject<floops::GlobalSim>::operator->(v55);
        }
        else
        {
          if ( !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v55) + 913LL) )
            goto LABEL_84;
          v106 = *(double *)v50->m128i_i64;
          v56 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
        }
        v117[(_QWORD)v114] = v106 - *(double *)(*(_QWORD *)v56 + 920LL);
LABEL_84:
        v47 = v120.m128d_f64[1];
        v50 = (__m128i *)((char *)v50 + 24);
        v114 = (char *)v114 + 1;
        v49 = ++v122;
        if ( !*(_QWORD *)&v120.m128d_f64[1] )
        {
          ++v51;
          goto LABEL_86;
        }
      }
      if ( !(_DWORD)v114 )
        goto LABEL_140;
LABEL_86:
      if ( v51 > 2 )
        FLPS_panic("Element has more than 2 nodes!");
      v57 = v124[1];
      v58 = ++v126;
      if ( !v124[1] )
      {
        v107 = v51;
LABEL_162:
        v95 = (__m128d *)operator new(8 * v107);
        v115 = (double *)v95;
        v96 = ((8 * v107 - 8) >> 3) + 1;
        if ( 8 * v107 == 8 )
        {
LABEL_167:
          v95->m128d_f64[0] = 1.0;
        }
        else
        {
          v97 = _mm_unpacklo_pd((__m128d)0x3FF0000000000000uLL, (__m128d)0x3FF0000000000000uLL);
          v98 = &v95[v96 >> 1];
          do
            *v95++ = v97;
          while ( v95 != v98 );
          if ( (v96 & 1) != 0 )
          {
            v95 = (__m128d *)&v115[v96 & 0xFFFFFFFFFFFFFFFELL];
            goto LABEL_167;
          }
        }
        v61 = v107;
        v107 *= 8LL;
        goto LABEL_95;
      }
      while ( 2 )
      {
        if ( *((_DWORD *)v57 + 5) != v58 )
        {
          v125 = *(double *)(v57[1] + 8LL * v58);
          if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                        + 912LL) )
          {
            (*(void (__fastcall **)(void **))(**(_QWORD **)&v125 + 400LL))(v130);
            v59 = v130[1];
            v60 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
            goto LABEL_91;
          }
          if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                        + 913LL) )
          {
            (*(void (__fastcall **)(void **))(**(_QWORD **)&v125 + 400LL))(v130);
            v59 = v130[0];
            v60 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
LABEL_91:
            v117[v51] = *(double *)&v59 - *(double *)(*(_QWORD *)v60 + 920LL);
          }
          ++v51;
          v57 = v124[1];
          v58 = ++v126;
          if ( !v124[1] )
            break;
          continue;
        }
        break;
      }
      v107 = v51;
      if ( v51 )
        goto LABEL_162;
      v115 = 0;
      v61 = 0;
LABEL_95:
      if ( !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                     + 912LL)
        && !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                     + 913LL) )
      {
        v99 = 0.6666666666666666;
        if ( *((_DWORD *)this + 204) == 2 )
          v100 = 0.1666666666666667;
        else
          v100 = 0.5;
        goto LABEL_99;
      }
      *(_OWORD *)v130 = xmmword_7020A00;
      v134 = 0x3FE1111111111111LL;
      v131 = xmmword_7020A10;
      v128 = xmmword_70209E0;
      v132 = xmmword_7020A20;
      v129 = xmmword_70209F0;
      v133 = _mm_unpacklo_pd((__m128d)0x3FB1111111111111uLL, (__m128d)0x3FB1111111111111uLL);
      if ( v61 )
      {
        v84 = &v128;
        v85 = *((_DWORD *)this + 204);
        v86 = v115;
        a5 = (__m128d)0x401921FB54442D18uLL;
        v87 = v130;
        do
        {
          *v86 = 0.0;
          if ( v85 == 1 )
          {
            v88 = *(double *)v84 * 6.283185307179586 * *v117 + 0.0;
            *v86 = v88;
            if ( v61 == 1 )
              goto LABEL_147;
            a4 = (__m128d)*((unsigned __int64 *)v84 + 1);
            a4.m128d_f64[0] = a4.m128d_f64[0] * 6.283185307179586 * v117[1];
            v89 = v88 + a4.m128d_f64[0];
            *v86 = v89;
            if ( v61 == 2 )
              goto LABEL_147;
            a4 = (__m128d)*((unsigned __int64 *)v84 + 2);
            a4.m128d_f64[0] = a4.m128d_f64[0] * 6.283185307179586 * v117[2];
            v90 = v89 + a4.m128d_f64[0];
            *v86 = v90;
            if ( v61 == 3 )
              goto LABEL_147;
            for ( i = 3; i != v61; ++i )
            {
              a4 = (__m128d)*((unsigned __int64 *)v84 + i);
              a4.m128d_f64[0] = a4.m128d_f64[0] * 6.283185307179586 * v117[i];
              v90 = v90 + a4.m128d_f64[0];
            }
          }
          else
          {
            if ( v85 != 2 )
              goto LABEL_147;
            v92 = *(double *)v87 * 6.283185307179586 * *v117 + 0.0;
            *v86 = v92;
            if ( v61 == 1 )
              goto LABEL_147;
            a4 = (__m128d)(unsigned __int64)v87[1];
            a4.m128d_f64[0] = a4.m128d_f64[0] * 6.283185307179586 * v117[1];
            v93 = v92 + a4.m128d_f64[0];
            *v86 = v93;
            if ( v61 == 2 )
              goto LABEL_147;
            a4 = (__m128d)(unsigned __int64)v87[2];
            a4.m128d_f64[0] = a4.m128d_f64[0] * 6.283185307179586 * v117[2];
            v90 = v93 + a4.m128d_f64[0];
            *v86 = v90;
            if ( v61 == 3 )
              goto LABEL_147;
            for ( j = 3; j != v61; ++j )
            {
              a4 = (__m128d)(unsigned __int64)v87[j];
              a4.m128d_f64[0] = a4.m128d_f64[0] * 6.283185307179586 * v117[j];
              v90 = v90 + a4.m128d_f64[0];
            }
          }
          *v86 = v90;
LABEL_147:
          ++v84;
          ++v86;
          v87 += 3;
        }
        while ( &v128 + v61 != v84 );
      }
      v99 = 1.0;
      v100 = 1.0;
LABEL_99:
      v62 = v120.m128d_f64[1];
      *(_QWORD *)&v131 = 0;
      v121 = 0.0;
      v122 = 0;
      *(_OWORD *)v130 = 0;
      if ( *(_QWORD *)&v120.m128d_f64[1] )
      {
        v63 = 0;
        v64 = 0;
        do
        {
          if ( *(_DWORD *)(*(_QWORD *)&v62 + 20LL) == v63 )
            break;
          v121 = *(double *)(*(_QWORD *)(*(_QWORD *)&v62 + 8LL) + 8LL * v63);
          v65 = _mm_xor_pd((__m128d)*(unsigned __int64 *)&v115[v64], (__m128d)xmmword_7020870);
          v65.m128d_f64[0] = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v109) + 344LL))(*(_QWORD *)(*a2 + v109))
                           * (v65.m128d_f64[0]
                            * a3);
          a5 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&v100, (__m128d)*(unsigned __int64 *)&v100);
          *(double *)&v128 = v121;
          a4 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v65, v65), v118), a5);
          *(double *)&v131 = v65.m128d_f64[0] * v119 * v100;
          *(__m128d *)v130 = a4;
          sub_129E220((char *)this + 720, &v128);
          v66 = (_DWORD *)*((_QWORD *)this + 94);
          LODWORD(v128) = 3;
          if ( v66 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v66, &v128);
          }
          else
          {
            *v66 = 3;
            *((_QWORD *)this + 94) = v66 + 1;
          }
          v67 = *((_QWORD *)this + 97);
          if ( v67 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v67, v130);
          }
          else
          {
            v68 = v67 + 8;
            *(double *)(v68 - 8) = a4.m128d_f64[0];
            *((_QWORD *)this + 97) = v68;
          }
          *(double *)&v128 = v121;
          sub_129E220((char *)this + 720, &v128);
          LODWORD(v128) = 4;
          v69 = (_DWORD *)*((_QWORD *)this + 94);
          if ( v69 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v69, &v128);
          }
          else
          {
            *v69 = 4;
            *((_QWORD *)this + 94) = v69 + 1;
          }
          v70 = *((_QWORD *)this + 97);
          if ( v70 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v70, &v130[1]);
          }
          else
          {
            v71 = v70 + 8;
            *(double *)(v71 - 8) = a4.m128d_f64[1];
            *((_QWORD *)this + 97) = v71;
          }
          v62 = v120.m128d_f64[1];
          ++v64;
          v63 = ++v122;
        }
        while ( *(_QWORD *)&v120.m128d_f64[1] );
      }
      else
      {
        v64 = 0;
      }
      v72 = v124[1];
      v125 = 0.0;
      v126 = 0;
      if ( v124[1] )
      {
        v73 = 0;
        do
        {
          if ( v73 == v72[5] )
            break;
          v125 = *(double *)(*((_QWORD *)v72 + 1) + 8LL * v73);
          v74 = _mm_xor_pd((__m128d)*(unsigned __int64 *)&v115[v64], (__m128d)xmmword_7020870);
          v74.m128d_f64[0] = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v109) + 344LL))(*(_QWORD *)(*a2 + v109))
                           * (v74.m128d_f64[0]
                            * a3);
          a5 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&v99, (__m128d)*(unsigned __int64 *)&v99);
          *(double *)&v128 = v125;
          a4 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v74, v74), v118), a5);
          *(double *)&v131 = v74.m128d_f64[0] * v119 * v99;
          *(__m128d *)v130 = a4;
          sub_129E220((char *)this + 720, &v128);
          v75 = (_DWORD *)*((_QWORD *)this + 94);
          LODWORD(v128) = 3;
          if ( v75 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v75, &v128);
          }
          else
          {
            *v75 = 3;
            *((_QWORD *)this + 94) = v75 + 1;
          }
          v76 = *((_QWORD *)this + 97);
          if ( v76 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v76, v130);
          }
          else
          {
            v77 = v76 + 8;
            *(double *)(v77 - 8) = a4.m128d_f64[0];
            *((_QWORD *)this + 97) = v77;
          }
          *(double *)&v128 = v125;
          sub_129E220((char *)this + 720, &v128);
          LODWORD(v128) = 4;
          v78 = (_DWORD *)*((_QWORD *)this + 94);
          if ( v78 == *((_DWORD **)this + 95) )
          {
            std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v78, &v128);
          }
          else
          {
            *v78 = 4;
            *((_QWORD *)this + 94) = v78 + 1;
          }
          v79 = *((_QWORD *)this + 97);
          if ( v79 == *((_QWORD *)this + 98) )
          {
            std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v79, &v130[1]);
          }
          else
          {
            v80 = v79 + 8;
            *(double *)(v80 - 8) = a4.m128d_f64[1];
            *((_QWORD *)this + 97) = v80;
          }
          v72 = v124[1];
          ++v64;
          v73 = ++v126;
        }
        while ( v124[1] );
      }
      if ( v115 )
        operator delete(v115, v107);
      if ( v117 )
        operator delete(v117, v105);
      v124[0] = &off_7A76A28;
      if ( v127 )
      {
        v81 = v124[1];
        if ( v124[1] )
        {
          v82 = *(__int64 (__fastcall **)(void *))(*(_QWORD *)v124[1] + 8LL);
          if ( v82 == TcadBase::Bag<floops::Node2>::~Bag )
          {
            v83 = (void *)*((_QWORD *)v124[1] + 1);
            *(_QWORD *)v124[1] = &off_7A76A08;
            if ( v83 )
              operator delete[](v83);
            operator delete(v81, 0x18u);
          }
          else
          {
            v82(v124[1]);
          }
        }
      }
      *(_QWORD *)&v120.m128d_f64[0] = &off_7A757D0;
      if ( v123 && *(_QWORD *)&v120.m128d_f64[1] )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v120.m128d_f64[1] + 8LL))(*(_QWORD *)&v120.m128d_f64[1]);
      v43 = *a2;
      v44 = ++v103;
      result = (a2[1] - *a2) >> 3;
      if ( v103 >= result )
        return result;
    }
    if ( !v124[1] )
    {
      ++v122;
LABEL_140:
      FLPS_panic("Mesh element has no nodes");
    }
    v48 = 0;
LABEL_74:
    v48 += *((_DWORD *)v124[1] + 5);
    goto LABEL_75;
  }
  v8 = *a2;
  if ( a2[1] == *a2 )
    return result;
  v9 = 0;
  v116 = 0;
  v113 = -a3;
  do
  {
    v10 = *(#148 **)(v8 + 8 * v9);
    v11 = 0;
    v120 = 0;
    v12 = 8 * v9;
    v121 = 0.0;
    floops::GeneralBoundary::compute_elem_normal(this, v10, (#1602 *)&v120, (__m128)0LL, a4, a5);
    (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + 8 * v9) + 192LL))(v130);
    if ( !v130[1] )
    {
      v42 = *((_DWORD *)this + 204);
      if ( v42 == 1 || v42 == 2 )
        goto LABEL_10;
LABEL_53:
      v15 = (__m128d)0x3FD5555555555555uLL;
      goto LABEL_11;
    }
    v13 = *((_DWORD *)v130[1] + 5);
    v130[0] = &off_7A757D0;
    if ( HIDWORD(v131) )
      (*(void (**)(void))(*(_QWORD *)v130[1] + 8LL))();
    v14 = *((_DWORD *)this + 204);
    if ( v14 != 1 )
    {
      if ( v14 == 2 )
      {
        v15 = (__m128d)0xBFB5555555555555LL;
        if ( v13 == 4 )
          goto LABEL_11;
LABEL_10:
        v15 = 0;
        goto LABEL_11;
      }
      goto LABEL_53;
    }
    if ( v13 == 3 )
      goto LABEL_53;
    v15 = (__m128d)0x3FD0000000000000uLL;
    if ( v13 != 4 )
      goto LABEL_10;
LABEL_11:
    v11.m128d_f64[0] = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v12) + 344LL))(*(_QWORD *)(*a2 + v12))
                     * v113;
    v16 = **(_QWORD **)(*a2 + v12);
    v17 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v11, v11), v120), _mm_unpacklo_pd(v15, v15));
    *(__m128d *)v124 = v17;
    v111 = v11.m128d_f64[0] * v121 * v15.m128d_f64[0];
    v125 = v111;
    (*(void (__fastcall **)(__int128 *))(v16 + 192))(&v128);
    v18 = *((_QWORD *)&v128 + 1);
    for ( k = ++DWORD2(v129); *((_QWORD *)&v128 + 1); k = ++DWORD2(v129) )
    {
      if ( k == *(_DWORD *)(v18 + 20) )
        break;
      *(_QWORD *)&v129 = *(_QWORD *)(*(_QWORD *)(v18 + 8) + 8LL * k);
      v130[0] = (void *)v129;
      sub_129E220((char *)this + 720, v130);
      v20 = (_DWORD *)*((_QWORD *)this + 94);
      LODWORD(v130[0]) = 3;
      v108 = (char *)this + 744;
      if ( v20 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v20, v130);
      }
      else
      {
        *v20 = 3;
        *((_QWORD *)this + 94) = v20 + 1;
      }
      v21 = *((_QWORD *)this + 97);
      v101 = (char *)this + 768;
      if ( v21 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v21, v124);
      }
      else
      {
        v22 = v21 + 8;
        *(double *)(v22 - 8) = v17.m128d_f64[0];
        *((_QWORD *)this + 97) = v22;
      }
      v130[0] = (void *)v129;
      sub_129E220((char *)this + 720, v130);
      LODWORD(v130[0]) = 4;
      v23 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v23 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v108, v23, v130);
      }
      else
      {
        *v23 = 4;
        *((_QWORD *)this + 94) = v23 + 1;
      }
      v24 = *((_QWORD *)this + 97);
      if ( v24 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v101, v24, &v124[1]);
      }
      else
      {
        v25 = v24 + 8;
        *(double *)(v25 - 8) = v17.m128d_f64[1];
        *((_QWORD *)this + 97) = v25;
      }
      v130[0] = (void *)v129;
      sub_129E220((char *)this + 720, v130);
      LODWORD(v130[0]) = 5;
      v26 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v26 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v108, v26, v130);
      }
      else
      {
        *v26 = 5;
        *((_QWORD *)this + 94) = v26 + 1;
      }
      v27 = *((_QWORD *)this + 97);
      if ( v27 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v101, v27, &v125);
      }
      else
      {
        v28 = v27 + 8;
        *(double *)(v28 - 8) = v111;
        *((_QWORD *)this + 97) = v28;
      }
      v18 = *((_QWORD *)&v128 + 1);
    }
    (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + v12) + 256LL))(v130);
    v11.m128d_f64[0] = (*(double (__fastcall **)(_QWORD))(**(_QWORD **)(*a2 + v12) + 344LL))(*(_QWORD *)(*a2 + v12))
                     * v113;
    v29 = v130[1];
    a5 = _mm_unpacklo_pd((__m128d)0x3FD5555555555555uLL, (__m128d)0x3FD5555555555555uLL);
    v30 = ++DWORD2(v131);
    a4 = _mm_mul_pd(_mm_mul_pd(_mm_unpacklo_pd(v11, v11), v120), a5);
    v112 = v11.m128d_f64[0] * v121 * 0.3333333333333333;
    v125 = v112;
    *(__m128d *)v124 = a4;
    if ( !v130[1] )
    {
LABEL_40:
      v130[0] = &off_7A76A28;
      goto LABEL_41;
    }
    while ( *((_DWORD *)v29 + 5) != v30 )
    {
      *(_QWORD *)&v131 = *(_QWORD *)(v29[1] + 8LL * v30);
      *(_QWORD *)&v118.m128d_f64[0] = v131;
      sub_129E220((char *)this + 720, &v118);
      v31 = (_DWORD *)*((_QWORD *)this + 94);
      LODWORD(v118.m128d_f64[0]) = 3;
      v104 = (char *)this + 744;
      if ( v31 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v31, &v118);
      }
      else
      {
        *v31 = 3;
        *((_QWORD *)this + 94) = v31 + 1;
      }
      v32 = *((_QWORD *)this + 97);
      v102 = (char *)this + 768;
      if ( v32 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v32, v124);
      }
      else
      {
        v33 = v32 + 8;
        *(double *)(v33 - 8) = a4.m128d_f64[0];
        *((_QWORD *)this + 97) = v33;
      }
      *(_QWORD *)&v118.m128d_f64[0] = v131;
      sub_129E220((char *)this + 720, &v118);
      LODWORD(v118.m128d_f64[0]) = 4;
      v34 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v34 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v104, v34, &v118);
        v35 = *((_QWORD *)this + 97);
        if ( v35 == *((_QWORD *)this + 98) )
        {
LABEL_64:
          std::vector<double>::_M_realloc_insert<double const&>(v102, v35, &v124[1]);
          goto LABEL_35;
        }
      }
      else
      {
        *v34 = 4;
        *((_QWORD *)this + 94) = v34 + 1;
        v35 = *((_QWORD *)this + 97);
        if ( v35 == *((_QWORD *)this + 98) )
          goto LABEL_64;
      }
      v36 = v35 + 8;
      *(double *)(v36 - 8) = a4.m128d_f64[1];
      *((_QWORD *)this + 97) = v36;
LABEL_35:
      *(_QWORD *)&v118.m128d_f64[0] = v131;
      sub_129E220((char *)this + 720, &v118);
      LODWORD(v118.m128d_f64[0]) = 5;
      v37 = (_DWORD *)*((_QWORD *)this + 94);
      if ( v37 == *((_DWORD **)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int>(v104, v37, &v118);
      }
      else
      {
        *v37 = 5;
        *((_QWORD *)this + 94) = v37 + 1;
      }
      v38 = *((_QWORD *)this + 97);
      if ( v38 == *((_QWORD *)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v102, v38, &v125);
      }
      else
      {
        v39 = v38 + 8;
        *(double *)(v39 - 8) = v112;
        *((_QWORD *)this + 97) = v39;
      }
      v29 = v130[1];
      v30 = ++DWORD2(v131);
      if ( !v130[1] )
        goto LABEL_40;
    }
    v130[0] = &off_7A76A28;
    if ( HIDWORD(v131) )
    {
      v40 = *(__int64 (__fastcall **)(void *))(*v29 + 8LL);
      if ( v40 == TcadBase::Bag<floops::Node2>::~Bag )
      {
        v41 = (void *)v29[1];
        *v29 = &off_7A76A08;
        if ( v41 )
          operator delete[](v41);
        operator delete(v29, 0x18u);
      }
      else
      {
        v40(v29);
      }
    }
LABEL_41:
    *(_QWORD *)&v128 = &off_7A757D0;
    if ( HIDWORD(v129) )
    {
      if ( *((_QWORD *)&v128 + 1) )
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v128 + 1) + 8LL))(*((_QWORD *)&v128 + 1));
    }
    v8 = *a2;
    v9 = ++v116;
    result = (a2[1] - *a2) >> 3;
  }
  while ( v116 < result );
  return result;
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_displacement(std::vector<floops::Element *,std::allocator<floops::Element *>> &,int,double)
// Address:  0x12A1060
// Size:     444 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::apply_displacement(_QWORD *a1, __int64 *a2, int a3, double a4)
{
  __int64 v4; // rdx
  unsigned int v6; // r12d
  __int64 v7; // rcx
  int v8; // eax
  _QWORD *v9; // rsi
  __int64 v10; // rax
  __int64 v11; // rsi
  __int64 v12; // rsi
  __int64 v13; // rsi
  __int64 v14; // rsi
  double v15; // [rsp+0h] [rbp-70h] BYREF
  _DWORD v16[3]; // [rsp+Ch] [rbp-64h] BYREF
  __int64 v17; // [rsp+18h] [rbp-58h] BYREF
  __int64 (__fastcall **v18)(); // [rsp+20h] [rbp-50h] BYREF
  __int64 v19; // [rsp+28h] [rbp-48h]
  __int64 v20; // [rsp+30h] [rbp-40h]
  int v21; // [rsp+38h] [rbp-38h]
  int v22; // [rsp+3Ch] [rbp-34h]

  v16[0] = a3;
  v4 = *a2;
  v15 = a4;
  if ( a2[1] != v4 )
  {
    v6 = 0;
    v7 = 0;
    do
    {
      (*(void (__fastcall **)(__int64 (__fastcall ***)()))(**(_QWORD **)(v4 + 8 * v7) + 296LL))(&v18);
      while ( 1 )
      {
        v8 = ++v21;
        if ( !v19 )
          break;
        if ( *(_DWORD *)(v19 + 20) == v8 )
        {
          v18 = &off_7A75268;
          if ( v22 )
            (*(void (**)(void))(*(_QWORD *)v19 + 8LL))();
          break;
        }
        v9 = (_QWORD *)a1[91];
        v10 = *(_QWORD *)(*(_QWORD *)(v19 + 8) + 8LL * v8);
        v20 = v10;
        v17 = v10;
        if ( v9 == (_QWORD *)a1[92] )
        {
          std::vector<floops::Element *>::_M_realloc_insert<floops::Element *>(a1 + 90, v9, &v17);
          v11 = a1[94];
          if ( v11 == a1[95] )
            goto LABEL_15;
LABEL_8:
          v12 = v11 + 4;
          *(_DWORD *)(v12 - 4) = v16[0];
          a1[94] = v12;
          v13 = a1[97];
          if ( v13 != a1[98] )
            goto LABEL_9;
LABEL_16:
          std::vector<double>::_M_realloc_insert<double const&>(a1 + 96, v13, &v15);
        }
        else
        {
          *v9 = v10;
          a1[91] = v9 + 1;
          v11 = a1[94];
          if ( v11 != a1[95] )
            goto LABEL_8;
LABEL_15:
          std::vector<int>::_M_realloc_insert<int const&>(a1 + 93, v11, v16);
          v13 = a1[97];
          if ( v13 == a1[98] )
            goto LABEL_16;
LABEL_9:
          v14 = v13 + 8;
          *(double *)(v14 - 8) = v15;
          a1[97] = v14;
        }
      }
      v4 = *a2;
      v7 = ++v6;
    }
    while ( v6 < (unsigned __int64)((a2[1] - *a2) >> 3) );
  }
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_displacement(std::vector<floops::Element *,std::allocator<floops::Element *>> &,int,char *)
// Address:  0x12A1220
// Size:     1408 bytes
//////////////////////////////////////////////////////////////////////

unsigned __int64 __fastcall sinterconnect::siGeneralBoundary::apply_displacement(
        #372 *this,
        __int64 *a2,
        int a3,
        const char *a4,
        double a5)
{
  #288 **v7; // rax
  #288 **v8; // rax
  __int64 v9; // rax
  __int64 v10; // rdx
  unsigned __int64 result; // rax
  __int64 v12; // rcx
  __int64 v13; // rdi
  int v14; // eax
  __int64 v15; // rax
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // rax
  double v20; // r15
  double v21; // r12
  double v22; // xmm2_8
  __int64 v23; // r12
  __int64 v24; // rax
  _QWORD *v25; // rdi
  __int64 v26; // r12
  __int64 v27; // rax
  _QWORD *v28; // rdi
  __int64 StringResult; // rax
  __int64 v30; // r15
  __int64 v31; // r12
  __int64 v32; // rax
  _QWORD *v33; // rdi
  _QWORD *v34; // rsi
  __int64 v35; // rsi
  __int64 v36; // rsi
  __int64 v37; // rsi
  __int64 v38; // rsi
  __int64 v39; // rax
  __int64 v40; // rax
  __int64 v41; // rax
  __int64 v42; // [rsp+10h] [rbp-690h]
  __int64 Match; // [rsp+18h] [rbp-688h]
  double v44; // [rsp+28h] [rbp-678h]
  unsigned int v45; // [rsp+38h] [rbp-668h]
  int v46; // [rsp+3Ch] [rbp-664h] BYREF
  double v47; // [rsp+40h] [rbp-660h] BYREF
  __int64 v48; // [rsp+48h] [rbp-658h] BYREF
  __int64 (__fastcall **v49)(); // [rsp+50h] [rbp-650h] BYREF
  __int64 v50; // [rsp+58h] [rbp-648h]
  __int64 v51; // [rsp+60h] [rbp-640h]
  int v52; // [rsp+68h] [rbp-638h]
  int v53; // [rsp+6Ch] [rbp-634h]
  char dest[512]; // [rsp+70h] [rbp-630h] BYREF
  char v55[1072]; // [rsp+270h] [rbp-430h] BYREF

  v46 = a3;
  v47 = 0.0;
  strcpy(dest, a4);
  v7 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  Match = floops::FieldServer::RealFindMatch(*v7, "Temperature");
  v8 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v9 = floops::FieldServer::RealFindMatch(*v8, "PrevTemperature");
  v10 = *a2;
  v45 = 0;
  v42 = v9;
  result = (unsigned __int64)&v49;
  if ( *a2 == a2[1] )
    return result;
  v12 = 0;
  do
  {
    (*(void (__fastcall **)(__int64 (__fastcall ***)()))(**(_QWORD **)(v10 + 8 * v12) + 192LL))(&v49);
    v13 = v50;
    v14 = ++v52;
    if ( !v50 )
    {
LABEL_18:
      v49 = &off_7A757D0;
      goto LABEL_19;
    }
    while ( *(_DWORD *)(v13 + 20) != v14 )
    {
      v15 = *(_QWORD *)(*(_QWORD *)(v13 + 8) + 8LL * v14);
      v16 = *(_QWORD *)(v15 + 16);
      v51 = v15;
      v17 = *(int *)(*(_QWORD *)(v16 + 152) + 52LL);
      v18 = *(int *)(v15 + 28);
      v19 = *(int *)(v15 + 32) + 12LL;
      v20 = *(double *)(**(_QWORD **)(*(_QWORD *)(Match + 8 * v19) + 8 * v17) + 8 * v18);
      v21 = *(double *)(**(_QWORD **)(*(_QWORD *)(v42 + 8 * v19) + 8 * v17) + 8 * v18);
      v55[0] = 0;
      floops::GeneralBoundary::getTimeStep(this);
      v44 = a5;
      floops::GeneralBoundary::getTime(this);
      v22 = a5;
      a5 = v20 - 273.156;
      sprintf(v55, "%s %2.15e %2.15e %2.15e %2.15e", dest, v20 - 273.156, v21 - 273.156, v22, v44);
      v23 = floops::_globalPool[0];
      v24 = *(_QWORD *)(floops::_globalPool[0] + 496LL);
      if ( v24 )
        goto LABEL_6;
      v39 = operator new(0x90u);
      a5 = 0.0;
      *(_OWORD *)(v39 + 16) = 0;
      *(_QWORD *)(v39 + 8) = 0x100000001LL;
      *(_OWORD *)(v39 + 32) = 0;
      *(_OWORD *)(v39 + 48) = 0;
      *(_OWORD *)(v39 + 64) = 0;
      *(_OWORD *)(v39 + 80) = 0;
      *(_OWORD *)(v39 + 96) = 0;
      *(_OWORD *)(v39 + 112) = 0;
      *(_OWORD *)(v39 + 128) = 0;
      v25 = *(_QWORD **)(v23 + 504);
      *(_QWORD *)v39 = off_7A75010;
      *(_QWORD *)(v23 + 496) = v39 + 16;
      *(_QWORD *)(v23 + 504) = v39;
      if ( v25 )
      {
        std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v25);
        v24 = *(_QWORD *)(v23 + 496);
LABEL_6:
        v25 = *(_QWORD **)(v24 + 64);
      }
      if ( (unsigned int)Tcl_Eval(*v25, v55) )
        FLPS_panic("Boundary condition procedure failed");
      v26 = floops::_globalPool[0];
      v27 = *(_QWORD *)(floops::_globalPool[0] + 496LL);
      if ( v27 )
        goto LABEL_10;
      v40 = operator new(0x90u);
      a5 = 0.0;
      *(_OWORD *)(v40 + 16) = 0;
      *(_QWORD *)(v40 + 8) = 0x100000001LL;
      *(_OWORD *)(v40 + 32) = 0;
      *(_OWORD *)(v40 + 48) = 0;
      *(_OWORD *)(v40 + 64) = 0;
      *(_OWORD *)(v40 + 80) = 0;
      *(_OWORD *)(v40 + 96) = 0;
      *(_OWORD *)(v40 + 112) = 0;
      *(_OWORD *)(v40 + 128) = 0;
      v28 = *(_QWORD **)(v26 + 504);
      *(_QWORD *)v40 = off_7A75010;
      *(_QWORD *)(v26 + 496) = v40 + 16;
      *(_QWORD *)(v26 + 504) = v40;
      if ( v28 )
      {
        std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v28);
        v27 = *(_QWORD *)(v26 + 496);
LABEL_10:
        v28 = *(_QWORD **)(v27 + 64);
      }
      StringResult = Tcl_GetStringResult(*v28);
      v30 = floops::_globalPool[0];
      v31 = StringResult;
      v32 = *(_QWORD *)(floops::_globalPool[0] + 496LL);
      if ( v32 )
        goto LABEL_12;
      v41 = operator new(0x90u);
      a5 = 0.0;
      *(_OWORD *)(v41 + 16) = 0;
      *(_OWORD *)(v41 + 32) = 0;
      *(_OWORD *)(v41 + 48) = 0;
      *(_OWORD *)(v41 + 64) = 0;
      *(_OWORD *)(v41 + 80) = 0;
      *(_OWORD *)(v41 + 96) = 0;
      *(_OWORD *)(v41 + 112) = 0;
      *(_OWORD *)(v41 + 128) = 0;
      v33 = *(_QWORD **)(v30 + 504);
      *(_QWORD *)v41 = off_7A75010;
      *(_QWORD *)(v41 + 8) = 0x100000001LL;
      *(_QWORD *)(v30 + 496) = v41 + 16;
      *(_QWORD *)(v30 + 504) = v41;
      if ( v33 )
      {
        std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v33);
        v32 = *(_QWORD *)(v30 + 496);
LABEL_12:
        v33 = *(_QWORD **)(v32 + 64);
      }
      Tcl_ExprDouble(*v33, v31, &v47);
      v34 = (_QWORD *)*((_QWORD *)this + 91);
      v48 = v51;
      if ( v34 == *((_QWORD **)this + 92) )
      {
        std::vector<floops::Element *>::_M_realloc_insert<floops::Element *>((char *)this + 720, v34, &v48);
        v35 = *((_QWORD *)this + 94);
        if ( v35 != *((_QWORD *)this + 95) )
        {
LABEL_15:
          v36 = v35 + 4;
          *(_DWORD *)(v36 - 4) = v46;
          *((_QWORD *)this + 94) = v36;
          v37 = *((_QWORD *)this + 97);
          if ( v37 == *((_QWORD *)this + 98) )
            goto LABEL_31;
          goto LABEL_16;
        }
      }
      else
      {
        *v34 = v51;
        *((_QWORD *)this + 91) = v34 + 1;
        v35 = *((_QWORD *)this + 94);
        if ( v35 != *((_QWORD *)this + 95) )
          goto LABEL_15;
      }
      std::vector<int>::_M_realloc_insert<int const&>((char *)this + 744, v35, &v46);
      v37 = *((_QWORD *)this + 97);
      if ( v37 == *((_QWORD *)this + 98) )
      {
LABEL_31:
        std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v37, &v47);
        goto LABEL_17;
      }
LABEL_16:
      a5 = v47;
      v38 = v37 + 8;
      *(double *)(v38 - 8) = v47;
      *((_QWORD *)this + 97) = v38;
LABEL_17:
      v13 = v50;
      v14 = ++v52;
      if ( !v50 )
        goto LABEL_18;
    }
    v49 = &off_7A757D0;
    if ( v53 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v13 + 8LL))(v13);
LABEL_19:
    v10 = *a2;
    v12 = ++v45;
    result = (a2[1] - *a2) >> 3;
  }
  while ( v45 < result );
  return result;
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_bforce(floops::Element *,double,int)
// Address:  0x12A17D0
// Size:     2986 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::apply_bforce(
        #2314 *this,
        #148 *a2,
        double a3,
        int a4,
        double a5,
        double a6)
{
  _DWORD *v8; // rdi
  __int64 (*v9)(void); // rax
  int v10; // r15d
  int v11; // r14d
  #288 **v12; // rax
  __int64 FE; // rax
  _QWORD *v14; // r15
  const void *v15; // r14
  __int64 v16; // rdi
  int v17; // eax
  __int64 v18; // r12
  __int64 v19; // rsi
  __int64 v20; // rsi
  double *v21; // rsi
  double v22; // xmm0_8
  void *v23; // rdi
  double v24; // xmm0_8
  __int64 v25; // rax
  double v26; // xmm0_8
  int v27; // r15d
  int v28; // eax
  __int64 v29; // rax
  __int64 v30; // rdi
  int v31; // r8d
  int v32; // edx
  int v33; // ecx
  double v34; // xmm0_8
  __int64 v35; // rax
  __int64 v36; // r10
  __int64 v37; // rsi
  double v38; // xmm0_8
  __int64 v39; // rdx
  double v40; // xmm1_8
  int v41; // eax
  double v42; // xmm0_8
  __int64 v43; // rsi
  __int64 v44; // rsi
  __int64 v45; // rax
  __int64 v46; // rdi
  int v47; // r8d
  int v48; // edx
  int v49; // ecx
  double v50; // xmm1_8
  __int64 v51; // rax
  __int64 v52; // r10
  double **v53; // rsi
  double v54; // xmm0_8
  double v55; // r12
  __int64 v56; // rax
  void (__fastcall *v57)(void **, #148 *); // rax
  int v58; // eax
  __int64 v59; // rax
  int v60; // eax
  __int64 v61; // rax
  int v62; // edi
  int v63; // esi
  int v64; // ecx
  double v65; // xmm1_8
  __int64 v66; // rax
  __int64 v67; // r9
  double **v68; // rdx
  int v69; // esi
  int v70; // ecx
  int v71; // edx
  double v72; // xmm0_8
  __int64 v73; // rax
  __int64 v74; // r9
  __int64 v75; // rdi
  __int64 v76; // rdx
  int v77; // eax
  int v78; // eax
  __int64 v79; // rax
  int v80; // eax
  double v82; // [rsp+10h] [rbp-A0h]
  int v83; // [rsp+1Ch] [rbp-94h] BYREF
  double i; // [rsp+20h] [rbp-90h] BYREF
  double v85; // [rsp+28h] [rbp-88h] BYREF
  double v86; // [rsp+30h] [rbp-80h] BYREF
  double v87; // [rsp+38h] [rbp-78h] BYREF
  void *v88; // [rsp+40h] [rbp-70h] BYREF
  __int64 v89; // [rsp+48h] [rbp-68h]
  __int64 (__fastcall **v90)(); // [rsp+50h] [rbp-60h]
  int v91; // [rsp+58h] [rbp-58h]
  __int64 (__fastcall **v92)(); // [rsp+60h] [rbp-50h] BYREF
  __int64 v93; // [rsp+68h] [rbp-48h]
  double **v94; // [rsp+70h] [rbp-40h]
  int v95; // [rsp+78h] [rbp-38h]
  int v96; // [rsp+7Ch] [rbp-34h]

  v8 = (_DWORD *)*((_QWORD *)a2 + 2);
  v83 = a4;
  v9 = *(__int64 (**)(void))(*(_QWORD *)v8 + 64LL);
  if ( (char *)v9 == (char *)floops::Mesh::Index )
    v10 = v8[132];
  else
    v10 = v9();
  v11 = (*(__int64 (__fastcall **)(#148 *))(*(_QWORD *)a2 + 536LL))(a2);
  v12 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  FE = floops::FieldServer::getFE(*v12, v10, v11);
  v14 = (_QWORD *)FE;
  if ( !FE )
    FLPS_panic("Could not find element");
  v15 = *(const void **)(FE + 8);
  if ( v15
    && (__dynamic_cast(
          *(const void **)(FE + 8),
          (const struct __class_type_info *)&`typeinfo for'FE::IsoparametricElement,
          (const struct __class_type_info *)&`typeinfo for'FE::LinearHex,
          0)
     || __dynamic_cast(
          v15,
          (const struct __class_type_info *)&`typeinfo for'FE::IsoparametricElement,
          (const struct __class_type_info *)&`typeinfo for'FE::QuadraticHex,
          0))
    || !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 912LL)
    && *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 913LL) != 1
    && v15
    && (__dynamic_cast(
          v15,
          (const struct __class_type_info *)&`typeinfo for'FE::IsoparametricElement,
          (const struct __class_type_info *)&`typeinfo for'FE::LinearQuad,
          0)
     || __dynamic_cast(
          v15,
          (const struct __class_type_info *)&`typeinfo for'FE::IsoparametricElement,
          (const struct __class_type_info *)&`typeinfo for'FE::QuadraticQuad,
          0)) )
  {
    floops::GeneralBoundary::apply_body_force_helper1((#372 *)&v88, this, v14, a3, a5);
    (*(void (__fastcall **)(__int64 (__fastcall ***)(), #148 *))(*(_QWORD *)a2 + 296LL))(&v92, a2);
    v16 = v93;
    v17 = ++v95;
    if ( !v93 )
      goto LABEL_14;
    v18 = 0;
    while ( *(_DWORD *)(v16 + 20) != v17 )
    {
      v94 = *(double ***)(*(_QWORD *)(v16 + 8) + 8LL * v17);
      v87 = *(double *)&v94;
      sub_129E220((char *)this + 720, &v87);
      v19 = *((_QWORD *)this + 94);
      if ( v19 == *((_QWORD *)this + 95) )
      {
        std::vector<int>::_M_realloc_insert<int const&>((char *)this + 744, v19, &v83);
      }
      else
      {
        v20 = v19 + 4;
        *(_DWORD *)(v20 - 4) = v83;
        *((_QWORD *)this + 94) = v20;
      }
      v21 = (double *)*((_QWORD *)this + 97);
      v22 = a3 * *(double *)((char *)v88 + v18);
      v87 = v22;
      if ( v21 == *((double **)this + 98) )
      {
        std::vector<double>::_M_realloc_insert<double>((char *)this + 768, v21, &v87);
      }
      else
      {
        *v21 = v22;
        *((_QWORD *)this + 97) = v21 + 1;
      }
      v16 = v93;
      v18 += 8;
      v17 = ++v95;
      if ( !v93 )
        goto LABEL_14;
    }
    v92 = &off_7A75268;
    if ( v96 )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 8LL))(v16);
      v23 = v88;
      if ( !v88 )
        return;
    }
    else
    {
LABEL_14:
      v23 = v88;
      if ( !v88 )
        return;
    }
    operator delete(v23, (char *)v90 - (_BYTE *)v23);
    return;
  }
  v24 = (*(double (__fastcall **)(#148 *))(*(_QWORD *)a2 + 344LL))(a2);
  v25 = *(_QWORD *)a2;
  v26 = v24 * a3;
  v82 = v26;
  i = v26;
  (*(void (__fastcall **)(__int64 (__fastcall ***)(), #148 *))(v25 + 192))(&v92, a2);
  if ( !v93 )
  {
    TcadBase::Iter<floops::Node>::~Iter(&v92, v26, a5, a6);
LABEL_57:
    FLPS_panic("Element has no nodes");
  }
  v27 = *(_DWORD *)(v93 + 20);
  TcadBase::Iter<floops::Node>::~Iter(&v92, v26, a5, a6);
  if ( !v27 )
    goto LABEL_57;
  v28 = *((_DWORD *)this + 204);
  if ( v28 == 1 )
  {
    (*(void (__fastcall **)(__int64 (__fastcall ***)(), #148 *))(*(_QWORD *)a2 + 192LL))(&v92, a2);
    if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                   + 96LL) != 2 )
    {
      v39 = v93;
LABEL_49:
      v40 = 1.0;
      goto LABEL_50;
    }
    v45 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
    v46 = floops::_globalPool[0] + 496LL;
    if ( *(_BYTE *)(*(_QWORD *)v45 + 912LL) )
    {
      v47 = v95;
      v48 = ++v95;
      if ( v93 )
      {
        v49 = *(_DWORD *)(v93 + 20);
        v50 = 0.0;
        if ( v49 != v48 )
        {
          v51 = 8LL * v48;
          v52 = *(_QWORD *)(v93 + 8);
          do
          {
            v53 = *(double ***)(v52 + v51);
            v51 += 8;
            v94 = v53;
            v50 = v50 + v53[7][1];
          }
          while ( v51 != 8 * ((unsigned int)(v49 - 2 - v47) + (__int64)v47 + 2) );
          v95 = v48 + v49 - 1 - v47;
        }
        v54 = (double)v49;
      }
      else
      {
        v54 = 0.0;
        v50 = 0.0;
      }
      v55 = v50 / v54;
      v56 = floops::GlobalObject<floops::GlobalSim>::operator->(v46);
    }
    else
    {
      v61 = floops::GlobalObject<floops::GlobalSim>::operator->(v46);
      v39 = v93;
      if ( !*(_BYTE *)(*(_QWORD *)v61 + 913LL) )
        goto LABEL_49;
      v62 = v95;
      v63 = ++v95;
      if ( v93 )
      {
        v64 = *(_DWORD *)(v93 + 20);
        v65 = 0.0;
        if ( v64 != v63 )
        {
          v66 = 8LL * v63;
          v67 = *(_QWORD *)(v93 + 8);
          do
          {
            v68 = *(double ***)(v67 + v66);
            v66 += 8;
            v94 = v68;
            v65 = v65 + *v68[7];
          }
          while ( 8 * ((unsigned int)(v64 - 2 - v62) + (__int64)v62 + 2) != v66 );
          v95 = v63 + v64 - 1 - v62;
        }
      }
      else
      {
        v65 = 0.0;
        v64 = 0;
      }
      v55 = v65 / (double)v64;
      v56 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
    }
    v39 = v93;
    v40 = (v55 - *(double *)(*(_QWORD *)v56 + 920LL)) * 6.283185307179586;
LABEL_50:
    v94 = 0;
    a6 = (double)v27;
    v41 = 0;
    v95 = 0;
    v42 = 1.0 / (double)v27 * v40 * v82;
    i = v42;
    if ( v39 )
    {
      do
      {
        if ( v41 == *(_DWORD *)(v39 + 20) )
          break;
        v94 = *(double ***)(*(_QWORD *)(v39 + 8) + 8LL * v41);
        v88 = v94;
        sub_129E220((char *)this + 720, &v88);
        v43 = *((_QWORD *)this + 94);
        if ( v43 == *((_QWORD *)this + 95) )
        {
          std::vector<int>::_M_realloc_insert<int const&>((char *)this + 744, v43, &v83);
        }
        else
        {
          v44 = v43 + 4;
          *(_DWORD *)(v44 - 4) = v83;
          *((_QWORD *)this + 94) = v44;
        }
        std::vector<double>::push_back((char *)this + 768, &i);
        v39 = v93;
        v41 = ++v95;
      }
      while ( v93 );
    }
LABEL_55:
    TcadBase::Iter<floops::Node>::~Iter(&v92, v42, v40, a6);
    return;
  }
  if ( v28 == 2 )
  {
    if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                   + 96LL) == 2 )
    {
      (*(void (__fastcall **)(void **, #148 *))(*(_QWORD *)a2 + 192LL))(&v88, a2);
      v29 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
      v30 = floops::_globalPool[0] + 496LL;
      if ( *(_BYTE *)(*(_QWORD *)v29 + 912LL) )
      {
        v31 = v91;
        v32 = ++v91;
        if ( v89 )
        {
          v33 = *(_DWORD *)(v89 + 20);
          v34 = 0.0;
          if ( v33 != v32 )
          {
            v35 = 8LL * v32;
            v36 = *(_QWORD *)(v89 + 8);
            do
            {
              v37 = *(_QWORD *)(v36 + v35);
              v35 += 8;
              v90 = (__int64 (__fastcall **)())v37;
              v34 = v34 + *(double *)(*(_QWORD *)(v37 + 56) + 8LL);
            }
            while ( 8 * ((unsigned int)(v33 - 2 - v31) + (__int64)v31 + 2) != v35 );
            v91 = v32 + v33 - 1 - v31;
          }
          a5 = (double)v33;
        }
        else
        {
          a5 = 0.0;
          v34 = 0.0;
        }
        v38 = (v34 / a5 - *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v30) + 920LL))
            * 6.283185307179586;
      }
      else if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v30) + 913LL) )
      {
        v69 = v91;
        v70 = ++v91;
        if ( v89 )
        {
          v71 = *(_DWORD *)(v89 + 20);
          v72 = 0.0;
          if ( v71 != v70 )
          {
            v73 = 8LL * v70;
            v74 = *(_QWORD *)(v89 + 8);
            do
            {
              v75 = *(_QWORD *)(v74 + v73);
              v73 += 8;
              v90 = (__int64 (__fastcall **)())v75;
              v72 = v72 + **(double **)(v75 + 56);
            }
            while ( 8 * ((unsigned int)(v71 - 2 - v69) + (__int64)v69 + 2) != v73 );
            v91 = v70 + v71 - 1 - v69;
          }
        }
        else
        {
          v72 = 0.0;
          v71 = 0;
        }
        a5 = (double)v71;
        v38 = (v72 / (double)v71
             - *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                         + 920LL))
            * 6.283185307179586;
      }
      else
      {
        v38 = 1.0;
      }
      if ( v27 != 3 )
      {
        if ( v27 == 4 )
        {
          v76 = v89;
          v90 = 0;
          v77 = 0;
          v38 = v38 * 0.25 * v82;
          v91 = 0;
          for ( i = v38; v89; v77 = ++v91 )
          {
            if ( v77 == *(_DWORD *)(v76 + 20) )
              break;
            v90 = *(__int64 (__fastcall ***)())(*(_QWORD *)(v76 + 8) + 8LL * v77);
            v92 = v90;
            sub_129E220((char *)this + 720, &v92);
            std::vector<int>::push_back((char *)this + 744, &v83);
            std::vector<double>::push_back((char *)this + 768, &i);
            v76 = v89;
          }
        }
        goto LABEL_34;
      }
      v59 = *(_QWORD *)a2;
      v38 = v38 * 0.3333333333333333 * v82;
      i = v38;
      (*(void (__fastcall **)(__int64 (__fastcall ***)(), #148 *))(v59 + 256))(&v92, a2);
      while ( 1 )
      {
        v60 = ++v95;
        if ( !v93 || v60 == *(_DWORD *)(v93 + 20) )
          break;
        v94 = *(double ***)(*(_QWORD *)(v93 + 8) + 8LL * v60);
        v87 = *(double *)&v94;
        sub_129E220((char *)this + 720, &v87);
        std::vector<int>::push_back((char *)this + 744, &v83);
        std::vector<double>::push_back((char *)this + 768, &i);
      }
LABEL_78:
      TcadBase::Iter<floops::Node2>::~Iter(&v92);
LABEL_34:
      TcadBase::Iter<floops::Node>::~Iter(&v88, v38, a5, a6);
      return;
    }
    if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                   + 96LL) == 3 )
    {
      v57 = *(void (__fastcall **)(void **, #148 *))(*(_QWORD *)a2 + 192LL);
      if ( v27 == 4 )
      {
        v85 = v26 * -0.05;
        v57(&v88, a2);
        while ( 1 )
        {
          v78 = ++v91;
          if ( !v89 || v78 == *(_DWORD *)(v89 + 20) )
            break;
          v90 = *(__int64 (__fastcall ***)())(*(_QWORD *)(v89 + 8) + 8LL * v78);
          v92 = v90;
          sub_129E220((char *)this + 720, &v92);
          std::vector<int>::push_back((char *)this + 744, &v83);
          std::vector<double>::push_back((char *)this + 768, &v85);
        }
        v79 = *(_QWORD *)a2;
        v38 = v26 * 0.2;
        v86 = v82 * 0.2;
        (*(void (__fastcall **)(__int64 (__fastcall ***)(), #148 *))(v79 + 256))(&v92, a2);
        while ( 1 )
        {
          v80 = ++v95;
          if ( !v93 || v80 == *(_DWORD *)(v93 + 20) )
            break;
          v94 = *(double ***)(*(_QWORD *)(v93 + 8) + 8LL * v80);
          v87 = *(double *)&v94;
          sub_129E220((char *)this + 720, &v87);
          std::vector<int>::push_back((char *)this + 744, &v83);
          std::vector<double>::push_back((char *)this + 768, &v86);
        }
        goto LABEL_78;
      }
      v40 = (double)v27;
      v42 = 1.0 / (double)v27 * v26;
      i = 1.0 / (double)v27 * v82;
      v57((void **)&v92, a2);
      while ( 1 )
      {
        v58 = ++v95;
        if ( !v93 || v58 == *(_DWORD *)(v93 + 20) )
          break;
        v94 = *(double ***)(*(_QWORD *)(v93 + 8) + 8LL * v58);
        v88 = v94;
        sub_129E220((char *)this + 720, &v88);
        std::vector<int>::push_back((char *)this + 744, &v83);
        std::vector<double>::push_back((char *)this + 768, &i);
      }
      goto LABEL_55;
    }
  }
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_gravity(void)
// Address:  0x12A2380
// Size:     1289 bytes
//////////////////////////////////////////////////////////////////////

__int64 __fastcall sinterconnect::siGeneralBoundary::apply_gravity(#2314 *this, double a2, double a3, double a4)
{
  __int64 v4; // rbx
  __int64 v5; // rax
  __int64 *v6; // rdi
  __int64 v7; // r12
  __int64 v8; // rax
  __int64 v9; // r15
  __int64 result; // rax
  __int64 v11; // rbx
  int v12; // r14d
  int v13; // eax
  int v14; // r8d
  int v15; // r9d
  double v16; // xmm0_8
  int v17; // r13d
  int v18; // eax
  __int64 v19; // rax
  #221 *v20; // rcx
  char v21; // r14
  int v22; // eax
  #148 *v23; // rsi
  int v24; // eax
  __int64 v25; // rdx
  int v26; // esi
  double v27; // xmm0_8
  __int64 v28; // r10
  __int64 v29; // rax
  __int64 v30; // rcx
  __int64 v31; // rdx
  __int64 v32; // rbx
  __int64 v33; // r9
  __int64 v34; // rax
  #221 *v35; // [rsp+8h] [rbp-E48h]
  #221 *v36; // [rsp+8h] [rbp-E48h]
  double v38; // [rsp+20h] [rbp-E30h]
  __int64 v39; // [rsp+28h] [rbp-E28h]
  void *v40; // [rsp+50h] [rbp-E00h] BYREF
  __int64 v41; // [rsp+58h] [rbp-DF8h]
  _QWORD v42[2]; // [rsp+60h] [rbp-DF0h] BYREF
  __int64 (__fastcall **v43)(); // [rsp+70h] [rbp-DE0h] BYREF
  __int64 v44; // [rsp+78h] [rbp-DD8h]
  __int64 v45; // [rsp+80h] [rbp-DD0h]
  int v46; // [rsp+88h] [rbp-DC8h]
  int v47; // [rsp+8Ch] [rbp-DC4h]

  v4 = floops::_globalPool[0];
  v5 = *(_QWORD *)(floops::_globalPool[0] + 496LL);
  if ( v5 )
  {
    v6 = *(__int64 **)(v5 + 64);
  }
  else
  {
    v34 = operator new(0x90u);
    *(_OWORD *)(v34 + 16) = 0;
    *(_QWORD *)(v34 + 8) = 0x100000001LL;
    *(_OWORD *)(v34 + 32) = 0;
    *(_OWORD *)(v34 + 48) = 0;
    *(_OWORD *)(v34 + 64) = 0;
    *(_OWORD *)(v34 + 80) = 0;
    *(_OWORD *)(v34 + 96) = 0;
    *(_OWORD *)(v34 + 112) = 0;
    *(_OWORD *)(v34 + 128) = 0;
    v6 = *(__int64 **)(v4 + 504);
    *(_QWORD *)v34 = off_7A75010;
    *(_QWORD *)(v4 + 496) = v34 + 16;
    *(_QWORD *)(v4 + 504) = v34;
    if ( v6 )
    {
      std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v6);
      v6 = *(__int64 **)(*(_QWORD *)(v4 + 496) + 64LL);
    }
    v4 = floops::_globalPool[0];
  }
  v7 = 0;
  v39 = *v6;
  v8 = floops::GlobalObject<floops::GlobalSim>::operator->(v4 + 496);
  v9 = *(_QWORD *)v8;
  result = *(unsigned int *)(*(_QWORD *)v8 + 180LL);
  if ( (_DWORD)result )
  {
    do
    {
      v11 = *(_QWORD *)(*(_QWORD *)(v9 + 168) + 8 * v7);
      if ( *(_DWORD *)(v11 + 540) <= 1u )
      {
        v12 = (int)pdblib::PDB0;
        v13 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 152LL))(v11);
        v16 = pdblib::pdbgetDouble(v39, v13, (unsigned int)"MassDensity", v12, v14, v15);
        v17 = (int)pdblib::PDB0;
        v38 = v16 * 980.665;
        v18 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 152LL))(v11);
        if ( (unsigned int)pdblib::pdbIsAvailable(
                             v39,
                             v18,
                             (unsigned int)"Mechanics",
                             (unsigned int)"Equation",
                             (unsigned int)"MassDensity",
                             v17) )
        {
          floops::MechParams::MechParams((#390 *)&v43);
          strcpy((char *)v42, "MassDensity");
          v40 = v42;
          v41 = 11;
          v19 = floops::MechParams::parseString(&v43, v39, v11, &v40);
          v20 = (#221 *)v19;
          if ( v40 != v42 )
          {
            v35 = (#221 *)v19;
            operator delete(v40, v42[0] + 1LL);
            v20 = v35;
          }
          v36 = (#221 *)floops::MechParams::evalExpr((#390 *)&v43, (#152 *)v11, "MassDensityField", v20);
          v21 = 1;
          floops::MechParams::~MechParams((#390 *)&v43);
        }
        else
        {
          v21 = 0;
          v36 = 0;
        }
        floops::Mesh::elements((#152 *)&v40, v11, -1);
        while ( 1 )
        {
          v22 = ++LODWORD(v42[1]);
          if ( !v41 )
            break;
          if ( v22 == *(_DWORD *)(v41 + 20) )
          {
            v40 = &off_7A75268;
            if ( HIDWORD(v42[1]) )
              (*(void (**)(void))(*(_QWORD *)v41 + 8LL))();
            break;
          }
          v23 = *(#148 **)(*(_QWORD *)(v41 + 8) + 8LL * v22);
          v42[0] = v23;
          if ( v21 )
          {
            (*(void (__fastcall **)(__int64 (__fastcall ***)()))(*(_QWORD *)v23 + 192LL))(&v43);
            if ( !v44 || (v24 = *(_DWORD *)(v44 + 20)) == 0 )
              FLPS_panic("Element has no nodes");
            v25 = v46;
            a3 = (double)v24;
            ++v46;
            v26 = *(_DWORD *)(v44 + 20);
            v27 = 0.0;
            if ( v26 != v46 )
            {
              v28 = *(_QWORD *)(v44 + 8);
              v29 = 8LL * v46;
              v30 = 8 * ((unsigned int)(v26 - v25 - 2) + v25 + 2);
              do
              {
                v31 = *(_QWORD *)(v28 + v29);
                v29 += 8;
                v32 = *(_QWORD *)(v31 + 16);
                v33 = *(int *)(v31 + 32);
                v45 = v31;
                v27 = v27
                    + *(double *)(**(_QWORD **)(*((_QWORD *)v36 + v33 + 12)
                                              + 8LL * *(int *)(*(_QWORD *)(v32 + 152) + 52LL))
                                + 8LL * *(int *)(v31 + 28));
              }
              while ( v30 != v29 );
              v46 = v26;
            }
            v43 = &off_7A757D0;
            v38 = v27 * 980.665 / a3;
            if ( v47 )
              (*(void (**)(void))(*(_QWORD *)v44 + 8LL))();
            v23 = (#148 *)v42[0];
          }
          sinterconnect::siGeneralBoundary::apply_bforce(this, v23, v38, 3, a3, a4);
        }
        result = *(unsigned int *)(v9 + 180);
      }
      ++v7;
    }
    while ( (_DWORD)result != (_DWORD)v7 );
  }
  return result;
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_body_force(void)
// Address:  0x12A2890
// Size:     2023 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::apply_body_force(#2314 *this, double a2, double a3, double a4)
{
  int v4; // r8d
  int v5; // r9d
  __int64 v6; // rcx
  int v7; // r12d
  __int64 v8; // rax
  __int64 v9; // rbx
  const char **v10; // r15
  const char *v11; // r13
  int v12; // r14d
  int v13; // esi
  const char *v14; // r13
  int v15; // r14d
  int v16; // esi
  int v17; // r9d
  __int64 (__fastcall ***v18)(); // rbx
  const char *v19; // rax
  size_t v20; // rax
  _BYTE *v21; // rdx
  #221 *v22; // r14
  double v23; // r13
  int v24; // eax
  #148 *v25; // rsi
  int v26; // eax
  __int64 v27; // rdx
  int v28; // ecx
  double v29; // xmm0_8
  __int64 v30; // r11
  __int64 v31; // rax
  __int64 v32; // r8
  __int64 v33; // rdx
  __int64 v34; // r10
  __int64 v35; // r9
  const char *v36; // r13
  int v37; // r14d
  int v38; // eax
  int v39; // r9d
  void *v40; // rdi
  size_t n; // [rsp+0h] [rbp-F40h]
  __int64 v42; // [rsp+10h] [rbp-F30h]
  __int64 v44; // [rsp+28h] [rbp-F18h]
  const char **v45; // [rsp+30h] [rbp-F10h]
  char src; // [rsp+38h] [rbp-F08h]
  const char *srca; // [rsp+38h] [rbp-F08h]
  __int64 v48; // [rsp+40h] [rbp-F00h]
  int v49; // [rsp+4Ch] [rbp-EF4h]
  _QWORD v50[4]; // [rsp+58h] [rbp-EE8h] BYREF
  int v51; // [rsp+78h] [rbp-EC8h]
  int v52; // [rsp+7Ch] [rbp-EC4h]
  void *v53; // [rsp+80h] [rbp-EC0h] BYREF
  size_t v54; // [rsp+88h] [rbp-EB8h]
  #148 *v55; // [rsp+90h] [rbp-EB0h] BYREF
  int v56; // [rsp+98h] [rbp-EA8h]
  int v57; // [rsp+9Ch] [rbp-EA4h]
  _QWORD v58[2]; // [rsp+A0h] [rbp-EA0h] BYREF
  char v59[16]; // [rsp+B0h] [rbp-E90h] BYREF
  char *v60; // [rsp+C0h] [rbp-E80h]
  __int64 v61; // [rsp+C8h] [rbp-E78h]
  char v62[16]; // [rsp+D0h] [rbp-E70h] BYREF
  char *v63; // [rsp+E0h] [rbp-E60h]
  __int64 v64; // [rsp+E8h] [rbp-E58h]
  char v65[16]; // [rsp+F0h] [rbp-E50h] BYREF
  _QWORD v66[2]; // [rsp+100h] [rbp-E40h] BYREF
  char v67[16]; // [rsp+110h] [rbp-E30h] BYREF
  char *v68; // [rsp+120h] [rbp-E20h]
  __int64 v69; // [rsp+128h] [rbp-E18h]
  char v70[16]; // [rsp+130h] [rbp-E10h] BYREF
  char *v71; // [rsp+140h] [rbp-E00h]
  __int64 v72; // [rsp+148h] [rbp-DF8h]
  char v73[16]; // [rsp+150h] [rbp-DF0h] BYREF
  __int64 (__fastcall **v74)(); // [rsp+160h] [rbp-DE0h] BYREF
  __int64 v75; // [rsp+168h] [rbp-DD8h]
  __int64 v76; // [rsp+170h] [rbp-DD0h]
  int v77; // [rsp+178h] [rbp-DC8h]
  int v78; // [rsp+17Ch] [rbp-DC4h]

  v48 = **(_QWORD **)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  if ( (unsigned int)pdblib::pdbgetBoolean(
                       v48,
                       (unsigned int)"Mechanics",
                       (unsigned int)"Apply.Body.Force",
                       (_DWORD)pdblib::PDB0,
                       v4,
                       v5) )
    sinterconnect::siGeneralBoundary::apply_gravity(this, a2, a3, a4);
  v58[0] = v59;
  strcpy(v59, "Body.Force.X");
  v60 = v62;
  strcpy(v62, "Body.Force.Y");
  strcpy(v65, "Body.Force.Z");
  v63 = v65;
  v66[0] = v67;
  strcpy(v67, "BodyForceXField");
  strcpy(v70, "BodyForceYField");
  strcpy(v73, "BodyForceZField");
  v68 = v70;
  v58[1] = 12;
  v61 = 12;
  v64 = 12;
  v66[1] = 15;
  v69 = 15;
  v71 = v73;
  v72 = 15;
  v6 = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v52 = 0;
  v7 = -1;
  v42 = v6;
  v50[1] = &off_7A758D0;
  v50[2] = v6 + 160;
LABEL_4:
  v8 = 8LL * v7 + 8;
  while ( ++v7 != *(_DWORD *)(v42 + 180) )
  {
    v9 = *(_QWORD *)(*(_QWORD *)(v42 + 168) + v8);
    v8 += 8;
    if ( *(_DWORD *)(v9 + 540) <= 1u )
    {
      v51 = v7;
      v50[3] = v9;
      v10 = (const char **)v58;
      v45 = (const char **)v66;
      v49 = 3;
      while ( 2 )
      {
        v11 = *v10;
        v12 = (int)pdblib::PDB0;
        v13 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 152LL))(v9);
        src = 0;
        v44 = 0;
        if ( !(unsigned int)pdblib::pdbIsAvailable(
                              v48,
                              v13,
                              (unsigned int)"Mechanics",
                              (unsigned int)"Equation",
                              (_DWORD)v11,
                              v12) )
          goto LABEL_9;
        floops::MechParams::MechParams((#390 *)&v74);
        v19 = *v10;
        srca = v19;
        v53 = &v55;
        if ( !v19 )
          std::__throw_logic_error("basic_string: construction from null is not valid");
        v20 = strlen(v19);
        n = v20;
        v50[0] = v20;
        if ( v20 <= 0xF )
        {
          if ( v20 == 1 )
          {
            LOBYTE(v55) = *srca;
            goto LABEL_25;
          }
          if ( v20 )
          {
            v40 = &v55;
LABEL_49:
            memcpy(v40, srca, n);
            v20 = v50[0];
            v21 = v53;
          }
          else
          {
LABEL_25:
            v21 = &v55;
          }
          v54 = v20;
          v21[v20] = 0;
          v22 = (#221 *)floops::MechParams::parseString(&v74, v48, v9, &v53);
          if ( v53 != &v55 )
            operator delete(v53, (unsigned __int64)v55 + 1);
          v44 = floops::MechParams::evalExpr((#390 *)&v74, (#152 *)v9, *v45, v22);
          floops::MechParams::~MechParams((#390 *)&v74);
          src = 1;
LABEL_9:
          v14 = *v10;
          v15 = (int)pdblib::PDB0;
          v16 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 152LL))(v9);
          if ( (unsigned int)pdblib::pdbIsAvailable(v48, v16, (unsigned int)"Mechanics", (_DWORD)v14, v15, v17) )
          {
            v36 = *v10;
            v37 = (int)pdblib::PDB0;
            v38 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 152LL))(v9);
            v23 = pdblib::pdbgetDouble(v48, v38, (unsigned int)"Mechanics", (_DWORD)v36, v37, v39);
LABEL_30:
            floops::Mesh::elements((#152 *)&v53, v9, -1);
            while ( 1 )
            {
              v24 = ++v56;
              if ( !v54 )
                goto LABEL_11;
              if ( v24 == *(_DWORD *)(v54 + 20) )
              {
                v53 = &off_7A75268;
                if ( v57 )
                  (*(void (**)(void))(*(_QWORD *)v54 + 8LL))();
                goto LABEL_11;
              }
              v25 = *(#148 **)(*(_QWORD *)(v54 + 8) + 8LL * v24);
              v55 = v25;
              if ( src )
              {
                (*(void (__fastcall **)(__int64 (__fastcall ***)()))(*(_QWORD *)v25 + 192LL))(&v74);
                if ( !v75 || (v26 = *(_DWORD *)(v75 + 20)) == 0 )
                  FLPS_panic("Element has no nodes");
                v27 = v77;
                a3 = (double)v26;
                ++v77;
                v28 = *(_DWORD *)(v75 + 20);
                v29 = 0.0;
                if ( v28 != v77 )
                {
                  v30 = *(_QWORD *)(v75 + 8);
                  v31 = 8LL * v77;
                  v32 = 8 * ((unsigned int)(v28 - v27 - 2) + v27 + 2);
                  do
                  {
                    v33 = *(_QWORD *)(v30 + v31);
                    v31 += 8;
                    v34 = *(_QWORD *)(v33 + 16);
                    v35 = *(int *)(v33 + 32);
                    v76 = v33;
                    v29 = v29
                        + *(double *)(**(_QWORD **)(*(_QWORD *)(v44 + 8 * v35 + 96)
                                                  + 8LL * *(int *)(*(_QWORD *)(v34 + 152) + 52LL))
                                    + 8LL * *(int *)(v33 + 28));
                  }
                  while ( v31 != v32 );
                  v77 = v28;
                }
                v74 = &off_7A757D0;
                v23 = v29 / a3;
                if ( v78 )
                  (*(void (**)(void))(*(_QWORD *)v75 + 8LL))();
                v25 = v55;
              }
              sinterconnect::siGeneralBoundary::apply_bforce(this, v25, v23, v49, a3, a4);
            }
          }
          if ( src )
          {
            v23 = 0.0;
            goto LABEL_30;
          }
LABEL_11:
          ++v49;
          v10 += 4;
          v45 += 4;
          if ( v49 == 6 )
            goto LABEL_4;
          continue;
        }
        break;
      }
      v53 = (void *)std::string::_M_create(&v53, v50, 0);
      v40 = v53;
      v55 = (#148 *)v50[0];
      goto LABEL_49;
    }
  }
  v18 = &v74;
  do
  {
    v18 -= 4;
    if ( *v18 != (__int64 (__fastcall **)())(v18 + 2) )
      operator delete(*v18, (unsigned __int64)v18[2] + 1);
  }
  while ( v18 != v66 );
  do
  {
    v18 -= 4;
    if ( *v18 != (__int64 (__fastcall **)())(v18 + 2) )
      operator delete(*v18, (unsigned __int64)v18[2] + 1);
  }
  while ( v18 != v58 );
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::countFaceBCs(int,std::vector<floops::Element *,std::allocator<floops::Element *>> &,std::map<int,floops::Element *,std::less<int>,std::allocator<std::pair<int const,floops::Element *>>> &)
// Address:  0x12A30D0
// Size:     2337 bytes
//////////////////////////////////////////////////////////////////////

__int64 __fastcall sinterconnect::siGeneralBoundary::countFaceBCs(
        __int64 a1,
        unsigned int a2,
        __int64 *a3,
        _QWORD *a4,
        double a5,
        double a6,
        double a7)
{
  __int64 v8; // r12
  __int64 v9; // rbx
  unsigned int v10; // ebx
  __int64 v12; // r15
  unsigned __int64 v13; // r12
  __int64 v14; // rdx
  __int64 v15; // rdi
  __int64 v16; // rax
  int v17; // esi
  int v18; // ecx
  __int64 v19; // rdx
  __int64 v20; // rbx
  __int64 v21; // r8
  __int64 v22; // rcx
  int *v23; // r8
  int v24; // r14d
  _QWORD *v25; // rdx
  _QWORD *v26; // r10
  _QWORD *v27; // r9
  _QWORD *v28; // rcx
  __int64 v29; // rdi
  int v30; // r8d
  int v31; // r9d
  __int64 v32; // rdi
  __int64 v33; // rbx
  __int64 v34; // r15
  __int64 v35; // rdi
  __int64 v36; // r15
  __int64 v37; // r12
  __int64 v38; // rdi
  __int64 v39; // rax
  __int64 insert_hint_unique_pos; // rax
  __int64 v41; // rdx
  _BOOL8 v42; // rdi
  double v43; // xmm0_8
  #288 **v44; // rax
  double v45; // xmm5_8
  int v46; // eax
  __int64 v47; // rdi
  double v48; // xmm3_8
  __int64 v49; // rax
  __int64 v50; // rsi
  char v51; // al
  __int64 v52; // rdx
  __int64 *v53; // r9
  __int64 *v54; // r8
  __int64 *v55; // rax
  __int64 v56; // rcx
  __int64 v57; // r10
  unsigned int v58; // eax
  __int64 v59; // r12
  __int64 v60; // r14
  __int64 v61; // r13
  double v62; // xmm2_8
  double v63; // xmm0_8
  double v64; // xmm0_8
  __int64 *v65; // rax
  __int64 v66; // r12
  int v67; // esi
  __int64 *v68; // rax
  int v69; // ecx
  __int64 *v70; // r8
  __int64 v71; // rdx
  __int64 v72; // rdx
  void *v73; // [rsp+8h] [rbp-E8h]
  _QWORD *v74; // [rsp+10h] [rbp-E0h]
  _QWORD *v75; // [rsp+18h] [rbp-D8h]
  double v79; // [rsp+30h] [rbp-C0h]
  double v80; // [rsp+38h] [rbp-B8h]
  __int128 v81; // [rsp+40h] [rbp-B0h] BYREF
  __int64 v82; // [rsp+50h] [rbp-A0h]
  __int128 v83; // [rsp+60h] [rbp-90h] BYREF
  __int64 v84; // [rsp+70h] [rbp-80h]
  __int64 (__fastcall **v85)(); // [rsp+80h] [rbp-70h]
  __int64 v86; // [rsp+88h] [rbp-68h]
  __int64 v87; // [rsp+90h] [rbp-60h]
  int v88; // [rsp+98h] [rbp-58h]
  int v89; // [rsp+9Ch] [rbp-54h]
  __int64 (__fastcall **v90)(); // [rsp+A0h] [rbp-50h] BYREF
  __int64 v91; // [rsp+A8h] [rbp-48h]
  __int64 v92; // [rsp+B0h] [rbp-40h]
  __int64 v93; // [rsp+B8h] [rbp-38h]

  v8 = floops::_globalPool[0];
  v9 = *(_QWORD *)(floops::_globalPool[0] + 400LL);
  if ( v9 )
  {
    if ( !*(_BYTE *)(v9 + 24) )
      goto LABEL_3;
  }
  else
  {
    v33 = operator new(0x1A8u);
    *(_QWORD *)(v33 + 8) = 0x100000001LL;
    v34 = v33 + 16;
    *(_QWORD *)v33 = off_7A776E8;
    FE::BeamProbHandler::BeamProbHandler((#368 *)(v33 + 16));
    v35 = *(_QWORD *)(v8 + 408);
    *(_QWORD *)(v8 + 400) = v33 + 16;
    *(_QWORD *)(v8 + 408) = v33;
    if ( v35 )
    {
      std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v35);
      v34 = *(_QWORD *)(v8 + 400);
    }
    if ( !*(_BYTE *)(v34 + 24) )
      goto LABEL_3;
    v36 = floops::_globalPool[0];
    v9 = *(_QWORD *)(floops::_globalPool[0] + 400LL);
    if ( !v9 )
    {
      v37 = operator new(0x1A8u);
      *(_QWORD *)(v37 + 8) = 0x100000001LL;
      v9 = v37 + 16;
      *(_QWORD *)v37 = off_7A776E8;
      FE::BeamProbHandler::BeamProbHandler((#368 *)(v37 + 16));
      v38 = *(_QWORD *)(v36 + 408);
      *(_QWORD *)(v36 + 400) = v37 + 16;
      *(_QWORD *)(v36 + 408) = v37;
      if ( v38 )
      {
        std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v38);
        v9 = *(_QWORD *)(v36 + 400);
      }
    }
  }
  if ( *(_BYTE *)(v9 + 189) )
    return 0;
LABEL_3:
  if ( a2 <= 1 )
  {
    v12 = *(_QWORD *)(*(_QWORD *)(a1 + 8) + 296LL);
  }
  else if ( a2 - 2 <= 1 )
  {
    v12 = *(_QWORD *)(*(_QWORD *)(a1 + 8) + 304LL);
  }
  else
  {
    if ( a2 != 4 )
      return 0;
    v12 = *(_QWORD *)(*(_QWORD *)(a1 + 8) + 288LL);
  }
  v13 = 0;
  sub_129DE20(a4[2]);
  a4[2] = 0;
  a4[3] = a4 + 1;
  v14 = *a3;
  a4[4] = a4 + 1;
  a4[5] = 0;
  v75 = a4 + 1;
  if ( a3[1] != v14 )
  {
    do
    {
      (*(void (__fastcall **)(__int64 (__fastcall ***)()))(**(_QWORD **)(v14 + 8 * v13) + 296LL))(&v90);
      v15 = v91;
      v16 = (int)v93;
LABEL_11:
      if ( v15 )
      {
        v17 = *(_DWORD *)(v15 + 20);
LABEL_13:
        v18 = v16 + 1;
        v19 = 8 * v16 + 8;
        while ( 1 )
        {
          v16 = v18;
          LODWORD(v93) = v18;
          if ( v18 == v17 )
            break;
          v20 = *(_QWORD *)(*(_QWORD *)(v15 + 8) + v19);
          v19 += 8;
          v21 = *(_QWORD *)(v20 + 16);
          v22 = *(int *)(v20 + 32);
          v92 = v20;
          v23 = (int *)(**(_QWORD **)(*(_QWORD *)(v12 + 8 * v22 + 96) + 8LL * *(int *)(*(_QWORD *)(v21 + 152) + 52LL))
                      + 4LL * *(int *)(v20 + 28));
          v18 = v16 + 1;
          v24 = *v23;
          if ( *v23 > 0 )
          {
            v25 = (_QWORD *)a4[2];
            if ( !v25 )
            {
              v74 = a4 + 1;
              goto LABEL_45;
            }
            v26 = a4 + 1;
            while ( 1 )
            {
              v27 = (_QWORD *)v25[2];
              v28 = (_QWORD *)v25[3];
              if ( *((_DWORD *)v25 + 8) < v24 )
                break;
LABEL_21:
              if ( !v27 )
                goto LABEL_42;
              v26 = v25;
              v25 = v27;
            }
            while ( v28 )
            {
              v25 = v28;
              v27 = (_QWORD *)v28[2];
              v28 = (_QWORD *)v28[3];
              if ( *((_DWORD *)v25 + 8) >= v24 )
                goto LABEL_21;
            }
            v25 = v26;
LABEL_42:
            if ( v75 == v25 || *((_DWORD *)v25 + 8) > v24 )
            {
              v74 = v25;
LABEL_45:
              v39 = operator new(0x30u);
              *(_DWORD *)(v39 + 32) = v24;
              *(_QWORD *)(v39 + 40) = v20;
              v73 = (void *)v39;
              insert_hint_unique_pos = std::_Rb_tree<int,std::pair<int const,floops::Element *>,std::_Select1st<std::pair<int const,floops::Element *>>,std::less<int>,std::allocator<std::pair<int const,floops::Element *>>>::_M_get_insert_hint_unique_pos(
                                         a4,
                                         v74,
                                         v39 + 32);
              if ( v41 )
              {
                v42 = insert_hint_unique_pos || v75 == (_QWORD *)v41 || *(_DWORD *)(v41 + 32) > v24;
                std::_Rb_tree_insert_and_rebalance(v42, v73, v41, v75);
                ++a4[5];
              }
              else
              {
                operator delete(v73, 0x30u);
              }
              v15 = v91;
              v16 = (int)v93;
              goto LABEL_11;
            }
            if ( v25[5] != v20 )
            {
              *v23 = -v24;
              v16 = (int)v93;
              v17 = *(_DWORD *)(v15 + 20);
            }
            goto LABEL_13;
          }
        }
        v90 = &off_7A75268;
        if ( HIDWORD(v93) )
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 8LL))(v15);
      }
      v14 = *a3;
      ++v13;
    }
    while ( v13 < (a3[1] - *a3) >> 3 );
  }
  v29 = **(_QWORD **)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  if ( *(_BYTE *)(a1 + 25) != 1 && a2 == 4 )
  {
    v10 = pdblib::pdbgetBoolean(
            v29,
            (unsigned int)"Mechanics",
            (unsigned int)"Bottom.Automatic.Free",
            (_DWORD)pdblib::PDB0,
            v30,
            v31);
    if ( v10 == 1 )
    {
      v43 = 0.0;
      v82 = 0;
      v81 = 0;
      v83 = 0;
      v84 = 0;
      v44 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
      floops::FieldServer::BoundingBox(*v44, (#1602 *)&v81, (#1602 *)&v83, 1);
      v45 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                      + 728LL);
      v46 = *(_DWORD *)(a1 + 28);
      v79 = v45;
      if ( v46 == 1 )
      {
        v80 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                        + 736LL);
      }
      else
      {
        v47 = floops::_globalPool[0] + 496LL;
        if ( v46 != 2 )
        {
          if ( v46 == 3 )
          {
            v80 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v47) + 744LL);
          }
          else
          {
            v48 = 0.0;
            v80 = 0.0;
            if ( v46 != 4 )
              goto LABEL_60;
            v80 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v47) + 736LL);
          }
          v48 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                          + 752LL);
LABEL_60:
          v49 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
          v50 = *(_QWORD *)v49;
          v51 = *(_BYTE *)(*(_QWORD *)v49 + 128LL);
          if ( (v51 & 1) != 0 )
          {
            v52 = *(unsigned int *)(v50 + 124);
            *(_BYTE *)(v50 + 128) = v51 & 0xFE;
            if ( (_DWORD)v52 )
            {
              v53 = *(__int64 **)(v50 + 112);
              v54 = &v53[v52];
              v55 = v53;
              LODWORD(v52) = 0;
              do
              {
                v56 = *v55;
                if ( *v55 )
                {
                  v57 = (unsigned int)v52;
                  *(_DWORD *)(v56 + 24) = v52;
                  LODWORD(v52) = v52 + 1;
                  v53[v57] = v56;
                }
                ++v55;
              }
              while ( v55 != v54 );
              v58 = v52;
            }
            else
            {
              v58 = 0;
            }
            *(_DWORD *)(v50 + 124) = v52;
          }
          else
          {
            v58 = *(_DWORD *)(v50 + 124);
          }
          v59 = v58;
          v60 = 0;
          v61 = 0;
          v86 = v50 + 104;
          v87 = 0;
          v85 = &off_7A77580;
          v89 = 0;
          while ( 1 )
          {
            v88 = v60;
            if ( v60 == v59 )
              break;
            v61 = *(_QWORD *)(*(_QWORD *)(v50 + 112) + 8 * v60);
            v62 = v80 - *(double *)(v61 + 8);
            v63 = v79 - *(double *)v61;
            v87 = v61;
            a7 = v62 * v62;
            v64 = v63 * v63 + a7 + (v48 - *(double *)(v61 + 16)) * (v48 - *(double *)(v61 + 16));
            if ( v64 < 0.0 )
            {
              ++v60;
              v43 = sqrt(v64);
              a6 = TcadGeom::Location::epsilon;
              if ( TcadGeom::Location::epsilon >= v43 )
                break;
            }
            else
            {
              v43 = sqrt(v64);
              ++v60;
              a6 = TcadGeom::Location::epsilon;
              if ( TcadGeom::Location::epsilon >= v43 )
                break;
            }
          }
          v92 = 0;
          v90 = &off_7A757D0;
          v91 = v61 + 32;
          v65 = *(__int64 **)(v61 + 40);
          v66 = *v65;
          v93 = 0;
          v67 = *(_DWORD *)(v61 + 52);
          if ( !v67 )
            goto LABEL_83;
          v68 = v65 + 1;
          v69 = 0;
          v70 = &v68[v67 - 1];
          v71 = v66;
          if ( *(_DWORD *)(*(_QWORD *)(v66 + 16) + 540LL) == 3 )
            goto LABEL_75;
LABEL_74:
          ++v69;
          v66 = v71;
LABEL_75:
          while ( v70 != v68 )
          {
            v71 = *v68++;
            if ( *(_DWORD *)(*(_QWORD *)(v71 + 16) + 540LL) != 3 )
              goto LABEL_74;
          }
          v92 = v71;
          LODWORD(v93) = v67;
          if ( v69 != 1 )
LABEL_83:
            FLPS_panic("Bottom dirichlet boundary condition cannot be applied", v43, a6, a7, v48, 0.0);
          v72 = *(_QWORD *)(v66 + 16);
          *(_QWORD *)(a1 + 680) = v66;
          if ( *(int *)(**(_QWORD **)(*(_QWORD *)(v12 + 8LL * *(int *)(v66 + 32) + 96)
                                    + 8LL * *(int *)(*(_QWORD *)(v72 + 152) + 52LL))
                      + 4LL * *(int *)(v66 + 28)) > 0 )
          {
            TcadBase::Iter<floops::Node>::~Iter(&v90, v43, a6, a7);
            return v10;
          }
          TcadBase::Iter<floops::Node>::~Iter(&v90, v43, a6, a7);
          goto LABEL_28;
        }
        v80 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v47) + 744LL);
      }
      v48 = *(double *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                      + 760LL);
      goto LABEL_60;
    }
  }
LABEL_28:
  v32 = a4[3];
  if ( v75 == (_QWORD *)v32 )
    return 0;
  v10 = 0;
  do
  {
    v10 += *(_DWORD *)(**(_QWORD **)(*(_QWORD *)(v12 + 8LL * *(int *)(*(_QWORD *)(v32 + 40) + 32LL) + 96)
                                   + 8LL
                                   * *(int *)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)(v32 + 40) + 16LL) + 152LL) + 52LL))
                     + 4LL * *(int *)(*(_QWORD *)(v32 + 40) + 28LL)) < 0x80000000;
    v32 = std::_Rb_tree_increment(v32);
  }
  while ( v75 != (_QWORD *)v32 );
  return v10;
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_stress(std::vector<floops::Element *,std::allocator<floops::Element *>> &,int,double)
// Address:  0x12A3A00
// Size:     5870 bytes
//////////////////////////////////////////////////////////////////////

unsigned __int64 __fastcall sinterconnect::siGeneralBoundary::apply_stress(#1602 *a1, __int64 *a2, int a3, double a4)
{
  __int64 v5; // rcx
  __int64 v6; // rdx
  unsigned __int64 result; // rax
  __int64 v8; // r14
  _DWORD *v9; // rbx
  int v10; // eax
  int v11; // r13d
  _OWORD *v12; // r12
  __int64 v13; // rdx
  char *v14; // rbx
  const __m128i *v15; // roff
  __int64 v16; // r12
  int v17; // r14d
  __int64 v18; // rax
  void *v19; // r13
  int v20; // eax
  char *v21; // r13
  __m128i *v22; // rcx
  _DWORD *v23; // rdx
  __int64 v24; // r12
  int v25; // eax
  _DWORD *v26; // rsi
  double *v27; // rsi
  double v28; // xmm0_8
  void (__fastcall ***v29)(_QWORD); // r13
  void (__fastcall ***v30)(_QWORD); // r12
  void (__fastcall **v31)(_QWORD); // rax
  void (__fastcall ***v32)(_QWORD); // rdi
  __int64 (__fastcall *v33)(void *); // rax
  void *v34; // rdi
  _QWORD *v35; // rdx
  __int64 v36; // r12
  int v37; // eax
  _DWORD *v38; // rsi
  double *v39; // rsi
  double v40; // xmm0_8
  double *v41; // r13
  double *v42; // r14
  __int64 v43; // r12
  _DWORD *v44; // rsi
  double *v45; // rsi
  double v46; // xmm0_8
  double v47; // rax
  double *v48; // rsi
  double *v49; // r12
  void (__fastcall **v50)(double *); // rax
  double *v51; // rdi
  __int64 v52; // rdx
  __int64 v53; // rbx
  _DWORD *v54; // rdx
  int v55; // eax
  double *v56; // r12
  int v57; // eax
  _OWORD *v58; // r13
  unsigned __int64 v59; // rbx
  const __m128i *v60; // roff
  __int64 v61; // rax
  __int64 v62; // rdi
  __int64 v63; // rax
  int v64; // eax
  void *v65; // r13
  __int64 v66; // rax
  double v67; // xmm0_8
  bool v68; // zf
  _DWORD *v69; // rdx
  int v70; // eax
  void *v71; // rbx
  int v72; // eax
  __int64 (__fastcall *v73)(void *); // rax
  void *v74; // rdi
  __m128d *v75; // rax
  double *v76; // r13
  unsigned __int64 v77; // rcx
  __m128d v78; // xmm0
  __m128d *v79; // rdx
  _DWORD *v80; // rdx
  int v81; // eax
  int v82; // ebx
  _DWORD *v83; // rsi
  double *v84; // rsi
  double v85; // xmm0_8
  _DWORD *v86; // rdx
  int v87; // eax
  _DWORD *v88; // rsi
  double *v89; // rsi
  double v90; // xmm0_8
  void *v91; // rbx
  __int64 (__fastcall *v92)(void *); // rax
  void *v93; // rdi
  int v94; // esi
  double *v95; // rax
  double *v96; // rdx
  double *v97; // rcx
  double v98; // xmm0_8
  double v99; // xmm0_8
  double v100; // xmm0_8
  unsigned __int64 i; // r8
  double v102; // xmm1_8
  double v103; // xmm0_8
  double v104; // xmm0_8
  unsigned __int64 j; // r8
  double v106; // xmm1_8
  __int64 v107; // [rsp+18h] [rbp-288h]
  double v108; // [rsp+20h] [rbp-280h]
  double v109; // [rsp+30h] [rbp-270h]
  double v110; // [rsp+30h] [rbp-270h]
  unsigned int v112; // [rsp+40h] [rbp-260h]
  double *v113; // [rsp+48h] [rbp-258h]
  unsigned __int64 v114; // [rsp+48h] [rbp-258h]
  double v115; // [rsp+48h] [rbp-258h]
  unsigned int v116; // [rsp+58h] [rbp-248h]
  __int64 v117; // [rsp+58h] [rbp-248h]
  double v118; // [rsp+58h] [rbp-248h]
  __m128i v121; // [rsp+70h] [rbp-230h] BYREF
  __int64 v122; // [rsp+80h] [rbp-220h]
  double v123; // [rsp+98h] [rbp-208h] BYREF
  void *v124[2]; // [rsp+A0h] [rbp-200h] BYREF
  _BYTE *v125; // [rsp+B0h] [rbp-1F0h]
  void *v126[2]; // [rsp+C0h] [rbp-1E0h] BYREF
  char *v127; // [rsp+D0h] [rbp-1D0h]
  int v128; // [rsp+D8h] [rbp-1C8h]
  int v129; // [rsp+DCh] [rbp-1C4h]
  void *v130; // [rsp+E0h] [rbp-1C0h] BYREF
  void *v131; // [rsp+E8h] [rbp-1B8h]
  _BYTE *v132; // [rsp+F0h] [rbp-1B0h]
  int v133; // [rsp+F8h] [rbp-1A8h]
  int v134; // [rsp+FCh] [rbp-1A4h]
  void *v135[2]; // [rsp+100h] [rbp-1A0h] BYREF
  __int128 v136; // [rsp+110h] [rbp-190h]
  void *v137[2]; // [rsp+120h] [rbp-180h] BYREF
  __int128 v138; // [rsp+130h] [rbp-170h]
  __int128 v139; // [rsp+140h] [rbp-160h]
  __m128d v140; // [rsp+150h] [rbp-150h]
  __int64 v141; // [rsp+160h] [rbp-140h]
  _OWORD v142[15]; // [rsp+1B0h] [rbp-F0h] BYREF

  memset(v142, 0, 192);
  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) == 3 )
  {
    v5 = *a2;
    v6 = 0;
    v116 = 0;
    result = (unsigned __int64)&v121;
    if ( *a2 == a2[1] )
      return result;
    while ( 1 )
    {
      v8 = 8 * v6;
      (*(void (__fastcall **)(void **))(**(_QWORD **)(v5 + 8 * v6) + 192LL))(v135);
      v9 = v135[1];
      v125 = 0;
      v10 = DWORD2(v136) + 1;
      *(_OWORD *)v124 = 0;
      ++DWORD2(v136);
      if ( v135[1] )
      {
        v11 = 0;
        v12 = v142;
        do
        {
          if ( v9[5] == v10 )
            break;
          v13 = *((_QWORD *)v9 + 1);
          v14 = (char *)v124[1];
          *(_QWORD *)&v136 = *(_QWORD *)(v13 + 8LL * v10);
          if ( v124[1] == v125 )
          {
            std::vector<TcadBase::Iter<floops::Node>>::_M_realloc_insert<TcadBase::Iter<floops::Node>&>(
              v124,
              v124[1],
              v135);
          }
          else
          {
            TcadBase::Iter<floops::Node>::Iter(v124[1], v135);
            v124[1] = v14 + 32;
          }
          v9 = v135[1];
          ++v11;
          v12 = (_OWORD *)((char *)v12 + 24);
          v15 = *(const __m128i **)(v136 + 56);
          *(__m128i *)((char *)v12 - 24) = _mm_loadu_si128(v15);
          *((_QWORD *)v12 - 1) = v15[1].m128i_i64[0];
          v10 = ++DWORD2(v136);
        }
        while ( v9 );
        if ( v11 == 3 )
        {
          v67 = floops::GeneralBoundary::DecomposedArea((__int64)a1, (double *)v142, 3);
          v68 = *((_DWORD *)a1 + 204) == 2;
          *(_QWORD *)&v136 = 0;
          v115 = 0.0;
          if ( !v68 )
            v115 = 0.3333333333333333;
          v69 = v135[1];
          DWORD2(v136) = 0;
          if ( v135[1] )
          {
            v70 = 0;
            do
            {
              if ( v69[5] == v70 )
                break;
              *(_QWORD *)&v136 = *(_QWORD *)(*((_QWORD *)v69 + 1) + 8LL * v70);
              v137[0] = (void *)v136;
              sub_129E220((char *)a1 + 720, v137);
              LODWORD(v137[0]) = a3 + 3;
              sub_129E1F0((char *)a1 + 744, v137);
              *(double *)v137 = a4 * v67 * v115;
              sub_12A17A0((char *)a1 + 768, v137);
              v69 = v135[1];
              v70 = ++DWORD2(v136);
            }
            while ( v135[1] );
          }
          (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + v8) + 256LL))(v137);
          while ( 1 )
          {
            v71 = v137[1];
            v72 = ++DWORD2(v138);
            if ( !v137[1] )
            {
              v9 = v124[0];
              v137[0] = &off_7A76A28;
              goto LABEL_30;
            }
            if ( v72 == *((_DWORD *)v137[1] + 5) )
              break;
            *(_QWORD *)&v138 = *(_QWORD *)(*((_QWORD *)v137[1] + 1) + 8LL * v72);
            v130 = *(void **)&v138;
            sub_129E220((char *)a1 + 720, &v130);
            LODWORD(v130) = a3 + 3;
            sub_129E1F0((char *)a1 + 744, &v130);
            *(double *)&v130 = a4 * v67 * 0.3333333333333333;
            sub_12A17A0((char *)a1 + 768, &v130);
          }
          v137[0] = &off_7A76A28;
          if ( HIDWORD(v138) )
          {
            v73 = *(__int64 (__fastcall **)(void *))(*(_QWORD *)v137[1] + 8LL);
            if ( v73 == TcadBase::Bag<floops::Node2>::~Bag )
            {
              v74 = (void *)*((_QWORD *)v137[1] + 1);
              *(_QWORD *)v137[1] = &off_7A76A08;
              if ( v74 )
                operator delete[](v74);
              operator delete(v71, 0x18u);
            }
            else
            {
              v73(v137[1]);
            }
          }
          v9 = v124[0];
LABEL_30:
          v29 = (void (__fastcall ***)(_QWORD))v124[1];
          if ( v124[1] != v9 )
          {
LABEL_31:
            v30 = (void (__fastcall ***)(_QWORD))v9;
            do
            {
              v31 = *v30;
              v32 = v30;
              v30 += 4;
              (*v31)(v32);
            }
            while ( v30 != v29 );
          }
          if ( !v9 )
            goto LABEL_35;
          goto LABEL_34;
        }
        v9 = v124[0];
      }
      if ( *((_DWORD *)a1 + 204) != 2 )
      {
        *(double *)&v130 = COERCE_DOUBLE(off_7A83AE0);
        v131 = (void *)0x200000004LL;
        floops::GeneralBoundary::apply_stress_helper1((#372 *)v137, a1, (#294 *)v142, (#294 *)&v130);
        v23 = v135[1];
        *(_QWORD *)&v136 = 0;
        DWORD2(v136) = 0;
        if ( v135[1] )
        {
          v24 = 0;
          v25 = 0;
          do
          {
            if ( v23[5] == v25 )
              break;
            *(_QWORD *)&v136 = *(_QWORD *)(*((_QWORD *)v23 + 1) + 8LL * v25);
            v126[0] = (void *)v136;
            sub_129E220((char *)a1 + 720, v126);
            v26 = (_DWORD *)*((_QWORD *)a1 + 94);
            LODWORD(v126[0]) = a3 + 3;
            if ( v26 == *((_DWORD **)a1 + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>((char *)a1 + 744, v26, v126);
            }
            else
            {
              *v26 = a3 + 3;
              *((_QWORD *)a1 + 94) = v26 + 1;
            }
            v27 = (double *)*((_QWORD *)a1 + 97);
            v28 = a4 * *(double *)((char *)v137[0] + v24);
            *(double *)v126 = v28;
            if ( v27 == *((double **)a1 + 98) )
            {
              std::vector<double>::_M_realloc_insert<double>((char *)a1 + 768, v27, v126);
            }
            else
            {
              *v27 = v28;
              *((_QWORD *)a1 + 97) = v27 + 1;
            }
            v23 = v135[1];
            v24 += 8;
            v25 = ++DWORD2(v136);
          }
          while ( v135[1] );
        }
        if ( v137[0] )
          operator delete(v137[0], v138 - (unsigned __int64)v137[0]);
        goto LABEL_30;
      }
      v16 = 1;
      v17 = 0;
      v127 = 0;
      *(_OWORD *)v126 = 0;
      do
      {
        v18 = floops::Node::EdgeMatch(*(#149 **)&v9[8 * v16 - 4], *(const #149 **)&v9[8 * (v16 & 3) + 4]);
        if ( !v18 )
          FLPS_panic("Could not find the edge!");
        (*(void (__fastcall **)(void **, __int64))(*(_QWORD *)v18 + 256LL))(v137, v18);
        while ( 1 )
        {
          v19 = v137[1];
          v20 = ++DWORD2(v138);
          if ( !v137[1] )
          {
            v137[0] = &off_7A76A28;
            goto LABEL_45;
          }
          if ( *((_DWORD *)v137[1] + 5) == v20 )
            break;
          v21 = (char *)v126[1];
          *(_QWORD *)&v138 = *(_QWORD *)(*((_QWORD *)v137[1] + 1) + 8LL * v20);
          if ( v126[1] == v127 )
          {
            std::vector<TcadBase::Iter<floops::Node2>>::_M_realloc_insert<TcadBase::Iter<floops::Node2>&>(
              v126,
              v126[1],
              v137);
          }
          else
          {
            TcadBase::Iter<floops::Node2>::Iter(v126[1], v137);
            v126[1] = v21 + 32;
          }
          (*(void (__fastcall **)(__m128i *))(*(_QWORD *)v138 + 400LL))(&v121);
          v22 = (__m128i *)((char *)v142 + 24 * (unsigned int)(v17 + 4));
          ++v17;
          *v22 = _mm_loadu_si128(&v121);
          v22[1].m128i_i64[0] = v122;
        }
        v137[0] = &off_7A76A28;
        if ( HIDWORD(v138) )
        {
          v33 = *(__int64 (__fastcall **)(void *))(*(_QWORD *)v137[1] + 8LL);
          if ( v33 == TcadBase::Bag<floops::Node2>::~Bag )
          {
            v34 = (void *)*((_QWORD *)v137[1] + 1);
            *(_QWORD *)v137[1] = &off_7A76A08;
            if ( v34 )
              operator delete[](v34);
            operator delete(v19, 0x18u);
          }
          else
          {
            v33(v137[1]);
          }
        }
LABEL_45:
        ++v16;
      }
      while ( v16 != 5 );
      v137[0] = off_7A83D48;
      v137[1] = (void *)0x200000008LL;
      floops::GeneralBoundary::apply_stress_helper1((#372 *)&v130, a1, (#294 *)v142, (#294 *)v137);
      v35 = v135[1];
      *(_QWORD *)&v136 = 0;
      DWORD2(v136) = 0;
      if ( v135[1] )
      {
        v36 = 0;
        v37 = 0;
        if ( *((_DWORD *)v135[1] + 5) )
        {
          while ( 1 )
          {
            *(_QWORD *)&v136 = *(_QWORD *)(v35[1] + 8LL * v37);
            v123 = *(double *)&v136;
            sub_129E220((char *)a1 + 720, &v123);
            v38 = (_DWORD *)*((_QWORD *)a1 + 94);
            LODWORD(v123) = a3 + 3;
            if ( v38 == *((_DWORD **)a1 + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>((char *)a1 + 744, v38, &v123);
            }
            else
            {
              *v38 = a3 + 3;
              *((_QWORD *)a1 + 94) = v38 + 1;
            }
            v39 = (double *)*((_QWORD *)a1 + 97);
            v40 = a4 * *((double *)v130 + v36);
            v123 = v40;
            if ( v39 == *((double **)a1 + 98) )
            {
              std::vector<double>::_M_realloc_insert<double>((char *)a1 + 768, v39, &v123);
            }
            else
            {
              *v39 = v40;
              *((_QWORD *)a1 + 97) = v39 + 1;
            }
            v35 = v135[1];
            v37 = ++DWORD2(v136);
            if ( !v135[1] )
              break;
            ++v36;
            if ( *((_DWORD *)v135[1] + 5) == v37 )
              goto LABEL_54;
          }
          LODWORD(v36) = v36 + 1;
        }
      }
      else
      {
        LODWORD(v36) = 0;
      }
LABEL_54:
      v41 = (double *)v126[0];
      v42 = (double *)v126[1];
      v113 = (double *)v126[0];
      if ( v126[0] == v126[1] )
      {
        if ( *(double *)&v130 != 0.0 )
          operator delete(v130, v132 - (_BYTE *)v130);
      }
      else
      {
        v43 = 8LL * (int)v36;
        do
        {
          while ( 1 )
          {
            v47 = v41[2];
            v48 = (double *)*((_QWORD *)a1 + 91);
            v123 = v47;
            if ( v48 == *((double **)a1 + 92) )
            {
              std::vector<floops::Element *>::_M_realloc_insert<floops::Element *>((char *)a1 + 720, v48, &v123);
            }
            else
            {
              *v48 = v47;
              *((_QWORD *)a1 + 91) = v48 + 1;
            }
            v44 = (_DWORD *)*((_QWORD *)a1 + 94);
            LODWORD(v123) = a3 + 3;
            if ( v44 == *((_DWORD **)a1 + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>((char *)a1 + 744, v44, &v123);
            }
            else
            {
              *v44 = a3 + 3;
              *((_QWORD *)a1 + 94) = v44 + 1;
            }
            v45 = (double *)*((_QWORD *)a1 + 97);
            v46 = a4 * *(double *)((char *)v130 + v43);
            v123 = v46;
            if ( v45 == *((double **)a1 + 98) )
              break;
            *v45 = v46;
            v41 += 4;
            v43 += 8;
            *((_QWORD *)a1 + 97) = v45 + 1;
            if ( v41 == v42 )
              goto LABEL_65;
          }
          std::vector<double>::_M_realloc_insert<double>((char *)a1 + 768, v45, &v123);
          v41 += 4;
          v43 += 8;
        }
        while ( v41 != v42 );
LABEL_65:
        if ( *(double *)&v130 != 0.0 )
          operator delete(v130, v132 - (_BYTE *)v130);
        v49 = v113;
        do
        {
          v50 = *(void (__fastcall ***)(double *))v49;
          v51 = v49;
          v49 += 4;
          (*v50)(v51);
        }
        while ( v42 != v49 );
      }
      if ( v113 )
        operator delete(v113, v127 - (char *)v113);
      v29 = (void (__fastcall ***)(_QWORD))v124[1];
      if ( v124[1] != v9 )
        goto LABEL_31;
LABEL_34:
      operator delete(v9, v125 - (_BYTE *)v9);
LABEL_35:
      v135[0] = &off_7A757D0;
      if ( HIDWORD(v136) && v135[1] )
        (*(void (__fastcall **)(void *))(*(_QWORD *)v135[1] + 8LL))(v135[1]);
      v6 = ++v116;
      v5 = *a2;
      result = (a2[1] - *a2) >> 3;
      if ( v116 >= result )
        return result;
    }
  }
  result = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  if ( *(_DWORD *)(result + 96) != 2 )
    return result;
  result = (unsigned __int64)a2;
  v52 = *a2;
  if ( *a2 == a2[1] )
    return result;
  v53 = 0;
  v112 = 0;
  do
  {
    (*(void (__fastcall **)(void **))(**(_QWORD **)(v52 + 8 * v53) + 192LL))(v126);
    (*(void (__fastcall **)(void **))(**(_QWORD **)(*a2 + 8 * v53) + 256LL))(&v130);
    v54 = v126[1];
    if ( !v126[1] )
    {
      if ( !v131 )
      {
        ++v128;
LABEL_170:
        FLPS_panic("Mesh element has no nodes");
      }
      v55 = 0;
LABEL_82:
      v55 += *((_DWORD *)v131 + 5);
      goto LABEL_83;
    }
    v55 = *((_DWORD *)v126[1] + 5);
    if ( v131 )
      goto LABEL_82;
LABEL_83:
    v114 = v55;
    if ( (unsigned __int64)v55 >> 60 )
      std::__throw_length_error("cannot create std::vector larger than max_size()");
    if ( v55 )
    {
      v114 = 8LL * v55;
      v56 = (double *)operator new(v114);
      memset(v56, 0, v114);
      v54 = v126[1];
    }
    else
    {
      v56 = 0;
    }
    v57 = ++v128;
    if ( !v54 )
      goto LABEL_170;
    v117 = 0;
    v58 = v142;
    while ( 1 )
    {
      v59 = (unsigned int)v117;
      if ( v54[5] == v57 )
        break;
      v127 = *(char **)(*((_QWORD *)v54 + 1) + 8LL * v57);
      v60 = (const __m128i *)*((_QWORD *)v127 + 7);
      *v58 = _mm_loadu_si128(v60);
      *((_QWORD *)v58 + 2) = v60[1].m128i_i64[0];
      v61 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
      v62 = floops::_globalPool[0] + 496LL;
      if ( *(_BYTE *)(*(_QWORD *)v61 + 912LL) )
      {
        v109 = *((double *)v58 + 1);
        v63 = floops::GlobalObject<floops::GlobalSim>::operator->(v62);
      }
      else
      {
        if ( !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(v62) + 913LL) )
          goto LABEL_92;
        v109 = *(double *)v58;
        v63 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
      }
      v56[v117] = v109 - *(double *)(*(_QWORD *)v63 + 920LL);
LABEL_92:
      v54 = v126[1];
      v58 = (_OWORD *)((char *)v58 + 24);
      ++v117;
      v57 = ++v128;
      if ( !v126[1] )
      {
        v59 = (unsigned int)(v59 + 1);
        goto LABEL_94;
      }
    }
    if ( !(_DWORD)v117 )
      goto LABEL_170;
LABEL_94:
    if ( (unsigned int)v59 > 2 )
      FLPS_panic("Element has more than 2 nodes!");
    v118 = floops::GeneralBoundary::DecomposedLength((__int64)a1, (double *)v142);
    while ( 2 )
    {
      v64 = ++v133;
      if ( v131 && *((_DWORD *)v131 + 5) != v64 )
      {
        v132 = *(_BYTE **)(*((_QWORD *)v131 + 1) + 8LL * v64);
        if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                      + 912LL) )
        {
          (*(void (__fastcall **)(void **))(*(_QWORD *)v132 + 400LL))(v137);
          v65 = v137[1];
          v66 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
          goto LABEL_100;
        }
        if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                      + 913LL) )
        {
          (*(void (__fastcall **)(void **))(*(_QWORD *)v132 + 400LL))(v137);
          v65 = v137[0];
          v66 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
LABEL_100:
          v56[(unsigned int)v59] = *(double *)&v65 - *(double *)(*(_QWORD *)v66 + 920LL);
        }
        v59 = (unsigned int)(v59 + 1);
        continue;
      }
      break;
    }
    if ( v59 )
    {
      v107 = 8 * v59;
      v75 = (__m128d *)operator new(8 * v59);
      v76 = (double *)v75;
      v77 = ((8 * v59 - 8) >> 3) + 1;
      if ( 8 * v59 == 8 )
        goto LABEL_133;
      v78 = _mm_unpacklo_pd((__m128d)0x3FF0000000000000uLL, (__m128d)0x3FF0000000000000uLL);
      v79 = &v75[v77 >> 1];
      do
        *v75++ = v78;
      while ( v79 != v75 );
      if ( (v77 & 1) != 0 )
      {
        v75 = (__m128d *)&v76[v77 & 0xFFFFFFFFFFFFFFFELL];
LABEL_133:
        v75->m128d_f64[0] = 1.0;
      }
    }
    else
    {
      v107 = 0;
      v76 = 0;
    }
    if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                  + 912LL)
      || *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                  + 913LL) )
    {
      v139 = xmmword_7020A20;
      *(_OWORD *)v135 = xmmword_70209E0;
      v141 = 0x3FE1111111111111LL;
      v136 = xmmword_70209F0;
      *(_OWORD *)v137 = xmmword_7020A00;
      v138 = xmmword_7020A10;
      v140 = _mm_unpacklo_pd((__m128d)0x3FB1111111111111uLL, (__m128d)0x3FB1111111111111uLL);
      if ( !v59 )
      {
LABEL_178:
        v108 = 1.0;
        v110 = 1.0;
        goto LABEL_138;
      }
      v94 = *((_DWORD *)a1 + 204);
      v95 = v76;
      v96 = (double *)v135;
      v97 = (double *)v137;
      while ( 2 )
      {
        *v95 = 0.0;
        if ( v94 == 1 )
        {
          v98 = *v96 * 6.283185307179586 * *v56 + 0.0;
          *v95 = v98;
          if ( v59 != 1 )
          {
            v99 = v98 + v96[1] * 6.283185307179586 * v56[1];
            *v95 = v99;
            if ( v59 != 2 )
            {
              v100 = v99 + v96[2] * 6.283185307179586 * v56[2];
              *v95 = v100;
              if ( v59 != 3 )
              {
                for ( i = 3; i < v59; ++i )
                {
                  v102 = v96[i] * 6.283185307179586 * v56[i];
                  v100 = v100 + v102;
                }
LABEL_184:
                *v95 = v100;
              }
            }
          }
        }
        else if ( v94 == 2 )
        {
          v103 = *v97 * 6.283185307179586 * *v56 + 0.0;
          *v95 = v103;
          if ( v59 != 1 )
          {
            v104 = v103 + v97[1] * 6.283185307179586 * v56[1];
            *v95 = v104;
            if ( v59 != 2 )
            {
              v100 = v104 + v97[2] * 6.283185307179586 * v56[2];
              *v95 = v100;
              if ( v59 != 3 )
              {
                for ( j = 3; j < v59; ++j )
                {
                  v106 = v97[j] * 6.283185307179586 * v56[j];
                  v100 = v100 + v106;
                }
                goto LABEL_184;
              }
            }
          }
        }
        ++v95;
        v96 += 2;
        v97 += 3;
        if ( v95 == &v76[v59] )
          goto LABEL_178;
        continue;
      }
    }
    v108 = 0.6666666666666666;
    if ( *((_DWORD *)a1 + 204) == 2 )
      v110 = 0.1666666666666667;
    else
      v110 = 0.5;
LABEL_138:
    v80 = v126[1];
    v127 = 0;
    v128 = 0;
    if ( v126[1] )
    {
      v81 = 0;
      v82 = 0;
      do
      {
        if ( v80[5] == v81 )
          break;
        v127 = *(char **)(*((_QWORD *)v80 + 1) + 8LL * v81);
        v137[0] = v127;
        sub_129E220((char *)a1 + 720, v137);
        v83 = (_DWORD *)*((_QWORD *)a1 + 94);
        LODWORD(v137[0]) = a3 + 3;
        if ( v83 == *((_DWORD **)a1 + 95) )
        {
          std::vector<int>::_M_realloc_insert<int>((char *)a1 + 744, v83, v137);
        }
        else
        {
          *v83 = a3 + 3;
          *((_QWORD *)a1 + 94) = v83 + 1;
        }
        v84 = (double *)*((_QWORD *)a1 + 97);
        v85 = a4 * v76[v82] * v118 * v110;
        *(double *)v137 = v85;
        if ( v84 == *((double **)a1 + 98) )
        {
          std::vector<double>::_M_realloc_insert<double>((char *)a1 + 768, v84, v137);
        }
        else
        {
          *v84 = v85;
          *((_QWORD *)a1 + 97) = v84 + 1;
        }
        v80 = v126[1];
        ++v82;
        v81 = ++v128;
      }
      while ( v126[1] );
    }
    else
    {
      v82 = 0;
    }
    v86 = v131;
    v132 = 0;
    v133 = 0;
    if ( v131 )
    {
      v87 = 0;
      do
      {
        if ( v86[5] == v87 )
          break;
        v132 = *(_BYTE **)(*((_QWORD *)v86 + 1) + 8LL * v87);
        v137[0] = v132;
        sub_129E220((char *)a1 + 720, v137);
        v88 = (_DWORD *)*((_QWORD *)a1 + 94);
        LODWORD(v137[0]) = a3 + 3;
        if ( v88 == *((_DWORD **)a1 + 95) )
        {
          std::vector<int>::_M_realloc_insert<int>((char *)a1 + 744, v88, v137);
        }
        else
        {
          *v88 = a3 + 3;
          *((_QWORD *)a1 + 94) = v88 + 1;
        }
        v89 = (double *)*((_QWORD *)a1 + 97);
        v90 = a4 * v76[v82] * v118 * v108;
        *(double *)v137 = v90;
        if ( v89 == *((double **)a1 + 98) )
        {
          std::vector<double>::_M_realloc_insert<double>((char *)a1 + 768, v89, v137);
        }
        else
        {
          *v89 = v90;
          *((_QWORD *)a1 + 97) = v89 + 1;
        }
        v86 = v131;
        ++v82;
        v87 = ++v133;
      }
      while ( v131 );
    }
    if ( v76 )
      operator delete(v76, v107);
    if ( v56 )
      operator delete(v56, v114);
    *(double *)&v130 = COERCE_DOUBLE(&off_7A76A28);
    if ( v134 )
    {
      v91 = v131;
      if ( v131 )
      {
        v92 = *(__int64 (__fastcall **)(void *))(*(_QWORD *)v131 + 8LL);
        if ( v92 == TcadBase::Bag<floops::Node2>::~Bag )
        {
          v93 = (void *)*((_QWORD *)v131 + 1);
          *(_QWORD *)v131 = &off_7A76A08;
          if ( v93 )
            operator delete[](v93);
          operator delete(v91, 0x18u);
        }
        else
        {
          v92(v131);
        }
      }
    }
    v126[0] = &off_7A757D0;
    if ( v129 && v126[1] )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v126[1] + 8LL))(v126[1]);
    v53 = ++v112;
    v52 = *a2;
    result = (a2[1] - *a2) >> 3;
  }
  while ( v112 < result );
  return result;
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_point_disp(void)
// Address:  0x12A50F0
// Size:     5752 bytes
//////////////////////////////////////////////////////////////////////

__int64 __fastcall sinterconnect::siGeneralBoundary::apply_point_disp(#2314 *this)
{
  int v2; // r8d
  int v3; // r9d
  __int64 result; // rax
  int v5; // r8d
  int v6; // r9d
  int v7; // r9d
  _QWORD *v8; // r13
  int v9; // r8d
  int v10; // r9d
  const char *v11; // r12
  size_t v12; // rax
  size_t v13; // rbx
  _QWORD *v14; // rax
  __m128i si128; // xmm5
  __int64 v16; // r15
  __int64 v17; // r12
  void *v18; // r13
  char *v19; // rax
  char *v20; // rsi
  unsigned int v21; // r12d
  __int64 v22; // rbx
  char *v23; // rax
  _QWORD *v24; // rsi
  __int64 v25; // rcx
  __m128d *v26; // rbx
  __m128d v27; // xmm0
  double v28; // rcx
  int v29; // r8d
  int v30; // r9d
  __int64 v31; // r15
  int v32; // edx
  __int64 v33; // r13
  int v34; // eax
  unsigned int v35; // r12d
  __int64 i; // rbx
  double *v37; // rsi
  double *v38; // r8
  __int64 v39; // rdi
  __int64 v40; // rcx
  __int64 v41; // rdx
  __int64 v42; // rbx
  __int64 v43; // rcx
  int v44; // eax
  __int64 v45; // r9
  __int64 v46; // r10
  double v47; // xmm0_8
  double v48; // xmm0_8
  char *v49; // rax
  __int64 v50; // rsi
  _QWORD *v51; // rbx
  int v52; // eax
  char *v53; // r13
  unsigned int v54; // r12d
  __int64 v55; // rbx
  double *v56; // rax
  double v57; // xmm0_8
  double v58; // xmm0_8
  double *v59; // rax
  __int64 v60; // r8
  int v61; // r9d
  double v62; // xmm0_8
  __int64 v63; // r15
  double *v64; // rbx
  __int64 v65; // rbx
  _QWORD *v66; // r15
  int v67; // r13d
  int v68; // r12d
  int v69; // r8d
  int v70; // r9d
  __int64 v71; // r12
  __int64 *v72; // rax
  __int64 v73; // rdi
  __int64 v74; // rcx
  double TimeStep; // xmm0_8
  __int64 v76; // rsi
  _QWORD *v77; // rdx
  __int64 v78; // rsi
  _DWORD *v79; // rsi
  __int64 v80; // rsi
  __int64 v81; // rsi
  double v82; // rax
  __int64 v83; // rax
  __int64 (__fastcall *v84)(void *); // rax
  void *v85; // rdi
  _QWORD *v86; // rdi
  __int64 v87; // r12
  __m128i *v88; // rax
  __int64 v89; // xmm0_8
  _QWORD *v90; // r13
  int v91; // ebx
  _OWORD *v92; // rax
  void *v93; // rdi
  int v94; // r9d
  int v95; // r8d
  int v96; // r9d
  _QWORD *v97; // rdi
  __int64 v98; // rbx
  int v99; // eax
  _QWORD *v100; // rsi
  __int64 v101; // rdx
  int v102; // eax
  __int64 *v103; // rdi
  __int64 v104; // rax
  __int64 (*v105)(void); // rax
  int v106; // eax
  __int64 v107; // rsi
  __int64 v108; // rax
  __int64 v109; // rsi
  int v110; // eax
  _BYTE *v111; // rdi
  __int64 (*v112)(void); // rax
  int v113; // eax
  char *v114; // rax
  __int64 v115; // rdx
  __int64 v116; // rcx
  __int64 v117; // rdx
  __int64 v118; // rcx
  double v119; // rdi
  double v120; // rcx
  __int128 *v121; // rax
  __int128 v122; // xmm1
  __int64 v123; // xmm0_8
  __int128 *v124; // rax
  __m128i v125; // xmm7
  __int128 v126; // xmm0
  __int64 v127; // rax
  char v128; // [rsp+0h] [rbp-4A0h]
  double v129; // [rsp+10h] [rbp-490h]
  char *v130; // [rsp+40h] [rbp-460h]
  int v131; // [rsp+40h] [rbp-460h]
  double v132; // [rsp+58h] [rbp-448h]
  double v133; // [rsp+58h] [rbp-448h]
  __int64 v134; // [rsp+58h] [rbp-448h]
  double v135; // [rsp+60h] [rbp-440h]
  __int64 v136; // [rsp+60h] [rbp-440h]
  int v137; // [rsp+7Ch] [rbp-424h]
  double v138; // [rsp+90h] [rbp-410h]
  __int64 v139; // [rsp+98h] [rbp-408h]
  unsigned int v140; // [rsp+A0h] [rbp-400h]
  __int64 v141; // [rsp+A0h] [rbp-400h]
  __int64 v142; // [rsp+A8h] [rbp-3F8h]
  int v143; // [rsp+A8h] [rbp-3F8h]
  char *v144; // [rsp+B0h] [rbp-3F0h]
  unsigned __int64 v145; // [rsp+C0h] [rbp-3E0h]
  double v146; // [rsp+C8h] [rbp-3D8h] BYREF
  __m128i *v147; // [rsp+D0h] [rbp-3D0h]
  __int64 v148; // [rsp+D8h] [rbp-3C8h]
  int v149; // [rsp+ECh] [rbp-3B4h] BYREF
  double v150; // [rsp+F0h] [rbp-3B0h] BYREF
  double v151; // [rsp+F8h] [rbp-3A8h] BYREF
  __m128i v152; // [rsp+100h] [rbp-3A0h] BYREF
  _QWORD *v153; // [rsp+110h] [rbp-390h]
  void *v154[2]; // [rsp+120h] [rbp-380h] BYREF
  char *v155; // [rsp+130h] [rbp-370h]
  void *v156[2]; // [rsp+140h] [rbp-360h] BYREF
  __int64 v157; // [rsp+150h] [rbp-350h]
  void *v158[2]; // [rsp+160h] [rbp-340h] BYREF
  __int64 v159; // [rsp+170h] [rbp-330h]
  void *v160[2]; // [rsp+180h] [rbp-320h] BYREF
  void *v161; // [rsp+190h] [rbp-310h]
  __m128i v162; // [rsp+1A0h] [rbp-300h] BYREF
  __int64 v163; // [rsp+1B0h] [rbp-2F0h]
  __int64 (__fastcall **v164)(); // [rsp+1C0h] [rbp-2E0h] BYREF
  void *v165; // [rsp+1C8h] [rbp-2D8h]
  __int64 v166; // [rsp+1D0h] [rbp-2D0h]
  char v167[8]; // [rsp+1E0h] [rbp-2C0h] BYREF
  __int64 v168; // [rsp+1E8h] [rbp-2B8h]
  int v169; // [rsp+1F0h] [rbp-2B0h]
  _QWORD v170[2]; // [rsp+200h] [rbp-2A0h] BYREF
  _QWORD v171[2]; // [rsp+210h] [rbp-290h] BYREF
  _QWORD v172[2]; // [rsp+220h] [rbp-280h] BYREF
  __int64 v173; // [rsp+230h] [rbp-270h]
  __int64 v174; // [rsp+238h] [rbp-268h]
  __m128 v175; // [rsp+240h] [rbp-260h] BYREF
  _QWORD *v176; // [rsp+250h] [rbp-250h]
  __int64 v177; // [rsp+258h] [rbp-248h]
  __int128 v178; // [rsp+260h] [rbp-240h] BYREF
  double v179[2]; // [rsp+270h] [rbp-230h] BYREF
  __m128i v180; // [rsp+280h] [rbp-220h] BYREF
  double v181; // [rsp+290h] [rbp-210h]
  _QWORD v182[2]; // [rsp+298h] [rbp-208h] BYREF
  __int64 v183; // [rsp+2A8h] [rbp-1F8h]
  _BYTE v184[24]; // [rsp+2B0h] [rbp-1F0h] BYREF
  __int64 v185; // [rsp+2C8h] [rbp-1D8h] BYREF
  __int128 v186; // [rsp+2D0h] [rbp-1D0h] BYREF
  __int64 v187; // [rsp+2E0h] [rbp-1C0h]
  _QWORD v188[2]; // [rsp+2F0h] [rbp-1B0h] BYREF
  char *v189; // [rsp+300h] [rbp-1A0h]
  char v190[16]; // [rsp+338h] [rbp-168h] BYREF
  char v191[32]; // [rsp+348h] [rbp-158h] BYREF
  char *v192; // [rsp+368h] [rbp-138h] BYREF

  v148 = floops::_globalPool[0];
  v148 = **(_QWORD **)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  result = pdblib::pdbIsAvailable(
             v148,
             (unsigned int)"Mechanics",
             (unsigned int)"PointDispList",
             (_DWORD)pdblib::PDB0,
             v2,
             v3);
  if ( !(_DWORD)result )
    return result;
  if ( !(unsigned int)pdblib::pdbIsAvailable(
                        v148,
                        (unsigned int)"Mechanics",
                        (unsigned int)"Point.DispRate.Distribute",
                        (_DWORD)pdblib::PDB0,
                        v5,
                        v6) )
    pdblib::pdbsetBoolean(
      v148,
      1,
      (unsigned int)"Mechanics",
      (unsigned int)"Point.DispRate.Distribute",
      (_DWORD)pdblib::PDB0,
      v7);
  v8 = v171;
  v147 = (__m128i *)floops::_globalPool[0];
  v137 = *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                   + 96LL);
  v170[0] = v171;
  v11 = (const char *)pdblib::pdbgetString(
                        v148,
                        (unsigned int)"Mechanics",
                        (unsigned int)"PointDispList",
                        (_DWORD)pdblib::PDB0,
                        v9,
                        v10);
  if ( !v11 )
    std::__throw_logic_error("basic_string: construction from null is not valid");
  v12 = strlen(v11);
  v188[0] = v12;
  v13 = v12;
  if ( v12 > 0xF )
  {
    v170[0] = std::string::_M_create(v170, v188, 0);
    v86 = (_QWORD *)v170[0];
    v171[0] = v188[0];
    goto LABEL_93;
  }
  if ( v12 != 1 )
  {
    if ( !v12 )
      goto LABEL_8;
    v86 = v171;
LABEL_93:
    memcpy(v86, v11, v13);
    v12 = v188[0];
    v8 = (_QWORD *)v170[0];
    goto LABEL_8;
  }
  LOBYTE(v171[0]) = *v11;
LABEL_8:
  v170[1] = v12;
  *((_BYTE *)v8 + v12) = 0;
  v152 = 0;
  v153 = 0;
  std::istringstream::basic_istringstream(v188, v170, 8);
  *(_QWORD *)v184 = 0;
  *(_QWORD *)&v184[8] = &v185;
  *(_QWORD *)&v184[16] = 0;
  LOBYTE(v185) = 0;
  BYTE8(v186) = 0;
  v181 = 0.0;
  LOBYTE(v182[0]) = 0;
  LOBYTE(v183) = 1;
  v180 = _mm_unpacklo_epi64((__m128i)(unsigned __int64)v188, (__m128i)(unsigned __int64)v182);
  v14 = (_QWORD *)std::operator>><char>(v188, &v180.m128i_u64[1]);
  if ( (*((_BYTE *)v14 + *(_QWORD *)(*v14 - 24LL) + 32) & 5) != 0 )
  {
    v180.m128i_i64[0] = 0;
    LOBYTE(v183) = 0;
  }
  v147 = &v180;
  std::vector<std::string>::vector<std::istream_iterator<std::string,char,std::char_traits<char>,long>,void>(
    &v175,
    &v180,
    v184,
    v172);
  si128 = _mm_load_si128((const __m128i *)&v175);
  v179[0] = 0.0;
  v16 = v175.m128_u64[0];
  v178 = 0;
  v17 = v175.m128_i64[1];
  v153 = v176;
  v175 = 0;
  v152 = si128;
  v139 = v16;
  v176 = 0;
  sub_11F2910(&v178);
  sub_11F2910(&v175);
  std::string::_M_dispose(&v180.m128i_u64[1]);
  std::string::_M_dispose(&v184[8]);
  v155 = 0;
  v157 = 0;
  *(_OWORD *)v154 = 0;
  v159 = 0;
  v161 = 0;
  v145 = (v17 - v16) >> 5;
  *(_OWORD *)v156 = 0;
  *(_OWORD *)v158 = 0;
  *(_OWORD *)v160 = 0;
  if ( v16 == v17 )
  {
    v144 = 0;
  }
  else
  {
    v18 = 0;
    v19 = 0;
    v20 = 0;
    v21 = 0;
    v22 = 0;
    while ( 1 )
    {
      if ( v20 == v19 )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v154, v20, &unk_7036278);
      }
      else
      {
        v24 = v20 + 8;
        *(v24 - 1) = 0x47D2CED32A16A1B1LL;
        v154[1] = v24;
      }
      *(_QWORD *)v184 = 0;
      sub_129E220(v156, v184);
      *(_QWORD *)v184 = 0;
      sub_129E220(v158, v184);
      v25 = *(_QWORD *)(v16 + 32 * v22);
      memset(v184, 0, sizeof(v184));
      v26 = (__m128d *)pdblib::pdbgetDoubleArray(
                         v148,
                         (_DWORD)v147,
                         (unsigned int)"Mechanics",
                         v25,
                         (unsigned int)"Coordinate",
                         (_DWORD)pdblib::PDB0,
                         v128);
      if ( v180.m128i_i32[0] != 6 )
        FLPS_warning("Inconsistent point displacement boundary condition data");
      v27 = *v26;
      v27.m128d_f64[1] = v26[1].m128d_f64[0];
      *(__m128d *)v184 = _mm_mul_pd(
                           v27,
                           _mm_unpacklo_pd((__m128d)0x3F1A36E2EB1C432DuLL, (__m128d)0x3F1A36E2EB1C432DuLL));
      *(double *)&v184[16] = 0.0001 * v26[2].m128d_f64[0];
      if ( v160[1] == v18 )
      {
        std::vector<TcadGeom::Location>::_M_realloc_insert<TcadGeom::Location const&>(v160, v18, v184);
      }
      else
      {
        v23 = (char *)v160[1] + 24;
        *(__m128i *)v160[1] = _mm_load_si128((const __m128i *)v184);
        *((_QWORD *)v23 - 1) = *(_QWORD *)&v184[16];
        v160[1] = v23;
      }
      operator delete[](v26);
      v22 = ++v21;
      if ( v21 >= v145 )
        break;
      v20 = (char *)v154[1];
      v19 = v155;
      v18 = v161;
    }
    v144 = (char *)v154[0];
  }
  v146 = *(double *)floops::_globalPool;
  v28 = *(double *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v31 = 0;
  v173 = 0;
  v174 = 0;
  v32 = *(_DWORD *)(*(_QWORD *)&v28 + 180LL);
  v146 = v28;
  v172[0] = &off_7A758D0;
  v172[1] = *(_QWORD *)&v28 + 160LL;
  if ( v32 )
  {
    do
    {
      v33 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)&v146 + 168LL) + 8 * v31);
      v34 = *(_DWORD *)(v33 + 540);
      v173 = v33;
      if ( v34 != 5 && v34 != 2 )
      {
        v35 = 0;
        for ( i = 0; v35 < v145; i = v35 )
        {
          v37 = (double *)v33;
          floops::Mesh::nodes((#152 *)v184, v33, -1);
          v39 = *(_QWORD *)&v184[8];
          v40 = 3 * i;
          v41 = (int)v185;
          v42 = 8 * i;
          v43 = 8 * v40;
          if ( *(_QWORD *)&v184[8] )
          {
LABEL_28:
            v44 = v41 + 1;
            v45 = 8 * v41 + 8;
            while ( 1 )
            {
              LODWORD(v185) = v44;
              v41 = v44;
              if ( v44 == *(_DWORD *)(v39 + 20) )
                break;
              v46 = *(_QWORD *)(*(_QWORD *)(v39 + 8) + v45);
              v38 = *(double **)(v46 + 56);
              *(_QWORD *)&v184[16] = v46;
              v47 = (v38[1] - *(double *)((char *)v160[0] + v43 + 8))
                  * (v38[1] - *(double *)((char *)v160[0] + v43 + 8))
                  + (*v38 - *(double *)((char *)v160[0] + v43)) * (*v38 - *(double *)((char *)v160[0] + v43))
                  + (v38[2] - *(double *)((char *)v160[0] + v43 + 16))
                  * (v38[2] - *(double *)((char *)v160[0] + v43 + 16));
              if ( v47 < 0.0 )
              {
                v131 = v44;
                v134 = v46;
                v136 = v43;
                v141 = v45;
                v143 = v44;
                v48 = sqrt(v47);
                v43 = v136;
                v37 = (double *)&v144[v42];
                v45 = v141 + 8;
                v46 = v134;
                v41 = v131;
                v44 = v143 + 1;
                if ( *(double *)&v144[v42] > v48 )
                {
LABEL_32:
                  v49 = (char *)v156[0];
                  *v37 = v48;
                  *(_QWORD *)&v49[v42] = v46;
                  *(_QWORD *)((char *)v158[0] + v42) = v46;
                  goto LABEL_28;
                }
              }
              else
              {
                v48 = sqrt(v47);
                ++v44;
                v45 += 8;
                v37 = (double *)&v144[v42];
                if ( *(double *)&v144[v42] > v48 )
                  goto LABEL_32;
              }
            }
            *(_QWORD *)v184 = &off_7A757D0;
            if ( HIDWORD(v185) )
              (*(void (__fastcall **)(__int64, double *, _QWORD, _QWORD, double *, __int64))(*(_QWORD *)v39 + 8LL))(
                v39,
                v37,
                v44,
                HIDWORD(v185),
                v38,
                v45);
          }
          else
          {
            LODWORD(v185) = v185 + 1;
            *(_QWORD *)v184 = &off_7A757D0;
          }
          ++v35;
        }
        v50 = v33;
        floops::Mesh::nodes2((#152 *)v184);
        v51 = *(_QWORD **)&v184[8];
        v52 = v185 + 1;
        LODWORD(v185) = v185 + 1;
        if ( *(_QWORD *)&v184[8] )
        {
          while ( *((_DWORD *)v51 + 5) != v52 )
          {
            v50 = *(_QWORD *)(v51[1] + 8LL * v52);
            *(_QWORD *)&v184[16] = v50;
            if ( v145 )
            {
              v53 = (char *)v160[0];
              v54 = 0;
              v55 = 0;
              while ( 1 )
              {
                (*(void (__fastcall **)(__m128i *))(*(_QWORD *)v50 + 400LL))(v147);
                v56 = (double *)&v53[24 * v55];
                v57 = (*(double *)v180.m128i_i64 - *v56) * (*(double *)v180.m128i_i64 - *v56)
                    + (*(double *)&v180.m128i_i64[1] - v56[1]) * (*(double *)&v180.m128i_i64[1] - v56[1])
                    + (v181 - v56[2]) * (v181 - v56[2]);
                if ( v57 < 0.0 )
                  v58 = sqrt(v57);
                else
                  v58 = sqrt(v57);
                v59 = (double *)&v144[8 * v55];
                if ( *v59 > v58 )
                {
                  *v59 = v58;
                  *((_QWORD *)v156[0] + v55) = *(_QWORD *)&v184[16];
                }
                v55 = ++v54;
                if ( v54 >= v145 )
                  break;
                v50 = *(_QWORD *)&v184[16];
              }
              v51 = *(_QWORD **)&v184[8];
              v52 = v185 + 1;
              LODWORD(v185) = v185 + 1;
              if ( !*(_QWORD *)&v184[8] )
                goto LABEL_47;
            }
            else
            {
              LODWORD(v185) = ++v52;
            }
          }
          *(_QWORD *)v184 = &off_7A76A28;
          if ( HIDWORD(v185) )
          {
            v84 = *(__int64 (__fastcall **)(void *))(*v51 + 8LL);
            if ( v84 == TcadBase::Bag<floops::Node2>::~Bag )
            {
              v85 = (void *)v51[1];
              *v51 = &off_7A76A08;
              if ( v85 )
                operator delete[](v85);
              operator delete(v51, 0x18u);
            }
            else
            {
              ((void (__fastcall *)(_QWORD *, __int64))v84)(v51, v50);
            }
          }
        }
        else
        {
LABEL_47:
          *(_QWORD *)v184 = &off_7A76A28;
        }
        v32 = *(_DWORD *)(*(_QWORD *)&v146 + 180LL);
      }
      LODWORD(v174) = ++v31;
    }
    while ( v32 != (_DWORD)v31 );
  }
  v62 = pdblib::pdbgetDouble(
          v148,
          (unsigned int)"Mechanics",
          (unsigned int)"Point.Snap.Dist",
          (_DWORD)pdblib::PDB0,
          v29,
          v30);
  v63 = 0;
  v180 = (__m128i)0x786470uLL;
  *(_QWORD *)&v181 = 7955568;
  v182[0] = 0;
  v182[1] = 8021104;
  v183 = 0;
  v140 = 0;
  v138 = v62;
  if ( v145 )
  {
    while ( 1 )
    {
      v142 = 8 * v63;
      v64 = (double *)&v144[8 * v63];
      if ( *v64 <= v138 )
        goto LABEL_52;
      if ( !(unsigned int)pdblib::pdbgetBoolean(
                            v148,
                            (unsigned int)"Mechanics",
                            (unsigned int)"Point.DispRate.Distribute",
                            (_DWORD)pdblib::PDB0,
                            v60,
                            v61) )
        break;
      FLPS_warning(
        "Snapped node is not within the tolerance; distributing displacement rate to nodes of the element containing the point");
      v87 = 0;
      v149 = 0;
      v88 = (__m128i *)((char *)v160[0] + 24 * v63);
      v89 = v88[1].m128i_i64[0];
      v162 = *v88;
      v90 = (_QWORD *)(v139 + 32 * v63);
      v163 = v89;
      v146 = COERCE_DOUBLE(&v164);
      do
      {
        v91 = (_DWORD)v147 + 16 * v87;
        if ( (unsigned int)pdblib::pdbIsAvailable(v148, (unsigned int)"Mechanics", *v90, v91, (_DWORD)pdblib::PDB0, v61) )
        {
          v165 = 0;
          v164 = &off_7A75810;
          v92 = (_OWORD *)operator new[](0x10u);
          v93 = v165;
          v165 = v92;
          *v92 = 0;
          if ( v93 )
            operator delete[](v93);
          v166 = 2;
          v164 = &off_7A75890;
          (*(void (__fastcall **)(_QWORD, double))(**((_QWORD **)v158[0] + v63) + 368LL))(
            *((_QWORD *)v158[0] + v63),
            COERCE_DOUBLE(*(_QWORD *)&v146));
          v132 = pdblib::pdbgetDouble(v148, (unsigned int)"Mechanics", *v90, v91, (_DWORD)pdblib::PDB0, v94);
          v150 = v132;
          if ( *(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                        + 928LL)
            || (unsigned int)pdblib::pdbgetBoolean(
                               v148,
                               (unsigned int)"Mechanics",
                               (unsigned int)"Solution.Type.Displacement",
                               (_DWORD)pdblib::PDB0,
                               v95,
                               v96) )
          {
            v150 = floops::GeneralBoundary::getTimeStep(this, (__int64)"Mechanics") * v132;
          }
          v97 = v165;
          v98 = 0;
          v177 = 0;
          v99 = HIDWORD(v166);
          v175 = _mm_loadh_ps(&v146);
          if ( HIDWORD(v166) )
          {
            do
            {
              v100 = (_QWORD *)v97[v98];
              v101 = v100[2];
              v176 = v100;
              if ( *(_DWORD *)(v101 + 540) <= 1u )
              {
                if ( v137 == 2 )
                {
                  (*(void (__fastcall **)(char *))(*v100 + 200LL))(v167);
                  while ( 1 )
                  {
                    v110 = ++v169;
                    if ( !v168 || *(_DWORD *)(v168 + 20) == v110 )
                      break;
                    v111 = *(_BYTE **)(*(_QWORD *)(v168 + 8) + 8LL * v110);
                    v112 = *(__int64 (**)(void))(*(_QWORD *)v111 + 96LL);
                    if ( (char *)v112 == (char *)floops::Edge::IsSkeletal )
                      v113 = (v111[36] & 2) != 0;
                    else
                      v113 = v112();
                    if ( v113 )
                    {
                      v114 = (char *)operator new(0x30u);
                      v115 = v168;
                      v130 = v114;
                      *(_OWORD *)v114 = 0;
                      v116 = *(_QWORD *)(v115 + 8);
                      *((_OWORD *)v114 + 1) = 0;
                      v117 = *(_QWORD *)(v115 + 24);
                      *((_OWORD *)v114 + 2) = 0;
                      v118 = *(_QWORD *)(v116 + 8LL * v169);
                      v119 = *(double *)(v118 + 56);
                      v120 = *(double *)(v118 + 64);
                      v133 = v119;
                      v135 = v120;
                      if ( !*(_BYTE *)(v117 + v169) )
                      {
                        v133 = v120;
                        v135 = v119;
                      }
                      v121 = *(__int128 **)(*(_QWORD *)&v135 + 56LL);
                      v122 = *v121;
                      v123 = *((_QWORD *)v121 + 2);
                      v124 = *(__int128 **)(*(_QWORD *)&v133 + 56LL);
                      *(_OWORD *)v130 = v122;
                      v125 = _mm_loadu_si128((const __m128i *)v130);
                      *((_QWORD *)v130 + 2) = v123;
                      v126 = *v124;
                      *((_QWORD *)v130 + 5) = *((_QWORD *)v124 + 2);
                      *(_OWORD *)(v130 + 24) = v126;
                      *(_QWORD *)v184 = off_7A775A0;
                      v185 = *((_QWORD *)v130 + 2);
                      v127 = *((_QWORD *)v130 + 5);
                      *(__m128i *)&v184[8] = v125;
                      v187 = v127;
                      v186 = v126;
                      if ( (unsigned __int8)mgoals::Segment<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>>::contained(
                                              v184,
                                              &v162) )
                      {
                        mgoals::GeometryPolicy::getWeights<double>(&v162, &v184[8], &v186, &v178, v179);
                        v151 = v135;
                        sub_129E220((char *)this + 720, &v151);
                        std::vector<int>::push_back((char *)this + 744, &v149);
                        v129 = v150;
                        v151 = *(double *)&v178 / *((double *)&v178 + 1) * v150;
                        sub_12A17A0((char *)this + 768, &v151);
                        v151 = v133;
                        sub_129E220((char *)this + 720, &v151);
                        std::vector<int>::push_back((char *)this + 744, &v149);
                        v151 = v179[0] / v179[1] * v129;
                        sub_12A17A0((char *)this + 768, &v151);
                      }
                      operator delete(v130, 0x30u);
                    }
                  }
                  floops::OEdgeIter::~OEdgeIter((#278 *)v167);
                  v99 = HIDWORD(v166);
                  v97 = v165;
                }
                else if ( v137 == 3 )
                {
                  (*(void (__fastcall **)(_BYTE *))(*v100 + 208LL))(v184);
                  while ( 1 )
                  {
                    v102 = v185 + 1;
                    LODWORD(v185) = v185 + 1;
                    if ( !*(_QWORD *)&v184[8] )
                    {
                      *(_QWORD *)v184 = &off_7A76318;
                      goto LABEL_135;
                    }
                    if ( v102 == *(_DWORD *)(*(_QWORD *)&v184[8] + 20LL) )
                      break;
                    v103 = *(__int64 **)(*(_QWORD *)(*(_QWORD *)&v184[8] + 8LL) + 8LL * v102);
                    v104 = *v103;
                    *(_QWORD *)&v184[16] = v103;
                    v105 = *(__int64 (**)(void))(v104 + 96);
                    if ( (char *)v105 == (char *)floops::Face::IsSkeletal )
                      v106 = (*((_BYTE *)v103 + 36) & 2) != 0;
                    else
                      v106 = v105();
                    if ( v106 )
                    {
                      *(_QWORD *)&v178 = *(_QWORD *)&v184[16];
                      sub_129E220((char *)this + 856, &v178);
                      v107 = *((_QWORD *)this + 111);
                      if ( v107 == *((_QWORD *)this + 112) )
                      {
                        std::vector<TcadGeom::Point<double>>::_M_realloc_insert<TcadGeom::Point<double> const&>(
                          (char *)this + 880,
                          v107,
                          &v162);
                      }
                      else
                      {
                        v108 = v163;
                        v109 = v107 + 24;
                        *(__m128i *)(v109 - 24) = _mm_load_si128(&v162);
                        *(_QWORD *)(v109 - 8) = v108;
                        *((_QWORD *)this + 111) = v109;
                      }
                      std::vector<int>::push_back((char *)this + 928, &v149);
                      std::vector<double>::push_back((char *)this + 904, &v150);
                    }
                  }
                  *(_QWORD *)v184 = &off_7A76318;
                  if ( HIDWORD(v185) )
                    (*(void (**)(void))(**(_QWORD **)&v184[8] + 8LL))();
LABEL_135:
                  v99 = HIDWORD(v166);
                  v97 = v165;
                }
              }
              LODWORD(v177) = ++v98;
            }
            while ( v99 != (_DWORD)v98 );
          }
          v164 = &off_7A75810;
          if ( v97 )
            operator delete[](v97);
        }
        v149 = ++v87;
      }
      while ( v87 != 3 );
LABEL_66:
      v63 = ++v140;
      if ( v140 >= v145 )
        goto LABEL_67;
    }
    if ( *v64 > v138 )
      FLPS_warning("Snapped node is not within the tolerance; Use the nearest node");
LABEL_52:
    LODWORD(v178) = 0;
    v65 = 0;
    v66 = (_QWORD *)(v152.m128i_i64[0] + 32 * v63);
    while ( 1 )
    {
      v67 = v65;
      v68 = (_DWORD)v147 + 16 * v65;
      if ( (unsigned int)pdblib::pdbIsAvailable(v148, (unsigned int)"Mechanics", *v66, v68, (_DWORD)pdblib::PDB0, v61) )
        break;
LABEL_53:
      ++v65;
      LODWORD(v178) = v67 + 1;
      if ( v65 == 3 )
        goto LABEL_66;
    }
    v146 = pdblib::pdbgetDouble(v148, (unsigned int)"Mechanics", *v66, v68, (_DWORD)pdblib::PDB0, v61);
    *(double *)v184 = v146;
    v71 = floops::_globalPool[0];
    v72 = *(__int64 **)(floops::_globalPool[0] + 496LL);
    if ( !v72 )
    {
      v83 = operator new(0x90u);
      *(_OWORD *)(v83 + 16) = 0;
      *(_OWORD *)(v83 + 32) = 0;
      *(_OWORD *)(v83 + 48) = 0;
      *(_OWORD *)(v83 + 64) = 0;
      *(_OWORD *)(v83 + 80) = 0;
      *(_OWORD *)(v83 + 96) = 0;
      *(_OWORD *)(v83 + 112) = 0;
      *(_OWORD *)(v83 + 128) = 0;
      v73 = *(_QWORD *)(v71 + 504);
      *(_QWORD *)v83 = off_7A75010;
      *(_QWORD *)(v83 + 8) = 0x100000001LL;
      *(_QWORD *)(v71 + 496) = v83 + 16;
      *(_QWORD *)(v71 + 504) = v83;
      if ( !v73 )
      {
LABEL_57:
        if ( *(_BYTE *)(v73 + 928)
          || (unsigned int)pdblib::pdbgetBoolean(
                             v148,
                             (unsigned int)"Mechanics",
                             (unsigned int)"Solution.Type.Displacement",
                             (_DWORD)pdblib::PDB0,
                             v69,
                             v70) )
        {
          TimeStep = floops::GeneralBoundary::getTimeStep(this, (__int64)"Mechanics");
          v146 = TimeStep * v146;
          *(double *)v184 = v146;
        }
        v76 = *((_QWORD *)this + 91);
        v77 = (char *)v156[0] + v142;
        if ( v76 == *((_QWORD *)this + 92) )
        {
          std::vector<floops::Element *>::_M_realloc_insert<floops::Element * const&>(
            (char *)this + 720,
            v76,
            v77,
            v74,
            v60);
        }
        else
        {
          v78 = v76 + 8;
          *(_QWORD *)(v78 - 8) = *v77;
          *((_QWORD *)this + 91) = v78;
        }
        v79 = (_DWORD *)*((_QWORD *)this + 94);
        if ( v79 == *((_DWORD **)this + 95) )
        {
          std::vector<int>::_M_realloc_insert<int const&>((char *)this + 744, v79, &v178);
        }
        else
        {
          *v79 = v65;
          *((_QWORD *)this + 94) = v79 + 1;
        }
        v80 = *((_QWORD *)this + 97);
        if ( v80 == *((_QWORD *)this + 98) )
        {
          std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v80, v184);
        }
        else
        {
          v81 = v80 + 8;
          *(double *)(v81 - 8) = v146;
          *((_QWORD *)this + 97) = v81;
        }
        goto LABEL_53;
      }
      std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v73);
      v72 = *(__int64 **)(v71 + 496);
    }
    v73 = *v72;
    goto LABEL_57;
  }
LABEL_67:
  if ( v160[0] )
    operator delete(v160[0], (unsigned __int64)v161 - (unsigned __int64)v160[0]);
  if ( v158[0] )
    operator delete(v158[0], v159 - (unsigned __int64)v158[0]);
  if ( v156[0] )
    operator delete(v156[0], v157 - (unsigned __int64)v156[0]);
  if ( v144 )
    operator delete(v144, v155 - v144);
  v192 = (char *)&`vtable for'std::istringstream + 64;
  v188[0] = (char *)&`vtable for'std::istringstream + 24;
  v189 = (char *)&`vtable for'std::stringbuf + 16;
  std::string::_M_dispose(v191);
  v189 = (char *)&`vtable for'std::streambuf + 16;
  std::locale::~locale((#1684 *)v190);
  v82 = `VTT for'std::istringstream[2];
  *(double *)v188 = `VTT for'std::istringstream[1];
  *(double *)((char *)v188 + *(_QWORD *)(v188[0] - 24LL)) = v82;
  v188[1] = 0;
  v192 = (char *)&`vtable for'std::ios + 16;
  std::ios_base::~ios_base((#853 *)&v192);
  sub_11F2910(&v152);
  return std::string::_M_dispose(v170);
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::processPointDispBCs(floops::Matrix *,floops::Vector *)
// Address:  0x12A6770
// Size:     3681 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::processPointDispBCs(#2314 *this, #330 *a2, #158 *a3)
{
  int v5; // r12d
  __int64 v6; // rax
  int v7; // r8d
  int v8; // r9d
  __int64 v9; // rdx
  __int64 v10; // rbx
  int v11; // eax
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // r12
  int v15; // eax
  __int64 v16; // rax
  char *v17; // rsi
  __int64 v18; // rax
  double v19; // r13
  double v20; // r15
  double *v21; // r13
  __int64 v22; // rax
  unsigned __int64 v23; // rcx
  size_t v24; // rbx
  int v25; // esi
  __int64 v26; // r12
  int i; // r15d
  _DWORD *v28; // rdi
  __int64 j; // rbx
  __int64 (__fastcall *v30)(#158 *__hidden); // rax
  __int64 v31; // rdx
  __int64 v32; // rax
  __int64 v33; // r12
  __int64 v34; // rbx
  void (__fastcall *v35)(#174 *__hidden); // rax
  __int64 v36; // rdx
  __int64 v37; // rax
  __int64 v38; // r12
  __int64 v39; // rbx
  void (__fastcall *v40)(#174 *__hidden); // rax
  __int128 v41; // xmm4
  __int64 v42; // rcx
  _QWORD **v43; // rdx
  char *v44; // rax
  char *v45; // rsi
  __int64 v46; // xmm0_8
  _QWORD *v47; // rcx
  _BYTE *v48; // rsi
  __int64 v49; // r12
  int v50; // edi
  int v51; // edx
  __int64 v52; // rax
  __int64 v53; // r9
  __int64 v54; // r8
  int v55; // ebx
  __int64 v56; // rdx
  __int64 v57; // r13
  int v58; // eax
  int v59; // edi
  __int64 v60; // rcx
  __int64 v61; // r9
  __int64 v62; // r8
  _QWORD *v63; // r9
  __int64 v64; // r8
  double *v65; // rax
  double v66; // xmm0_8
  __int64 v67; // rdx
  __int64 v68; // rax
  __int64 v69; // r12
  __int64 v70; // rbx
  void (__fastcall *v71)(#174 *__hidden); // rax
  __m128i v72; // xmm6
  double v73; // [rsp+0h] [rbp-22E0h]
  int v74; // [rsp+2Ch] [rbp-22B4h]
  double v75; // [rsp+38h] [rbp-22A8h]
  __int64 v76; // [rsp+40h] [rbp-22A0h]
  #1752 *v79; // [rsp+78h] [rbp-2268h]
  char *v80; // [rsp+80h] [rbp-2260h]
  double v81; // [rsp+88h] [rbp-2258h]
  bool v82; // [rsp+88h] [rbp-2258h]
  #1616 *v83; // [rsp+90h] [rbp-2250h]
  #1616 *v84; // [rsp+98h] [rbp-2248h]
  __int64 v85; // [rsp+A0h] [rbp-2240h]
  char *v86; // [rsp+A0h] [rbp-2240h]
  #1752 *v87; // [rsp+B0h] [rbp-2230h]
  #370 *v88; // [rsp+B8h] [rbp-2228h]
  #1616 *v89; // [rsp+C0h] [rbp-2220h]
  #1616 *v90; // [rsp+C0h] [rbp-2220h]
  __int64 v91; // [rsp+C8h] [rbp-2218h]
  int v92; // [rsp+D4h] [rbp-220Ch] BYREF
  char v93[8]; // [rsp+D8h] [rbp-2208h] BYREF
  void *v94[2]; // [rsp+E0h] [rbp-2200h] BYREF
  _BYTE *v95; // [rsp+F0h] [rbp-21F0h]
  __int64 v96; // [rsp+100h] [rbp-21E0h] BYREF
  int v97; // [rsp+10Ch] [rbp-21D4h]
  __int64 (__fastcall **v98)(); // [rsp+120h] [rbp-21C0h] BYREF
  __int64 v99; // [rsp+128h] [rbp-21B8h]
  __int64 v100; // [rsp+130h] [rbp-21B0h]
  int v101; // [rsp+138h] [rbp-21A8h]
  int v102; // [rsp+13Ch] [rbp-21A4h]
  __int64 (__fastcall **v103)(); // [rsp+140h] [rbp-21A0h] BYREF
  __int64 v104; // [rsp+148h] [rbp-2198h]
  __int64 v105; // [rsp+150h] [rbp-2190h]
  int v106; // [rsp+158h] [rbp-2188h]
  int v107; // [rsp+15Ch] [rbp-2184h]
  __int64 (__fastcall **v108)(); // [rsp+160h] [rbp-2180h] BYREF
  __int64 v109; // [rsp+168h] [rbp-2178h]
  __int64 v110; // [rsp+170h] [rbp-2170h]
  int v111; // [rsp+178h] [rbp-2168h]
  int v112; // [rsp+17Ch] [rbp-2164h]
  _BYTE v113[24]; // [rsp+180h] [rbp-2160h] BYREF
  _BYTE v114[24]; // [rsp+198h] [rbp-2148h] BYREF
  _BYTE v115[32]; // [rsp+1B0h] [rbp-2130h] BYREF
  _BYTE v116[24]; // [rsp+1D0h] [rbp-2110h] BYREF
  _BYTE v117[24]; // [rsp+1E8h] [rbp-20F8h] BYREF
  _BYTE v118[32]; // [rsp+200h] [rbp-20E0h] BYREF
  _BYTE v119[24]; // [rsp+220h] [rbp-20C0h] BYREF
  _BYTE v120[24]; // [rsp+238h] [rbp-20A8h] BYREF
  _BYTE v121[32]; // [rsp+250h] [rbp-2090h] BYREF
  _BYTE v122[24]; // [rsp+270h] [rbp-2070h] BYREF
  char v123[24]; // [rsp+288h] [rbp-2058h] BYREF
  char v124[32]; // [rsp+2A0h] [rbp-2040h] BYREF
  _BYTE v125[24]; // [rsp+2C0h] [rbp-2020h] BYREF
  char v126[24]; // [rsp+2D8h] [rbp-2008h] BYREF
  char v127[32]; // [rsp+2F0h] [rbp-1FF0h] BYREF
  __int128 v128; // [rsp+310h] [rbp-1FD0h] BYREF
  __int64 v129; // [rsp+320h] [rbp-1FC0h]
  char v130[24]; // [rsp+328h] [rbp-1FB8h] BYREF
  char v131[32]; // [rsp+340h] [rbp-1FA0h] BYREF
  _QWORD v132[3]; // [rsp+360h] [rbp-1F80h] BYREF
  char v133[24]; // [rsp+378h] [rbp-1F68h] BYREF
  char v134[32]; // [rsp+390h] [rbp-1F50h] BYREF
  _BYTE v135[160]; // [rsp+3B0h] [rbp-1F30h] BYREF
  _BYTE v136[160]; // [rsp+450h] [rbp-1E90h] BYREF
  _BYTE v137[160]; // [rsp+4F0h] [rbp-1DF0h] BYREF
  _BYTE v138[160]; // [rsp+590h] [rbp-1D50h] BYREF
  _BYTE v139[24]; // [rsp+630h] [rbp-1CB0h] BYREF
  __int64 v140; // [rsp+648h] [rbp-1C98h]
  __m128i v141; // [rsp+650h] [rbp-1C90h]
  __int64 v142; // [rsp+660h] [rbp-1C80h]
  __m128i v143; // [rsp+668h] [rbp-1C78h]
  __int64 v144; // [rsp+678h] [rbp-1C68h]
  int v145; // [rsp+B00h] [rbp-17E0h]

  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) != 3
    || a3 == 0
    || a2 == 0 )
  {
    return;
  }
  v5 = (int)pdblib::PDB0;
  v6 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v73 = pdblib::pdbgetDouble(
          **(_QWORD **)(v6 + 64),
          (unsigned int)"Mechanics",
          (unsigned int)"Displacement.Penalty.Factor",
          v5,
          v7,
          v8);
  v74 = *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                  + 908LL);
  FE::P1Tri::P1Tri((#1840 *)v135);
  FE::Q1Quad::Q1Quad((#1847 *)v136);
  FE::P2Tri::P2Tri((#1846 *)v137);
  FE::P2Quad::P2Quad((#1844 *)v138);
  v91 = 0;
  v9 = *((_QWORD *)this + 107);
  v88 = 0;
  if ( v9 == *((_QWORD *)this + 108) )
    goto LABEL_101;
  while ( 2 )
  {
    v10 = *(_QWORD *)(v9 + 8 * v91);
    if ( !(*(unsigned int (__fastcall **)(__int64))(*(_QWORD *)v10 + 96LL))(v10) )
      goto LABEL_7;
    v11 = *(_DWORD *)(*((_QWORD *)this + 116) + 4 * v91);
    if ( v11 == 1 )
    {
      v76 = *(_QWORD *)(*((_QWORD *)this + 1) + 296LL);
    }
    else if ( v11 == 2 )
    {
      v76 = *(_QWORD *)(*((_QWORD *)this + 1) + 304LL);
    }
    else
    {
      if ( v11 )
        goto LABEL_7;
      v76 = *(_QWORD *)(*((_QWORD *)this + 1) + 288LL);
    }
    v12 = *((_QWORD *)this + 110);
    v95 = 0;
    *(_OWORD *)v94 = 0;
    v85 = v12;
    v75 = *(double *)(*((_QWORD *)this + 113) + 8 * v91);
    (*(void (__fastcall **)(__int64 (__fastcall ***)(), __int64))(*(_QWORD *)v10 + 192LL))(&v98, v10);
    v13 = v99;
    v14 = 0;
    v15 = ++v101;
    if ( v99 )
    {
      do
      {
        if ( *(_DWORD *)(v13 + 20) == v15 )
          break;
        v100 = *(_QWORD *)(*(_QWORD *)(v13 + 8) + 8LL * v15);
        v16 = *(_QWORD *)(v100 + 56);
        *(_OWORD *)v139 = *(_OWORD *)v16;
        *(_QWORD *)&v139[16] = *(_QWORD *)(v16 + 16);
        if ( v94[1] == v95 )
        {
          std::vector<TcadGeom::Point<double>>::_M_realloc_insert<TcadGeom::Point<double>>(v94, v94[1], v139);
          v13 = v99;
        }
        else
        {
          v17 = (char *)v94[1] + 24;
          *(__m128i *)v94[1] = _mm_load_si128((const __m128i *)v139);
          *((_QWORD *)v17 - 1) = *(_QWORD *)&v139[16];
          v94[1] = v17;
        }
        ++v14;
        v15 = ++v101;
      }
      while ( v13 );
      if ( v14 == 3 )
      {
        if ( v74 == 1 )
        {
          v88 = (#370 *)v135;
          goto LABEL_20;
        }
        if ( v74 == 2 )
        {
          v88 = (#370 *)v137;
          goto LABEL_20;
        }
      }
      else if ( v14 == 4 )
      {
        if ( v74 == 1 )
        {
          v88 = (#370 *)v136;
          goto LABEL_20;
        }
        if ( v74 == 2 )
        {
          v88 = (#370 *)v138;
          goto LABEL_20;
        }
      }
    }
    if ( !v88 )
      FLPS_panic("Could not find element");
LABEL_20:
    v18 = *(_QWORD *)v88;
    *((_QWORD *)v88 + 19) = v10;
    (*(void (**)(void))(v18 + 24))();
    v80 = (char *)v94[0];
    v19 = *((double *)v94[0] + 2);
    v84 = (#1616 *)*((_QWORD *)v94[0] + 1);
    v83 = (#1616 *)*((_QWORD *)v94[0] + 3);
    v20 = *((double *)v94[0] + 4);
    v79 = (#1752 *)*((_QWORD *)v94[0] + 5);
    v87 = (#1752 *)*((_QWORD *)v94[0] + 6);
    v89 = (#1616 *)*((_QWORD *)v94[0] + 7);
    v81 = *((double *)v94[0] + 8);
    TcadMath::EDouble::EDouble((#1616 *)v113, *(double *)v94[0]);
    TcadMath::EDouble::EDouble((#1616 *)v114, *(double *)&v84);
    TcadMath::EDouble::EDouble((#1616 *)v115, v19);
    TcadMath::EDouble::EDouble((#1616 *)v116, *(double *)&v83);
    TcadMath::EDouble::EDouble((#1616 *)v117, v20);
    TcadMath::EDouble::EDouble((#1616 *)v118, *(double *)&v79);
    TcadMath::EDouble::EDouble((#1616 *)v119, *(double *)&v87);
    TcadMath::EDouble::EDouble((#1616 *)v120, *(double *)&v89);
    TcadMath::EDouble::EDouble((#1616 *)v121, v81);
    TcadMath::EDouble::EDouble((#1616 *)v122, (const #1616 *)v119);
    TcadMath::EDouble::EDouble((#1616 *)v123, (const #1616 *)v120);
    TcadMath::EDouble::EDouble((#1616 *)v124, (const #1616 *)v121);
    TcadMath::EDouble::EDouble((#1616 *)v125, (const #1616 *)v116);
    TcadMath::EDouble::EDouble((#1616 *)v126, (const #1616 *)v117);
    TcadMath::EDouble::EDouble((#1616 *)v127, (const #1616 *)v118);
    TcadMath::EDouble::EDouble((#1616 *)&v128, (const #1616 *)v113);
    TcadMath::EDouble::EDouble((#1616 *)v130, (const #1616 *)v114);
    TcadMath::EDouble::EDouble((#1616 *)v131, (const #1616 *)v115);
    v21 = (double *)(v85 + 24 * v91);
    TcadMath::EDouble::EDouble((#1616 *)v132, *v21);
    TcadMath::EDouble::EDouble((#1616 *)v133, v21[1]);
    TcadMath::EDouble::EDouble((#1616 *)v134, v21[2]);
    mgoals::Triangle<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>>::getPointLocation(
      v132,
      &v128,
      v125,
      v122,
      &v92,
      v93);
    if ( v92 == 2 )
    {
      v82 = 0;
      if ( v14 == 4 )
      {
        v72 = _mm_loadu_si128((const __m128i *)v80);
        *(_QWORD *)v139 = off_7A77690;
        *(__m128i *)&v139[8] = v72;
        v140 = *((_QWORD *)v80 + 2);
        v141 = _mm_loadu_si128((const __m128i *)v80 + 3);
        v142 = *((_QWORD *)v80 + 8);
        v143 = _mm_loadu_si128((const __m128i *)(v80 + 72));
        v144 = *((_QWORD *)v80 + 11);
        mgoals::Triangle<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>>::getPointLocation<double>(
          v139,
          v21,
          &v92,
          v93);
        v82 = v92 != 2;
      }
      floops::BasicSingleStiff::BasicSingleStiff((#332 *)v139, 1);
    }
    else
    {
      v82 = 1;
      floops::BasicSingleStiff::BasicSingleStiff((#332 *)v139, 1);
    }
    (*(void (__fastcall **)(__int64 (__fastcall ***)(), __int64))(*(_QWORD *)v10 + 296LL))(&v103, v10);
    (*(void (__fastcall **)(__int64 (__fastcall ***)(), __int64))(*(_QWORD *)v10 + 296LL))(&v108, v10);
    v22 = v104;
    if ( v104 )
    {
      v23 = *(int *)(v104 + 20);
      v90 = (#1616 *)v23;
      if ( v23 > 0xFFFFFFFFFFFFFFFLL )
        std::__throw_length_error("cannot create std::vector larger than max_size()");
      if ( *(_DWORD *)(v104 + 20) )
      {
        v24 = 8 * v23;
        v90 = (#1616 *)(8 * v23);
        v86 = (char *)operator new(8 * v23);
        memset(v86, 0, v24);
        v22 = v104;
        if ( !v104 )
        {
          v25 = 0;
          goto LABEL_29;
        }
      }
      else
      {
        v86 = 0;
      }
      v25 = *(_DWORD *)(v22 + 20);
    }
    else
    {
      v86 = 0;
      v25 = 0;
      v90 = 0;
    }
LABEL_29:
    floops::SingleDense::SingleDense((#1752 *)&v96, v25, 1);
    if ( v97 <= 0 )
      goto LABEL_37;
    v26 = 0;
    for ( i = 0; i < v97; ++i )
    {
      v28 = (_DWORD *)v96;
      for ( j = 0; ; ++j )
      {
        v30 = *(__int64 (__fastcall **)(#158 *__hidden))(*(_QWORD *)v28 + 16LL);
        if ( v30 != floops::Vector::Length )
          break;
        if ( v28[2] <= (int)j )
          goto LABEL_36;
LABEL_33:
        v28 = (_DWORD *)v96;
        *(_QWORD *)(*(_QWORD *)(v96 + v26 + 16) + 8 * j) = 0;
      }
      if ( ((int (*)(void))v30)() > (int)j )
        goto LABEL_33;
LABEL_36:
      v26 += 2424;
    }
LABEL_37:
    if ( v82 )
    {
      v106 = -1;
      v105 = 0;
      v41 = *(_OWORD *)v21;
      v129 = *((_QWORD *)v21 + 2);
      v128 = v41;
      FE::FiniteElement::get_shape_fn_phy(v88, (const #1602 *)&v128, (double *)v86);
      if ( v104 )
      {
        v42 = *(unsigned int *)(v104 + 20);
        if ( (int)v42 > 0 )
        {
          v43 = (_QWORD **)(v96 + 16);
          v44 = v86;
          v45 = &v86[8 * v42];
          do
          {
            v46 = *(_QWORD *)v44;
            v47 = *v43;
            v44 += 8;
            v43 += 303;
            *v47 = v46;
          }
          while ( v45 != v44 );
        }
      }
      floops::SingleDense::SingleDense((#1752 *)v132, (const #1752 *)&v96);
      floops::SingleDense::Transpose((#1752 *)v132);
      v48 = v132;
      floops::SingleDense::operator*=(&v96, v132);
      v49 = 0;
LABEL_79:
      if ( v104 )
      {
        v50 = *(_DWORD *)(v104 + 20);
        v51 = v106 + 1;
        v48 = (_BYTE *)(8LL * v106 + 8);
        while ( 1 )
        {
          v106 = v51;
          if ( v51 == v50 )
            break;
          ++v51;
          v52 = *(_QWORD *)&v48[*(_QWORD *)(v104 + 8)];
          v48 += 8;
          v53 = *(_QWORD *)(v52 + 16);
          v54 = *(int *)(v52 + 32);
          v105 = v52;
          v55 = *(_DWORD *)(**(_QWORD **)(*(_QWORD *)(v76 + 8 * v54 + 96) + 8LL
                                                                          * *(int *)(*(_QWORD *)(v53 + 152) + 52LL))
                          + 4LL * *(int *)(v52 + 28));
          if ( v55 >= 0 )
          {
            v56 = v109;
            v57 = 0;
            HIDWORD(v140) = *(_DWORD *)(**(_QWORD **)(*(_QWORD *)(v76 + 8 * v54 + 96)
                                                    + 8LL * *(int *)(*(_QWORD *)(v53 + 152) + 52LL))
                                      + 4LL * *(int *)(v52 + 28));
            v58 = -1;
            v145 = v55;
            v110 = 0;
            if ( v109 )
            {
LABEL_84:
              v59 = *(_DWORD *)(v56 + 20);
              v48 = (_BYTE *)(8LL * v58 + 8);
              while ( 1 )
              {
                v111 = ++v58;
                if ( v59 == v58 )
                  break;
                v60 = *(_QWORD *)&v48[*(_QWORD *)(v56 + 8)];
                v48 += 8;
                v61 = *(_QWORD *)(v60 + 16);
                v62 = *(int *)(v60 + 32);
                v110 = v60;
                v63 = *(_QWORD **)(*(_QWORD *)(v76 + 8 * v62 + 96) + 8LL * *(int *)(*(_QWORD *)(v61 + 152) + 52LL));
                v64 = *(int *)(v60 + 28);
                if ( *(int *)(*v63 + 4 * v64) >= 0 )
                {
                  v145 = *(_DWORD *)(*v63 + 4 * v64);
                  v48 = v139;
                  **(double **)(*(_QWORD *)v139 + 16LL) = v73 * *(double *)(*(_QWORD *)(v96 + 303 * v49 + 16) + v57);
                  floops::Matrix::AddElement(a2, (#332 *)v139);
                  v56 = v109;
                  v58 = v111;
                  v57 += 8;
                  if ( v109 )
                    goto LABEL_84;
                  goto LABEL_88;
                }
              }
            }
            else
            {
LABEL_88:
              v111 = v58 + 1;
            }
            v65 = (double *)(*((_QWORD *)a3 + 2) + 8LL * (v55 - 1));
            v66 = v73 * v75 * *(double *)(*(_QWORD *)(v132[0] + 16LL) + v49);
            v49 += 8;
            *v65 = v66 + *v65;
            goto LABEL_79;
          }
        }
      }
      else
      {
        ++v106;
      }
      v67 = v132[0];
      if ( v132[0] )
      {
        v68 = 2424LL * *(_QWORD *)(v132[0] - 8LL);
        v69 = v132[0] + v68;
        if ( v132[0] != v132[0] + v68 )
        {
          while ( 1 )
          {
            v70 = v69 - 2424;
            v71 = **(void (__fastcall ***)(#174 *__hidden))(v69 - 2424);
            if ( v71 == floops::VectorStatic::~VectorStatic )
            {
              if ( v70 == v67 )
                goto LABEL_98;
            }
            else
            {
              ((void (__fastcall *)(__int64, _BYTE *))v71)(v69 - 2424, v48);
              v67 = v132[0];
              if ( v70 == v132[0] )
              {
LABEL_98:
                v68 = 2424LL * *(_QWORD *)(v69 - 2432);
                goto LABEL_99;
              }
            }
            v69 -= 2424;
          }
        }
        v70 = v132[0];
LABEL_99:
        operator delete[]((void *)(v70 - 8), v68 + 8);
      }
    }
    v31 = v96;
    if ( v96 )
    {
      v32 = 2424LL * *(_QWORD *)(v96 - 8);
      v33 = v96 + v32;
      if ( v96 != v96 + v32 )
      {
        while ( 1 )
        {
          v34 = v33 - 2424;
          v35 = **(void (__fastcall ***)(#174 *__hidden))(v33 - 2424);
          if ( v35 == floops::VectorStatic::~VectorStatic )
          {
            if ( v34 == v31 )
              goto LABEL_45;
          }
          else
          {
            v35((#174 *)(v33 - 2424));
            v31 = v96;
            if ( v34 == v96 )
            {
LABEL_45:
              v32 = 2424LL * *(_QWORD *)(v33 - 2432);
              goto LABEL_46;
            }
          }
          v33 -= 2424;
        }
      }
      v34 = v96;
LABEL_46:
      operator delete[]((void *)(v34 - 8), v32 + 8);
    }
    if ( v86 )
      operator delete(v86, (unsigned __int64)v90);
    v108 = &off_7A75268;
    if ( v112 && v109 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v109 + 8LL))(v109);
    v103 = &off_7A75268;
    if ( v107 && v104 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v104 + 8LL))(v104);
    v36 = *(_QWORD *)v139;
    if ( *(_QWORD *)v139 )
    {
      v37 = 2424LL * *(_QWORD *)(*(_QWORD *)v139 - 8LL);
      v38 = *(_QWORD *)v139 + v37;
      if ( *(_QWORD *)v139 != *(_QWORD *)v139 + v37 )
      {
        while ( 1 )
        {
          v39 = v38 - 2424;
          v40 = **(void (__fastcall ***)(#174 *__hidden))(v38 - 2424);
          if ( v40 == floops::VectorStatic::~VectorStatic )
          {
            if ( v39 == v36 )
              goto LABEL_62;
          }
          else
          {
            v40((#174 *)(v38 - 2424));
            v36 = *(_QWORD *)v139;
            if ( v39 == *(_QWORD *)v139 )
            {
LABEL_62:
              v37 = 2424LL * *(_QWORD *)(v38 - 2432);
              goto LABEL_63;
            }
          }
          v38 -= 2424;
        }
      }
      v39 = *(_QWORD *)v139;
LABEL_63:
      operator delete[]((void *)(v39 - 8), v37 + 8);
    }
    v98 = &off_7A757D0;
    if ( v102 )
    {
      if ( v99 )
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v99 + 8LL))(v99);
    }
    operator delete(v80, v95 - v80);
LABEL_7:
    v9 = *((_QWORD *)this + 107);
    if ( ++v91 < (unsigned __int64)((*((_QWORD *)this + 108) - v9) >> 3) )
      continue;
    break;
  }
LABEL_101:
  FE::P2Quad::~P2Quad((#1844 *)v138);
  FE::P2Tri::~P2Tri((#1846 *)v137);
  FE::Q1Quad::~Q1Quad((#1847 *)v136);
  FE::P1Tri::~P1Tri((#1840 *)v135);
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_point_force(void)
// Address:  0x12A75E0
// Size:     9444 bytes
//////////////////////////////////////////////////////////////////////

__int64 __fastcall sinterconnect::siGeneralBoundary::apply_point_force(#2314 *this, double a2, __m128d a3, __m128 a4)
{
  int v5; // r8d
  int v6; // r9d
  __int64 result; // rax
  int v8; // r8d
  int v9; // r9d
  int v10; // r9d
  _QWORD *v11; // r13
  int v12; // r8d
  int v13; // r9d
  const char *v14; // r14
  size_t v15; // rax
  size_t v16; // r12
  _QWORD *v17; // rax
  __m128i v18; // xmm4
  __int64 v19; // r14
  __int64 v20; // r13
  double v21; // xmm0_8
  __int64 v22; // r13
  char *v23; // rax
  char *v24; // rsi
  unsigned int v25; // r14d
  __int64 v26; // r12
  void *i; // r13
  int v28; // r9d
  _QWORD *v29; // r12
  char *v30; // r12
  __m128d v31; // xmm0
  double *v32; // rsi
  __m128d v33; // xmm0
  double *v34; // rsi
  _QWORD *v35; // rsi
  char *v36; // rax
  int v37; // r8d
  int v38; // r9d
  size_t v39; // r13
  _BYTE *v40; // rax
  _BYTE *v41; // rax
  int v42; // r8d
  int v43; // r9d
  void *v44; // rdi
  void *v45; // rdi
  char *v46; // rdx
  int v47; // r8d
  int v48; // r9d
  int *v49; // r14
  char *v50; // rax
  int v51; // edx
  _DWORD *v52; // r12
  int v53; // eax
  int v54; // esi
  char *v55; // rdi
  int v56; // eax
  int v57; // r8d
  int v58; // esi
  int *v59; // rcx
  unsigned __int64 v60; // r9
  double v61; // r11
  __int64 v62; // rdx
  __int64 v63; // r13
  #370 *v64; // r10
  unsigned int v65; // r14d
  __int64 v66; // r12
  double *v67; // rsi
  double *v68; // rax
  double v69; // xmm0_8
  unsigned __int64 *v70; // rax
  _DWORD *v71; // rsi
  _QWORD *v72; // r12
  int v73; // eax
  unsigned int v74; // r13d
  __int64 v75; // r12
  double *v76; // rax
  double v77; // xmm0_8
  unsigned __int64 *v78; // rax
  int v79; // r8d
  int v80; // r9d
  int v81; // r9d
  __int64 v82; // r12
  __int64 v83; // rcx
  char *v84; // r13
  __int64 v85; // rsi
  __int64 v86; // rsi
  __int64 v87; // rsi
  #152 *v88; // rdi
  __int64 v89; // rsi
  #152 *v90; // rdi
  int v91; // r9d
  __int64 v92; // r8
  __int64 v93; // r8
  __int64 v94; // rsi
  __int64 v95; // rsi
  _DWORD *v96; // rsi
  void *v97; // rcx
  __int64 v98; // rsi
  _QWORD *v99; // r12
  __int64 v100; // rsi
  __int64 v101; // rsi
  __int64 v102; // rsi
  _DWORD *v103; // rsi
  __int64 v104; // rsi
  __int64 v105; // rsi
  __int64 v106; // rsi
  __int64 v107; // rsi
  _DWORD *v108; // rsi
  __int64 v109; // rsi
  __int64 v110; // rsi
  __int64 *v111; // r14
  __int64 v112; // r13
  double v113; // xmm0_8
  double v114; // rax
  char *v115; // r12
  __m128 v116; // xmm5
  __int64 v117; // xmm7_8
  double *v118; // r14
  _OWORD *v119; // rax
  void *v120; // rdi
  double *v121; // rdi
  __int64 (__fastcall *v122)(); // rax
  int v123; // eax
  int v124; // r12d
  _OWORD *v125; // rax
  void *v126; // rdi
  __int64 v127; // r12
  char *v128; // rax
  char *v129; // rcx
  int v130; // edx
  _QWORD *v131; // rdi
  __int64 v132; // rdx
  unsigned __int64 v133; // rax
  unsigned __int64 v134; // rax
  __int64 v135; // rsi
  __int64 v136; // rax
  __int64 v137; // rdx
  __int64 (__fastcall *v138)(void *); // rax
  void *v139; // rdi
  _QWORD *v140; // rdi
  __int64 v141; // rsi
  _QWORD *v142; // rcx
  __int64 v143; // rdx
  __int64 v144; // rdx
  __int64 v145; // rsi
  double v146; // xmm4_8
  _QWORD *v147; // rsi
  __int64 v148; // rdx
  int v149; // eax
  __int64 *v150; // rdi
  __int64 v151; // rax
  __int64 (*v152)(void); // rax
  int v153; // eax
  double v154; // xmm0_8
  __int64 v155; // rax
  double v156; // rdx
  int v157; // eax
  __int64 v158; // rcx
  char *v159; // rsi
  __m128i v160; // xmm6
  __m128i v161; // xmm3
  double v162; // xmm4_8
  double v163; // xmm5_8
  double **v164; // rsi
  __int64 (__fastcall *v165)(#149 *__hidden); // rax
  double v166; // xmm0_8
  double v167; // xmm0_8
  int v168; // r9d
  __int64 v169; // r8
  double v170; // xmm0_8
  int v171; // esi
  int v172; // edi
  double v173; // xmm3_8
  double v174; // xmm4_8
  __int64 (__fastcall *v175)(#149 *__hidden); // rax
  __int64 (__fastcall *v176)(#149 *__hidden); // rax
  int v177; // eax
  _BYTE *v178; // rdi
  __int64 (*v179)(void); // rax
  int v180; // eax
  __m128d *v181; // rax
  double v182; // rdx
  __int64 v183; // rcx
  __int64 v184; // rdx
  __int64 v185; // rcx
  double v186; // rdi
  double v187; // rcx
  #152 *v188; // rdi
  __m128d *v189; // rax
  double v190; // xmm0_8
  __int64 v191; // rax
  __m128i v192; // xmm4
  __m128i v193; // xmm0
  double v194; // rax
  unsigned __int64 v195; // rax
  __int64 v196; // rdx
  int v197; // eax
  double *v198; // [rsp+0h] [rbp-7F0h]
  char *v199; // [rsp+8h] [rbp-7E8h]
  __m128d *v200; // [rsp+20h] [rbp-7D0h]
  size_t v201; // [rsp+20h] [rbp-7D0h]
  __int64 v202; // [rsp+30h] [rbp-7C0h]
  double v203; // [rsp+30h] [rbp-7C0h]
  void *v204; // [rsp+30h] [rbp-7C0h]
  double v205; // [rsp+48h] [rbp-7A8h]
  __m128 v206; // [rsp+50h] [rbp-7A0h]
  __int64 v207; // [rsp+60h] [rbp-790h]
  #1840 *v208; // [rsp+68h] [rbp-788h]
  #370 *v209; // [rsp+68h] [rbp-788h]
  int v210; // [rsp+70h] [rbp-780h]
  int v211; // [rsp+74h] [rbp-77Ch]
  double n; // [rsp+80h] [rbp-770h]
  char *na; // [rsp+80h] [rbp-770h]
  int nb; // [rsp+80h] [rbp-770h]
  double v215; // [rsp+88h] [rbp-768h] BYREF
  _QWORD *v216; // [rsp+90h] [rbp-760h]
  #1840 *v217; // [rsp+98h] [rbp-758h]
  char *v218; // [rsp+A0h] [rbp-750h]
  #1846 *v219; // [rsp+A8h] [rbp-748h]
  int *v220; // [rsp+B0h] [rbp-740h]
  unsigned __int64 v221; // [rsp+B8h] [rbp-738h]
  void *v222; // [rsp+C0h] [rbp-730h]
  #1847 *v223; // [rsp+C8h] [rbp-728h]
  double v224; // [rsp+D0h] [rbp-720h]
  char *v225; // [rsp+D8h] [rbp-718h]
  void *v226; // [rsp+E0h] [rbp-710h]
  #152 *v227; // [rsp+E8h] [rbp-708h]
  __int64 v228; // [rsp+F0h] [rbp-700h]
  unsigned __int64 v229; // [rsp+F8h] [rbp-6F8h]
  #1844 *v230; // [rsp+100h] [rbp-6F0h]
  void *src; // [rsp+108h] [rbp-6E8h]
  void *v232; // [rsp+110h] [rbp-6E0h]
  __int64 v233; // [rsp+118h] [rbp-6D8h]
  int v234; // [rsp+128h] [rbp-6C8h] BYREF
  int v235; // [rsp+12Ch] [rbp-6C4h] BYREF
  char v236[8]; // [rsp+130h] [rbp-6C0h] BYREF
  double v237; // [rsp+138h] [rbp-6B8h] BYREF
  __m128i v238; // [rsp+140h] [rbp-6B0h] BYREF
  __int64 v239; // [rsp+150h] [rbp-6A0h]
  void *v240[2]; // [rsp+160h] [rbp-690h] BYREF
  char *v241; // [rsp+170h] [rbp-680h]
  void *v242[2]; // [rsp+180h] [rbp-670h] BYREF
  __int64 v243; // [rsp+190h] [rbp-660h]
  void *v244[2]; // [rsp+1A0h] [rbp-650h] BYREF
  void *v245; // [rsp+1B0h] [rbp-640h]
  void *v246[2]; // [rsp+1C0h] [rbp-630h] BYREF
  void *v247; // [rsp+1D0h] [rbp-620h]
  void *v248[2]; // [rsp+1E0h] [rbp-610h] BYREF
  _BYTE *v249; // [rsp+1F0h] [rbp-600h]
  __m128 v250; // [rsp+200h] [rbp-5F0h] BYREF
  __int64 v251; // [rsp+210h] [rbp-5E0h]
  __int64 (__fastcall **v252)(); // [rsp+220h] [rbp-5D0h] BYREF
  void *v253; // [rsp+228h] [rbp-5C8h]
  __int64 v254; // [rsp+230h] [rbp-5C0h]
  void *v255[2]; // [rsp+240h] [rbp-5B0h] BYREF
  _BYTE *v256; // [rsp+250h] [rbp-5A0h]
  __m128 v257; // [rsp+260h] [rbp-590h] BYREF
  __int64 v258; // [rsp+270h] [rbp-580h]
  _QWORD v259[2]; // [rsp+280h] [rbp-570h] BYREF
  _QWORD v260[4]; // [rsp+290h] [rbp-560h] BYREF
  _DWORD *v261; // [rsp+2B0h] [rbp-540h]
  __int64 v262; // [rsp+2B8h] [rbp-538h]
  __m128 v263; // [rsp+2C0h] [rbp-530h] BYREF
  _QWORD *v264; // [rsp+2D0h] [rbp-520h]
  __int64 v265; // [rsp+2D8h] [rbp-518h]
  double v266; // [rsp+2E0h] [rbp-510h] BYREF
  __int64 v267; // [rsp+2E8h] [rbp-508h]
  __int64 *v268; // [rsp+2F0h] [rbp-500h]
  int v269; // [rsp+2F8h] [rbp-4F8h]
  int v270; // [rsp+2FCh] [rbp-4F4h]
  double v271; // [rsp+300h] [rbp-4F0h] BYREF
  double v272; // [rsp+308h] [rbp-4E8h]
  double v273; // [rsp+310h] [rbp-4E0h]
  int v274; // [rsp+318h] [rbp-4D8h]
  double v275; // [rsp+320h] [rbp-4D0h] BYREF
  __m128i v276; // [rsp+328h] [rbp-4C8h] BYREF
  double v277; // [rsp+338h] [rbp-4B8h]
  __m128i v278; // [rsp+340h] [rbp-4B0h]
  __int64 v279; // [rsp+350h] [rbp-4A0h]
  __m128i v280; // [rsp+358h] [rbp-498h]
  __int64 v281; // [rsp+368h] [rbp-488h]
  _BYTE v282[24]; // [rsp+370h] [rbp-480h] BYREF
  double v283; // [rsp+388h] [rbp-468h]
  __m128i v284; // [rsp+390h] [rbp-460h] BYREF
  double v285; // [rsp+3A0h] [rbp-450h]
  __m128i v286; // [rsp+3A8h] [rbp-448h]
  __int64 v287; // [rsp+3B8h] [rbp-438h]
  __m128i v288; // [rsp+3C0h] [rbp-430h] BYREF
  __int64 v289; // [rsp+3D0h] [rbp-420h]
  __int128 v290; // [rsp+460h] [rbp-390h] BYREF
  __int64 v291; // [rsp+470h] [rbp-380h]
  __m128d v292; // [rsp+500h] [rbp-2F0h] BYREF
  double v293; // [rsp+510h] [rbp-2E0h]
  char v294; // [rsp+518h] [rbp-2D8h] BYREF
  char v295; // [rsp+528h] [rbp-2C8h]
  void *v296; // [rsp+5A0h] [rbp-250h] BYREF
  _BYTE *v297; // [rsp+5A8h] [rbp-248h] BYREF
  __int64 v298; // [rsp+5B0h] [rbp-240h] BYREF
  _BYTE v299[136]; // [rsp+5B8h] [rbp-238h] BYREF
  _QWORD v300[2]; // [rsp+640h] [rbp-1B0h] BYREF
  char *v301; // [rsp+650h] [rbp-1A0h]
  char v302[16]; // [rsp+688h] [rbp-168h] BYREF
  char v303[32]; // [rsp+698h] [rbp-158h] BYREF
  char *v304; // [rsp+6B8h] [rbp-138h] BYREF

  v233 = floops::_globalPool[0];
  v233 = **(_QWORD **)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  result = pdblib::pdbIsAvailable(
             v233,
             (unsigned int)"Mechanics",
             (unsigned int)"PointForceList",
             (_DWORD)pdblib::PDB0,
             v5,
             v6);
  if ( !(_DWORD)result )
    return result;
  if ( !(unsigned int)pdblib::pdbIsAvailable(
                        v233,
                        (unsigned int)"Mechanics",
                        (unsigned int)"Point.Force.Distribute",
                        (_DWORD)pdblib::PDB0,
                        v8,
                        v9) )
    pdblib::pdbsetBoolean(
      v233,
      1,
      (unsigned int)"Mechanics",
      (unsigned int)"Point.Force.Distribute",
      (_DWORD)pdblib::PDB0,
      v10);
  v11 = v260;
  v232 = (void *)floops::_globalPool[0];
  v211 = *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                   + 96LL);
  v259[0] = v260;
  v14 = (const char *)pdblib::pdbgetString(
                        v233,
                        (unsigned int)"Mechanics",
                        (unsigned int)"PointForceList",
                        (_DWORD)pdblib::PDB0,
                        v12,
                        v13);
  v216 = v259;
  if ( !v14 )
    std::__throw_logic_error("basic_string: construction from null is not valid");
  v15 = strlen(v14);
  v300[0] = v15;
  v16 = v15;
  if ( v15 > 0xF )
  {
    v259[0] = std::string::_M_create(v216, v300, 0);
    v140 = (_QWORD *)v259[0];
    v260[0] = v300[0];
    goto LABEL_173;
  }
  if ( v15 != 1 )
  {
    if ( !v15 )
      goto LABEL_8;
    v140 = v260;
LABEL_173:
    memcpy(v140, v14, v16);
    v15 = v300[0];
    v11 = (_QWORD *)v259[0];
    goto LABEL_8;
  }
  LOBYTE(v260[0]) = *v14;
LABEL_8:
  v259[1] = v15;
  *((_BYTE *)v11 + v15) = 0;
  v238 = 0;
  v239 = 0;
  std::istringstream::basic_istringstream(v300, v216, 8);
  v296 = 0;
  v297 = v299;
  v298 = 0;
  v299[0] = 0;
  v299[16] = 0;
  v293 = 0.0;
  v294 = 0;
  v295 = 1;
  v292 = (__m128d)_mm_unpacklo_epi64((__m128i)(unsigned __int64)v300, (__m128i)(unsigned __int64)&v294);
  v17 = (_QWORD *)std::operator>><char>(v300, &v292.m128d_f64[1]);
  if ( (*((_BYTE *)v17 + *(_QWORD *)(*v17 - 24LL) + 32) & 5) != 0 )
  {
    v292.m128d_f64[0] = 0.0;
    v295 = 0;
  }
  v227 = (#152 *)v282;
  v230 = (#1844 *)&v296;
  v219 = (#1846 *)&v292;
  v217 = (#1840 *)&v288;
  std::vector<std::string>::vector<std::istream_iterator<std::string,char,std::char_traits<char>,long>,void>(
    &v288,
    &v292,
    &v296,
    v282);
  v18 = _mm_load_si128(&v288);
  v291 = 0;
  v19 = v288.m128i_i64[0];
  v290 = 0;
  v20 = v288.m128i_i64[1];
  v239 = v289;
  v288 = 0;
  v223 = (#1847 *)&v290;
  v238 = v18;
  v228 = v19;
  v289 = 0;
  sub_11F2910(&v290);
  sub_11F2910(&v288);
  std::string::_M_dispose(&v292.m128d_f64[1]);
  std::string::_M_dispose(&v297);
  v21 = 0.0;
  v241 = 0;
  v243 = 0;
  v245 = 0;
  v247 = 0;
  v249 = 0;
  *(_OWORD *)v240 = 0;
  *(_OWORD *)v242 = 0;
  *(_OWORD *)v244 = 0;
  *(_OWORD *)v246 = 0;
  *(_OWORD *)v248 = 0;
  if ( v20 != v19 )
  {
    v22 = v20 - v19;
    v23 = 0;
    v24 = 0;
    v25 = 0;
    v26 = 0;
    v226 = (void *)(v22 >> 5);
    v229 = v22 >> 5;
    for ( i = 0; ; i = v245 )
    {
      if ( v24 == v23 )
      {
        std::vector<double>::_M_realloc_insert<double const&>(v240, v24, &unk_7036278);
      }
      else
      {
        v35 = v24 + 8;
        *(v35 - 1) = 0x47D2CED32A16A1B1LL;
        v240[1] = v35;
      }
      v296 = 0;
      sub_129E220(v242, v230);
      v36 = (char *)v244[1];
      v296 = 0;
      if ( v244[1] == i )
      {
        std::vector<floops::Node *>::_M_realloc_insert<floops::Node *>(v244, i, v230);
      }
      else
      {
        *(_QWORD *)v244[1] = 0;
        v244[1] = v36 + 8;
      }
      v293 = 0.0;
      v292 = 0;
      v232 = (void *)floops::_globalPool[0];
      if ( !*(_BYTE *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                     + 928LL)
        && !(unsigned int)pdblib::pdbgetBoolean(
                            v233,
                            (unsigned int)"Mechanics",
                            (unsigned int)"Solution.Type.Displacement",
                            (_DWORD)pdblib::PDB0,
                            v37,
                            v38) )
      {
        v29 = (_QWORD *)(v228 + 32 * v26);
LABEL_14:
        v30 = (char *)pdblib::pdbgetDoubleArray(
                        v233,
                        (_DWORD)v223,
                        (unsigned int)"Mechanics",
                        *v29,
                        (_DWORD)pdblib::PDB0,
                        v28,
                        (char)v198);
        goto LABEL_15;
      }
      v29 = (_QWORD *)(v228 + 32 * v26);
      v232 = &v298;
      v39 = v29[1];
      v296 = &v298;
      v40 = (_BYTE *)*v29;
      *(_QWORD *)&v290 = v39;
      src = v40;
      if ( v39 > 0xF )
      {
        v296 = (void *)std::string::_M_create(v230, v223, 0);
        v44 = v296;
        v298 = v290;
      }
      else
      {
        if ( v39 == 1 )
        {
          LOBYTE(v298) = *v40;
LABEL_31:
          v41 = v232;
          goto LABEL_32;
        }
        if ( !v39 )
          goto LABEL_31;
        v44 = v232;
      }
      memcpy(v44, src, v39);
      v39 = v290;
      v41 = v296;
LABEL_32:
      v297 = (_BYTE *)v39;
      v41[v39] = 0;
      if ( (unsigned __int64)(0x3FFFFFFFFFFFFFFFLL - (_QWORD)v297) <= 4 )
        std::__throw_length_error("basic_string::append");
      std::string::_M_append(v230, ".Rate");
      if ( !(unsigned int)pdblib::pdbIsAvailable(
                            v233,
                            (unsigned int)"Mechanics",
                            (_DWORD)v296,
                            (_DWORD)pdblib::PDB0,
                            v42,
                            v43) )
      {
        if ( v296 != v232 )
          operator delete(v296, v298 + 1);
        goto LABEL_14;
      }
      v30 = (char *)pdblib::pdbgetDoubleArray(
                      v233,
                      (_DWORD)v223,
                      (unsigned int)"Mechanics",
                      (_DWORD)v296,
                      (_DWORD)pdblib::PDB0,
                      v28,
                      (char)v198);
      v45 = v296;
      *((double *)v30 + 1) = *((double *)v30 + 1) * *((double *)this + 106);
      *((double *)v30 + 3) = *((double *)v30 + 3) * *((double *)this + 106);
      *((double *)v30 + 5) = *((double *)v30 + 5) * *((double *)this + 106);
      if ( v45 != v232 )
        operator delete(v45, v298 + 1);
LABEL_15:
      if ( (_DWORD)v290 != 6 )
        FLPS_warning("Inconsistent point force boundary condition data");
      v31 = *(__m128d *)v30;
      v31.m128d_f64[1] = *((double *)v30 + 2);
      a3 = _mm_unpacklo_pd((__m128d)0x3F1A36E2EB1C432DuLL, (__m128d)0x3F1A36E2EB1C432DuLL);
      v292 = _mm_mul_pd(v31, a3);
      v293 = 0.0001 * *((double *)v30 + 4);
      if ( v246[1] == v247 )
      {
        std::vector<TcadGeom::Location>::_M_realloc_insert<TcadGeom::Location const&>(v246, v246[1], v219);
      }
      else
      {
        v32 = (double *)((char *)v246[1] + 24);
        *(__m128i *)v246[1] = _mm_load_si128((const __m128i *)&v292);
        *(v32 - 1) = v293;
        v246[1] = v32;
      }
      v33 = *(__m128d *)(v30 + 8);
      v33.m128d_f64[1] = *((double *)v30 + 3);
      v292 = v33;
      v21 = *((double *)v30 + 5);
      v293 = v21;
      if ( v248[1] == v249 )
      {
        std::vector<TcadGeom::Location>::_M_realloc_insert<TcadGeom::Location const&>(v248, v248[1], v219);
      }
      else
      {
        v34 = (double *)((char *)v248[1] + 24);
        *(__m128i *)v248[1] = _mm_load_si128((const __m128i *)&v292);
        *(v34 - 1) = v293;
        v248[1] = v34;
      }
      operator delete[](v30);
      v26 = ++v25;
      if ( v25 >= (unsigned __int64)v226 )
      {
        v226 = v240[0];
        v222 = v248[0];
        goto LABEL_46;
      }
      v24 = (char *)v240[1];
      v23 = v241;
    }
  }
  v222 = 0;
  *(double *)&v226 = 0.0;
  v229 = 0;
LABEL_46:
  v232 = (void *)floops::_globalPool[0];
  v210 = *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                   + 908LL);
  FE::P1Tri::P1Tri(v217);
  FE::Q1Quad::Q1Quad(v223);
  FE::P2Tri::P2Tri(v219);
  FE::P2Quad::P2Quad(v230);
  v46 = *(char **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v49 = 0;
  v261 = 0;
  v262 = 0;
  v225 = v46;
  v260[2] = &off_7A758D0;
  v50 = v46 + 160;
  v51 = *((_DWORD *)v46 + 45);
  v260[3] = v50;
  if ( v51 )
  {
    do
    {
      v52 = *(_DWORD **)(*((_QWORD *)v225 + 21) + 8LL * (_QWORD)v49);
      v53 = v52[135];
      v261 = v52;
      if ( v53 != 2 && v53 != 5 )
      {
        v224 = COERCE_DOUBLE(&v275);
        floops::Mesh::nodes((#152 *)&v275, (int)v52, -1);
        v54 = LODWORD(v277);
        v55 = (char *)v276.m128i_i64[0];
        v56 = ++LODWORD(v277);
        if ( v276.m128i_i64[0] )
        {
          v57 = *(_DWORD *)(v276.m128i_i64[0] + 20);
          if ( v56 != v57 )
          {
            src = v52;
            v58 = v54 + 2;
            v59 = v49;
            v60 = v229;
            v61 = *(double *)&v226;
            v62 = 8LL * v56;
            while ( 1 )
            {
              v63 = *(_QWORD *)(*((_QWORD *)v55 + 1) + v62);
              v276.m128i_i64[1] = v63;
              if ( v60 )
              {
                LODWORD(v232) = v58;
                v64 = (#370 *)v246[0];
                v65 = 0;
                v66 = 0;
                while ( 1 )
                {
                  v67 = *(double **)(v63 + 56);
                  v68 = (double *)((char *)v64 + 24 * v66);
                  *(double *)a4.m128_u64 = (v67[1] - v68[1]) * (v67[1] - v68[1]);
                  v69 = (*v67 - *v68) * (*v67 - *v68) + *(double *)a4.m128_u64 + (v67[2] - v68[2]) * (v67[2] - v68[2]);
                  if ( v69 < 0.0 )
                  {
                    v207 = v62;
                    v209 = v64;
                    nb = v57;
                    v215 = v61;
                    v218 = v55;
                    v220 = v59;
                    v221 = v60;
                    v21 = sqrt(v69);
                    v62 = v207;
                    v64 = v209;
                    v57 = nb;
                    v61 = v215;
                    v59 = v220;
                    v60 = v221;
                  }
                  else
                  {
                    v21 = sqrt(v69);
                  }
                  v70 = (unsigned __int64 *)(*(_QWORD *)&v61 + 8 * v66);
                  *(_QWORD *)&a3.m128d_f64[0] = *v70;
                  if ( *(double *)v70 > v21 )
                  {
                    *(double *)v70 = v21;
                    *((_QWORD *)v242[0] + v66) = v63;
                    *((_QWORD *)v244[0] + v66) = v63;
                  }
                  v66 = ++v65;
                  if ( v65 >= v60 )
                    break;
                  v63 = v276.m128i_i64[1];
                }
                v58 = (int)v232;
              }
              LODWORD(v277) = v58;
              v62 += 8;
              if ( v58 == v57 )
                break;
              ++v58;
            }
            v52 = src;
            v49 = v59;
          }
        }
        v71 = v52;
        floops::Mesh::nodes2(v227);
        v72 = *(_QWORD **)&v282[8];
        v73 = ++LODWORD(v283);
        if ( *(_QWORD *)&v282[8] )
        {
          src = &v271;
          while ( *((_DWORD *)v72 + 5) != v73 )
          {
            v71 = *(_DWORD **)(v72[1] + 8LL * v73);
            *(_QWORD *)&v282[16] = v71;
            if ( v229 )
            {
              v74 = 0;
              v75 = 0;
              v232 = v246[0];
              while ( 1 )
              {
                (*(void (__fastcall **)(void *))(*(_QWORD *)v71 + 400LL))(src);
                v76 = (double *)((char *)v232 + 24 * v75);
                *(double *)a4.m128_u64 = (v272 - v76[1]) * (v272 - v76[1]);
                v77 = (v271 - *v76) * (v271 - *v76) + *(double *)a4.m128_u64 + (v273 - v76[2]) * (v273 - v76[2]);
                if ( v77 < 0.0 )
                  v21 = sqrt(v77);
                else
                  v21 = sqrt(v77);
                v78 = (unsigned __int64 *)((char *)v226 + 8 * v75);
                *(_QWORD *)&a3.m128d_f64[0] = *v78;
                if ( *(double *)v78 > v21 )
                {
                  *(double *)v78 = v21;
                  *((_QWORD *)v242[0] + v75) = *(_QWORD *)&v282[16];
                }
                v75 = ++v74;
                if ( v74 >= v229 )
                  break;
                v71 = *(_DWORD **)&v282[16];
              }
              v72 = *(_QWORD **)&v282[8];
              v73 = ++LODWORD(v283);
              if ( !*(_QWORD *)&v282[8] )
                goto LABEL_76;
            }
            else
            {
              LODWORD(v283) = ++v73;
            }
          }
          *(_QWORD *)v282 = &off_7A76A28;
          if ( HIDWORD(v283) )
          {
            v138 = *(__int64 (__fastcall **)(void *))(*v72 + 8LL);
            if ( v138 == TcadBase::Bag<floops::Node2>::~Bag )
            {
              v139 = (void *)v72[1];
              *v72 = &off_7A76A08;
              if ( v139 )
                operator delete[](v139);
              operator delete(v72, 0x18u);
            }
            else
            {
              ((void (__fastcall *)(_QWORD *, _DWORD *))v138)(v72, v71);
            }
          }
        }
        else
        {
LABEL_76:
          *(_QWORD *)v282 = &off_7A76A28;
        }
        TcadBase::Iter<floops::Node>::~Iter(*(_QWORD *)&v224, v21, a3.m128d_f64[0], *(double *)a4.m128_u64);
        v51 = *((_DWORD *)v225 + 45);
      }
      v49 = (int *)((char *)v49 + 1);
      LODWORD(v262) = (_DWORD)v49;
    }
    while ( v51 != (_DWORD)v49 );
  }
  LODWORD(v221) = pdblib::pdbgetBoolean(
                    v233,
                    (unsigned int)"Mechanics",
                    (unsigned int)"Point.Force.Snap",
                    (_DWORD)pdblib::PDB0,
                    v47,
                    v48);
  v224 = pdblib::pdbgetDouble(
           v233,
           (unsigned int)"Mechanics",
           (unsigned int)"Point.Snap.Dist",
           (_DWORD)pdblib::PDB0,
           v79,
           v80);
  if ( v229 )
  {
    v82 = 0;
    LODWORD(src) = 0;
    v220 = &v234;
    v208 = 0;
    v218 = (char *)this + 720;
    while ( 1 )
    {
      v111 = (__int64 *)(v228 + 32 * v82);
      v232 = (void *)pdblib::pdbgetDoubleArray(
                       v233,
                       (_DWORD)v220,
                       (unsigned int)"Mechanics",
                       *v111,
                       (_DWORD)pdblib::PDB0,
                       v81,
                       (char)v198);
      if ( v234 != 6 )
        FLPS_warning("Inconsistent point force boundary condition data");
      v112 = 8 * v82;
      v113 = *((double *)v226 + v82);
      v225 = (char *)v226 + 8 * v82;
      if ( v113 <= v224 )
        goto LABEL_81;
      if ( !(unsigned int)pdblib::pdbgetBoolean(
                            v233,
                            (unsigned int)"Mechanics",
                            (unsigned int)"Point.Force.Distribute",
                            (_DWORD)pdblib::PDB0,
                            v93,
                            v81) )
      {
        if ( *(double *)v225 > v224 )
          FLPS_warning("Snapped node is not within the tolerance; Use the nearest node");
LABEL_81:
        v83 = (unsigned int)v221;
        v84 = (char *)v242[0] + v112;
        if ( (_DWORD)v221 )
        {
          v85 = *((_QWORD *)this + 87);
          if ( v85 == *((_QWORD *)this + 88) )
          {
            std::vector<floops::Element *>::_M_realloc_insert<floops::Element * const&>(
              (char *)this + 688,
              v85,
              v84,
              (unsigned int)v221,
              v93);
          }
          else
          {
            v86 = v85 + 8;
            *(_QWORD *)(v86 - 8) = *(_QWORD *)v84;
            *((_QWORD *)this + 87) = v86;
          }
          (*(void (__fastcall **)(#152 *))(**(_QWORD **)v84 + 400LL))(v227);
          v87 = *(_QWORD *)v84;
          v88 = v227;
          *(double *)v232 = 10000.0 * *(double *)v282;
          (*(void (__fastcall **)(#152 *))(*(_QWORD *)v87 + 400LL))(v88);
          v89 = *(_QWORD *)v84;
          v90 = v227;
          *((double *)v232 + 2) = 10000.0 * *(double *)&v282[8];
          (*(void (__fastcall **)(#152 *))(*(_QWORD *)v89 + 400LL))(v90);
          v91 = (int)pdblib::PDB0;
          v92 = *v111;
          LODWORD(v90) = v233;
          LODWORD(v89) = (_DWORD)v232;
          *((double *)v232 + 4) = 10000.0 * *(double *)&v282[16];
          pdblib::pdbsetDoubleArray((_DWORD)v90, v89, 6, (unsigned int)"Mechanics", v92, v91);
        }
        v94 = *((_QWORD *)this + 91);
        if ( v94 == *((_QWORD *)this + 92) )
        {
          std::vector<floops::Element *>::_M_realloc_insert<floops::Element * const&>(v218, v94, v84, v83, v93);
        }
        else
        {
          v95 = v94 + 8;
          *(_QWORD *)(v95 - 8) = *(_QWORD *)v84;
          *((_QWORD *)this + 91) = v95;
        }
        v96 = (_DWORD *)*((_QWORD *)this + 94);
        *(_DWORD *)v282 = 3;
        v225 = (char *)this + 744;
        if ( v96 == *((_DWORD **)this + 95) )
        {
          std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v96, v227);
        }
        else
        {
          *v96 = 3;
          *((_QWORD *)this + 94) = v96 + 1;
        }
        v97 = v222;
        v98 = *((_QWORD *)this + 97);
        v99 = (char *)v222 + 24 * v82;
        if ( v98 == *((_QWORD *)this + 98) )
        {
          std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v98, v99);
        }
        else
        {
          v100 = v98 + 8;
          *(_QWORD *)(v100 - 8) = *v99;
          *((_QWORD *)this + 97) = v100;
        }
        v101 = *((_QWORD *)this + 91);
        if ( v101 == *((_QWORD *)this + 92) )
        {
          std::vector<floops::Element *>::_M_realloc_insert<floops::Element * const&>(v218, v101, v84, v97, v93);
        }
        else
        {
          v102 = v101 + 8;
          *(_QWORD *)(v102 - 8) = *(_QWORD *)v84;
          *((_QWORD *)this + 91) = v102;
        }
        *(_DWORD *)v282 = 4;
        v103 = (_DWORD *)*((_QWORD *)this + 94);
        if ( v103 == *((_DWORD **)this + 95) )
        {
          std::vector<int>::_M_realloc_insert<int>(v225, v103, v227);
        }
        else
        {
          *v103 = 4;
          *((_QWORD *)this + 94) = v103 + 1;
        }
        v104 = *((_QWORD *)this + 97);
        if ( v104 == *((_QWORD *)this + 98) )
        {
          std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v104, v99 + 1);
        }
        else
        {
          v105 = v104 + 8;
          *(_QWORD *)(v105 - 8) = v99[1];
          *((_QWORD *)this + 97) = v105;
        }
        v106 = *((_QWORD *)this + 91);
        if ( v106 == *((_QWORD *)this + 92) )
        {
          std::vector<floops::Element *>::_M_realloc_insert<floops::Element * const&>(v218, v106, v84, v97, v93);
        }
        else
        {
          v107 = v106 + 8;
          *(_QWORD *)(v107 - 8) = *(_QWORD *)v84;
          *((_QWORD *)this + 91) = v107;
        }
        *(_DWORD *)v282 = 5;
        v108 = (_DWORD *)*((_QWORD *)this + 94);
        if ( v108 == *((_DWORD **)this + 95) )
        {
          std::vector<int>::_M_realloc_insert<int>(v225, v108, v227);
        }
        else
        {
          *v108 = 5;
          *((_QWORD *)this + 94) = v108 + 1;
        }
        v109 = *((_QWORD *)this + 97);
        if ( v109 == *((_QWORD *)this + 98) )
        {
          std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v109, v99 + 2);
        }
        else
        {
          v110 = v109 + 8;
          *(_QWORD *)(v110 - 8) = v99[2];
          *((_QWORD *)this + 97) = v110;
        }
        goto LABEL_103;
      }
      FLPS_warning("Snapped node is not within the tolerance; distributing force to nodes of the element containing the point");
      v225 = (char *)v246[0];
      if ( (_DWORD)v221 )
        break;
      v115 = (char *)v246[0] + 24 * v82;
LABEL_134:
      v116 = *(__m128 *)v115;
      v117 = *((_QWORD *)v115 + 2);
      LODWORD(v225) = 3;
      v206 = v116;
      v250 = v116;
      v118 = (double *)((char *)v232 + 8);
      v251 = v117;
      do
      {
        if ( *v118 == 0.0 )
          goto LABEL_136;
        v253 = 0;
        v252 = &off_7A75810;
        v119 = (_OWORD *)operator new[](0x10u);
        v120 = v253;
        v253 = v119;
        *v119 = 0;
        if ( v120 )
          operator delete[](v120);
        v254 = 2;
        v252 = &off_7A75890;
        v121 = *(double **)((char *)v244[0] + v112);
        v122 = *(__int64 (__fastcall **)())(*(_QWORD *)v121 + 368LL);
        if ( v122 != floops::Node::ElementMatch )
        {
          v215 = COERCE_DOUBLE(&v252);
          ((void (__fastcall *)(double *, __int64 (__fastcall ***)()))v122)(v121, &v252);
          v174 = *v118;
          v264 = 0;
          v123 = HIDWORD(v254);
          v265 = 0;
          n = v174;
          v263 = _mm_loadh_ps(&v215);
          if ( !HIDWORD(v254) )
            goto LABEL_185;
          v142 = v253;
          goto LABEL_180;
        }
        v215 = v121[7];
        v123 = *(_DWORD *)(*(_QWORD *)&v215 + 52LL);
        if ( v123 > 2 )
        {
          v124 = 2;
          do
          {
            if ( !v124 )
            {
              LODWORD(v254) = 2;
              v125 = (_OWORD *)operator new[](0x10u);
              v126 = v253;
              v253 = v125;
              *v125 = 0;
              if ( v126 )
                operator delete[](v126);
              HIDWORD(v254) = 0;
              goto LABEL_148;
            }
            v127 = (unsigned int)(2 * v124);
            LODWORD(v254) = v127;
            v128 = (char *)operator new[](8 * v127);
            v129 = v128;
            if ( v127 )
              v129 = (char *)memset(v128, 0, 8 * v127);
            v130 = HIDWORD(v254);
            v131 = v253;
            if ( !HIDWORD(v254) )
            {
              v253 = v129;
              if ( !v131 )
                goto LABEL_148;
              goto LABEL_158;
            }
            if ( (unsigned int)(HIDWORD(v254) - 1) <= 2 || v129 == (char *)v253 + 8 )
            {
              v132 = 8LL * HIDWORD(v254);
              v133 = 0;
              do
              {
                *(_QWORD *)&v129[v133] = v131[v133 / 8];
                v133 += 8LL;
              }
              while ( v133 != v132 );
            }
            else
            {
              v134 = 0;
              v135 = 16LL * (HIDWORD(v254) >> 1);
              do
              {
                *(__m128i *)&v129[v134] = _mm_loadu_si128((const __m128i *)&v131[v134 / 8]);
                v134 += 16LL;
              }
              while ( v135 != v134 );
              v136 = v130 & 0xFFFFFFFE;
              if ( (v130 & 1) != 0 )
              {
                v137 = v131[v136];
                v253 = v129;
                *(_QWORD *)&v129[8 * v136] = v137;
                goto LABEL_158;
              }
            }
            v253 = v129;
LABEL_158:
            operator delete[](v131);
LABEL_148:
            v124 = v254;
            v123 = *(_DWORD *)(*(_QWORD *)&v215 + 52LL);
          }
          while ( v123 > (int)v254 );
        }
        HIDWORD(v254) = v123;
        if ( !v123 )
        {
          v264 = 0;
          v265 = 0;
          v263 = (__m128)_mm_unpacklo_epi64((__m128i)(unsigned __int64)off_7A75288, (__m128i)(unsigned __int64)&v252);
          goto LABEL_185;
        }
        v141 = *(_QWORD *)(*(_QWORD *)&v215 + 40LL);
        v142 = v253;
        if ( v123 == 1 )
        {
          v144 = 0;
LABEL_179:
          v145 = *(_QWORD *)(v141 + 8 * v144);
          v146 = *v118;
          v265 = 0;
          v142[v144] = v145;
          n = v146;
          v263 = (__m128)_mm_unpacklo_epi64((__m128i)(unsigned __int64)off_7A75288, (__m128i)(unsigned __int64)&v252);
          goto LABEL_180;
        }
        v143 = 0;
        do
        {
          *(__m128i *)&v142[v143] = _mm_loadu_si128((const __m128i *)(v141 + v143 * 8));
          v143 += 2;
        }
        while ( v143 != 2LL * ((unsigned int)v123 >> 1) );
        v144 = v123 & 0xFFFFFFFE;
        if ( (v123 & 1) != 0 )
          goto LABEL_179;
        v173 = *v118;
        v265 = 0;
        v123 &= ~1u;
        n = v173;
        v263 = (__m128)_mm_unpacklo_epi64((__m128i)(unsigned __int64)off_7A75288, (__m128i)(unsigned __int64)&v252);
LABEL_180:
        v215 = 0.0;
        while ( 2 )
        {
          v147 = (_QWORD *)v142[*(_QWORD *)&v215];
          v148 = v147[2];
          v264 = v147;
          if ( *(_DWORD *)(v148 + 540) > 1u )
            goto LABEL_182;
          if ( v211 == 2 )
          {
            (*(void (__fastcall **)(double *))(*v147 + 200LL))(&v271);
            while ( 1 )
            {
              v177 = ++LODWORD(v273);
              if ( v272 == 0.0 || *(_DWORD *)(*(_QWORD *)&v272 + 20LL) == v177 )
                break;
              v178 = *(_BYTE **)(*(_QWORD *)(*(_QWORD *)&v272 + 8LL) + 8LL * v177);
              v179 = *(__int64 (**)(void))(*(_QWORD *)v178 + 96LL);
              if ( (char *)v179 == (char *)floops::Edge::IsSkeletal )
                v180 = (v178[36] & 2) != 0;
              else
                v180 = v179();
              if ( v180 )
              {
                v181 = (__m128d *)operator new(0x30u);
                v182 = v272;
                v200 = v181;
                *v181 = 0;
                v183 = *(_QWORD *)(*(_QWORD *)&v182 + 8LL);
                v181[1] = 0;
                v184 = *(_QWORD *)(*(_QWORD *)&v182 + 24LL);
                v181[2] = 0;
                v185 = *(_QWORD *)(v183 + 8LL * SLODWORD(v273));
                v186 = *(double *)(v185 + 56);
                v187 = *(double *)(v185 + 64);
                v203 = v186;
                v205 = v187;
                if ( !*(_BYTE *)(v184 + SLODWORD(v273)) )
                {
                  v203 = v187;
                  v205 = v186;
                }
                v188 = v227;
                v189 = *(__m128d **)(*(_QWORD *)&v205 + 56LL);
                a3 = *v189;
                v190 = v189[1].m128d_f64[0];
                v191 = *(_QWORD *)(*(_QWORD *)&v203 + 56LL);
                *v200 = a3;
                v192 = _mm_loadu_si128((const __m128i *)v200);
                v200[1].m128d_f64[0] = v190;
                v193 = *(__m128i *)v191;
                a3.m128d_f64[0] = *(double *)(v191 + 16);
                v200[2].m128d_f64[1] = a3.m128d_f64[0];
                *(__m128i *)((char *)v200 + 24) = v193;
                *(_QWORD *)v282 = off_7A775A0;
                v194 = v200[1].m128d_f64[0];
                *(__m128i *)&v282[8] = v192;
                v283 = v194;
                v285 = v200[2].m128d_f64[1];
                v284 = v193;
                if ( (unsigned __int8)mgoals::Segment<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>>::contained(
                                        v188,
                                        &v250) )
                {
                  mgoals::GeometryPolicy::getWeights<double>(&v250, &v282[8], &v284, &v275, &v276.m128i_u64[1]);
                  v266 = v205;
                  sub_129E220((char *)this + 720, &v266);
                  LODWORD(v266) = (_DWORD)v225;
                  sub_129E1F0((char *)this + 744, &v266);
                  LOBYTE(v198) = (_BYTE)this;
                  v266 = v275 / *(double *)v276.m128i_i64 * n;
                  sub_12A17A0((char *)this + 768, &v266);
                  v266 = v203;
                  sub_129E220((char *)this + 720, &v266);
                  LODWORD(v266) = (_DWORD)v225;
                  sub_129E1F0((char *)this + 744, &v266);
                  v266 = *(double *)&v276.m128i_i64[1] / v277 * n;
                  sub_12A17A0((char *)this + 768, &v266);
                }
                operator delete(v200, 0x30u);
              }
            }
            floops::OEdgeIter::~OEdgeIter((#278 *)&v271);
            v123 = HIDWORD(v254);
            goto LABEL_182;
          }
          if ( v211 != 3 )
            goto LABEL_182;
          (*(void (__fastcall **)(double *))(*v147 + 208LL))(&v266);
          while ( 1 )
          {
            v149 = ++v269;
            if ( !v267 )
            {
              v266 = COERCE_DOUBLE(&off_7A76318);
              goto LABEL_234;
            }
            if ( *(_DWORD *)(v267 + 20) == v149 )
              break;
            v150 = *(__int64 **)(*(_QWORD *)(v267 + 8) + 8LL * v149);
            v151 = *v150;
            v268 = v150;
            v152 = *(__int64 (**)(void))(v151 + 96);
            if ( (char *)v152 == (char *)floops::Face::IsSkeletal )
              v153 = (*((_BYTE *)v150 + 36) & 2) != 0;
            else
              v153 = v152();
            if ( v153 )
            {
              v154 = 0.0;
              v256 = 0;
              v155 = *v268;
              *(_OWORD *)v255 = 0;
              (*(void (__fastcall **)(double *))(v155 + 192))(&v271);
              v156 = v272;
              v202 = 0;
              v157 = ++v274;
              if ( v272 != 0.0 )
              {
                do
                {
                  if ( *(_DWORD *)(*(_QWORD *)&v156 + 20LL) == v157 )
                    break;
                  while ( 1 )
                  {
                    v273 = *(double *)(*(_QWORD *)(*(_QWORD *)&v156 + 8LL) + 8LL * v157);
                    v158 = *(_QWORD *)(*(_QWORD *)&v273 + 56LL);
                    *(_OWORD *)v282 = *(_OWORD *)v158;
                    v154 = *(double *)(v158 + 16);
                    *(double *)&v282[16] = v154;
                    if ( v255[1] == v256 )
                      break;
                    v159 = (char *)v255[1] + 24;
                    ++v157;
                    ++v202;
                    *(__m128i *)v255[1] = _mm_load_si128((const __m128i *)v282);
                    *((_QWORD *)v159 - 1) = *(_QWORD *)&v282[16];
                    v255[1] = v159;
                    v274 = v157;
                    if ( *(_DWORD *)(*(_QWORD *)&v156 + 20LL) == v157 )
                      goto LABEL_199;
                  }
                  std::vector<TcadGeom::Point<double>>::_M_realloc_insert<TcadGeom::Point<double>>(v255, v255[1], v227);
                  v156 = v272;
                  ++v202;
                  v157 = ++v274;
                }
                while ( v272 != 0.0 );
LABEL_199:
                if ( v202 == 3 )
                {
                  if ( v210 == 1 )
                  {
                    v208 = v217;
                    goto LABEL_202;
                  }
                  if ( v210 == 2 )
                  {
                    v208 = v219;
                    goto LABEL_202;
                  }
                }
                else if ( v202 == 4 )
                {
                  if ( v210 == 1 )
                  {
                    v208 = v223;
                    goto LABEL_202;
                  }
                  if ( v210 == 2 )
                  {
                    v208 = v230;
                    goto LABEL_202;
                  }
                }
              }
              if ( !v208 )
                FLPS_panic("Could not find element");
LABEL_202:
              *((_QWORD *)v208 + 19) = v268;
              (*(void (__fastcall **)(#1840 *))(*(_QWORD *)v208 + 24LL))(v208);
              v198 = (double *)v236;
              v160 = _mm_loadu_si128((const __m128i *)v255[0]);
              v199 = (char *)v255[0];
              v275 = COERCE_DOUBLE(off_7A77690);
              v276 = v160;
              v277 = *((double *)v255[0] + 2);
              v278 = _mm_loadu_si128((const __m128i *)((char *)v255[0] + 24));
              v279 = *((_QWORD *)v255[0] + 5);
              v161 = _mm_loadu_si128((const __m128i *)v255[0] + 3);
              v280 = v161;
              v281 = *((_QWORD *)v255[0] + 8);
              mgoals::Triangle<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>>::getPointLocation<double>(
                &v275,
                &v250,
                &v235,
                v236);
              if ( v235 != 2 )
                goto LABEL_239;
              if ( v202 == 4 )
              {
                v160 = _mm_loadu_si128((const __m128i *)v199);
                *(_QWORD *)v282 = off_7A77690;
                *(__m128i *)&v282[8] = v160;
                v283 = *((double *)v199 + 2);
                v284 = _mm_loadu_si128((const __m128i *)v199 + 3);
                v285 = *((double *)v199 + 8);
                v161 = _mm_loadu_si128((const __m128i *)(v199 + 72));
                v286 = v161;
                v287 = *((_QWORD *)v199 + 11);
                mgoals::Triangle<TcadGeom::Point<double>,TcadBase::Identity<TcadGeom::Point<double>>>::getPointLocation<double>(
                  v227,
                  &v250,
                  &v235,
                  v236);
                if ( v235 != 2 )
                {
LABEL_239:
                  (*(void (__fastcall **)(#152 *, double, double, double, double, double, double, double, double))(*v268 + 296))(
                    v227,
                    v154,
                    a3.m128d_f64[0],
                    *(double *)a4.m128_u64,
                    *(double *)v161.m128i_i64,
                    v162,
                    v163,
                    *(double *)v160.m128i_i64,
                    0.0);
                  if ( !*(_QWORD *)&v282[8] )
                    goto LABEL_256;
                  v195 = *(int *)(*(_QWORD *)&v282[8] + 20LL);
                  if ( v195 >> 60 )
                    std::__throw_length_error("cannot create std::vector larger than max_size()");
                  if ( *(_DWORD *)(*(_QWORD *)&v282[8] + 20LL) )
                  {
                    v201 = 8 * v195;
                    v204 = (void *)operator new(8 * v195);
                    memset(v204, 0, v201);
                  }
                  else
                  {
LABEL_256:
                    v201 = 0;
                    v204 = 0;
                  }
                  v257 = v206;
                  v258 = v117;
                  FE::FiniteElement::get_shape_fn_phy(v208, (const #1602 *)&v257, (double *)v204);
                  v196 = *(_QWORD *)&v282[8];
                  v197 = ++LODWORD(v283);
                  if ( *(_QWORD *)&v282[8] )
                  {
                    v198 = (double *)v204;
                    do
                    {
                      if ( *(_DWORD *)(v196 + 20) == v197 )
                        break;
                      *(_QWORD *)&v282[16] = *(_QWORD *)(*(_QWORD *)(v196 + 8) + 8LL * v197);
                      v237 = *(double *)&v282[16];
                      sub_129E220((char *)this + 720, &v237);
                      LODWORD(v237) = (_DWORD)v225;
                      sub_129E1F0((char *)this + 744, &v237);
                      v154 = n * *v198;
                      v237 = v154;
                      sub_12A17A0((char *)this + 768, &v237);
                      ++v198;
                      v197 = LODWORD(v283) + 1;
                      v196 = *(_QWORD *)&v282[8];
                      ++LODWORD(v283);
                    }
                    while ( *(_QWORD *)&v282[8] );
                  }
                  if ( v204 )
                    operator delete(v204, v201);
                  *(_QWORD *)v282 = off_7A75288;
                  TcadBase::Iter<floops::Element>::~Iter(v227);
                }
              }
              TcadBase::Iter<floops::Node>::~Iter(&v271, v154, a3.m128d_f64[0], *(double *)a4.m128_u64);
              operator delete(v199, v256 - v199);
            }
          }
          v266 = COERCE_DOUBLE(&off_7A76318);
          if ( v270 )
            (*(void (**)(void))(*(_QWORD *)v267 + 8LL))();
LABEL_234:
          v123 = HIDWORD(v254);
LABEL_182:
          ++*(_QWORD *)&v215;
          LODWORD(v265) = LODWORD(v215);
          if ( v123 != LODWORD(v215) )
          {
            v142 = v253;
            continue;
          }
          break;
        }
LABEL_185:
        TcadBase::Iter<floops::Element>::~Iter(&v263);
        v252 = &off_7A75810;
        if ( v253 )
          operator delete[](v253);
LABEL_136:
        LODWORD(v225) = (_DWORD)v225 + 1;
        v118 += 2;
      }
      while ( (_DWORD)v225 != 6 );
LABEL_103:
      if ( v232 )
        operator delete[](v232);
      LODWORD(src) = (_DWORD)src + 1;
      v82 = (unsigned int)src;
      if ( (unsigned int)src >= v229 )
        goto LABEL_121;
    }
    na = (char *)v244[0] + v112;
    *(_QWORD *)v282 = *(_QWORD *)((char *)v244[0] + v112);
    sub_129E220((char *)this + 688, v227);
    v164 = *(double ***)na;
    v165 = *(__int64 (__fastcall **)(#149 *__hidden))(**(_QWORD **)na + 400LL);
    if ( v165 == floops::Node::position )
    {
      v166 = *v164[7];
      v215 = 10000.0;
      *(double *)v232 = v166 * 10000.0;
    }
    else
    {
      v165(v227);
      v164 = *(double ***)na;
      v215 = 10000.0;
      v175 = (__int64 (__fastcall *)(#149 *__hidden))*((_QWORD *)*v164 + 50);
      *(double *)v232 = 10000.0 * *(double *)v282;
      if ( v175 != floops::Node::position )
      {
        v175(v227);
        a3 = (__m128d)*(unsigned __int64 *)&v215;
        a3.m128d_f64[0] = v215 * *(double *)&v282[8];
        v164 = *(double ***)na;
        v176 = *(__int64 (__fastcall **)(#149 *__hidden))(**(_QWORD **)na + 400LL);
        *((double *)v232 + 2) = v215 * *(double *)&v282[8];
        if ( v176 != floops::Node::position )
        {
          v176(v227);
          v167 = *(double *)&v282[16];
          a3 = (__m128d)*((unsigned __int64 *)v232 + 2);
          goto LABEL_209;
        }
LABEL_208:
        v167 = v164[7][2];
LABEL_209:
        v168 = (int)pdblib::PDB0;
        v169 = *v111;
        v170 = v167 * v215;
        v171 = (int)v232;
        v172 = v233;
        v115 = &v225[24 * v82];
        a4 = (__m128)_mm_unpacklo_pd((__m128d)*(unsigned __int64 *)v232, a3);
        *((double *)v232 + 4) = v170;
        *(__m128 *)v115 = a4;
        *((double *)v115 + 2) = v170;
        pdblib::pdbsetDoubleArray(v172, v171, 6, (unsigned int)"Mechanics", v169, v168);
        goto LABEL_134;
      }
    }
    a3 = (__m128d)*(unsigned __int64 *)&v215;
    a3.m128d_f64[0] = v215 * v164[7][1];
    *((_QWORD *)v232 + 2) = *(_QWORD *)&a3.m128d_f64[0];
    goto LABEL_208;
  }
LABEL_121:
  FE::P2Quad::~P2Quad(v230);
  FE::P2Tri::~P2Tri(v219);
  FE::Q1Quad::~Q1Quad(v223);
  FE::P1Tri::~P1Tri(v217);
  if ( v222 )
    operator delete(v222, v249 - (_BYTE *)v222);
  if ( v246[0] )
    operator delete(v246[0], (unsigned __int64)v247 - (unsigned __int64)v246[0]);
  if ( v244[0] )
    operator delete(v244[0], (unsigned __int64)v245 - (unsigned __int64)v244[0]);
  if ( v242[0] )
    operator delete(v242[0], v243 - (unsigned __int64)v242[0]);
  if ( *(double *)&v226 != 0.0 )
    operator delete(v226, v241 - (_BYTE *)v226);
  v304 = (char *)&`vtable for'std::istringstream + 64;
  v300[0] = (char *)&`vtable for'std::istringstream + 24;
  v301 = (char *)&`vtable for'std::stringbuf + 16;
  std::string::_M_dispose(v303);
  v301 = (char *)&`vtable for'std::streambuf + 16;
  std::locale::~locale((#1684 *)v302);
  v114 = `VTT for'std::istringstream[2];
  *(double *)v300 = `VTT for'std::istringstream[1];
  *(double *)((char *)v300 + *(_QWORD *)(v300[0] - 24LL)) = v114;
  v300[1] = 0;
  v304 = (char *)&`vtable for'std::ios + 16;
  std::ios_base::~ios_base((#853 *)&v304);
  sub_11F2910(&v238);
  return std::string::_M_dispose(v216);
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::zipping_distance(std::vector<floops::Element *,std::allocator<floops::Element *>> &,std::vector&<double,std::allocator<double>>,floops::Mesh *,floops::Mesh *,floops::Mesh *,floops::Mesh *)
// Address:  0x12A9AD0
// Size:     7625 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::zipping_distance(
        double a1,
        double a2,
        double a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        int a8,
        __int64 a9,
        int a10)
{
  unsigned int v11; // r13d
  #288 **v13; // rax
  #288 **v14; // rax
  #288 **v15; // rax
  double v16; // r13
  int v17; // r8d
  int v18; // r9d
  int v19; // eax
  double v20; // rsi
  __int64 v21; // rax
  __int64 v22; // rcx
  unsigned int v23; // eax
  __int64 v24; // r8
  __int64 v25; // rdx
  __int64 v26; // rax
  __int64 v27; // rdx
  _QWORD *v28; // rsi
  __int64 (__fastcall *v29)(#149 *__hidden); // rcx
  const __m128i *v30; // rcx
  __m128i v31; // kr10_16
  int v32; // eax
  _QWORD *v33; // rsi
  __int64 (__fastcall *v34)(#149 *__hidden); // rax
  const __m128i *v35; // rax
  __m128i v36; // kr00_16
  __m128d v37; // xmm4
  __m128d v38; // xmm7
  double v39; // xmm1_8
  __m128d v40; // xmm0
  __m128d v41; // xmm0
  double *v42; // r12
  unsigned __int64 v43; // r15
  double **v44; // rax
  double **v45; // rsi
  unsigned __int64 v46; // r13
  double **v47; // rsi
  double **v48; // rsi
  const double **v49; // rdx
  int v50; // eax
  __int64 *v51; // rsi
  __int64 v52; // rax
  double v53; // rcx
  __int64 v54; // r9
  int v55; // esi
  unsigned int v56; // eax
  __int64 v57; // r8
  unsigned int v58; // edx
  __int64 v59; // rdx
  int v60; // ecx
  __int64 v61; // rcx
  __int64 (__fastcall *v62)(#149 *__hidden); // r8
  int v63; // eax
  _QWORD *v64; // rsi
  __int64 (__fastcall *v65)(#149 *__hidden); // rax
  double *v66; // rsi
  __m128d *v67; // r14
  __int64 v68; // r15
  char *v69; // r13
  int v70; // eax
  _QWORD *v71; // rax
  __int64 v72; // rcx
  __int64 v73; // rdx
  __int64 v74; // rax
  __int64 v75; // rsi
  _QWORD *v76; // rax
  __m128d v77; // xmm0
  __m128d v78; // xmm7
  double v79; // xmm6_8
  __int64 v80; // rcx
  __int64 v81; // r8
  __int64 v82; // rsi
  __int64 v83; // rsi
  __int64 v84; // rsi
  __int64 v85; // rsi
  _QWORD *v86; // rdi
  double v87; // xmm0_8
  int v88; // eax
  unsigned __int64 v89; // r15
  unsigned __int64 v90; // rbx
  unsigned __int64 v91; // rax
  unsigned __int64 v92; // r15
  unsigned __int64 v93; // r13
  unsigned __int64 v94; // r12
  char *v95; // rcx
  unsigned __int64 v96; // rbx
  unsigned __int64 v97; // r13
  unsigned __int64 v98; // r12
  unsigned __int64 v99; // rax
  __int64 v100; // r14
  __int64 i; // r14
  __int64 v102; // rdi
  _QWORD *v103; // r14
  void *v104; // rdi
  __int64 v105; // rax
  __int64 v106; // rax
  __int64 v107; // r12
  __int64 v108; // r13
  #298 *v109; // r14
  const #1207 *Brep3D; // rax
  unsigned __int64 v111; // r12
  __int64 v112; // r14
  __int64 v113; // rax
  double v114; // rdx
  int j; // eax
  __int64 *v116; // rsi
  __int64 v117; // rax
  int v118; // r8d
  __int64 v119; // rdx
  __int64 v120; // rdi
  int v121; // eax
  _QWORD *v122; // rsi
  __m128d v123; // xmm7
  __m128d v124; // xmm4
  __m128d v125; // xmm6
  unsigned __int64 v126; // xmm2_8
  __m128d v127; // xmm1
  __m128d v128; // xmm2
  double v129; // xmm0_8
  double v130; // xmm0_8
  double v131; // rdi
  __int128 v132; // xmm0
  int v133; // eax
  double v134; // rax
  __int64 v135; // rcx
  __int64 v136; // rdx
  __int64 v137; // rax
  __int64 v138; // rsi
  __int64 v139; // rax
  __int64 v140; // rax
  __int64 v141; // rdi
  int v142; // eax
  int v143; // eax
  __m128d v144; // xmm5
  __m128d v145; // xmm0
  int v146; // eax
  void **v147; // [rsp+0h] [rbp-450h]
  __m128d *v148; // [rsp+8h] [rbp-448h]
  unsigned __int64 v149; // [rsp+10h] [rbp-440h]
  unsigned __int64 v150; // [rsp+18h] [rbp-438h]
  void *v151; // [rsp+20h] [rbp-430h]
  _BYTE *v152; // [rsp+28h] [rbp-428h]
  void *v153[2]; // [rsp+30h] [rbp-420h]
  _DWORD *v154; // [rsp+30h] [rbp-420h]
  double **v155; // [rsp+40h] [rbp-410h]
  __m128d v156; // [rsp+50h] [rbp-400h]
  double v157; // [rsp+50h] [rbp-400h]
  double v158; // [rsp+60h] [rbp-3F0h]
  signed __int64 v160; // [rsp+68h] [rbp-3E8h]
  int v161[2]; // [rsp+68h] [rbp-3E8h]
  double v162; // [rsp+70h] [rbp-3E0h]
  __m128d v163; // [rsp+70h] [rbp-3E0h]
  double v164; // [rsp+80h] [rbp-3D0h]
  double v166; // [rsp+90h] [rbp-3C0h]
  #264 *v167; // [rsp+98h] [rbp-3B8h]
  #177 *Match; // [rsp+B0h] [rbp-3A0h]
  double v170; // [rsp+B8h] [rbp-398h]
  unsigned __int64 v171; // [rsp+B8h] [rbp-398h]
  _QWORD *v172; // [rsp+B8h] [rbp-398h]
  #1754 *v173; // [rsp+C0h] [rbp-390h]
  double v174; // [rsp+C0h] [rbp-390h]
  #1754 *v175; // [rsp+C0h] [rbp-390h]
  double v176; // [rsp+C0h] [rbp-390h]
  double v177; // [rsp+C8h] [rbp-388h]
  double v178; // [rsp+C8h] [rbp-388h]
  double v179; // [rsp+C8h] [rbp-388h]
  char *v180; // [rsp+C8h] [rbp-388h]
  double v181; // [rsp+C8h] [rbp-388h]
  double v182; // [rsp+C8h] [rbp-388h]
  void *v183; // [rsp+C8h] [rbp-388h]
  char v184; // [rsp+DFh] [rbp-371h] BYREF
  __int128 v185; // [rsp+E0h] [rbp-370h] BYREF
  double v186; // [rsp+F0h] [rbp-360h]
  __int128 v187; // [rsp+100h] [rbp-350h] BYREF
  double v188; // [rsp+110h] [rbp-340h]
  void *v189[2]; // [rsp+120h] [rbp-330h] BYREF
  __int64 v190; // [rsp+130h] [rbp-320h]
  void *v191[2]; // [rsp+140h] [rbp-310h] BYREF
  _BYTE *v192; // [rsp+150h] [rbp-300h]
  void *v193[2]; // [rsp+160h] [rbp-2F0h] BYREF
  __int64 v194; // [rsp+170h] [rbp-2E0h]
  __m128i v195; // [rsp+180h] [rbp-2D0h] BYREF
  double v196; // [rsp+190h] [rbp-2C0h]
  __m128i v197; // [rsp+1A0h] [rbp-2B0h] BYREF
  double v198; // [rsp+1B0h] [rbp-2A0h]
  double **v199[2]; // [rsp+1C0h] [rbp-290h] BYREF
  double **v200; // [rsp+1D0h] [rbp-280h]
  __m128d v201; // [rsp+1E0h] [rbp-270h] BYREF
  double v202; // [rsp+1F0h] [rbp-260h]
  double v203[4]; // [rsp+200h] [rbp-250h] BYREF
  double v204; // [rsp+220h] [rbp-230h] BYREF
  double v205; // [rsp+228h] [rbp-228h]
  double v206; // [rsp+230h] [rbp-220h]
  __m128d v207; // [rsp+240h] [rbp-210h] BYREF
  double v208; // [rsp+250h] [rbp-200h]
  __m128d v209; // [rsp+260h] [rbp-1F0h] BYREF
  double v210; // [rsp+270h] [rbp-1E0h]
  int v211; // [rsp+278h] [rbp-1D8h]
  int v212; // [rsp+27Ch] [rbp-1D4h]
  void *v213; // [rsp+280h] [rbp-1D0h] BYREF
  _DWORD *v214; // [rsp+288h] [rbp-1C8h]
  double v215; // [rsp+290h] [rbp-1C0h]
  int v216; // [rsp+298h] [rbp-1B8h]
  int v217; // [rsp+29Ch] [rbp-1B4h]
  __m128d v218; // [rsp+2A0h] [rbp-1B0h] BYREF
  double v219; // [rsp+2B0h] [rbp-1A0h]
  unsigned int v220; // [rsp+2B8h] [rbp-198h]
  unsigned int v221; // [rsp+2BCh] [rbp-194h]
  __int64 (__fastcall **v222)(); // [rsp+2C0h] [rbp-190h] BYREF
  __int64 v223; // [rsp+2C8h] [rbp-188h]
  _QWORD *v224; // [rsp+2D0h] [rbp-180h]
  int v225; // [rsp+2D8h] [rbp-178h]
  int v226; // [rsp+2DCh] [rbp-174h]
  __m128d v227; // [rsp+2E0h] [rbp-170h] BYREF
  __m128d v228; // [rsp+2F0h] [rbp-160h]
  __m128d v229; // [rsp+300h] [rbp-150h]
  __m128d v230; // [rsp+310h] [rbp-140h]
  double v231; // [rsp+320h] [rbp-130h]
  __int128 v232; // [rsp+328h] [rbp-128h]
  __int128 v233; // [rsp+338h] [rbp-118h]
  __int128 v234; // [rsp+348h] [rbp-108h]
  __int128 v235; // [rsp+358h] [rbp-F8h]
  __int128 v236; // [rsp+368h] [rbp-E8h]
  __int128 v237; // [rsp+378h] [rbp-D8h]
  __int128 v238; // [rsp+388h] [rbp-C8h]
  unsigned __int64 v239; // [rsp+398h] [rbp-B8h]
  void *v240[2]; // [rsp+3A0h] [rbp-B0h]
  __int64 v241; // [rsp+3B0h] [rbp-A0h]
  int v242; // [rsp+3C0h] [rbp-90h] BYREF
  void *v243; // [rsp+3C8h] [rbp-88h]
  int *v244; // [rsp+3D0h] [rbp-80h]
  int *v245; // [rsp+3D8h] [rbp-78h]
  __int64 v246; // [rsp+3E0h] [rbp-70h]
  void *v247[2]; // [rsp+3E8h] [rbp-68h]
  void *v248[2]; // [rsp+3F8h] [rbp-58h]
  __int128 v249; // [rsp+408h] [rbp-48h]

  v11 = 2;
  v173 = **(#1754 ***)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) != 2 )
    v11 = 2
        * (*(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                     + 96LL) == 3)
        + 1;
  v13 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  Match = (#177 *)floops::FieldServer::RealFindMatch(*v13, "ADistance");
  if ( !Match )
  {
    Match = (#177 *)operator new(0xB8u);
    floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
    floops::RealData::RealData(Match);
    floops::RealData::SetName(Match, "ADistance");
    *((_DWORD *)Match + 10) = 0;
  }
  v14 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v167 = (#264 *)floops::FieldServer::VectorFindMatch(*v14, "ANorm");
  if ( !v167 )
  {
    v167 = (#264 *)operator new(0xC0u);
    v105 = floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
    floops::LocationData::LocationData(v167, v105, v11);
    floops::BaseData::SetName(v167, "ANorm", 1);
    *((_DWORD *)v167 + 10) = 0;
  }
  v186 = 0.0;
  v185 = 0;
  v187 = 0;
  v188 = 0.0;
  v164 = fmin(TcadGeom::Location::epsilon, 0.00000001);
  v15 = (#288 **)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  floops::FieldServer::BoundingBox(*v15, (#1602 *)&v185, (#1602 *)&v187, 0);
  v16 = v188;
  v177 = v186;
  v166 = fmax(*((double *)&v187 + 1) - *((double *)&v185 + 1), *(double *)&v187 - *(double *)&v185);
  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) == 3 )
    v166 = fmax(v16 - v177, v166);
  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) == 2 )
  {
    v190 = 0;
    v192 = 0;
    v194 = 0;
    *(_OWORD *)v189 = 0;
    *(_OWORD *)v191 = 0;
    *(_OWORD *)v193 = 0;
    v148 = &v209;
    v178 = pdblib::pdbgetDouble(
             (_DWORD)v173,
             (unsigned int)"Mechanics",
             (unsigned int)"Zipping.Extrusion.Thickness",
             (_DWORD)pdblib::PDB0,
             v17,
             v18);
    floops::Mesh::edges((#152 *)&v209, a10, -1);
    v19 = v211 + 1;
    v155 = *(double ***)&v209.m128d_f64[1];
    ++v211;
    if ( *(_QWORD *)&v209.m128d_f64[1] )
    {
      do
      {
        if ( *((_DWORD *)v155 + 5) == v19 )
          break;
        v20 = v155[1][v19];
        v21 = **(_QWORD **)&v20;
        v210 = v20;
        (*(void (__fastcall **)(__m128d *))(v21 + 384))(&v218);
LABEL_15:
        if ( *(_QWORD *)&v218.m128d_f64[1] )
        {
          v22 = *(unsigned int *)(*(_QWORD *)&v218.m128d_f64[1] + 20LL);
          v23 = v220 + 1;
          v24 = 8LL * (int)v220 + 8;
          while ( 1 )
          {
            v25 = v23;
            if ( v23 == (_DWORD)v22 )
              break;
            ++v23;
            v20 = *(double *)(*(_QWORD *)(*(_QWORD *)&v218.m128d_f64[1] + 8LL) + v24);
            v24 += 8;
            v219 = v20;
            if ( a9 == *(_QWORD *)(*(_QWORD *)&v20 + 16LL) )
            {
              v26 = **(_QWORD **)&v20;
              v220 = v25;
              (*(void (__fastcall **)(__int64 (__fastcall ***)(), double, __int64, __int64, __int64))(v26 + 192))(
                &v222,
                COERCE_DOUBLE(*(_QWORD *)&v20),
                v25,
                v22,
                v24);
              v27 = v223;
              if ( !v223 || *(_DWORD *)(v223 + 20) != 2 )
                FLPS_panic("Must be an edge with 2 nodes");
              v142 = ++v225;
              if ( *(_DWORD *)(v223 + 20) == v142 )
              {
                v28 = v224;
              }
              else
              {
                v28 = *(_QWORD **)(*(_QWORD *)(v223 + 8) + 8LL * v142);
                v224 = v28;
              }
              v29 = *(__int64 (__fastcall **)(#149 *__hidden))(*v28 + 400LL);
              if ( v29 == floops::Node::position )
              {
                v30 = (const __m128i *)v28[7];
                v195 = _mm_loadu_si128(v30);
                v196 = *(double *)v30[1].m128i_i64;
                v174 = *(double *)v30[1].m128i_i64;
                v31 = *v30;
              }
              else
              {
                v29((#149 *)&v195);
                v27 = v223;
                v142 = v225;
                v31 = v195;
                v174 = v196;
              }
              v32 = v142 + 1;
              v225 = v32;
              if ( !v27 || v32 == *(_DWORD *)(v27 + 20) )
              {
                v33 = v224;
              }
              else
              {
                v33 = *(_QWORD **)(*(_QWORD *)(v27 + 8) + 8LL * v32);
                v224 = v33;
              }
              v34 = *(__int64 (__fastcall **)(#149 *__hidden))(*v33 + 400LL);
              if ( v34 == floops::Node::position )
              {
                v35 = (const __m128i *)v33[7];
                v197 = _mm_loadu_si128(v35);
                v198 = *(double *)v35[1].m128i_i64;
                v170 = *(double *)v35[1].m128i_i64;
                v36 = *v35;
              }
              else
              {
                v34((#149 *)&v197);
                v36 = v197;
                v170 = v198;
              }
              (*(void (__fastcall **)(void **, double, _QWORD, _QWORD))(**(_QWORD **)&v219 + 432LL))(
                &v213,
                COERCE_DOUBLE(*(_QWORD *)&v219),
                *(_QWORD *)(*(_QWORD *)&v219 + 16LL),
                *(_QWORD *)(*(_QWORD *)&v219 + 16LL));
              *(_QWORD *)&v37.m128d_f64[0] = v36.m128i_i64[0];
              v37.m128d_f64[1] = *(double *)&v36.m128i_i64[1];
              *(__m128d *)v153 = v37;
              v38 = _mm_unpacklo_pd((__m128d)v31.m128i_u64[0], (__m128d)v31.m128i_u64[1]);
              a3 = ((v178 - v174) * (*(double *)&v36.m128i_i64[1] - *(double *)&v31.m128i_i64[1])
                  - (*(double *)&v31.m128i_i64[1] - *(double *)&v31.m128i_i64[1]) * (v170 - v174))
                 * *(double *)&v213;
              v39 = ((v170 - v174) * (*(double *)v31.m128i_i64 - *(double *)v31.m128i_i64)
                   - (v178 - v174) * (*(double *)v36.m128i_i64 - *(double *)v31.m128i_i64))
                  * *(double *)&v214
                  + a3
                  + ((*(double *)&v31.m128i_i64[1] - *(double *)&v31.m128i_i64[1])
                   * (*(double *)v36.m128i_i64 - *(double *)v31.m128i_i64)
                   - (*(double *)v31.m128i_i64 - *(double *)v31.m128i_i64)
                   * (*(double *)&v36.m128i_i64[1] - *(double *)&v31.m128i_i64[1]))
                  * v215;
              if ( v39 <= 0.0 )
              {
                *(_QWORD *)&v144.m128d_f64[0] = v31.m128i_i64[1];
                v145.m128d_f64[0] = v174;
                v227 = v38;
                v144.m128d_f64[1] = v178;
                v145.m128d_f64[1] = *(double *)v31.m128i_i64;
                v228 = v145;
                v163 = v144;
                v229 = v144;
                v230 = v37;
                v231 = v170;
                sub_12A3080(v189, &v227);
                v41.m128d_f64[0] = v170;
                v20 = COERCE_DOUBLE(&v227);
                v41.m128d_f64[1] = *(double *)v31.m128i_i64;
                v227 = *(__m128d *)v153;
                v228 = v41;
                v229 = v163;
                v230 = *(__m128d *)v153;
                v231 = v178;
                sub_12A3080(v189, &v227);
              }
              else
              {
                v227 = v38;
                v228 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&v174, (__m128d)v36.m128i_u64[0]);
                *(_QWORD *)&v40.m128d_f64[0] = v36.m128i_i64[1];
                v230 = v38;
                v40.m128d_f64[1] = v170;
                v231 = v178;
                v229 = v40;
                sub_12A3080(v189, &v227);
                v40.m128d_f64[0] = v170;
                v40.m128d_f64[1] = *(double *)v36.m128i_i64;
                v20 = COERCE_DOUBLE(&v227);
                v227 = *(__m128d *)v153;
                v228 = v40;
                *(_QWORD *)&v40.m128d_f64[0] = v36.m128i_i64[1];
                v230 = v38;
                v41.m128d_f64[1] = v178;
                v231 = v178;
                v229 = v41;
                v41.m128d_f64[0] = sub_12A3080(v189, &v227);
              }
              TcadBase::Iter<floops::Node>::~Iter(&v222, v41.m128d_f64[0], v39, a3);
              goto LABEL_15;
            }
          }
          v220 = v23;
          *(_QWORD *)&v218.m128d_f64[0] = &off_7A75268;
          if ( v221 )
            (*(void (__fastcall **)(_QWORD, double, _QWORD))(**(_QWORD **)&v218.m128d_f64[1] + 8LL))(
              *(_QWORD *)&v218.m128d_f64[1],
              COERCE_DOUBLE(*(_QWORD *)&v20),
              v23);
        }
        v19 = v211 + 1;
        v155 = *(double ***)&v209.m128d_f64[1];
        ++v211;
      }
      while ( *(_QWORD *)&v209.m128d_f64[1] );
      v151 = v189[0];
      v42 = (double *)v189[0];
      v150 = v190 - (unsigned __int64)v189[0];
      v43 = 0x8E38E38E38E38E39LL * (((char *)v189[1] - (char *)v189[0]) >> 3);
      v200 = 0;
      *(_OWORD *)v199 = 0;
      if ( v189[1] != v189[0] )
      {
        v44 = 0;
        v45 = 0;
        v46 = 0;
        while ( 1 )
        {
          *(_QWORD *)&v227.m128d_f64[0] = v42;
          if ( v45 == v44 )
          {
            std::vector<double const*>::_M_realloc_insert<double const*>(v199, v45, &v227);
            v47 = v199[1];
            v44 = v200;
          }
          else
          {
            *v45 = v42;
            v47 = v45 + 1;
            v199[1] = v47;
          }
          *(_QWORD *)&v227.m128d_f64[0] = v42 + 3;
          if ( v47 == v44 )
          {
            std::vector<double const*>::_M_realloc_insert<double const*>(v199, v47, &v227);
            v48 = v199[1];
            v44 = v200;
          }
          else
          {
            *v47 = v42 + 3;
            v48 = v47 + 1;
            v199[1] = v48;
          }
          *(_QWORD *)&v227.m128d_f64[0] = v42 + 6;
          if ( v48 == v44 )
          {
            std::vector<double const*>::_M_realloc_insert<double const*>(v199, v48, &v227);
            ++v46;
            v44 = v200;
            v42 += 9;
            if ( v46 >= v43 )
            {
LABEL_48:
              v155 = v199[0];
              v49 = (const double **)v199[0];
              v149 = (char *)v44 - (char *)v199[0];
              goto LABEL_49;
            }
          }
          else
          {
            *v48 = v42 + 6;
            ++v46;
            v42 += 9;
            v199[1] = v48 + 1;
            if ( v46 >= v43 )
              goto LABEL_48;
          }
          v45 = v199[1];
        }
      }
      v155 = 0;
      v49 = 0;
      v149 = 0;
    }
    else
    {
      LODWORD(v43) = 0;
      v200 = 0;
      v151 = 0;
      v49 = 0;
      v150 = 0;
      v149 = 0;
      *(_OWORD *)v199 = 0;
    }
LABEL_49:
    *(_OWORD *)v247 = 0;
    v231 = 0.0;
    v239 = 0;
    v241 = 0;
    v242 = 0;
    v243 = 0;
    v244 = &v242;
    v245 = &v242;
    v246 = 0;
    v227 = 0;
    v228 = 0;
    v229 = 0;
    v230 = 0;
    v232 = 0;
    v233 = 0;
    v234 = 0;
    v235 = 0;
    v236 = 0;
    v237 = 0;
    v238 = 0;
    *(_OWORD *)v240 = 0;
    *(_OWORD *)v248 = 0;
    v249 = 0;
    mgoals::PackedFaceQueryMap3d::init((#1754 *)&v227, v43, v49, -1);
    v147 = &v213;
    floops::Mesh::edges((#152 *)&v213, a8, -1);
    v50 = v216 + 1;
    v154 = v214;
    ++v216;
    if ( *(double *)&v214 == 0.0 )
    {
      v152 = 0;
      v90 = 0;
      v89 = 0;
    }
    else
    {
      do
      {
        if ( v154[5] == v50 )
          break;
        v51 = *(__int64 **)(*((_QWORD *)v154 + 1) + 8LL * v50);
        v52 = *v51;
        v215 = *(double *)&v51;
        (*(void (__fastcall **)(__m128d *))(v52 + 384))(&v218);
LABEL_52:
        if ( *(_QWORD *)&v218.m128d_f64[1] )
        {
          v55 = *(_DWORD *)(*(_QWORD *)&v218.m128d_f64[1] + 20LL);
          v56 = v220 + 1;
          v57 = 8LL * (int)v220 + 8;
          while ( 1 )
          {
            v58 = v56;
            if ( v56 == v55 )
              break;
            ++v56;
            v53 = *(double *)(*(_QWORD *)(*(_QWORD *)&v218.m128d_f64[1] + 8LL) + v57);
            v57 += 8;
            v219 = v53;
            if ( a7 == *(_QWORD *)(*(_QWORD *)&v53 + 16LL) )
            {
              v220 = v58;
              v222 = *(__int64 (__fastcall ***)())&v53;
              sub_129E220(v193, &v222);
              (*(void (__fastcall **)(__int64 (__fastcall ***)()))(**(_QWORD **)&v219 + 192LL))(&v222);
              v59 = v223;
              if ( !v223 || *(_DWORD *)(v223 + 20) != 2 )
                FLPS_panic("Must be an edge with 2 nodes");
              v146 = ++v225;
              v60 = *(_DWORD *)(v223 + 20);
              if ( v146 == v60 )
              {
                v62 = *(__int64 (__fastcall **)(#149 *__hidden))(*v224 + 400LL);
                if ( v62 != floops::Node::position )
                  goto LABEL_188;
              }
              else
              {
                v61 = **(_QWORD **)(*(_QWORD *)(v223 + 8) + 8LL * v146);
                v224 = *(_QWORD **)(*(_QWORD *)(v223 + 8) + 8LL * v146);
                v62 = *(__int64 (__fastcall **)(#149 *__hidden))(v61 + 400);
                if ( v62 == floops::Node::position )
                {
                  v63 = v146 + 1;
                  v225 = v63;
                  goto LABEL_62;
                }
LABEL_188:
                v62((#149 *)v203);
                v60 = v225;
                v59 = v223;
              }
              v63 = v60 + 1;
              v225 = v60 + 1;
              if ( v59 )
              {
LABEL_62:
                if ( v63 == *(_DWORD *)(v59 + 20) )
                  goto LABEL_190;
                v64 = *(_QWORD **)(*(_QWORD *)(v59 + 8) + 8LL * v63);
                v224 = v64;
              }
              else
              {
LABEL_190:
                v64 = v224;
              }
              v65 = *(__int64 (__fastcall **)(#149 *__hidden))(*v64 + 400LL);
              if ( v65 != floops::Node::position )
                v65((#149 *)&v204);
              (*(void (__fastcall **)(__m128d *, double, _QWORD, _QWORD))(**(_QWORD **)&v219 + 432LL))(
                &v207,
                COERCE_DOUBLE(*(_QWORD *)&v219),
                *(_QWORD *)(*(_QWORD *)&v219 + 16LL),
                *(_QWORD *)(*(_QWORD *)&v219 + 16LL));
              if ( v191[1] == v192 )
              {
                std::vector<TcadGeom::Location>::_M_realloc_insert<TcadGeom::Location const&>(v191, v191[1], &v207);
              }
              else
              {
                v66 = (double *)((char *)v191[1] + 24);
                *(__m128i *)v191[1] = _mm_load_si128((const __m128i *)&v207);
                *(v66 - 1) = v208;
                v191[1] = v66;
              }
              TcadBase::Iter<floops::Node>::~Iter(&v222, 0.0, 0.0, a3);
              goto LABEL_52;
            }
          }
          v220 = v56;
          *(_QWORD *)&v218.m128d_f64[0] = &off_7A75268;
          if ( v221 )
            (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD, double, __int64, __int64, void **, __m128d *))(**(_QWORD **)&v218.m128d_f64[1] + 8LL))(
              *(_QWORD *)&v218.m128d_f64[1],
              v221,
              v56,
              COERCE_DOUBLE(*(_QWORD *)&v53),
              v57,
              v54,
              v147,
              v148);
        }
        v50 = v216 + 1;
        v154 = v214;
        ++v216;
      }
      while ( *(double *)&v214 != 0.0 );
      v154 = v193[0];
      v152 = v191[0];
      v160 = ((char *)v193[1] - (char *)v193[0]) >> 3;
      if ( v160 )
      {
        v67 = (__m128d *)v191[0];
        v68 = 0;
        v69 = (char *)v193[0];
        v156 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&v164, (__m128d)*(unsigned __int64 *)&v164);
        do
        {
          (*(void (__fastcall **)(__m128d *))(**(_QWORD **)v69 + 400LL))(&v201);
          v77 = (__m128d)0x4014000000000000uLL;
          v77.m128d_f64[0] = 5.0 * v166;
          v78 = *v67;
          v79 = v67[1].m128d_f64[0];
          v184 = 0;
          v207 = _mm_add_pd(_mm_mul_pd(v156, v78), v201);
          v208 = v164 * v79 + v202;
          v219 = 5.0 * v166 * v79 + v208;
          v218 = _mm_add_pd(_mm_mul_pd(_mm_unpacklo_pd(v77, v77), v78), v207);
          v179 = -1.0;
          if ( (int)mgoals::PackedFaceQueryMap3d::ray_hit(&v227, &v207, &v218, v203, &v184) >= 0 )
          {
            v87 = ((v218.m128d_f64[0] - v207.m128d_f64[0]) * v203[0] + v207.m128d_f64[0] - v207.m128d_f64[0])
                * ((v218.m128d_f64[0] - v207.m128d_f64[0]) * v203[0] + v207.m128d_f64[0] - v207.m128d_f64[0])
                + ((v218.m128d_f64[1] - v207.m128d_f64[1]) * v203[0] + v207.m128d_f64[1] - v207.m128d_f64[1])
                * ((v218.m128d_f64[1] - v207.m128d_f64[1]) * v203[0] + v207.m128d_f64[1] - v207.m128d_f64[1])
                + ((v219 - v208) * v203[0] + v208 - v208) * ((v219 - v208) * v203[0] + v208 - v208);
            if ( v87 < 0.0 )
              v179 = sqrt(v87);
            else
              v179 = sqrt(v87);
          }
          v204 = v179;
          v82 = *(_QWORD *)(a5 + 8);
          if ( v82 == *(_QWORD *)(a5 + 16) )
          {
            std::vector<floops::Element *>::_M_realloc_insert<floops::Element * const&>(a5, v82, v69, v80, v81);
          }
          else
          {
            v83 = v82 + 8;
            *(_QWORD *)(v83 - 8) = *(_QWORD *)v69;
            *(_QWORD *)(a5 + 8) = v83;
          }
          v84 = *(_QWORD *)(a6 + 8);
          if ( v84 == *(_QWORD *)(a6 + 16) )
          {
            std::vector<double>::_M_realloc_insert<double const&>(a6, v84, &v204);
          }
          else
          {
            v85 = v84 + 8;
            *(double *)(v85 - 8) = v179;
            *(_QWORD *)(a6 + 8) = v85;
          }
          (*(void (__fastcall **)(__int64 (__fastcall ***)()))(**(_QWORD **)v69 + 328LL))(&v222);
          if ( !v223 || *(_DWORD *)(v223 + 20) != 2 )
            FLPS_panic("Surface edge should match only 2 elements");
          v88 = ++v225;
          if ( *(_DWORD *)(v223 + 20) == v88 )
          {
            v86 = v224;
          }
          else
          {
            v86 = *(_QWORD **)(*(_QWORD *)(v223 + 8) + 8LL * v88);
            v224 = v86;
          }
          if ( (*(unsigned int (__fastcall **)(_QWORD *))(*v86 + 96LL))(v86)
            && (v70 = v225 + 1, ++v225, v223)
            && v70 != *(_DWORD *)(v223 + 20) )
          {
            v71 = *(_QWORD **)(*(_QWORD *)(v223 + 8) + 8LL * v70);
            v224 = v71;
          }
          else
          {
            v71 = v224;
          }
          v72 = *(int *)(*(_QWORD *)(v71[2] + 152LL) + 52LL);
          v73 = *((int *)v71 + 7);
          v74 = *((int *)v71 + 8) + 12LL;
          v75 = **(_QWORD **)(*((_QWORD *)v167 + v74 + 1) + 8 * v72) + 24 * v73;
          *(__m128d *)v75 = v78;
          *(double *)(v75 + 16) = v79;
          v76 = *(_QWORD **)(*((_QWORD *)Match + v74) + 8 * v72);
          LODWORD(v72) = v226;
          *(double *)(*v76 + 8 * v73) = v179;
          v222 = &off_7A75268;
          if ( (_DWORD)v72 && v223 )
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v223 + 8LL))(v223);
          ++v68;
          v69 += 8;
          v67 = (__m128d *)((char *)v67 + 24);
        }
        while ( v68 != v160 );
      }
      v89 = v192 - v152;
      v90 = v194 - (_QWORD)v154;
    }
    *(double *)&v213 = COERCE_DOUBLE(&off_7A75850);
    if ( v217 && *(double *)&v214 != 0.0 )
      (*(void (__fastcall **)(_DWORD *))(*(_QWORD *)v214 + 8LL))(v214);
    if ( v248[1] )
      operator delete(v248[1], *((_QWORD *)&v249 + 1) - (unsigned __int64)v248[1]);
    if ( v247[0] )
      operator delete(v247[0], (char *)v248[0] - (char *)v247[0]);
    v91 = v238;
    if ( (_QWORD)v238 )
    {
      v171 = v90;
      v175 = (#1754 *)v89;
      v92 = 0;
      v93 = *((_QWORD *)&v238 + 1);
      do
      {
        if ( v93 )
        {
          v94 = v239;
          v95 = 0;
          do
          {
            if ( !v94 )
              break;
            v96 = v93;
            v180 = v95;
            v97 = v94;
            v98 = 0;
            do
            {
              while ( 1 )
              {
                v99 = v98 + v97 * (_QWORD)&v180[v96 * v92];
                v100 = *((_QWORD *)v240[0] + v99);
                if ( v100 )
                {
                  if ( !__dynamic_cast(
                          *((const void **)v240[0] + v99),
                          (const struct __class_type_info *)&`typeinfo for'mgoals::SComplex3dContainer_Chunk,
                          (const struct __class_type_info *)&`typeinfo for'mgoals::SComplex3dContainer_L0Chunk,
                          0) )
                    break;
                }
                if ( ++v98 >= v97 )
                  goto LABEL_118;
              }
              ++v98;
              (*(void (__fastcall **)(__int64))(*(_QWORD *)v100 + 8LL))(v100);
              v97 = v239;
              v96 = *((_QWORD *)&v238 + 1);
            }
            while ( v98 < v239 );
LABEL_118:
            v94 = v97;
            v93 = v96;
            v95 = v180 + 1;
          }
          while ( (unsigned __int64)(v180 + 1) < v96 );
          v91 = v238;
        }
        ++v92;
      }
      while ( v92 < v91 );
      v89 = (unsigned __int64)v175;
      v90 = v171;
    }
    for ( i = (__int64)v244; (int *)i != &v242; i = std::_Rb_tree_increment(i) )
    {
      v102 = *(_QWORD *)(i + 32);
      if ( v102 )
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v102 + 8LL))(v102);
    }
    v103 = v243;
    if ( v243 )
    {
      do
      {
        sub_129DFF0(v103[3]);
        v104 = v103;
        v103 = (_QWORD *)v103[2];
        operator delete(v104, 0x28u);
      }
      while ( v103 );
    }
    if ( v240[0] )
      operator delete(v240[0], v241 - (unsigned __int64)v240[0]);
    if ( v155 )
      operator delete(v155, v149);
    *(_QWORD *)&v209.m128d_f64[0] = &off_7A75850;
    if ( v212 && *(_QWORD *)&v209.m128d_f64[1] )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v209.m128d_f64[1] + 8LL))(*(_QWORD *)&v209.m128d_f64[1]);
    if ( v154 )
      operator delete(v154, v90);
    if ( v152 )
      operator delete(v152, v89);
    if ( v151 )
      operator delete(v151, v150);
  }
  else if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                      + 96LL) == 3 )
  {
    v106 = operator new(0xC0u);
    v107 = floops::_globalPool[0];
    v108 = v106;
    v109 = *(#298 **)(floops::_globalPool[0] + 256LL);
    if ( !v109 )
    {
      v140 = operator new(0x3E0u);
      v109 = (#298 *)(v140 + 16);
      v183 = (void *)v140;
      *(_QWORD *)(v140 + 8) = 0x100000001LL;
      *(_QWORD *)v140 = off_7A75A48;
      floops::StructureManager::StructureManager((#298 *)(v140 + 16));
      v141 = *(_QWORD *)(v107 + 264);
      *(_QWORD *)(v107 + 256) = v109;
      *(_QWORD *)(v107 + 264) = v183;
      if ( v141 )
      {
        std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v141);
        v109 = *(#298 **)(v107 + 256);
      }
    }
    Brep3D = (const #1207 *)floops::StructureManager::getBrep3D(v109);
    mgoals::Brep::Brep((#1207 *)v108, Brep3D);
    v172 = (_QWORD *)operator new(0x18u);
    v111 = 0;
    v172[2] = v108;
    v172[1] = 0x100000001LL;
    *v172 = off_7A776B0;
    if ( *(_QWORD *)(v108 + 112) != *(_QWORD *)(v108 + 104) )
    {
      do
      {
        v112 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a9 + 152LL))(a9);
        v113 = TcadGeom::Material::floopsRegionName[abi:cxx11](*(_QWORD *)(v108 + 104) + 80 * v111);
        if ( !(unsigned int)std::string::compare(v113, v112) )
          break;
        ++v111;
      }
      while ( v111 < 0xCCCCCCCCCCCCCCCDLL * ((__int64)(*(_QWORD *)(v108 + 112) - *(_QWORD *)(v108 + 104)) >> 4) );
    }
    mgoals::Brep::getBody(&v201, v108, v111, 0, 0);
    mgoals::BrepRayTracer::BrepRayTracer(&v195, &v201, 0xFFFFFFFFLL);
    floops::Mesh::elements((#152 *)&v218, a8, -1);
    v114 = v218.m128d_f64[1];
    for ( j = ++v220; *(_QWORD *)&v218.m128d_f64[1]; j = ++v220 )
    {
      if ( *(_DWORD *)(*(_QWORD *)&v114 + 20LL) == j )
        break;
      v116 = *(__int64 **)(*(_QWORD *)(*(_QWORD *)&v114 + 8LL) + 8LL * j);
      v117 = *v116;
      v219 = *(double *)&v116;
      (*(void (__fastcall **)(__int64 (__fastcall ***)()))(v117 + 384))(&v222);
LABEL_149:
      if ( v223 )
      {
        v118 = *(_DWORD *)(v223 + 20);
        LODWORD(v119) = v225 + 1;
        v120 = 8LL * v225 + 8;
        while ( 1 )
        {
          v121 = v119;
          if ( (_DWORD)v119 == v118 )
            break;
          v119 = (unsigned int)(v119 + 1);
          v122 = *(_QWORD **)(*(_QWORD *)(v223 + 8) + v120);
          v120 += 8;
          v224 = v122;
          if ( a7 == v122[2] )
          {
            v225 = v121;
            (*(void (__fastcall **)(double *, _QWORD *, __int64))(*v122 + 400LL))(v203, v122, v119);
            v181 = v203[0];
            v157 = v203[1];
            v176 = v203[2];
            (*(void (__fastcall **)(double *, _QWORD *, __int64, __int64))(*v224 + 432LL))(&v204, v224, a7, a7);
            v123 = (__m128d)_mm_loadl_epi64((const __m128i *)&xmmword_7020870);
            v124 = (__m128d)*(unsigned __int64 *)&v204;
            *(double *)v161 = v204;
            v125 = _mm_unpacklo_pd((__m128d)0x40C3880000000000uLL, (__m128d)0x40C3880000000000uLL);
            v158 = v205;
            v124.m128d_f64[0] = v204 * v164 + v181;
            *(double *)&v126 = v164 * v205 + v157;
            v162 = v206;
            v127 = (__m128d)*(unsigned __int64 *)&v205;
            v207 = _mm_mul_pd(_mm_unpacklo_pd((__m128d)v126, _mm_xor_pd(v124, v123)), v125);
            v208 = (v206 * v164 + v176) * 10000.0;
            v127.m128d_f64[0] = v205 * (v166 * 5.0) + *(double *)&v126;
            v128 = (__m128d)*(unsigned __int64 *)&v204;
            v128.m128d_f64[0] = v204 * (v166 * 5.0) + v124.m128d_f64[0];
            v210 = (v166 * 5.0 * v206 + v206 * v164 + v176) * 10000.0;
            v209 = _mm_mul_pd(_mm_unpacklo_pd(v127, _mm_xor_pd(v128, v123)), v125);
            mgoals::FaceQueryMap3d::ray_hit(&v213, &v195, &v207, &v209, &v197);
            v182 = -0.0001;
            if ( v214 != v213 )
            {
              v129 = ((v209.m128d_f64[0] - v207.m128d_f64[0]) * *(double *)v197.m128i_i64
                    + v207.m128d_f64[0]
                    - v207.m128d_f64[0])
                   * ((v209.m128d_f64[0] - v207.m128d_f64[0]) * *(double *)v197.m128i_i64
                    + v207.m128d_f64[0]
                    - v207.m128d_f64[0])
                   + ((v209.m128d_f64[1] - v207.m128d_f64[1]) * *(double *)v197.m128i_i64
                    + v207.m128d_f64[1]
                    - v207.m128d_f64[1])
                   * ((v209.m128d_f64[1] - v207.m128d_f64[1]) * *(double *)v197.m128i_i64
                    + v207.m128d_f64[1]
                    - v207.m128d_f64[1])
                   + ((v210 - v208) * *(double *)v197.m128i_i64 + v208 - v208)
                   * ((v210 - v208) * *(double *)v197.m128i_i64 + v208 - v208);
              if ( v129 < 0.0 )
                v130 = sqrt(v129);
              else
                v130 = sqrt(v129);
              v182 = v130 * 0.0001;
            }
            *(_QWORD *)&v227.m128d_f64[0] = v224;
            v199[0] = *(double ***)&v182;
            sub_129E220(a5, &v227);
            std::vector<double>::push_back(a6, v199);
            (*(void (__fastcall **)(__m128d *))(*v224 + 328LL))(&v227);
            if ( !*(_QWORD *)&v227.m128d_f64[1] || *(_DWORD *)(*(_QWORD *)&v227.m128d_f64[1] + 20LL) != 2 )
              FLPS_panic("Surface face should match only 2 elements");
            v143 = ++LODWORD(v228.m128d_f64[1]);
            if ( v143 == *(_DWORD *)(*(_QWORD *)&v227.m128d_f64[1] + 20LL) )
            {
              v131 = v228.m128d_f64[0];
            }
            else
            {
              v131 = *(double *)(*(_QWORD *)(*(_QWORD *)&v227.m128d_f64[1] + 8LL) + 8LL * v143);
              v228.m128d_f64[0] = v131;
            }
            *(_QWORD *)&v132 = *(_QWORD *)v161;
            *((double *)&v132 + 1) = v158;
            if ( (*(unsigned int (__fastcall **)(double))(**(_QWORD **)&v131 + 96LL))(COERCE_DOUBLE(*(_QWORD *)&v131))
              && (v133 = LODWORD(v228.m128d_f64[1]) + 1, ++LODWORD(v228.m128d_f64[1]), *(_QWORD *)&v227.m128d_f64[1])
              && v133 != *(_DWORD *)(*(_QWORD *)&v227.m128d_f64[1] + 20LL) )
            {
              v134 = *(double *)(*(_QWORD *)(*(_QWORD *)&v227.m128d_f64[1] + 8LL) + 8LL * v133);
              v228.m128d_f64[0] = v134;
            }
            else
            {
              v134 = v228.m128d_f64[0];
            }
            v135 = *(int *)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)&v134 + 16LL) + 152LL) + 52LL);
            v136 = *(int *)(*(_QWORD *)&v134 + 28LL);
            v137 = *(int *)(*(_QWORD *)&v134 + 32LL) + 12LL;
            v138 = **(_QWORD **)(*((_QWORD *)v167 + v137 + 1) + 8 * v135) + 24 * v136;
            *(_OWORD *)v138 = v132;
            v139 = *((_QWORD *)Match + v137);
            *(double *)(v138 + 16) = v162;
            *(double *)(**(_QWORD **)(v139 + 8 * v135) + 8 * v136) = v182;
            *(_QWORD *)&v227.m128d_f64[0] = off_7A75288;
            TcadBase::Iter<floops::Element>::~Iter(&v227);
            if ( *(double *)&v213 != 0.0 )
              operator delete(v213, *(_QWORD *)&v215 - (_QWORD)v213);
            goto LABEL_149;
          }
        }
      }
      else
      {
        v121 = v225 + 1;
      }
      v225 = v121;
      v222 = (__int64 (__fastcall **)())off_7A75288;
      TcadBase::Iter<floops::Element>::~Iter(&v222);
      v114 = v218.m128d_f64[1];
    }
    *(_QWORD *)&v218.m128d_f64[0] = off_7A75288;
    TcadBase::Iter<floops::Element>::~Iter(&v218);
    mgoals::BrepRayTracer::~BrepRayTracer((#2429 *)&v195);
    if ( *(_QWORD *)&v201.m128d_f64[1] )
      std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(*(_QWORD *)&v201.m128d_f64[1]);
    std::_Sp_counted_base<(__gnu_cxx::_Lock_policy)2>::_M_release(v172);
  }
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_zipping_force(std::__cxx11::basic_string<char,std::char_traits<char>,std::allocator<char>>)
// Address:  0x12AB8A0
// Size:     4530 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::apply_zipping_force(
        #372 *this,
        char **a2,
        double a3,
        __m128d a4,
        __m128d a5)
{
  int v7; // r9d
  int v8; // r8d
  int v9; // r9d
  int v10; // r9d
  int v11; // r8d
  int v12; // r9d
  int v13; // r8d
  int v14; // r9d
  __m128 v15; // xmm0
  int v16; // r8d
  int v17; // r9d
  const char *v18; // rsi
  const char *v19; // r13
  size_t v20; // rax
  size_t v21; // r12
  double v22; // rdx
  __int64 v23; // r15
  __int64 v24; // r12
  int v25; // ecx
  __int64 v26; // rdx
  __int64 v27; // rax
  _DWORD *v28; // r13
  bool v29; // zf
  __int64 v30; // rax
  int v31; // edx
  __int64 v32; // rax
  __int64 v33; // rax
  __int64 v34; // rax
  __int64 v35; // rax
  char *v36; // rax
  __int64 v37; // rax
  char *v38; // rdx
  int v39; // r8d
  int v40; // r9d
  __int64 v41; // r15
  int v42; // r13d
  int v43; // edx
  __int64 v44; // rax
  _DWORD *v45; // r12
  __int64 v46; // rax
  __int64 v47; // rdx
  __int64 v48; // rax
  __int64 v49; // rax
  void **v50; // rsi
  int v51; // edx
  __int64 v52; // rcx
  __int64 v53; // r8
  __int64 v54; // r9
  __int64 v55; // rax
  __int64 v56; // rax
  __int64 v57; // rax
  __int64 v58; // rax
  _QWORD *v59; // r15
  _QWORD *v60; // r13
  unsigned __int64 v61; // r12
  unsigned __int64 i; // rbx
  _QWORD *v63; // rdx
  unsigned int v64; // r13d
  __int64 v65; // r12
  #148 *v66; // rsi
  double v67; // xmm1_8
  double v68; // xmm2_8
  __int64 v69; // rax
  __m128d v70; // xmm0
  __int64 v71; // rdi
  int v72; // eax
  _DWORD *v73; // rsi
  __int64 v74; // rsi
  __int64 v75; // rsi
  _DWORD *v76; // rsi
  __int64 v77; // rsi
  __int64 v78; // rsi
  _DWORD *v79; // rsi
  __int64 v80; // rsi
  __int64 v81; // rsi
  _QWORD *v82; // rdx
  unsigned int v83; // r12d
  __int64 v84; // rbx
  #148 *v85; // rsi
  double v86; // xmm1_8
  double v87; // xmm5_8
  double v88; // xmm2_8
  __int64 v89; // rax
  __m128d v90; // xmm1
  __int64 v91; // rdi
  int v92; // eax
  _DWORD *v93; // rsi
  __int64 v94; // rsi
  __int64 v95; // rsi
  _DWORD *v96; // rsi
  __int64 v97; // rsi
  __int64 v98; // rsi
  double v99; // rdi
  char *v100; // rax
  __int64 v101; // rax
  char *v102; // rdx
  __int64 v103; // [rsp-10h] [rbp-160h]
  int v104; // [rsp-8h] [rbp-158h]
  double v105; // [rsp+8h] [rbp-148h]
  double v106; // [rsp+10h] [rbp-140h]
  double v107; // [rsp+18h] [rbp-138h]
  int v108; // [rsp+18h] [rbp-138h]
  const char *v109; // [rsp+28h] [rbp-128h]
  char *v110; // [rsp+28h] [rbp-128h]
  __int64 v111; // [rsp+30h] [rbp-120h]
  char *v112; // [rsp+30h] [rbp-120h]
  char *s2c; // [rsp+48h] [rbp-108h]
  char *s2d; // [rsp+48h] [rbp-108h]
  char *s2e; // [rsp+48h] [rbp-108h]
  char *s2f; // [rsp+48h] [rbp-108h]
  char *s2g; // [rsp+48h] [rbp-108h]
  char *s2h; // [rsp+48h] [rbp-108h]
  char *s2i; // [rsp+48h] [rbp-108h]
  char *s2j; // [rsp+48h] [rbp-108h]
  signed __int64 s2; // [rsp+48h] [rbp-108h]
  double s2a; // [rsp+48h] [rbp-108h]
  double s2b; // [rsp+48h] [rbp-108h]
  _DWORD *v124; // [rsp+58h] [rbp-F8h] BYREF
  void *v125[2]; // [rsp+60h] [rbp-F0h] BYREF
  __int64 v126; // [rsp+70h] [rbp-E0h]
  void *v127[2]; // [rsp+80h] [rbp-D0h] BYREF
  __int64 v128; // [rsp+90h] [rbp-C0h]
  void *v129[2]; // [rsp+A0h] [rbp-B0h] BYREF
  const char *v130; // [rsp+B0h] [rbp-A0h]
  void *v131[2]; // [rsp+C0h] [rbp-90h] BYREF
  double v132; // [rsp+D0h] [rbp-80h]
  __m128d v133; // [rsp+E0h] [rbp-70h] BYREF
  _QWORD v134[2]; // [rsp+F0h] [rbp-60h] BYREF
  __int64 (__fastcall **v135)(); // [rsp+100h] [rbp-50h] BYREF
  __int64 v136; // [rsp+108h] [rbp-48h]
  void *v137; // [rsp+110h] [rbp-40h]
  int v138; // [rsp+118h] [rbp-38h]
  int v139; // [rsp+11Ch] [rbp-34h]

  v111 = **(_QWORD **)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  if ( (unsigned int)pdblib::pdbIsAvailable(
                       v111,
                       (unsigned int)*a2,
                       (unsigned int)"Mechanics",
                       (unsigned int)"Zipping.Energy",
                       (_DWORD)pdblib::PDB0,
                       v7) )
    v105 = pdblib::pdbgetDouble(
             v111,
             (unsigned int)*a2,
             (unsigned int)"Mechanics",
             (unsigned int)"Zipping.Energy",
             (_DWORD)pdblib::PDB0,
             v9);
  else
    v105 = pdblib::pdbgetDouble(
             v111,
             (unsigned int)"Mechanics",
             (unsigned int)"Zipping.Energy",
             (_DWORD)pdblib::PDB0,
             v8,
             v9);
  if ( (unsigned int)pdblib::pdbIsAvailable(
                       v111,
                       (unsigned int)*a2,
                       (unsigned int)"Mechanics",
                       (unsigned int)"Zipping.Max.Traction",
                       (_DWORD)pdblib::PDB0,
                       v10) )
    v106 = pdblib::pdbgetDouble(
             v111,
             (unsigned int)*a2,
             (unsigned int)"Mechanics",
             (unsigned int)"Zipping.Max.Traction",
             (_DWORD)pdblib::PDB0,
             v12);
  else
    v106 = pdblib::pdbgetDouble(
             v111,
             (unsigned int)"Mechanics",
             (unsigned int)"Zipping.Max.Traction",
             (_DWORD)pdblib::PDB0,
             v11,
             v12);
  v15 = 0;
  v126 = 0;
  v128 = 0;
  *(_OWORD *)v125 = 0;
  *(_OWORD *)v127 = 0;
  if ( (unsigned int)pdblib::pdbIsAvailable(
                       v111,
                       (unsigned int)"Mechanics",
                       (unsigned int)"Zipping.Medium",
                       (_DWORD)pdblib::PDB0,
                       v13,
                       v14) )
  {
    v18 = "Mechanics";
    v19 = (const char *)pdblib::pdbgetString(
                          v111,
                          (unsigned int)"Mechanics",
                          (unsigned int)"Zipping.Medium",
                          (_DWORD)pdblib::PDB0,
                          v16,
                          v17);
    *(_QWORD *)&v133.m128d_f64[0] = v134;
    if ( !v19 )
      std::__throw_logic_error("basic_string: construction from null is not valid");
    v20 = strlen(v19);
    v135 = (__int64 (__fastcall **)())v20;
    v21 = v20;
    if ( v20 > 0xF )
    {
      *(_QWORD *)&v133.m128d_f64[0] = std::string::_M_create(&v133, &v135, 0);
      v99 = v133.m128d_f64[0];
      v134[0] = v135;
    }
    else
    {
      if ( v20 == 1 )
      {
        LOBYTE(v134[0]) = *v19;
LABEL_10:
        v22 = COERCE_DOUBLE(v134);
LABEL_11:
        *(_QWORD *)&v133.m128d_f64[1] = v20;
        v15 = 0;
        *(_BYTE *)(*(_QWORD *)&v22 + v20) = 0;
        v130 = 0;
        v132 = 0.0;
        *(_OWORD *)v129 = 0;
        *(_OWORD *)v131 = 0;
        v23 = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
        v137 = 0;
        v24 = -1;
        v139 = 0;
        v107 = 0.0;
        v135 = &off_7A758D0;
        v136 = v23 + 160;
        v109 = 0;
LABEL_12:
        v25 = *(_DWORD *)(v23 + 180);
        LODWORD(v26) = v24 + 1;
        v27 = 8 * v24 + 8;
        while ( 1 )
        {
          v24 = (int)v26;
          if ( v25 == (_DWORD)v26 )
            break;
          v28 = *(_DWORD **)(*(_QWORD *)(v23 + 168) + v27);
          v27 += 8;
          v26 = (unsigned int)(v26 + 1);
          v29 = v28[135] == 2;
          v137 = v28;
          if ( v29 )
          {
            v138 = v24;
            s2c = *(char **)&v133.m128d_f64[0];
            v30 = (*(__int64 (__fastcall **)(_DWORD *, const char *, __int64))(*(_QWORD *)v28 + 136LL))(v28, v18, v26);
            v31 = strcmp(*(const char **)(*(_QWORD *)(v30 + 152) + 8LL), s2c);
            v32 = *(_QWORD *)v28;
            if ( v31 )
            {
              s2d = *(char **)&v133.m128d_f64[0];
              v33 = (*(__int64 (__fastcall **)(_DWORD *))(v32 + 144))(v28);
              v18 = s2d;
              if ( strcmp(*(const char **)(*(_QWORD *)(v33 + 152) + 8LL), s2d) )
                goto LABEL_12;
              v32 = *(_QWORD *)v28;
            }
            s2e = *a2;
            v34 = (*(__int64 (__fastcall **)(_DWORD *))(v32 + 136))(v28);
            if ( !strcmp(*(const char **)(*(_QWORD *)(v34 + 152) + 8LL), s2e) )
            {
              v100 = (char *)v129[1];
              v124 = v28;
              if ( v129[1] == v109 )
              {
                std::vector<floops::Mesh *>::_M_realloc_insert<floops::Mesh *>(v129, v109, &v124);
              }
              else
              {
                *(_QWORD *)v129[1] = v28;
                v129[1] = v100 + 8;
              }
              v101 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)v28 + 136LL))(v28);
              v102 = (char *)v131[1];
              v124 = (_DWORD *)v101;
              if ( v131[1] == *(void **)&v107 )
              {
                std::vector<floops::Mesh *>::_M_realloc_insert<floops::Mesh *>(v131, *(_QWORD *)&v107, &v124);
                v107 = v132;
              }
              else
              {
                *(_QWORD *)v131[1] = v101;
                v131[1] = v102 + 8;
              }
              v109 = v130;
            }
            s2f = *a2;
            v35 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)v28 + 144LL))(v28);
            v18 = s2f;
            if ( !strcmp(*(const char **)(*(_QWORD *)(v35 + 152) + 8LL), s2f) )
            {
              v36 = (char *)v129[1];
              v124 = v28;
              if ( v129[1] == v109 )
              {
                v18 = v109;
                std::vector<floops::Mesh *>::_M_realloc_insert<floops::Mesh *>(v129, v109, &v124);
                v109 = v130;
              }
              else
              {
                *(_QWORD *)v129[1] = v28;
                v129[1] = v36 + 8;
              }
              v37 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)v28 + 144LL))(v28);
              v38 = (char *)v131[1];
              v124 = (_DWORD *)v37;
              if ( v131[1] == *(void **)&v107 )
              {
                v18 = *(const char **)&v107;
                std::vector<floops::Mesh *>::_M_realloc_insert<floops::Mesh *>(v131, *(_QWORD *)&v107, &v124);
                v107 = v132;
              }
              else
              {
                *(_QWORD *)v131[1] = v37;
                v131[1] = v38 + 8;
              }
            }
            goto LABEL_12;
          }
        }
        v59 = v129[0];
        v138 = v25;
        v60 = v131[0];
        s2 = ((char *)v129[1] - (char *)v129[0]) >> 3;
        if ( v129[0] == v129[1] || !s2 )
        {
          if ( v131[0] )
            operator delete(v131[0], *(_QWORD *)&v107 - (unsigned __int64)v131[0]);
          if ( !v59 )
            goto LABEL_44;
        }
        else
        {
          v61 = 0;
          do
          {
            for ( i = 0; i != s2; ++i )
              sinterconnect::siGeneralBoundary::zipping_distance(
                0.0,
                a4.m128d_f64[0],
                a5.m128d_f64[0],
                (__int64)this,
                (__int64)v125,
                (__int64)v127,
                v60[v61],
                v59[v61],
                v60[i],
                v59[i]);
            ++v61;
          }
          while ( v61 < i );
          operator delete(v60, *(_QWORD *)&v107 - (_QWORD)v60);
        }
        operator delete(v59, v109 - (const char *)v59);
LABEL_44:
        std::string::_M_dispose(&v133);
        goto LABEL_45;
      }
      if ( !v20 )
        goto LABEL_10;
      v99 = COERCE_DOUBLE(v134);
    }
    v18 = v19;
    memcpy(*(void **)&v99, v19, v21);
    v20 = (size_t)v135;
    v22 = v133.m128d_f64[0];
    goto LABEL_11;
  }
  v41 = *(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL);
  v139 = 0;
  v42 = -1;
  v135 = &off_7A758D0;
  v136 = v41 + 160;
LABEL_26:
  v43 = *(_DWORD *)(v41 + 180);
  v44 = 8LL * v42 + 8;
  while ( ++v42 != v43 )
  {
    v45 = *(_DWORD **)(*(_QWORD *)(v41 + 168) + v44);
    v44 += 8;
    v29 = v45[135] == 2;
    v137 = v45;
    if ( v29 )
    {
      v46 = *(_QWORD *)v45;
      v138 = v42;
      v47 = (*(__int64 (__fastcall **)(_DWORD *))(v46 + 136))(v45);
      v48 = *(_QWORD *)v45;
      if ( *(_DWORD *)(v47 + 540) != 5 )
      {
        if ( *(_DWORD *)((*(__int64 (__fastcall **)(_DWORD *))(v48 + 144))(v45) + 540) != 5 )
          goto LABEL_26;
        v48 = *(_QWORD *)v45;
      }
      s2g = *a2;
      v49 = (*(__int64 (__fastcall **)(_DWORD *))(v48 + 136))(v45);
      v50 = (void **)s2g;
      v51 = strcmp(*(const char **)(*(_QWORD *)(v49 + 152) + 8LL), s2g);
      v55 = *(_QWORD *)v45;
      if ( !v51 )
      {
        s2h = (char *)(*(__int64 (__fastcall **)(_DWORD *))(v55 + 136))(v45);
        v56 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)v45 + 136LL))(v45);
        v50 = v125;
        sinterconnect::siGeneralBoundary::zipping_distance(
          0.0,
          a4.m128d_f64[0],
          a5.m128d_f64[0],
          (__int64)this,
          (__int64)v125,
          (__int64)v127,
          v56,
          (int)v45,
          (__int64)s2h,
          (int)v45);
        v55 = *(_QWORD *)v45;
        v54 = v103;
      }
      s2i = *a2;
      v57 = (*(__int64 (__fastcall **)(_DWORD *, void **, char *, __int64, __int64, __int64))(v55 + 144))(
              v45,
              v50,
              *a2,
              v52,
              v53,
              v54);
      if ( !strcmp(*(const char **)(*(_QWORD *)(v57 + 152) + 8LL), s2i) )
      {
        s2j = (char *)(*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)v45 + 144LL))(v45);
        v58 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)v45 + 144LL))(v45);
        sinterconnect::siGeneralBoundary::zipping_distance(
          0.0,
          a4.m128d_f64[0],
          a5.m128d_f64[0],
          (__int64)this,
          (__int64)v125,
          (__int64)v127,
          v58,
          (int)v45,
          (__int64)s2j,
          (int)v45);
        v39 = v104;
      }
      goto LABEL_26;
    }
  }
LABEL_45:
  v108 = pdblib::pdbgetBoolean(
           v111,
           (unsigned int)"Mechanics",
           (unsigned int)"Testing.Zipping.Constant.Traction",
           (_DWORD)pdblib::PDB0,
           v39,
           v40);
  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) == 3 )
  {
    v63 = v125[0];
    v64 = 0;
    v65 = 0;
    if ( v125[1] != v125[0] )
    {
      do
      {
        v66 = (#148 *)v63[v65];
        v132 = 0.0;
        *(_OWORD *)v131 = 0;
        floops::GeneralBoundary::compute_elem_normal(this, v66, (#1602 *)v131, v15, a4, a5);
        v67 = *((double *)v127[0] + v65);
        if ( v67 <= 0.0 )
        {
          s2a = 0.0;
        }
        else
        {
          s2a = v106;
          if ( !v108 )
          {
            s2a = 0.0;
            v68 = 0.8577638849607068 * v105 / v106;
            if ( v67 <= 4.0 * v68 )
              s2a = (v105 + v105) * v67 * exp(-(v67 / v68) * (v67 / v68)) / (v68 * v68);
          }
        }
        a4 = (__m128d)*(unsigned __int64 *)&s2a;
        a4.m128d_f64[0] = s2a
                        * (*(double (__fastcall **)(_QWORD))(**((_QWORD **)v125[0] + v65) + 344LL))(*((_QWORD *)v125[0] + v65));
        a5 = _mm_unpacklo_pd((__m128d)0x4008000000000000uLL, (__m128d)0x4008000000000000uLL);
        v69 = **((_QWORD **)v125[0] + v65);
        v70 = _mm_mul_pd(_mm_unpacklo_pd(a4, a4), *(__m128d *)v131);
        a4.m128d_f64[0] = a4.m128d_f64[0] * v132 / 3.0;
        v134[0] = *(_QWORD *)&a4.m128d_f64[0];
        v15 = (__m128)_mm_div_pd(v70, a5);
        v133 = (__m128d)v15;
        (*(void (__fastcall **)(__int64 (__fastcall ***)()))(v69 + 192))(&v135);
        v71 = v136;
        v72 = ++v138;
        if ( v136 )
        {
          while ( *(_DWORD *)(v71 + 20) != v72 )
          {
            v137 = *(void **)(*(_QWORD *)(v71 + 8) + 8LL * v72);
            v129[0] = v137;
            sub_129E220((char *)this + 720, v129);
            v73 = (_DWORD *)*((_QWORD *)this + 94);
            LODWORD(v129[0]) = 3;
            v112 = (char *)this + 744;
            if ( v73 == *((_DWORD **)this + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v73, v129);
            }
            else
            {
              *v73 = 3;
              *((_QWORD *)this + 94) = v73 + 1;
            }
            v74 = *((_QWORD *)this + 97);
            v110 = (char *)this + 768;
            if ( v74 == *((_QWORD *)this + 98) )
            {
              std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v74, &v133);
            }
            else
            {
              v75 = v74 + 8;
              *(_QWORD *)(v75 - 8) = v15.m128_u64[0];
              *((_QWORD *)this + 97) = v75;
            }
            v129[0] = v137;
            sub_129E220((char *)this + 720, v129);
            LODWORD(v129[0]) = 4;
            v76 = (_DWORD *)*((_QWORD *)this + 94);
            if ( v76 == *((_DWORD **)this + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>(v112, v76, v129);
            }
            else
            {
              *v76 = 4;
              *((_QWORD *)this + 94) = v76 + 1;
            }
            v77 = *((_QWORD *)this + 97);
            if ( v77 == *((_QWORD *)this + 98) )
            {
              std::vector<double>::_M_realloc_insert<double const&>(v110, v77, &v133.m128d_f64[1]);
            }
            else
            {
              v78 = v77 + 8;
              *(_QWORD *)(v78 - 8) = v15.m128_u64[1];
              *((_QWORD *)this + 97) = v78;
            }
            v129[0] = v137;
            sub_129E220((char *)this + 720, v129);
            LODWORD(v129[0]) = 5;
            v79 = (_DWORD *)*((_QWORD *)this + 94);
            if ( v79 == *((_DWORD **)this + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>(v112, v79, v129);
            }
            else
            {
              *v79 = 5;
              *((_QWORD *)this + 94) = v79 + 1;
            }
            v80 = *((_QWORD *)this + 97);
            if ( v80 == *((_QWORD *)this + 98) )
            {
              std::vector<double>::_M_realloc_insert<double const&>(v110, v80, v134);
            }
            else
            {
              v81 = v80 + 8;
              *(double *)(v81 - 8) = a4.m128d_f64[0];
              *((_QWORD *)this + 97) = v81;
            }
            v71 = v136;
            v72 = ++v138;
            if ( !v136 )
              goto LABEL_66;
          }
          v135 = &off_7A757D0;
          if ( v139 )
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v71 + 8LL))(v71);
        }
        else
        {
LABEL_66:
          v135 = &off_7A757D0;
        }
        v63 = v125[0];
        v65 = ++v64;
      }
      while ( v64 < (unsigned __int64)(((char *)v125[1] - (char *)v125[0]) >> 3) );
    }
  }
  else if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL)
                      + 96LL) == 2 )
  {
    v82 = v125[0];
    if ( v125[1] != v125[0] )
    {
      v83 = 0;
      v84 = 0;
      do
      {
        v85 = (#148 *)v82[v84];
        v132 = 0.0;
        *(_OWORD *)v131 = 0;
        floops::GeneralBoundary::compute_elem_normal(this, v85, (#1602 *)v131, v15, a4, a5);
        v15 = 0;
        v86 = *((double *)v127[0] + v84);
        if ( v86 <= 0.0 )
        {
          s2b = 0.0;
        }
        else
        {
          v87 = v106;
          s2b = v106;
          if ( !v108 )
          {
            s2b = 0.0;
            v15 = (__m128)0x4010000000000000uLL;
            v88 = 0.8577638849607068 * v105 / v106;
            if ( v86 <= 4.0 * v88 )
            {
              v15.m128_u64[1] = 0;
              s2b = (v105 + v105)
                  * v86
                  * exp(-(v86 / v88) * (v86 / v88))
                  / (0.8577638849607068
                   * v105
                   / v87
                   * (0.8577638849607068
                    * v105
                    / v87));
            }
          }
        }
        *(double *)v15.m128_u64 = (*(double (__fastcall **)(_QWORD))(**((_QWORD **)v125[0] + v84) + 344LL))(*((_QWORD *)v125[0] + v84))
                                * s2b;
        a5 = _mm_unpacklo_pd((__m128d)0x3FE0000000000000uLL, (__m128d)0x3FE0000000000000uLL);
        v89 = **((_QWORD **)v125[0] + v84);
        v90 = _mm_mul_pd(_mm_unpacklo_pd((__m128d)v15, (__m128d)v15), *(__m128d *)v131);
        *(double *)v15.m128_u64 = *(double *)v15.m128_u64 * v132 * 0.5;
        a4 = _mm_mul_pd(v90, a5);
        v134[0] = v15.m128_u64[0];
        v133 = a4;
        (*(void (__fastcall **)(__int64 (__fastcall ***)()))(v89 + 192))(&v135);
        v91 = v136;
        v92 = ++v138;
        if ( v136 )
        {
          while ( *(_DWORD *)(v91 + 20) != v92 )
          {
            v137 = *(void **)(*(_QWORD *)(v91 + 8) + 8LL * v92);
            v129[0] = v137;
            sub_129E220((char *)this + 720, v129);
            v93 = (_DWORD *)*((_QWORD *)this + 94);
            LODWORD(v129[0]) = 3;
            if ( v93 == *((_DWORD **)this + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v93, v129);
            }
            else
            {
              *v93 = 3;
              *((_QWORD *)this + 94) = v93 + 1;
            }
            v94 = *((_QWORD *)this + 97);
            if ( v94 == *((_QWORD *)this + 98) )
            {
              std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v94, &v133);
            }
            else
            {
              v95 = v94 + 8;
              *(double *)(v95 - 8) = a4.m128d_f64[0];
              *((_QWORD *)this + 97) = v95;
            }
            v129[0] = v137;
            sub_129E220((char *)this + 720, v129);
            LODWORD(v129[0]) = 4;
            v96 = (_DWORD *)*((_QWORD *)this + 94);
            if ( v96 == *((_DWORD **)this + 95) )
            {
              std::vector<int>::_M_realloc_insert<int>((char *)this + 744, v96, v129);
            }
            else
            {
              *v96 = 4;
              *((_QWORD *)this + 94) = v96 + 1;
            }
            v97 = *((_QWORD *)this + 97);
            if ( v97 == *((_QWORD *)this + 98) )
            {
              std::vector<double>::_M_realloc_insert<double const&>((char *)this + 768, v97, &v133.m128d_f64[1]);
            }
            else
            {
              v98 = v97 + 8;
              *(double *)(v98 - 8) = a4.m128d_f64[1];
              *((_QWORD *)this + 97) = v98;
            }
            v91 = v136;
            v92 = ++v138;
            if ( !v136 )
              goto LABEL_101;
          }
          v135 = &off_7A757D0;
          if ( v139 )
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v91 + 8LL))(v91);
        }
        else
        {
LABEL_101:
          v135 = &off_7A757D0;
        }
        v82 = v125[0];
        v84 = ++v83;
      }
      while ( v83 < (unsigned __int64)(((char *)v125[1] - (char *)v125[0]) >> 3) );
    }
  }
  if ( v127[0] )
    operator delete(v127[0], v128 - (unsigned __int64)v127[0]);
  if ( v125[0] )
    operator delete(v125[0], v126 - (unsigned __int64)v125[0]);
}


//////////////////////////////////////////////////////////////////////
// Function: sinterconnect::siGeneralBoundary::apply_zipping_force(void)
// Address:  0x12ACA60
// Size:     2115 bytes
//////////////////////////////////////////////////////////////////////

void __fastcall sinterconnect::siGeneralBoundary::apply_zipping_force(#2314 *this)
{
  __int64 v1; // rbx
  int v2; // r8d
  int v3; // r9d
  int v4; // r8d
  int v5; // r9d
  const char *v6; // r12
  size_t v7; // rax
  size_t v8; // rbx
  _QWORD *v9; // rdx
  __int64 v10; // rdi
  double v11; // rcx
  double v12; // rdx
  __int64 v13; // rax
  void *v14; // r12
  void *v15; // rbx
  _QWORD *v16; // rax
  __m128i v17; // xmm1
  __m128d v18; // xmm1
  __m128i si128; // xmm3
  _QWORD *v20; // rax
  __m128i v21; // xmm5
  unsigned __int64 v22; // r13
  _QWORD *v23; // r12
  void **v24; // rax
  char **v25; // rsi
  void *v26; // rbx
  _BYTE *v27; // r15
  void **v28; // rdi
  __int64 v29; // r12
  void **v30; // rbx
  _QWORD *v31; // rdi
  _QWORD *v32; // rdi
  __int64 v33; // [rsp+8h] [rbp-2F8h]
  double v34; // [rsp+10h] [rbp-2F0h]
  double v35; // [rsp+18h] [rbp-2E8h]
  __m128i v36; // [rsp+48h] [rbp-2B8h] BYREF
  void *v37; // [rsp+58h] [rbp-2A8h]
  unsigned __int64 v38; // [rsp+60h] [rbp-2A0h]
  #372 *v39; // [rsp+68h] [rbp-298h]
  __m128d v40; // [rsp+70h] [rbp-290h] BYREF
  char v41; // [rsp+8Fh] [rbp-271h] BYREF
  __m128i v42; // [rsp+90h] [rbp-270h]
  __int64 v43; // [rsp+A0h] [rbp-260h]
  __m128i v44; // [rsp+B0h] [rbp-250h] BYREF
  __int64 v45; // [rsp+C0h] [rbp-240h]
  void *src; // [rsp+D0h] [rbp-230h] BYREF
  void *n; // [rsp+D8h] [rbp-228h]
  _QWORD v48[2]; // [rsp+E0h] [rbp-220h] BYREF
  void *v49[2]; // [rsp+F0h] [rbp-210h] BYREF
  __int64 v50; // [rsp+100h] [rbp-200h]
  _QWORD v51[2]; // [rsp+108h] [rbp-1F8h] BYREF
  char v52; // [rsp+118h] [rbp-1E8h]
  void *v53; // [rsp+120h] [rbp-1E0h] BYREF
  void *v54; // [rsp+128h] [rbp-1D8h]
  void *v55; // [rsp+130h] [rbp-1D0h] BYREF
  _QWORD v56[2]; // [rsp+138h] [rbp-1C8h] BYREF
  char v57; // [rsp+148h] [rbp-1B8h]
  double v58; // [rsp+150h] [rbp-1B0h] BYREF
  __int64 v59; // [rsp+158h] [rbp-1A8h]
  _QWORD v60[7]; // [rsp+160h] [rbp-1A0h] BYREF
  _BYTE v61[8]; // [rsp+198h] [rbp-168h] BYREF
  int v62; // [rsp+1A0h] [rbp-160h]
  void *v63[2]; // [rsp+1A8h] [rbp-158h] BYREF
  _QWORD v64[2]; // [rsp+1B8h] [rbp-148h] BYREF
  _QWORD v65[28]; // [rsp+1C8h] [rbp-138h] BYREF
  __int16 v66; // [rsp+2A8h] [rbp-58h]
  __int128 v67; // [rsp+2B0h] [rbp-50h]
  __int128 v68; // [rsp+2C0h] [rbp-40h]

  v39 = this;
  v1 = **(_QWORD **)(floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 64);
  if ( !(unsigned int)pdblib::pdbgetBoolean(
                        v1,
                        (unsigned int)"Mechanics",
                        (unsigned int)"Zipping.Effect",
                        (_DWORD)pdblib::PDB0,
                        v2,
                        v3) )
    return;
  if ( *(_DWORD *)(*(_QWORD *)floops::GlobalObject<floops::GlobalSim>::operator->(floops::_globalPool[0] + 496LL) + 96LL) == 1 )
    FLPS_panic("Zipping model is not availabe in 1D");
  v6 = (const char *)pdblib::pdbgetString(
                       v1,
                       (unsigned int)"Mechanics",
                       (unsigned int)"Zipping.Material",
                       (_DWORD)pdblib::PDB0,
                       v4,
                       v5);
  src = v48;
  if ( !v6 )
    std::__throw_logic_error("basic_string: construction from null is not valid");
  v7 = strlen(v6);
  v58 = *(double *)&v7;
  v8 = v7;
  if ( v7 > 0xF )
  {
    v36.m128i_i64[0] = (__int64)&v58;
    src = (void *)std::string::_M_create(&src, &v58, 0);
    v32 = src;
    *(double *)v48 = v58;
    goto LABEL_51;
  }
  if ( v7 != 1 )
  {
    if ( !v7 )
      goto LABEL_8;
    v32 = v48;
    v36.m128i_i64[0] = (__int64)&v58;
LABEL_51:
    memcpy(v32, v6, v8);
    v7 = *(_QWORD *)&v58;
    v9 = src;
    goto LABEL_9;
  }
  LOBYTE(v48[0]) = *v6;
LABEL_8:
  v9 = v48;
  v36.m128i_i64[0] = (__int64)&v58;
LABEL_9:
  n = (void *)v7;
  *((_BYTE *)v9 + v7) = 0;
  v42 = 0;
  v43 = 0;
  std::ios_base::ios_base((#853 *)v65);
  v66 = 0;
  v10 = v36.m128i_i64[0];
  v67 = 0;
  v65[0] = (char *)&`vtable for'std::ios + 16;
  v68 = 0;
  v11 = `VTT for'std::istringstream[1];
  v12 = `VTT for'std::istringstream[2];
  v65[27] = 0;
  v13 = *(_QWORD *)(*(_QWORD *)&v11 - 24LL);
  v58 = v11;
  v35 = v11;
  *(double *)((char *)&v58 + v13) = v12;
  v59 = 0;
  v34 = v12;
  std::ios::init(*(_QWORD *)(*(_QWORD *)&v11 - 24LL) + v10, 0);
  memset(&v60[1], 0, 48);
  *(_QWORD *)&v58 = (char *)&`vtable for'std::istringstream + 24;
  v65[0] = (char *)&`vtable for'std::istringstream + 64;
  v60[0] = (char *)&`vtable for'std::streambuf + 16;
  std::locale::locale((#1684 *)v61);
  v14 = src;
  v62 = 0;
  v15 = n;
  v60[0] = (char *)&`vtable for'std::stringbuf + 16;
  v63[0] = v64;
  if ( !src && n )
    std::__throw_logic_error("basic_string: construction from null is not valid");
  v53 = n;
  if ( (unsigned __int64)n > 0xF )
  {
    v63[0] = (void *)std::string::_M_create(v63, &v53, 0);
    v31 = v63[0];
    v64[0] = v53;
  }
  else
  {
    if ( n == (void *)1 )
    {
      LOBYTE(v64[0]) = *(_BYTE *)src;
LABEL_14:
      v16 = v64;
      goto LABEL_15;
    }
    if ( !n )
      goto LABEL_14;
    v31 = v64;
  }
  memcpy(v31, v14, (size_t)v15);
  v15 = v53;
  v16 = v63[0];
LABEL_15:
  v63[1] = v15;
  *((_BYTE *)v15 + (_QWORD)v16) = 0;
  v17 = _mm_loadl_epi64(&v36);
  v62 = 8;
  v18 = (__m128d)_mm_unpacklo_epi64(v17, (__m128i)(unsigned __int64)v51);
  v40 = v18;
  std::stringbuf::_M_sync(v60, v63[0], 0, 0);
  std::ios::init(v65, v60);
  si128 = _mm_load_si128((const __m128i *)&v40);
  v53 = 0;
  v54 = v56;
  v55 = 0;
  LOBYTE(v56[0]) = 0;
  v57 = 0;
  v50 = 0;
  LOBYTE(v51[0]) = 0;
  v52 = 1;
  *(__m128i *)v49 = si128;
  v20 = (_QWORD *)std::operator>><char>(v36.m128i_i64[0], &v49[1]);
  if ( (*((_BYTE *)v20 + *(_QWORD *)(*v20 - 24LL) + 32) & 5) != 0 )
  {
    v49[0] = 0;
    v52 = 0;
  }
  *(_QWORD *)&v40.m128d_f64[0] = &v53;
  std::vector<std::string>::vector<std::istream_iterator<std::string,char,std::char_traits<char>,long>,void>(
    &v44,
    v49,
    &v53,
    &v41);
  v21 = _mm_load_si128(&v44);
  v36.m128i_i64[1] = v44.m128i_i64[1];
  v37 = (void *)v44.m128i_i64[0];
  v33 = v45;
  v43 = v45;
  v42 = v21;
  if ( v49[1] != v51 )
    operator delete(v49[1], v51[0] + 1LL);
  if ( v54 != v56 )
    operator delete(v54, v56[0] + 1LL);
  v22 = 0;
  v23 = v37;
  v38 = (v36.m128i_i64[1] - (__int64)v37) >> 5;
  if ( (void *)v36.m128i_i64[1] != v37 )
  {
    while ( 1 )
    {
      v26 = (void *)v23[1];
      v53 = &v55;
      v27 = (_BYTE *)*v23;
      v49[0] = v26;
      if ( (unsigned __int64)v26 > 0xF )
        break;
      if ( v26 == (void *)1 )
      {
        LOBYTE(v55) = *v27;
      }
      else if ( v26 )
      {
        v28 = &v55;
        goto LABEL_31;
      }
      v24 = &v55;
LABEL_26:
      v54 = v26;
      v25 = *(char ***)&v40.m128d_f64[0];
      *((_BYTE *)v26 + (_QWORD)v24) = 0;
      sinterconnect::siGeneralBoundary::apply_zipping_force(v39, v25, 0.0, v18, (__m128d)(unsigned __int64)v51);
      if ( v53 != &v55 )
        operator delete(v53, (unsigned __int64)v55 + 1);
      ++v22;
      v23 += 4;
      if ( v22 >= v38 )
        goto LABEL_34;
    }
    v53 = (void *)std::string::_M_create(*(_QWORD *)&v40.m128d_f64[0], v49, 0);
    v28 = (void **)v53;
    v55 = v49[0];
LABEL_31:
    memcpy(v28, v27, (size_t)v26);
    v26 = v49[0];
    v24 = (void **)v53;
    goto LABEL_26;
  }
LABEL_34:
  *(_QWORD *)&v58 = (char *)&`vtable for'std::istringstream + 24;
  v65[0] = (char *)&`vtable for'std::istringstream + 64;
  v60[0] = (char *)&`vtable for'std::stringbuf + 16;
  if ( v63[0] != v64 )
    operator delete(v63[0], v64[0] + 1LL);
  v60[0] = (char *)&`vtable for'std::streambuf + 16;
  std::locale::~locale((#1684 *)v61);
  v58 = v35;
  *(double *)((char *)&v58 + *(_QWORD *)(*(_QWORD *)&v35 - 24LL)) = v34;
  v59 = 0;
  v65[0] = (char *)&`vtable for'std::ios + 16;
  std::ios_base::~ios_base((#853 *)v65);
  v29 = v36.m128i_i64[1];
  v30 = (void **)v37;
  if ( (void *)v36.m128i_i64[1] != v37 )
  {
    do
    {
      if ( *v30 != v30 + 2 )
        operator delete(*v30, (unsigned __int64)v30[2] + 1);
      v30 += 4;
    }
    while ( (void **)v29 != v30 );
  }
  if ( v37 )
    operator delete(v37, v33 - (_QWORD)v37);
  if ( src != v48 )
    operator delete(src, v48[0] + 1LL);
}


