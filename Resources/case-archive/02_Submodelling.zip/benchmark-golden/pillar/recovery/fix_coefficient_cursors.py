from pathlib import Path
p=Path('/home/mozztcad/geo3d/src/abi/floops/floops/GeneralBoundary.cpp');s=p.read_text();s=s.replace('floops::BasicSingleStiff entry(1);\n        for(std::size_t i=0;', '''floops::BasicSingleStiff entry(1);
        // Native advances dense coefficient cursors only for nonnegative
        // equation IDs (0x12a717f..0x12a7339); preserve that order even when
        // an earlier face DOF has already been eliminated by a direct BC.
        std::size_t activeRow=0;
        for(std::size_t i=0;''');s=s.replace('entry.rowIds_.data_[0]=row;entry.currentRow_=entry.rows_;','entry.rowIds_.data_[0]=row;entry.currentRow_=entry.rows_;\n            std::size_t activeCol=0;');s=s.replace('penalty*(shape[i]*shape[j])','penalty*(shape[activeRow]*shape[activeCol++])');s=s.replace('penalty*elementsL_[k]*shape[i];','penalty*elementsL_[k]*shape[activeRow++];');p.write_text(s)
