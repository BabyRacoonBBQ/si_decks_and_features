"""Offline audit of every completed native repetition; run only after timing ends."""
from pathlib import Path
import sys, json, hashlib
import h5py
import numpy as np
base=Path(sys.argv[1])
terminal=json.loads((base/'exit.json').read_text())
assert terminal['exit']==0
runs=terminal['runs']
assert len(runs)==12
names=(b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress')
def fields(p):
    with h5py.File(p) as f:
        return {(int(d.attrs['region']),d.attrs['name']):d['values'][:] for d in f['collection/geometry_0/state_0'].values() if d.attrs.get('name') in names}
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
audit=[]
for stage in ('global','unit-fine'):
    reference=fields(base/'r1-vendor'/f'{stage}_sis.tdr')
    for tool in ('vendor','stressthermal'):
        for rep in (1,2,3):
            meta=next(r for r in runs if (r['stage'],r['tool'],r['rep'])==(stage,tool,rep))
            p=base/f'r{rep}-{tool}'/f'{stage}_sis.tdr'
            assert meta['exit']==0 and sha(p)==meta['result_sha256']
            actual=fields(p)
            assert actual.keys()==reference.keys()
            diffs={}
            for name in names:
                keys=[k for k in reference if k[1]==name]
                assert keys
                assert all(actual[k].shape==reference[k].shape and np.isfinite(actual[k]).all() for k in keys)
                error=max(float(np.max(np.abs(actual[k]-reference[k]))) for k in keys)
                scale=max(float(np.max(np.abs(reference[k]))) for k in keys)
                assert error<=1e-8*max(scale,1e-12),(stage,tool,rep,name,error,scale)
                diffs[name.decode()]={'absolute_error_native_units':error,'relative_to_peak':error/max(scale,1e-300)}
            if stage=='unit-fine':
                g=next(r for r in runs if (r['stage'],r['tool'],r['rep'])==('global',tool,rep))
                assert meta['global_input_sha256']==g['result_sha256']
            audit.append({'stage':stage,'tool':tool,'rep':rep,'result_sha256':meta['result_sha256'],'fields':diffs})
result={'passed':True,'runs_checked':len(audit),'reference':'r1-vendor, same stage','full_field_comparisons':audit}
(base/'all-repetitions-field-audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'passed':True,'runs_checked':len(audit)}))
