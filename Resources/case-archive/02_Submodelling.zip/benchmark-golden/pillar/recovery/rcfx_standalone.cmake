# =============================================================================
# rcfx_standalone.cmake —— RCFX 独立程序 rc_run 构建链
# =============================================================================
#
# 本文件是 rc_run 的完整定义：模块静态库、产品入口、链接闭包和运行期
# 路径都在这里，root CMakeLists.txt 只负责 include。第三方依赖一律通过
# cmake/rcfx_toolchain.cmake 导出的 RCFX_* 变量引用，换库版本不改本文件。
#
# 与另外两条链路的边界：
#   sprocess / sinterconnect  geo_* target（cmake/geo_libraries.cmake），本文件不复用
#   RCFX Frida Hook           rcfx_hook_* target（cmake/rcfx_hook_libraries.cmake）
#
# 源文件清单是显式的，按 vendor 模块边界分库，不再从 geo_* target 读取
# SOURCES。清单只包含 rc_run 链接闭包里真正用到的翻译单元：链接器对静态库
# 按符号抽取，从未被抽取的 TU 不进产物，编译它们纯属浪费。新增还原实现时
# 把文件加进对应模块的清单即可。
#
# 模块划分（依赖互相递归，统一放进一个 --start-group，不假装线性分层）：
#
#   rcfx_standalone_base      基础设施与 TCAD 基础层
#   rcfx_standalone_tdr       TDR 文件 I/O
#   rcfx_standalone_pdb       PDB 参数数据库与 Tcl 绑定
#   rcfx_standalone_geometry  几何与网格内核
#   rcfx_standalone_ts4mesh   TS4 网格运行时
#   rcfx_standalone_solver    有限元与线性代数
#   rcfx_standalone_kmc       KMC 模块
#   rcfx_standalone_floops    floops 仿真核心与命令层
#   rcfx_standalone_product   RCFX 产品层
#
# =============================================================================

# -----------------------------------------------------------------------------
# 所有 rc_run 翻译单元共用的编译开关。
#
# RECON_STANDALONE=1 / RECON_RCFX=1 选中共享源码里的 RCFX 独立程序分支；
# RECON_BISECT_ENABLE=0 让 RECON_MAYBE_SKIP* 编成 no-op —— 独立程序没有
# vendor original 可以回退。
#
# 这一组同时给模块库和 rc_run 自己的 TU 使用：产品宏必须整条链路一致，
# 否则同一个 inline 函数在库里和入口 TU 里展开不同，构成 ODR 违例。
# -----------------------------------------------------------------------------
set(RCFX_STANDALONE_DEFINITIONS
    RECON_STANDALONE=1
    RECON_RCFX=1
    RECON_SPROCESS=0
    RECON_BISECT_ENABLE=0
    RECON_CONTACT_BREP_SUPPORT=1
    TS4_RUNTIME_NAMESPACE_ONLY=1)

set(RCFX_STANDALONE_TEST_SUPPORT_DIR
    "${CMAKE_CURRENT_SOURCE_DIR}/tests/standalone/tdr16_init_struct/support")


# -----------------------------------------------------------------------------
# rcfx_standalone_add_library —— 建一个 RCFX 模块静态库。
#   module  模块名，target 为 rcfx_standalone_<module>
#   ARGN    该模块的源文件
# -----------------------------------------------------------------------------
function(rcfx_standalone_add_library module)
    set(target rcfx_standalone_${module})
    if(NOT ARGN)
        message(FATAL_ERROR "rcfx_standalone_add_library(${module}) 缺少源文件")
    endif()

    add_library(${target} STATIC ${ARGN})

    target_include_directories(${target} PRIVATE
        ${RCFX_TOOLCHAIN_INCLUDE_DIRS})

    target_include_directories(${target} SYSTEM PRIVATE
        ${RCFX_BOOST_INCLUDE_DIR})

    target_link_libraries(${target} PUBLIC TBB::tbb)
    target_compile_definitions(${target} PRIVATE
        ${RCFX_STANDALONE_DEFINITIONS}
        DISABLE_RTTI=1)
    target_compile_options(${target} PRIVATE $<$<COMPILE_LANGUAGE:CXX>:-fno-rtti>)

    # 函数级 section，交给 rc_run 链接期的 --gc-sections 收割。
    target_compile_options(${target} PRIVATE -ffunction-sections)

    if(BUILD_TESTING)
        target_include_directories(${target} PRIVATE
            ${RCFX_STANDALONE_TEST_SUPPORT_DIR})
        target_compile_definitions(${target} PRIVATE
            GEO3D_ENABLE_FIELD_SERVER_SNAPSHOT=1)
    endif()
endfunction()

# -----------------------------------------------------------------------------
# rcfx_standalone_base —— 基础设施与 TCAD 基础层（34 个翻译单元）
#
#   src/common 的加解密与 dump 工具、vendor 自带的 cityhash、TcadBase 的
#   消息/计时/随机数底座、TcadMath 的扩展精度算术，以及 MKL 的 CNR/LAYER 包装。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(base
        src/abi/TcadBase/TcadBase/BackCompatibility.cpp
        src/abi/TcadBase/TcadBase/BackCompatibilityDefaults.cpp
        src/abi/TcadBase/TcadBase/BitArray.cpp
        src/abi/TcadBase/TcadBase/Coordinate.cpp
        src/abi/TcadBase/TcadBase/CpuTime.cpp
        src/abi/TcadBase/TcadBase/EncryptionKey.cpp
        src/abi/TcadBase/TcadBase/Event.cpp
        src/abi/TcadBase/TcadBase/FatalError.cpp
        src/abi/TcadBase/TcadBase/Messages.cpp
        src/abi/TcadBase/TcadBase/OutputObject.cpp
        src/abi/TcadBase/TcadBase/RandomGenerator.cpp
        src/abi/TcadBase/TcadBase/RandomGeneratorFactory.cpp
        src/abi/TcadBase/TcadBase/Rounding.cpp
        src/abi/TcadBase/TcadBase/Subject.cpp
        src/abi/TcadBase/TcadBase/Timer.cpp
        src/abi/TcadMath/TcadMath/BigDouble.cpp
        src/abi/TcadMath/TcadMath/DigitVector.cpp
        src/abi/TcadMath/TcadMath/EDouble.cpp
        src/abi/TcadMath/TcadMath/FloatInterval.cpp
        src/abi/TcadMath/TcadMath/IDouble.cpp
        src/abi/TcadMath/TcadMath/IDoubleBase.cpp
        src/abi/TcadMath/TcadMath/Math.cpp
        src/abi/TcadMath/TcadMath/Matrix3.cpp
        src/abi/TcadMath/TcadMath/MersenneRand.cpp
        src/abi/TcadMath/TcadMath/RBigDouble.cpp
        src/abi/TcadMath/TcadMath/UDouble.cpp
        src/abi/TcadMath/TcadMath/ZFloatL.cpp
        src/abi/TcadMath/TcadMath/Zfloat.cpp
        src/abi/mkl/mkl/MKL_CNR.cpp
        src/abi/mkl/mkl/MKL_LAYER.cpp
        src/abi/sentaurus_version/sentaurus_version.cpp
        ${GEO3D_CITYHASH_SOURCE}
        src/common/Aes256Cbc.cpp
        src/common/GcBlockDump.cpp
)

target_link_libraries(rcfx_standalone_base PUBLIC MKL::MKL)

# -----------------------------------------------------------------------------
# rcfx_standalone_tdr —— TDR 文件 I/O（169 个翻译单元）
#
#   src/abi/Tdr/** 全量：Tdr 数据模型、tdr_thi/tdr_tdi/tdr_tsi 读写层、HDF5 后端
#   与 tdr_crypto 过滤器。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(tdr
        src/abi/Tdr/Tdr/Tdr_atom_cryst_properties_base.cpp
        src/abi/Tdr/Tdr/Tdr_boundary.cpp
        src/abi/Tdr/Tdr/Tdr_bulk.cpp
        src/abi/Tdr/Tdr/Tdr_collection.cpp
        src/abi/Tdr/Tdr/Tdr_contact.cpp
        src/abi/Tdr/Tdr/Tdr_crack.cpp
        src/abi/Tdr/Tdr/Tdr_coord_sys.cpp
        src/abi/Tdr/Tdr/Tdr_crystal_properties.cpp
        src/abi/Tdr/Tdr/Tdr_cuboid.cpp
        src/abi/Tdr/Tdr/Tdr_dataset.cpp
        src/abi/Tdr/Tdr/Tdr_edge.cpp
        src/abi/Tdr/Tdr/Tdr_element.cpp
        src/abi/Tdr/Tdr/Tdr_element_edge.cpp
        src/abi/Tdr/Tdr/Tdr_element_face.cpp
        src/abi/Tdr/Tdr/Tdr_element_w_edges.cpp
        src/abi/Tdr/Tdr/Tdr_element_w_faces.cpp
        src/abi/Tdr/Tdr/Tdr_envelop.cpp
        src/abi/Tdr/Tdr/Tdr_face.cpp
        src/abi/Tdr/Tdr/Tdr_gc_geometry.cpp
        src/abi/Tdr/Tdr/Tdr_geometry.cpp
        src/abi/Tdr/Tdr/Tdr_grid.cpp
        src/abi/Tdr/Tdr/Tdr_grid_ten.cpp
        src/abi/Tdr/Tdr/Tdr_hexahedron.cpp
        src/abi/Tdr/Tdr/Tdr_interface.cpp
        src/abi/Tdr/Tdr/Tdr_interface_extractor.cpp
        src/abi/Tdr/Tdr/Tdr_line.cpp
        src/abi/Tdr/Tdr/Tdr_material_properties.cpp
        src/abi/Tdr/Tdr/Tdr_matrix.cpp
        src/abi/Tdr/Tdr/Tdr_miller_indices.cpp
        src/abi/Tdr/Tdr/Tdr_mixed_element.cpp
        src/abi/Tdr/Tdr/Tdr_overlay.cpp
        src/abi/Tdr/Tdr/Tdr_part.cpp
        src/abi/Tdr/Tdr/Tdr_part_env.cpp
        src/abi/Tdr/Tdr/Tdr_point.cpp
        src/abi/Tdr/Tdr/Tdr_polygon.cpp
        src/abi/Tdr/Tdr/Tdr_polyhedron.cpp
        src/abi/Tdr/Tdr/Tdr_prism.cpp
        src/abi/Tdr/Tdr/Tdr_pyramid.cpp
        src/abi/Tdr/Tdr/Tdr_quadrilateral.cpp
        src/abi/Tdr/Tdr/Tdr_rectangle.cpp
        src/abi/Tdr/Tdr/Tdr_reg_ten_bulk.cpp
        src/abi/Tdr/Tdr/Tdr_region.cpp
        src/abi/Tdr/Tdr/Tdr_region_ten.cpp
        src/abi/Tdr/Tdr/Tdr_state.cpp
        src/abi/Tdr/Tdr/Tdr_tag.cpp
        src/abi/Tdr/Tdr/Tdr_tag_group.cpp
        src/abi/Tdr/Tdr/Tdr_tensor.cpp
        src/abi/Tdr/Tdr/Tdr_tensor_rectilinear.cpp
        src/abi/Tdr/Tdr/Tdr_tetrahedron.cpp
        src/abi/Tdr/Tdr/Tdr_transformation.cpp
        src/abi/Tdr/Tdr/Tdr_triangle.cpp
        src/abi/Tdr/Tdr/Tdr_unit.cpp
        src/abi/Tdr/Tdr/Tdr_vector.cpp
        src/abi/Tdr/Tdr/Tdr_vertex.cpp
        src/abi/Tdr/Tdr/Tdr_vertex1.cpp
        src/abi/Tdr/Tdr/Tdr_vertex3.cpp
        src/abi/Tdr/tdr_crypto/Encryption_filter_base.cpp
        src/abi/Tdr/tdr_crypto/TdrCrypto.cpp
        src/abi/Tdr/tdr_thi/Meta_data.cpp
        src/abi/Tdr/tdr_thi/Provenance_info.cpp
        src/abi/Tdr/tdr_thi/Provenance_info_reader.cpp
        src/abi/Tdr/tdr_thi/Provenance_info_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_collection_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_collection_reader_base.cpp
        src/abi/Tdr/tdr_thi/Thi_collection_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_collection_writer_impl.cpp
        src/abi/Tdr/tdr_thi/Thi_coord_sys_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_coord_sys_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_cuboid_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_cuboid_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_base_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_writer_creator.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_writer_scalar.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_writer_tensor_sym.cpp
        src/abi/Tdr/tdr_thi/Thi_dataset_writer_vector.cpp
        src/abi/Tdr/tdr_thi/Thi_element_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_element_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_gc_geometry_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_writer_creator.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_writer_env.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_writer_grid.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_writer_ten.cpp
        src/abi/Tdr/tdr_thi/Thi_geometry_writer_tr.cpp
        src/abi/Tdr/tdr_thi/Thi_hexahedron_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_hexahedron_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_line_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_line_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_material_properties_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_material_properties_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_miller_indices_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_miller_indices_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_overlay_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_part_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_point_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_point_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_polygon_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_polygon_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_polyhedron_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_polyhedron_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_prism_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_prism_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_pyramid_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_pyramid_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_quadrilateral_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_quadrilateral_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_reader_options.cpp
        src/abi/Tdr/tdr_thi/Thi_rectangle_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_rectangle_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_region_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer_bulk.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer_contact.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer_creator.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer_interface.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer_me.cpp
        src/abi/Tdr/tdr_thi/Thi_region_writer_ten.cpp
        src/abi/Tdr/tdr_thi/Thi_state_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_state_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_storage_observer.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_group_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_writer_creator.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_writer_matrix.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_writer_scalar.cpp
        src/abi/Tdr/tdr_thi/Thi_tag_writer_vector.cpp
        src/abi/Tdr/tdr_thi/Thi_tetrahedron_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_tetrahedron_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_transformation_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_triangle_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_triangle_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_unit_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_unit_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_vertex_reader.cpp
        src/abi/Tdr/tdr_thi/Thi_vertex_writer.cpp
        src/abi/Tdr/tdr_thi/Thi_writer_options.cpp
        src/abi/Tdr/tdr_thi/utils.cpp
        src/abi/Tdr/tdr_tdi/Tdi_data_writer.cpp
        src/abi/Tdr/tdr_tdi/Tdi_geometry_writer.cpp
        src/abi/Tdr/tdr_tsi/HMG.cpp
        src/abi/Tdr/tdr_tsi/ICompoundProperty.cpp
        src/abi/Tdr/tdr_tsi/IObject.cpp
        src/abi/Tdr/tdr_tsi/IStorage.cpp
        src/abi/Tdr/tdr_tsi/IStorageOptions.cpp
        src/abi/Tdr/tdr_tsi/OCompoundProperty.cpp
        src/abi/Tdr/tdr_tsi/OObject.cpp
        src/abi/Tdr/tdr_tsi/OStorage.cpp
        src/abi/Tdr/tdr_tsi/OStorageOptions.cpp
        src/abi/Tdr/tdr_tsi/Tdr_exception.cpp
        src/abi/Tdr/tdr_tsi/hdf5/EncryptionFilter.cpp
        src/abi/Tdr/tdr_tsi/hdf5/FilterBase.cpp
        src/abi/Tdr/tdr_tsi/hdf5/ICompoundPropertyImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/IObjectImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/IObjectLinkImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/IStorageImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/OCompoundPropertyImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/OObjectImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/OStorageImpl.cpp
        src/abi/Tdr/tdr_tsi/hdf5/ZLibFilter.cpp
        src/abi/Tdr/tdr_tsi/hdf5/complex_hdf5_type.cpp
        src/abi/Tdr/tdr_tsi/hdf5/h5u.cpp
        src/abi/Tdr/tdr_tsi/hdf5/h5uu.cpp
        src/abi/Tdr/tdr_tsi/hdf5/read_hdf5_attribute.cpp
        src/abi/Tdr/tdr_tsi/hdf5/read_hdf5_dataset.cpp
        src/abi/Tdr/tdr_tsi/hdf5/vertex_hdf5_type.cpp
        src/abi/Tdr/tdr_tsi/hdf5/write_hdf5_attribute.cpp
        src/abi/Tdr/tdr_tsi/hdf5/write_hdf5_dataset.cpp
)

# -----------------------------------------------------------------------------
# rcfx_standalone_pdb —— PDB 参数数据库与 Tcl 绑定（24 个翻译单元）
#
#   pdblib 的参数解析、Datex 编码表和 Tcl 执行层，加上 ParamInterp 的
#   参数插值与合金化合物模型。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(pdb
        src/abi/ParamInterp/ParamInterp/AlloyCompound.cpp
        src/abi/ParamInterp/ParamInterp/ArrayDoubleParam.cpp
        src/abi/ParamInterp/ParamInterp/Base.cpp
        src/abi/ParamInterp/ParamInterp/BinaryBase.cpp
        src/abi/ParamInterp/ParamInterp/Component.cpp
        src/abi/ParamInterp/ParamInterp/DoubleArrayParam.cpp
        src/abi/ParamInterp/ParamInterp/DoubleParam.cpp
        src/abi/ParamInterp/ParamInterp/FourBasesFunctions.cpp
        src/abi/ParamInterp/ParamInterp/Functions.cpp
        src/abi/ParamInterp/ParamInterp/Parameter.cpp
        src/abi/ParamInterp/ParamInterp/ParameterBox.cpp
        src/abi/ParamInterp/ParamInterp/TDoubleParam.cpp
        src/abi/ParamInterp/ParamInterp/ThreeBasesFunctions.cpp
        src/abi/ParamInterp/ParamInterp/TwoBasesFunctions.cpp
        src/abi/ParamInterp/ParamInterp/UnaryBase.cpp
        src/abi/pdblib/DatexCodeTable.cpp
        src/abi/pdblib/DatexNameTable.cpp
        src/abi/pdblib/GlobalAlias.cpp
        src/abi/pdblib/ParamParse.cpp
        src/abi/pdblib/PdbCompat.cpp
        src/abi/pdblib/PdbGet.cpp
        src/abi/pdblib/TclExecution.cpp
        src/abi/pdblib/TclInterp.cpp
        src/abi/pdblib/UserParam.cpp
)

# -----------------------------------------------------------------------------
# rcfx_standalone_geometry —— 几何与网格内核（307 个翻译单元）
#
#   Sm* 系列（Delaunay/MeshGen/Mesh/Boundary/Geom/PolyBool/Datex/Tensor/Io/
#   Offset/Assess/Base/Tools/Bnd）、mgoals 与 mgoalsProcess 的 Brep 与形貌演化、
#   mpn 的 NTree，以及 TcadGeom 的谓词与坐标工具。Clipper2 仅供
#   mgoals::RPolygon2d 使用；RCNet 的 bop 链路使用本地 liblop 还原。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(geometry
        src/abi/SmAssess/SmAssess/MeshQualityReport.cpp
        src/abi/SmAssess/SmAssess/MeshQualityReportParam.cpp
        src/abi/SmBase/SmBase/Cuts.cpp
        src/abi/SmBase/SmBase/SMeshState.cpp
        src/abi/SmBnd/SmBnd/AppendBoundary.cpp
        src/abi/SmBnd/SmBnd/Bnd2D.cpp
        src/abi/SmBnd/SmBnd/BoundaryParam.cpp
        src/abi/SmBnd/SmBnd/RegionLocator2D.cpp
        src/abi/SmBnd/SmBnd/RegionLocator3D.cpp
        src/abi/SmBoundary/SmBoundary/BEdge.cpp
        src/abi/SmBoundary/SmBoundary/BElement.cpp
        src/abi/SmBoundary/SmBoundary/BFace.cpp
        src/abi/SmBoundary/SmBoundary/BItem.cpp
        src/abi/SmBoundary/SmBoundary/BRegion.cpp
        src/abi/SmBoundary/SmBoundary/BVertex.cpp
        src/abi/SmBoundary/SmBoundary/Boundary.cpp
        src/abi/SmBoundary/SmBoundary/RegionLocator3D.cpp
        src/abi/SmBoundary/SmBoundary/SweepBoundary.cpp
        src/abi/SmBoundary/SmBoundary/TransformBoundary.cpp
        src/abi/SmBoundary/SmBoundary/Utilities.cpp
        src/abi/SmDatex/SmDatex/Datex.cpp
        src/abi/SmDatex/SmDatex/DatexBase.cpp
        src/abi/SmDatex/SmDatex/DatexFileInterface.cpp
        src/abi/SmDatex/SmDatex/DatexScanner.cpp
        src/abi/SmDatex/SmDatex/Material.cpp
        src/abi/SmDelaunay/SmDelaunay/Analyzer3D.cpp
        src/abi/SmDelaunay/SmDelaunay/BrepDelPSC.cpp
        src/abi/SmDelaunay/SmDelaunay/Cavity2D.cpp
        src/abi/SmDelaunay/SmDelaunay/Cavity3D.cpp
        src/abi/SmDelaunay/SmDelaunay/ConstraintSolver2D.cpp
        src/abi/SmDelaunay/SmDelaunay/ConstraintSolver3D.cpp
        src/abi/SmDelaunay/SmDelaunay/DelParam.cpp
        src/abi/SmDelaunay/SmDelaunay/DelaunayChecker.cpp
        src/abi/SmDelaunay/SmDelaunay/DelaunayTolerance.cpp
        src/abi/SmDelaunay/SmDelaunay/DelaunizeFaces2D.cpp
        src/abi/SmDelaunay/SmDelaunay/Delaunizer2D.cpp
        src/abi/SmDelaunay/SmDelaunay/Delaunizer3D.cpp
        src/abi/SmDelaunay/SmDelaunay/DiagonalChecker.cpp
        src/abi/SmDelaunay/SmDelaunay/DiagonalFixer2D.cpp
        src/abi/SmDelaunay/SmDelaunay/EdgeFlipper2D.cpp
        src/abi/SmDelaunay/SmDelaunay/ElementOptimizer3D.cpp
        src/abi/SmDelaunay/SmDelaunay/ElementQuality3D.cpp
        src/abi/SmDelaunay/SmDelaunay/ElementSize.cpp
        src/abi/SmDelaunay/SmDelaunay/FaceOptimizer2D.cpp
        src/abi/SmDelaunay/SmDelaunay/FaceQuality2D.cpp
        src/abi/SmDelaunay/SmDelaunay/FaceSize.cpp
        src/abi/SmDelaunay/SmDelaunay/EdgeTime.cpp
        src/abi/SmDelaunay/SmDelaunay/FaceTime.cpp
        src/abi/SmDelaunay/SmDelaunay/FlipFaceConf.cpp
        src/abi/SmDelaunay/SmDelaunay/IntersectingCavity.cpp
        src/abi/SmDelaunay/SmDelaunay/PolygonTriangulation.cpp
        src/abi/SmDelaunay/SmDelaunay/Protect3D.cpp
        src/abi/SmDelaunay/SmDelaunay/Recover2D.cpp
        src/abi/SmDelaunay/SmDelaunay/Recover3D.cpp
        src/abi/SmDelaunay/SmDelaunay/SimpleFlip3D.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverPerturber.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverPerturberImpl.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverRefiner.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverRefinerImpl.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverRemover.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverRemoverImpl.cpp
        src/abi/SmDelaunay/SmDelaunay/SliverRemoverTime.cpp
        src/abi/SmDelaunay/SmDelaunay/SurfaceCavity.cpp
        src/abi/SmDelaunay/SmDelaunay/Utility.cpp
        src/abi/SmDelaunay/SmDelaunay/VertexTree.cpp
        src/abi/SmGeom/SmGeom/PointOctree.cpp
        src/abi/SmGeom/SmGeom/PolygonTriangulation.cpp
        src/abi/SmGeom/SmGeom/TensorUtilities.cpp
        src/abi/SmIo/SmIo/Bnd2Brep.cpp
        src/abi/SmIo/SmIo/Brep2Bnd.cpp
        src/abi/SmIo/SmIo/Mesh2TetGrid.cpp
        src/abi/SmIo/SmIo/Mesh2TriGrid.cpp
        src/abi/SmIo/SmIo/Mesh2SegGrid.cpp
        src/abi/SmMesh/SmMesh/BasicMesh.cpp
        src/abi/SmMesh/SmMesh/Edge.cpp
        src/abi/SmMesh/SmMesh/EdgeAttributes.cpp
        src/abi/SmMesh/SmMesh/Element.cpp
        src/abi/SmMesh/SmMesh/ElementLocator.cpp
        src/abi/SmMesh/SmMesh/Face.cpp
        src/abi/SmMesh/SmMesh/FaceAttributes.cpp
        src/abi/SmMesh/SmMesh/Field.cpp
        src/abi/SmMesh/SmMesh/HalfEdge.cpp
        src/abi/SmMesh/SmMesh/Mesh.cpp
        src/abi/SmMesh/SmMesh/Region.cpp
        src/abi/SmMesh/SmMesh/RegionAssigner2D.cpp
        src/abi/SmMesh/SmMesh/RegionAssigner3D.cpp
        src/abi/SmMesh/SmMesh/RegionMapper.cpp
        src/abi/SmMesh/SmMesh/SurfaceInfo.cpp
        src/abi/SmMesh/SmMesh/Vertex.cpp
        src/abi/SmMesh/SmMesh/VertexAttributes.cpp
        src/abi/SmMeshGen/SmMeshGen/AaParam.cpp
        src/abi/SmMeshGen/SmMeshGen/AppendUtilities.cpp
        src/abi/SmMeshGen/SmMeshGen/BrepImprinter.cpp
        src/abi/SmMeshGen/SmMeshGen/BrepImprinterImpl.cpp
        src/abi/SmMeshGen/SmMeshGen/BrepImprinterSupport.cpp
        src/abi/SmMeshGen/SmMeshGen/CdtInput.cpp
        src/abi/SmMeshGen/SmMeshGen/CdtInput1303.cpp
        src/abi/SmMeshGen/SmMeshGen/CdtInput2D.cpp
        src/abi/SmMeshGen/SmMeshGen/CutMaker.cpp
        src/abi/SmMeshGen/SmMeshGen/GenOffset2D.cpp
        src/abi/SmMeshGen/SmMeshGen/GenOffset3D.cpp
        src/abi/SmMeshGen/SmMeshGen/InputGeometry.cpp
        src/abi/SmMeshGen/SmMeshGen/IsoParam.cpp
        src/abi/SmMeshGen/SmMeshGen/MeshGen2D.cpp
        src/abi/SmMeshGen/SmMeshGen/MeshGen1D.cpp
        src/abi/SmMeshGen/SmMeshGen/MeshGen3D.cpp
        src/abi/SmMeshGen/SmMeshGen/MeshGen3DIsotropic.cpp
        src/abi/SmMeshGen/SmMeshGen/MeshGen3DNew.cpp
        src/abi/SmMeshGen/SmMeshGen/MyContactMapper.cpp
        src/abi/SmMeshGen/SmMeshGen/MyContactMapper2D.cpp
        src/abi/SmMeshGen/SmMeshGen/MyRegionMapper.cpp
        src/abi/SmMeshGen/SmMeshGen/MyRegionMapper2D.cpp
        src/abi/SmMeshGen/SmMeshGen/OldBrepImprinter.cpp
        src/abi/SmMeshGen/SmMeshGen/OldBrepImprinterImpl.cpp
        src/abi/SmMeshGen/SmMeshGen/QualityReporter.cpp
        src/abi/SmMeshGen/SmMeshGen/VolumeChecker.cpp
        src/abi/SmOffset/SmOffset/Brep2DBrep.cpp
        src/abi/SmOffset/SmOffset/Brep2DUtilities.cpp
        src/abi/SmOffset/SmOffset/Brep2DVertexFaceMap.cpp
        src/abi/SmOffset/SmOffset/BrepEdgeBBTree.cpp
        src/abi/SmOffset/SmOffset/BrepEdgeBBoxMapper.cpp
        src/abi/SmOffset/SmOffset/BrepInterfaceExtension.cpp
        src/abi/SmOffset/SmOffset/BrepUtilities.cpp
        src/abi/SmOffset/SmOffset/BrepFaceBBoxMapper.cpp
        src/abi/SmOffset/SmOffset/BrepFaceBBTree.cpp
        src/abi/SmOffset/SmOffset/BrepVertexNormals.cpp
        src/abi/SmOffset/SmOffset/ComputeExtension.cpp
        src/abi/SmOffset/SmOffset/DBrep.cpp
        src/abi/SmOffset/SmOffset/DBrepBBTree.cpp
        src/abi/SmOffset/SmOffset/DBrep2Brep.cpp
        src/abi/SmOffset/SmOffset/DBrepEdge.cpp
        src/abi/SmOffset/SmOffset/DBrepEdgeFaceMap.cpp
        src/abi/SmOffset/SmOffset/DBrepFace.cpp
        src/abi/SmOffset/SmOffset/DBrepNormals.cpp
        src/abi/SmOffset/SmOffset/DBrepRegion.cpp
        src/abi/SmOffset/SmOffset/DBrepUtilities.cpp
        src/abi/SmOffset/SmOffset/DBrepVertex.cpp
        src/abi/SmOffset/SmOffset/DBrepVertexFaceMap.cpp
        src/abi/SmOffset/SmOffset/BBox2Brep.cpp
        src/abi/SmOffset/SmOffset/ExtendPatch.cpp
        src/abi/SmOffset/SmOffset/GenLayers2D.cpp
        src/abi/SmOffset/SmOffset/GenLayers2DSideClasses.cpp
        src/abi/SmOffset/SmOffset/GenLayers3DSideClasses.cpp
        src/abi/SmOffset/SmOffset/GenOffsetImpl.cpp
        src/abi/SmOffset/SmOffset/SnapNormal2Bounds.cpp
        src/abi/SmOffset/SmOffset/GroupFaces.cpp
        src/abi/SmOffset/SmOffset/InterfaceParam.cpp
        src/abi/SmOffset/SmOffset/OffsetParam.cpp
        src/abi/SmOffset/SmOffset/RegionParam.cpp
        src/abi/SmOffset/SmOffset/SmoothOffsetNormals.cpp
        src/abi/SmOffset/SmOffset/TwoSidedOffset.cpp
        src/abi/SmOffset/SmOffset/computeOffsetVector.cpp
        src/abi/SmPolyBool/SmPolyBool/BrepTransform.cpp
        src/abi/SmPolyBool/SmPolyBool/GridRepairer.cpp
        src/abi/SmTools/SmTools/ExtractCrackContactElements.cpp
        src/abi/TcadGeom/TcadGeom/BBNode.cpp
        src/abi/TcadGeom/TcadGeom/BrepInserter2d.cpp
        src/abi/TcadGeom/TcadGeom/Location.cpp
        src/abi/TcadGeom/TcadGeom/Material.cpp
        src/abi/TcadGeom/TcadGeom/Predicates.cpp
        src/abi/TcadGeom/TcadGeom/Simplifier.cpp
        src/abi/TcadGeom/TcadGeom/TriSurger.cpp
        src/abi/TcadGeom/TcadGeom/Vector.cpp
        src/abi/TcadGeom/TcadGeom/toEPoint.cpp
        src/abi/mgoals/mgoals/BigFaceBrepAdapter.cpp
        src/abi/mgoals/mgoals/BigPointAdapter.cpp
        src/abi/mgoals/mgoals/BigPolygon.cpp
        src/abi/mgoals/mgoals/BigPolyhedron.cpp
        src/abi/mgoals/mgoals/BinOctree.cpp
        src/abi/mgoals/mgoals/BinOctreeGenerator.cpp
        src/abi/mgoals/mgoals/BinOctreeOraclePolyOffset.cpp
        src/abi/mgoals/mgoals/BinOctreeSoothe.cpp
        src/abi/mgoals/mgoals/BinTree2d.cpp
        src/abi/mgoals/mgoals/BinTree2dNode.cpp
        src/abi/mgoals/mgoals/BinTree1d.cpp
        src/abi/mgoals/mgoals/BinTree1dNode.cpp
        src/abi/mgoals/mgoals/Brep1d.cpp
        src/abi/mgoals/mgoals/SegmentGrid.cpp
        src/abi/mgoals/mgoals/BinTree3d.cpp
        src/abi/mgoals/mgoals/BinTree3dNode.cpp
        src/abi/mgoals/mgoals/BinTreeDelaunayChecker.cpp
        src/abi/mgoals/mgoals/BinTreeMesh.cpp
        src/abi/mgoals/mgoals/BinTreeMesh2D.cpp
        src/abi/mgoals/mgoals/BinTreeMeshImpl.cpp
        src/abi/mgoals/mgoals/BinTreeParams.cpp
        src/abi/mgoals/mgoals/Boolean.cpp
        src/abi/mgoals/mgoals/Boolean2D.cpp
        src/abi/mgoals/mgoals/BoxIntersecter.cpp
        src/abi/mgoals/mgoals/Brep.cpp
        src/abi/mgoals/mgoals/Brep2d.cpp
        src/abi/mgoals/mgoals/Brep2dDecimator.cpp
        src/abi/mgoals/mgoals/Brep2dMatClassifier.cpp
        src/abi/mgoals/mgoals/Brep2dPointLess.cpp
        src/abi/mgoals/mgoals/Brep2dSurgeon.cpp
        src/abi/mgoals/mgoals/BrepBintreeIntersector.cpp
        src/abi/mgoals/mgoals/BrepDecimator.cpp
        src/abi/mgoals/mgoals/BrepDecimatorPredicatesTools.cpp
        src/abi/mgoals/mgoals/BrepMatClassifier.cpp
        src/abi/mgoals/mgoals/BrepRayTracer.cpp
        src/abi/mgoals/mgoals/BrepRepairer.cpp
        src/abi/mgoals/mgoals/BrepSelfIntersectionTester.cpp
        src/abi/mgoals/mgoals/BrepSimplifier.cpp
        src/abi/mgoals/mgoals/BrepSimplifier2D.cpp
        src/abi/mgoals/mgoals/BrepSurgeon.cpp
        src/abi/mgoals/mgoals/BrepUtilities.cpp
        src/abi/mgoals/mgoals/BrepUtils.cpp
        src/abi/mgoals/mgoals/BrepWindowOp2d.cpp
        src/abi/mgoals/mgoals/BrepWindowOp3d.cpp
        src/abi/mgoals/mgoals/BvhRegionLocator3D.cpp
        src/abi/mgoals/mgoals/BvhTree.cpp
        src/abi/mgoals/mgoals/CellQueryMap2d.cpp
        src/abi/mgoals/mgoals/CellQueryMap3d.cpp
        src/abi/mgoals/mgoals/CloseProximityExpander.cpp
        src/abi/mgoals/mgoals/CloseProximityExpander2D.cpp
        src/abi/mgoals/mgoals/ConstrainedRefinementField.cpp
        src/abi/mgoals/mgoals/Brep1dMatClassifier.cpp
        src/abi/mgoals/mgoals/CellQueryMap1d.cpp
        src/abi/mgoals/mgoals/CountArray.cpp
        src/abi/mgoals/mgoals/Deloop.cpp
        src/abi/mgoals/mgoals/Deloop2D.cpp
        src/abi/mgoals/mgoals/Dfise.cpp
        src/abi/mgoals/mgoals/df_read.cpp
        src/abi/mgoals/mgoals/df_write.cpp
        src/abi/mgoals/mgoals/Dfise1D.cpp
        src/abi/mgoals/mgoals/Dist2SComplex2d.cpp
        src/abi/mgoals/mgoals/Distances2d.cpp
        src/abi/mgoals/mgoals/EPointAdapter.cpp
        src/abi/mgoals/mgoals/EdgeFaceMap.cpp
        src/abi/mgoals/mgoals/EdgeIntersecter.cpp
        src/abi/mgoals/mgoals/FaceBoxIntersections.cpp
        src/abi/mgoals/mgoals/FaceIndexHashCompare.cpp
        src/abi/mgoals/mgoals/FaceIntersecter.cpp
        src/abi/mgoals/mgoals/FaceQueryMap2d.cpp
        src/abi/mgoals/mgoals/FaceQueryMap3d.cpp
        src/abi/mgoals/mgoals/FastTriangulation2D.cpp
        src/abi/mgoals/mgoals/GcBlock.cpp
        src/abi/mgoals/mgoals/GcBlock2Brep.cpp
        src/abi/mgoals/mgoals/GcBlock2Tdr.cpp
        src/abi/mgoals/mgoals/GcBlockSeparator.cpp
        src/abi/mgoals/mgoals/GcData.cpp
        src/abi/mgoals/mgoals/GcPackedPointersMatrix.cpp
        src/abi/mgoals/mgoals/GeometryPolicy.cpp
        src/abi/mgoals/mgoals/GeometryPolicyInCircle.cpp
        src/abi/mgoals/mgoals/GeometryPolicyIntersection.cpp
        src/abi/mgoals/mgoals/GridCharacteristics.cpp
        src/abi/mgoals/mgoals/IntersectionInfo.cpp
        src/abi/mgoals/mgoals/IntersectionInfo2.cpp
        src/abi/mgoals/mgoals/Intersects2d.cpp
        src/abi/GiftWrappingCdt2d.cpp
        src/abi/mgoals/mgoals/MgoalsOp_AddGasOnTop.cpp
        src/abi/mgoals/mgoals/Intersects3d.cpp
        src/abi/mgoals/mgoals/Mesher2d.cpp
        src/abi/mgoals/mgoals/Mesher2dOptions.cpp
        src/abi/mgoals/mgoals/Mesher3dOptions.cpp
        src/abi/mgoals/mgoals/Mgoals.cpp
        src/abi/mgoals/mgoals/Mgoals3d.cpp
        src/abi/mgoals/mgoals/MgoalsState.cpp
        src/abi/mgoals/mgoals/Offset2D.cpp
        src/abi/mgoals/mgoals/OffsetAdaptive.cpp
        src/abi/mgoals/mgoals/OffsetVoxelizer.cpp
        src/abi/mgoals/mgoals/PackedOffset2D.cpp
        src/abi/mgoals/mgoals/PackedOffset3D.cpp
        src/abi/mgoals/mgoals/PerturbInsphere.cpp
        src/abi/mgoals/mgoals/PointEdgeMap.cpp
        src/abi/mgoals/mgoals/PointIndexHashCompare.cpp
        src/abi/mgoals/mgoals/Polygon.cpp
        src/abi/mgoals/mgoals/PolygonBuilder.cpp
        src/abi/mgoals/mgoals/PolygonClipper.cpp
        src/abi/mgoals/mgoals/PolyhedronBuilder.cpp
        src/abi/mgoals/mgoals/Predicates.cpp
        src/abi/mgoals/mgoals/RPolygon2d.cpp
        src/abi/mgoals/mgoals/RPolygon2dLegacy.cpp
        src/abi/mgoals/mgoals/RefinementBox.cpp
        src/abi/mgoals/mgoals/RefinementBoxes.cpp
        src/abi/mgoals/mgoals/RefinementBrepSource.cpp
        src/abi/mgoals/mgoals/Offset1D.cpp
        src/abi/mgoals/mgoals/RefinementField.cpp
        src/abi/mgoals/mgoals/RefinementFieldGroup.cpp
        src/abi/mgoals/mgoals/RefinementMaskSource2d.cpp
        src/abi/mgoals/mgoals/RefinementMaskSource3d.cpp
        src/abi/mgoals/mgoals/RefinementPlaneSource.cpp
        src/abi/mgoals/mgoals/RefinementSource.cpp
        src/abi/mgoals/mgoals/RegionLocator2D.cpp
        src/abi/mgoals/mgoals/RegionLocator3D.cpp
        src/abi/mgoals/mgoals/SaTeardown.cpp
        src/abi/mgoals/mgoals/SegmentPoint.cpp
        src/abi/mgoals/mgoals/SegmentSmMesh.cpp
        src/abi/mgoals/mgoals/SegmentTriangulation.cpp
        src/abi/mgoals/mgoals/Tdr2Brep.cpp
        src/abi/mgoals/mgoals/TetTetIntersectionVolume.cpp
        src/abi/mgoals/mgoals/ThinOffset.cpp
        src/abi/mgoals/mgoals/Utilities2D.cpp
        src/abi/mgoals/mgoals/WindowOp.cpp
        src/abi/mgoals/mgoals/utilities.cpp
        src/abi/mgoalsProcess/gc/GcProcess.cpp
        src/abi/mgoalsProcess/gc/GcVolumeAndAreaFinder.cpp
        src/abi/mgoalsProcess/mask/MaskClass.cpp
        src/abi/mgoalsProcess/mask/MaskOps.cpp
        src/abi/mgoalsProcess/mask/MaskUtil.cpp
        src/abi/mgoalsProcess/mgoalsProcess/AnisotropicEtch.cpp
        src/abi/mgoalsProcess/mgoalsProcess/BrepContactMaker.cpp
        src/abi/mgoalsProcess/mgoalsProcess/BrepContactMaker2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/BrepMatClassifierBridge.cpp
        src/abi/mgoalsProcess/mgoalsProcess/BrepUtilities3D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/DepEtch2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Deposit.cpp
        src/abi/mgoalsProcess/mgoalsProcess/DirEtchDeposit.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Etch.cpp
        src/abi/mgoalsProcess/mgoalsProcess/FastMarch2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/FrontMove2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/GeoHolder.cpp
        src/abi/mgoalsProcess/mgoalsProcess/IsoDepEtch3d.cpp
        src/abi/mgoalsProcess/mgoalsProcess/LevelsetMove2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/MgoalsProcessState.cpp
        src/abi/mgoalsProcess/mgoalsProcess/MgoalsProcessTemplate.cpp
        src/abi/mgoalsProcess/mgoalsProcess/MgoalsProcessTemplate2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/TaperedDepEtch2d.cpp
        src/abi/mgoalsProcess/mgoalsProcess/NewCrystal2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Photo3D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Shadow.cpp
        src/abi/mgoalsProcess/mgoalsProcess/ShadowUtilities.cpp
        src/abi/mgoalsProcess/mgoalsProcess/SimpleDepEtch3d.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Ls3dOracle.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Ls3dContourer.cpp
        src/abi/mgoalsProcess/mgoalsProcess/Ls3dCellContourer.cpp
        src/abi/mgoalsProcess/mgoalsProcess/SpeedFunc2D.cpp
        src/abi/mgoalsProcess/mgoalsProcess/BeamSourceT.cpp
        src/abi/mgoalsProcess/mgoalsProcess/EtchStop.cpp
        src/abi/mgoalsProcess/mgoalsProcess/FourierDepEtch.cpp
        src/abi/mgoalsProcess/mgoalsProcess/SurfaceResponse.cpp
        src/abi/mgoalsProcess/mgoalsProcess/TaperedDepEtch.cpp
        src/abi/mgoalsProcess/mgoalsProcess/ThinLayerIsoDep.cpp
        src/abi/mgoalsProcess/mgoalsProcess/ThinLayerSelIsoDep.cpp
        src/abi/mgoalsProcess/polylib/Polyhedron.cpp
        src/abi/mgoalsProcess/polylib/PolyhedronCylinder.cpp
        src/abi/mgoalsProcess/polylib/PolyhedronFromBrick.cpp
        src/abi/mgoalsProcess/polylib/PolyhedronFromFaces.cpp
        src/abi/mgoalsProcess/polylib/PolyhedronFromSkinning.cpp
        src/abi/mgoalsProcess/polylib/PolyhedronSTI.cpp
        src/abi/mpn/mpn/NTree.cpp
        ${RCFX_CLIPPER1_SOURCE}
        ${GEO3D_CLIPPER2_SOURCE}
)

# -----------------------------------------------------------------------------
# rcfx_standalone_ts4mesh —— TS4 网格运行时（52 个翻译单元）
#
#   src/abi/TS4/**：ts4 命名空间的网格生成、拓扑修复、时间步与 runtime 状态。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(ts4mesh
        src/abi/TS4/TS4/GeometryNamespace.cpp
        src/abi/TS4/TS4/StringNamespace.cpp
        src/abi/TS4/ts4/runtime/Ts4AbiGlobalState.cpp
        src/abi/TS4/ts4/runtime/Ts4ElementAllocator.cpp
        src/abi/TS4/ts4/runtime/Ts4KmcPolicy.cpp
        src/abi/TS4/ts4/runtime/Ts4RuntimeSupport.cpp
        src/abi/TS4/ts4/ts4/MaterialNameFunctions.cpp
        src/abi/TS4/ts4/ts4/TS4DisAll.cpp
        src/abi/TS4/ts4/ts4/TS4DisAllLeaves.cpp
        src/abi/TS4/ts4/ts4/TS4FixFlat.cpp
        src/abi/TS4/ts4/ts4/TS4FixRegions.cpp
        src/abi/TS4/ts4/ts4/TS4GridAdd.cpp
        src/abi/TS4/ts4/ts4/TS4GridAddShell.cpp
        src/abi/TS4/ts4/ts4/TS4GridPrep.cpp
        src/abi/TS4/ts4/ts4/TS4GridSub.cpp
        src/abi/TS4/ts4/ts4/TS4Impurity.cpp
        src/abi/TS4/ts4/ts4/TS4KillNode.cpp
        src/abi/TS4/ts4/ts4/TS4MeshCleanup.cpp
        src/abi/TS4/ts4/ts4/TS4MeshCleanupLeaves.cpp
        src/abi/TS4/ts4/ts4/TS4MeshEnd.cpp
        src/abi/TS4/ts4/ts4/TS4MeshExportMaterial.cpp
        src/abi/TS4/ts4/ts4/TS4MeshExportSolution.cpp
        src/abi/TS4/ts4/ts4/TS4MeshSelfTest.cpp
        src/abi/TS4/ts4/ts4/TS4MeshStartEndExportImport.cpp
        src/abi/TS4/ts4/ts4/TS4MotionSafety.cpp
        src/abi/TS4/ts4/ts4/TS4NodeToTri.cpp
        src/abi/TS4/ts4/ts4/TS4Nxtel.cpp
        src/abi/TS4/ts4/ts4/TS4PolyLeaves.cpp
        src/abi/TS4/ts4/ts4/TS4PtToNode.cpp
        src/abi/TS4/ts4/ts4/TS4QuickTri.cpp
        src/abi/TS4/ts4/ts4/TS4RegionNames.cpp
        src/abi/TS4/ts4/ts4/TS4Stage2Snapshot.cpp
        src/abi/TS4/ts4/ts4/TS4Stage3Json.cpp
        src/abi/TS4/ts4/ts4/TS4TimeStep.cpp
        src/abi/TS4/ts4/ts4/TS4TimeStepLeaves.cpp
        src/abi/TS4/ts4/ts4/TS4TopologyAllocation.cpp
        src/abi/TS4/ts4/ts4/TS4TopologyLookup.cpp
        src/abi/TS4/ts4/ts4/TS4TopologyMutationLeaves.cpp
        src/abi/TS4/ts4/ts4/TS4TopologyRepair.cpp
        src/abi/TS4/ts4/ts4/TS4TopologyRotate.cpp
        src/abi/TS4/ts4/ts4/TS4TrapezoidEtch.cpp
        src/abi/TS4/ts4/ts4/TS4TriangleGeometry.cpp
        src/abi/TS4/ts4/ts4/TS4Velocity.cpp
        src/abi/TS4/ts4/ts4/ts4MeshExportDyDefault.cpp
        src/abi/TS4/ts4/ts4/ts4MeshExportExpanding.cpp
        src/abi/TS4/ts4/ts4/ts4MeshExportFaceData.cpp
        src/abi/TS4/ts4/ts4/ts4MeshExportMethData.cpp
        src/abi/TS4/ts4/ts4/ts4MeshExportRecords.cpp
        src/abi/TS4/ts4/ts4/ts4MeshGetMeshName.cpp
        src/abi/TS4/ts4/ts4/ts4MeshImportFaceData.cpp
        src/abi/TS4/ts4/ts4/ts4MeshImportLeaves.cpp
        src/abi/TS4/ts4/ts4/ts4MeshSolutionData.cpp
)

# -----------------------------------------------------------------------------
# rcfx_standalone_solver —— 有限元与线性代数（29 个翻译单元）
#
#   FE 的单元与材料模型、Mechanics 的矩阵与 Voigt 变换、AlloyHelper、
#   ImpAdaptPrivate，以及 METIS 的最小度排序 mmd。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(solver
        src/abi/AlloyHelper/AlloyHelper.cpp
        src/abi/FE/FE/AbstractMatFactory.cpp
        src/abi/FE/FE/Aniso.cpp
        src/abi/FE/FE/BaseMaterialModel.cpp
        src/abi/FE/FE/CompositeAnisotropicShell.cpp
        src/abi/FE/FE/CompositeIsotropicShell.cpp
        src/abi/FE/FE/Creep.cpp
        src/abi/FE/FE/DefPlasticity.cpp
        src/abi/FE/FE/Elastic.cpp
        src/abi/FE/FE/IncPlasticity.cpp
        src/abi/FE/FE/IsoparametricElement.cpp
        src/abi/FE/FE/LinearHex.cpp
        src/abi/FE/FE/LinearPrism.cpp
        src/abi/FE/FE/LinearPyramid.cpp
        src/abi/FE/FE/LinearQuad.cpp
        src/abi/FE/FE/LinearTet.cpp
        src/abi/FE/FE/MaterialModel.cpp
        src/abi/FE/FE/MechMatFactory.cpp
        src/abi/FE/FE/P1Tet.cpp
        src/abi/FE/FE/P1Hex.cpp
        src/abi/FE/FE/P1Prism.cpp
        src/abi/FE/FE/P1Pyramid.cpp
        src/abi/FE/FE/P1Hex.cpp
        src/abi/FE/FE/P1Prism.cpp
        src/abi/FE/FE/P1Pyramid.cpp
        src/abi/FE/FE/PlaneStress.cpp
        src/abi/FE/FE/Tet_1pt_gauss.cpp
        src/abi/FE/FE/Tet_4pt_gauss.cpp
        src/abi/FE/FE/Hex_27pt_gauss.cpp
        src/abi/FE/FE/Prism_6pt_gauss.cpp
        src/abi/FE/FE/Pyramid_5pt_gauss.cpp
        src/abi/FE/FE/ViscoElastic.cpp
        src/abi/FE/FE/ViscoElastic_sls.cpp
        src/abi/FE/FE/ViscoPlasticity.cpp
        src/abi/ImpAdaptPrivate/ImpAdaptPrivate/ImpAdaptPrivate.cpp
        src/abi/Mechanics/Mechanics/Matrix.cpp
        src/abi/Mechanics/Mechanics/VoigtTransform.cpp
)

# -----------------------------------------------------------------------------
# rcfx_standalone_kmc —— KMC 模块（1 个翻译单元）
#
#   RCFX 闭包里只剩 SP_ReactionCmd 这一个翻译单元；KMCInterface 的 handler
#   全链路不在 rc_run 的链接闭包内。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(kmc
        src/abi/KMC/KMC/SP_ReactionCmd.cpp
)

# -----------------------------------------------------------------------------
# rcfx_standalone_floops —— floops 仿真核心与命令层（356 个翻译单元）
#
#   src/abi/floops/**：全局态、结构与网格管理、表达式与场求解、解算器
#   驱动，以及全部 *_tcl / *Cmd 命令实现。RCFX 闭包里最大的一个模块。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(floops
        src/abi/floops/floops/AmbientClass.cpp
        src/abi/floops/floops/AnalyticImplantExecutor.cpp
        src/abi/floops/floops/AnalyticImplantProfile.cpp
        src/abi/floops/floops/AnalyticImplantTable.cpp
        src/abi/sprocess/sprocess/Implant.cpp
        src/abi/sprocess/sprocess/LPim.cpp
        src/abi/sprocess/sprocess/HeatAbsorption.cpp
        src/abi/floops/floops/AnnealChainProbeStubs.cpp
        src/abi/floops/floops/AnnealChainProbeSymbols.cpp
        src/abi/floops/floops/ArrheniusCmd.cpp
        src/abi/BM/BM/BMBaseGrid.cpp
        src/abi/BM/BM/BMData.cpp
        src/abi/BM/BM/BMDataSet.cpp
        src/abi/BM/BM/BMFunGrid.cpp
        src/abi/BM/BM/BMGrid.cpp
        src/abi/BM/BM/BMGridPerVertex.cpp
        src/abi/BM/BM/BMUtil.cpp
        src/abi/BM/BM/FNC_k_filename.cpp
        src/abi/JLIB/JLIB/JLIB_k_timer.cpp
        src/abi/BM/BM/NDF_k_geometry.cpp
        src/abi/BM/BM/DatexMatManager.cpp
        src/abi/BM/BM/CVPL_BuildVPolygon.cpp
        src/abi/BM/BM/EdgeElementInfo.cpp
        src/abi/BM/BM/FVData.cpp
        src/abi/BM/BM/FVMethod.cpp
        src/abi/BM/BM/IISObtuseElement2D.cpp
        src/abi/BM/BM/NonDelaunayElements2D.cpp
        src/abi/BM/BM/IISObtuseElement3D.cpp
        src/abi/BM/BM/MeshInfo.cpp
        src/abi/BM/BM/NonDelaunayData.cpp
        src/abi/BM/BM/NonDelaunayInfo.cpp
        src/abi/BM/BM/NonDelaunayList.cpp
        src/abi/BM/BM/Tee.cpp
        src/abi/BM/BM/ObtuseElements.cpp
        src/abi/BM/BM/VertexFaceInfo.cpp
        src/abi/BM/BM/VoronoiLines.cpp
        src/abi/BM/BM/WeightedVertices.cpp
        src/abi/BM/BM/WorkMemory.cpp
        src/abi/floops/floops/Barycentric.cpp
        src/abi/floops/floops/BaseData.cpp
        src/abi/floops/floops/BasicSingleStiff.cpp
        src/abi/floops/floops/BasicStiff.cpp
        src/abi/floops/floops/Beam.cpp
        src/abi/floops/floops/BeamCmd.cpp
        src/abi/floops/floops/BestElementFinder.cpp
        src/abi/floops/floops/BoolData.cpp
        src/abi/floops/floops/BrepCutter.cpp
        src/abi/floops/floops/CircuitNode.cpp
        src/abi/floops/floops/CleanUtilities.cpp
        src/abi/floops/floops/CmdUtil.cpp
        src/abi/floops/floops/CompRowMatrix.cpp
        src/abi/floops/floops/ConstExpr.cpp
        src/abi/floops/floops/Contact.cpp
        src/abi/floops/floops/ContactCmd_contact_tcl.cpp
        src/abi/floops/floops/ContactInterpolator.cpp
        src/abi/floops/floops/ContactMesh.cpp
        src/abi/floops/floops/ContactPDE.cpp
        src/abi/floops/floops/Controller.cpp
        src/abi/floops/floops/ControllerAnneal.cpp
        src/abi/floops/floops/ControllerTs4Stage3.cpp
        src/abi/floops/floops/Coordinate.cpp
        src/abi/floops/floops/CoordinateSystemManager.cpp
        src/abi/floops/floops/CriterionBase.cpp
        src/abi/floops/floops/CrystalOrient.cpp
        src/abi/floops/floops/CutLine.cpp
        src/abi/floops/floops/CutLineParams.cpp
        src/abi/floops/floops/CutMesh.cpp
        src/abi/floops/floops/MarchingTet.cpp
        src/abi/floops/floops/MarchingTri.cpp
        src/abi/floops/floops/CutNode.cpp
        src/abi/floops/floops/DFISEHelper.cpp
        src/abi/floops/floops/DFISEInterface.cpp
        src/abi/floops/floops/DFISEInterfaceHelper.cpp
        src/abi/floops/floops/DataField.cpp
        src/abi/floops/floops/DataManager.cpp
        src/abi/floops/floops/DataProfile.cpp
        src/abi/floops/floops/DataUtil.cpp
        src/abi/floops/floops/DatabaseGet.cpp
        src/abi/floops/floops/DefineCmd.cpp
        src/abi/floops/floops/DepEtchSpecError.cpp
        src/abi/floops/floops/DepEtchSpecParamParse.cpp
        src/abi/floops/floops/DepositCmd.cpp
        src/abi/floops/floops/DepositSpec.cpp
        src/abi/floops/floops/DiffController.cpp
        src/abi/floops/floops/DiffSolver.cpp
        src/abi/floops/floops/HeatData.cpp
        src/abi/floops/floops/DiffuseAnnealChain.cpp
        src/abi/floops/floops/DiffuseCmd.cpp
        src/abi/floops/floops/DirectMultiRefinementField.cpp
        src/abi/floops/floops/DiscExpr.cpp
        src/abi/floops/floops/DopantProfile.cpp
        src/abi/floops/floops/Doping.cpp
        src/abi/floops/floops/DopingBase.cpp
        src/abi/floops/floops/DopingHandleFactory.cpp
        src/abi/floops/floops/DopingHelper.cpp
        src/abi/floops/floops/DopingProfile.cpp
        src/abi/floops/floops/DopingProfile3D.cpp
        src/abi/floops/floops/DopingRefinementField.cpp
        src/abi/floops/floops/IRF.cpp
        src/abi/floops/floops/Edge.cpp
        src/abi/floops/floops/Edge2.cpp
        src/abi/floops/floops/Element.cpp
        src/abi/floops/floops/ElementInfo.cpp
        src/abi/floops/floops/ElementIter.cpp
        src/abi/floops/floops/ElementUtilHelper.cpp
        src/abi/floops/floops/ElementQueue.cpp
        src/abi/floops/floops/ErrorCriterion.cpp
        src/abi/floops/floops/EtchCmd.cpp
        src/abi/floops/floops/EtchHelper.cpp
        src/abi/floops/floops/EtchSpec.cpp
        src/abi/floops/floops/Expr.cpp
        src/abi/floops/floops/ExprList.cpp
        src/abi/floops/floops/ExprIter.cpp
        src/abi/floops/floops/ExprMInfo.cpp
        src/abi/floops/floops/ExprStore.cpp
        src/abi/floops/floops/ExprTypeStore.cpp
        src/abi/floops/floops/FLPS.cpp
        src/abi/floops/floops/Face.cpp
        src/abi/floops/floops/DistanceHelper.cpp
        src/abi/floops/floops/FaceHelper.cpp
        src/abi/floops/floops/Polynomial.cpp
        src/abi/floops/floops/Face2.cpp
        src/abi/floops/floops/FastMode.cpp
        src/abi/floops/floops/FieldGlobals.cpp
        src/abi/floops/floops/FieldGradient.cpp
        src/abi/floops/floops/FieldServer.cpp
        src/abi/floops/floops/File2Parser.cpp
        src/abi/floops/floops/Find3D.cpp
        src/abi/floops/floops/FindBBTree.cpp
        src/abi/floops/floops/FiniteVolume.cpp
        src/abi/floops/floops/FiniteVolData.cpp
        src/abi/floops/floops/SideVoronoiIntersect.cpp
        src/abi/floops/floops/FloopsCmd.cpp
        src/abi/floops/floops/FloopsLicenseManager.cpp
        src/abi/floops/floops/FloopsLicenseWrapper.cpp
        src/abi/TCADSCL/TCADSCL/LicenseManager.cpp
        src/abi/floops/floops/FloopsMain.cpp
        src/abi/floops/floops/FloopsOutputObject.cpp
        src/abi/floops/floops/Gas_Flow.cpp
        src/abi/floops/floops/GeneralBoundary.cpp
        src/abi/floops/floops/GenericBC.cpp
        src/abi/floops/floops/GenericID.cpp
        src/abi/floops/floops/GenericPDE.cpp
        src/abi/floops/floops/GeoOps.cpp
        src/abi/floops/floops/GeomData.cpp
        src/abi/floops/floops/GetCrystal.cpp
        src/abi/floops/floops/GlobalHandler.cpp
        src/abi/floops/floops/GlobalParams.cpp
        src/abi/floops/floops/GlobalPool.cpp
        src/abi/floops/floops/GlobalSteps.cpp
        src/abi/floops/floops/GridCmd.cpp
        src/abi/floops/floops/GridLoopHelperFixTop.cpp
        src/abi/floops/floops/GridSubAndAdd.cpp
        src/abi/floops/floops/HoblerProfile.cpp
        src/abi/floops/floops/IFTExpr.cpp
        src/abi/floops/floops/ILS.cpp
        ${RCFX_ILS_ABI_SOURCES}
        src/abi/tbb_support/tbb_support/global_control.cpp
        src/abi/tbb_support/tbb_support/parallel_for.cpp
        src/abi/floops/floops/IcwbCmd.cpp
        src/abi/floops/floops/IcwbCommand.cpp
        src/abi/floops/floops/ImpAdapt.cpp
        src/abi/floops/floops/ImplantCmd.cpp
        src/abi/floops/floops/InitFLOO.cpp
        src/abi/floops/floops/Initialize.cpp
        src/abi/floops/floops/MeshFreeStore.cpp
        src/abi/floops/floops/InputUtil.cpp
        src/abi/floops/floops/IntBlock.cpp
        src/abi/floops/floops/SolverType.cpp
        src/abi/floops/floops/IntData.cpp
        src/abi/floops/floops/IntegrateCmd.cpp
        src/abi/floops/floops/InterfaceMesh.cpp
        src/abi/floops/floops/Interpolator.cpp
        src/abi/floops/floops/IntervalRefinementField.cpp
        src/abi/floops/floops/JobContext.cpp
        src/abi/floops/floops/JobInfo.cpp
        src/abi/floops/floops/LicenseCheck.cpp
        src/abi/floops/floops/LicensePool.cpp
        src/abi/floops/floops/LineCmd.cpp
        src/abi/floops/floops/LocationData.cpp
        src/abi/floops/floops/MGoalsBoxMaker.cpp
        src/abi/floops/floops/MGoalsDimInterface.cpp
        src/abi/floops/floops/MGoalsGenericGeoOp.cpp
        src/abi/floops/floops/MGoalsInterface.cpp
        src/abi/floops/floops/MGoalsInterfaceFlags.cpp
        src/abi/floops/floops/MGoalsInterfaceHelper.cpp
        src/abi/floops/floops/MGoalsInterfaceState.cpp
        src/abi/floops/floops/MGoalsStructureInterface.cpp
        src/abi/floops/floops/Mask2Brep.cpp
        src/abi/floops/floops/Mask2Brep1D.cpp
        src/abi/floops/floops/Mask2Brep2D.cpp
        src/abi/floops/floops/MaskClass.cpp
        src/abi/floops/floops/MaskCmd.cpp
        src/abi/floops/floops/MatInterpolator.cpp
        src/abi/floops/floops/MaterDataManager.cpp
        src/abi/floops/floops/Material.cpp
        src/abi/floops/floops/MaterialHelper.cpp
        src/abi/floops/floops/MathCmd.cpp
        src/abi/floops/floops/MathParams.cpp
        src/abi/floops/floops/Matrix.cpp
        src/abi/floops/floops/MatrixInvert.cpp
        src/abi/floops/floops/MechBC.cpp
        src/abi/floops/floops/MechController.cpp
        src/abi/floops/floops/MechData.cpp
        src/abi/sinterconnect/siMechData.cpp
        src/abi/floops/floops/MechPDE.cpp
        src/abi/floops/floops/StressUpdate.cpp
        src/abi/floops/floops/MechParams.cpp
        src/abi/floops/floops/MechSolver.cpp
        src/abi/floops/floops/MechState.cpp
        src/abi/floops/floops/MechanicsGlobals.cpp
        src/abi/floops/floops/MechanicsSolver.cpp
        src/abi/sinterconnect/siMechanicsSolver.cpp
        src/abi/sinterconnect/siMechPDE.cpp
        src/abi/floops/floops/Mesh.cpp
        src/abi/floops/floops/StructHelper.cpp
        src/abi/floops/floops/RemoveType.cpp
        src/abi/floops/floops/MeshFlowInterface.cpp
        src/abi/floops/floops/MeshUtil.cpp
        src/abi/floops/floops/MeshUtilData.cpp
        src/abi/floops/floops/MgoalsCmd.cpp
        src/abi/floops/floops/MixedElementOverlap3D.cpp
        src/abi/floops/floops/MultiProfiles3D.cpp
        src/abi/floops/floops/Newton.cpp
        src/abi/floops/floops/NewtonHelper.cpp
        src/abi/floops/floops/Node.cpp
        src/abi/floops/floops/Utility.cpp
        src/abi/floops/floops/Node2.cpp
        src/abi/floops/floops/NodeItem.cpp
        src/abi/floops/floops/OEdge.cpp
        src/abi/floops/floops/OEdgeBag.cpp
        src/abi/floops/floops/OEdgeIter.cpp
        src/abi/floops/floops/OpSpecDepEtch.cpp
        src/abi/floops/floops/OpSpecDeposit.cpp
        src/abi/floops/floops/OpSpecEtch.cpp
        src/abi/floops/floops/OpSpecPhoto.cpp
        src/abi/floops/floops/OutputUtil.cpp
        src/abi/floops/floops/PDEinMaterial.cpp
        src/abi/floops/floops/PInterpolator.cpp
        src/abi/floops/floops/ParamParseHelper.cpp
        src/abi/floops/floops/ParamTableData.cpp
        src/abi/floops/floops/Pardiso.cpp
        src/abi/floops/floops/Symm.cpp
        src/abi/floops/floops/Parse.cpp
        src/abi/floops/floops/Partitioner.cpp
        src/abi/floops/floops/PartitionHelper.cpp
        src/abi/floops/floops/PeriodicTable.cpp
        src/abi/floops/floops/PersistedCommandReplay.cpp
        src/abi/floops/floops/PhotoCmd.cpp
        src/abi/floops/floops/LineEdgeRoughness.cpp
        src/abi/floops/floops/PhotoSpec.cpp
        src/abi/floops/floops/PhysicsDataMap.cpp
        src/abi/floops/floops/PlaceExpr.cpp
        src/abi/floops/floops/PlotLine.cpp
        src/abi/floops/floops/PlotSeg.cpp
        src/abi/floops/floops/PointCmd.cpp
        src/abi/floops/floops/PointData.cpp
        src/abi/floops/floops/PolygonCmd.cpp
        src/abi/floops/floops/PolygonData.cpp
        src/abi/floops/floops/PolyhedronCmd.cpp
        src/abi/floops/floops/PolyhedronFromExtrusion.cpp
        src/abi/floops/floops/PolynomialRoots.cpp
        src/abi/floops/floops/PowExpr.cpp
        src/abi/floops/floops/PrdExpr.cpp
        src/abi/floops/floops/PreCondOnly.cpp
        src/abi/floops/floops/Preconditioner.cpp
        src/abi/floops/floops/Reaction.cpp
        src/abi/floops/floops/RealData.cpp
        src/abi/floops/floops/RefineboxCmd.cpp
        src/abi/floops/floops/RegionCmd.cpp
        src/abi/floops/floops/RegionHelper.cpp
        src/abi/floops/floops/RegionNaming.cpp
        src/abi/floops/floops/RelExpr.cpp
        src/abi/floops/floops/RestartUtil.cpp
        src/abi/floops/floops/RuntimeContext.cpp
        src/abi/floops/floops/SCMHandler.cpp
        src/abi/floops/floops/SCMHandlerManager.cpp
        src/abi/floops/floops/SVNotifierHandler.cpp
        src/abi/floops/floops/SVSmartNotifier.cpp
        src/abi/floops/floops/SdeObject.cpp
        src/abi/floops/floops/SetTemp_tcl.cpp
        src/abi/floops/floops/SimFnExpr.cpp
        src/abi/floops/floops/SingleDense.cpp
        src/abi/floops/floops/SingleStiff.cpp
        src/abi/floops/floops/SolExpr.cpp
        src/abi/floops/floops/Solution.cpp
        src/abi/floops/floops/SolutionID.cpp
        src/abi/floops/floops/Solver.cpp
        src/abi/floops/floops/SsourceCmd.cpp
        src/abi/floops/floops/SsourceDecrypt.cpp
        src/abi/floops/floops/StaticDense.cpp
        src/abi/floops/floops/Stats.cpp
        src/abi/floops/floops/Stiff.cpp
        src/abi/floops/floops/StrExpr.cpp
        src/abi/floops/floops/StripCmd.cpp
        src/abi/floops/floops/StripSpec.cpp
        src/abi/floops/floops/StructSpec.cpp
        src/abi/floops/floops/StructureCmd.cpp
        src/abi/floops/floops/StructureManager.cpp
        src/abi/floops/floops/StructureManagerParams.cpp
        src/abi/floops/floops/StructureService.cpp
        src/abi/floops/floops/StructureState.cpp
        src/abi/floops/floops/StructureUtilities.cpp
        src/abi/floops/floops/StructureWriter.cpp
        src/abi/floops/floops/Substrate.cpp
        src/abi/floops/floops/ComExpr.cpp
        src/abi/floops/floops/SumExpr.cpp
        src/abi/floops/floops/SymTensorData.cpp
        src/abi/floops/floops/TDRInterfaceHelper.cpp
        src/abi/floops/floops/TS4interfaceConfig.cpp
        src/abi/floops/floops/TS4interfaceCtor.cpp
        src/abi/floops/floops/TS4interfaceEtchTrapez.cpp
        src/abi/floops/floops/TS4interfaceExportData.cpp
        src/abi/floops/floops/TS4interfaceFieldserver.cpp
        src/abi/floops/floops/TS4interfaceImportData.cpp
        src/abi/floops/floops/TS4interfaceMakeNative.cpp
        src/abi/floops/floops/TS4interfaceNativeStorage.cpp
        src/abi/floops/floops/TbStopwatch.cpp
        src/abi/floops/floops/Tcl_Main2.cpp
        src/abi/floops/floops/TdrWriterUtils.cpp
        src/abi/floops/floops/Tdr_reader.cpp
        src/abi/floops/floops/Tdr_writer.cpp
        src/abi/floops/floops/Tee.cpp
        src/abi/floops/floops/Temp_Ramp.cpp
        src/abi/floops/floops/Temp_Ramp_Cmd.cpp
        src/abi/floops/floops/Tensor.cpp
        src/abi/floops/floops/Term.cpp
        src/abi/floops/floops/TermList.cpp
        src/abi/floops/floops/TimeStepManager.cpp
        src/abi/floops/floops/Time_TRBDF.cpp
        src/abi/floops/floops/ToolVersion.cpp
        src/abi/floops/floops/TransformCmd.cpp
        src/abi/floops/floops/TriLineCutter2D.cpp
        src/abi/floops/floops/TriLineCutter3D.cpp
        src/abi/floops/floops/UserDefinedTimePoints.cpp
        src/abi/floops/floops/UserRefinementCriteria.cpp
        src/abi/floops/floops/UserReg.cpp
        src/abi/floops/floops/Vector.cpp
        src/abi/floops/floops/VectorDense.cpp
        src/abi/floops/floops/VectorDynamic.cpp
        src/abi/floops/floops/VectorExpr.cpp
        src/abi/floops/floops/VectorStatic.cpp
        src/abi/floops/floops/VelocitySolution.cpp
        src/abi/floops/floops/Volume.cpp
        src/abi/floops/floops/VolumeHelper.cpp
        src/abi/floops/floops/Volume2.cpp
        src/abi/floops/floops/XYZTicks.cpp
        src/abi/floops/floops/ambient_tcl.cpp
        src/abi/floops/floops/arpack_gv.cpp
        src/abi/floops/floops/doping_tcl.cpp
        src/abi/floops/floops/floopsGetOPT.cpp
        src/abi/floops/floops/mater_tcl.cpp
        src/abi/floops/floops/mechdata_tcl.cpp
        src/abi/floops/floops/reaction_tcl.cpp
        src/abi/floops/floops/sMeshInterface.cpp
        src/abi/floops/floops/sel_var_tcl.cpp
        src/abi/floops/floops/solution_tcl.cpp
        src/abi/floops/floops/sptopo3d.cpp
        src/abi/floops/floops/principal_strain_tcl.cpp
        src/abi/floops/floops/update_substrate_tcl.cpp
        src/abi/floops/floops/principal_stress_tcl.cpp
        src/abi/floops/floops/strain_profile_tcl.cpp
        src/abi/floops/floops/term_tcl.cpp
        src/abi/floops/floops/util3dHelper.cpp
        src/abi/floops/floops/xgPlot.cpp
)

target_link_libraries(rcfx_standalone_floops PUBLIC MKL::MKL)

# -----------------------------------------------------------------------------
# rcfx_standalone_product —— RCFX 产品层（9 个翻译单元）
#
#   src/abi/rcfx 的 solve/supply/license 实现、mpiRcExtraction 的 GcBlockGraph，
#   以及 sprocess 命名空间中被 RCFX 共用的 ImpData 与命令工具。
# -----------------------------------------------------------------------------
rcfx_standalone_add_library(product
        src/abi/mpiRcExtraction/mpiRcExtraction/GcBlockGraph.cpp
        src/abi/sinterconnect/Crack.cpp
        src/abi/rcfx/rcfx/LicensePoolRcfx.cpp
        src/abi/sinterconnect/SI_StructureCmd.cpp
        src/abi/sinterconnect/SolveCmd.cpp
        src/abi/sinterconnect/SolveController.cpp
        src/abi/sinterconnect/SolveModeCmd.cpp
        src/abi/sinterconnect/Supply.cpp
        src/abi/sprocess/sprocess/ImpData.cpp
        src/abi/sprocess/sprocess/SProcessCmdUtil.cpp
        src/abi/sprocess/sprocess/LoadCommand.cpp
        src/abi/sprocess/sprocess/MultipleLoad.cpp
        src/abi/floops/floops/CheckOutLicenseCmd.cpp
        src/abi/floops/floops/EqnCmd.cpp
        src/abi/floops/floops/InterfaceCmd.cpp
        src/abi/floops/floops/SdeCmd.cpp
        src/abi/FE/FE/Assembler.cpp
        src/abi/FE/FE/FiniteElement.cpp
        src/abi/FE/FE/MechanicsAssembler.cpp
        src/abi/FE/FE/integration_scheme.cpp
        src/abi/FE/FE/Hex_8pt_gauss.cpp
        src/abi/FE/FE/CSSEintegration.cpp
        src/abi/FE/FE/TwoDQuad_4pt_gauss.cpp
        src/abi/FE/FE/TwoDQuad_3x3_gauss.cpp
        src/abi/FE/FE/Q1Quad.cpp
        src/abi/FE/FE/P1Tri.cpp
        src/abi/FE/FE/P2Tri.cpp
        src/abi/FE/FE/P2Quad.cpp
        src/abi/FE/FE/LinearTriangle.cpp
        src/abi/FE/FE/QuadraticTriangle.cpp
        src/abi/FE/FE/QuadraticQuad.cpp
        src/abi/FE/FE/TwoDTri_1pt_gauss.cpp
        src/abi/FE/FE/TwoDTri_3pt_gauss.cpp
        src/abi/FE/FE/TwoDQuad_4x4_gauss.cpp
        src/abi/FE/FE/CompositeSolidShellGeometryRecovered.cpp
        src/abi/FE/FE/CompositeSolidShellRecovered.cpp
        src/abi/FE/FE/CompositeSolidShell.cpp
)

# -----------------------------------------------------------------------------
# icwbReader —— 手写 flex 扫描器，带 COMDAT 表。
# 与 vendor 的 force-include 语义一致：直接编进产品可执行文件，不经静态库，
# 避免链接器按符号抽取时丢掉扫描器的表定义。
# -----------------------------------------------------------------------------
set(RCFX_STANDALONE_ICWBREADER_SOURCES
    src/abi/icwbReader/icwbReader/Domain.cpp
    src/abi/icwbReader/icwbReader/GaugeDomain.cpp
    src/abi/icwbReader/icwbReader/HighlightDomain.cpp
    src/abi/icwbReader/icwbReader/MacParser.cpp
    src/abi/icwbReader/icwbReader/MacScanner.cpp
    src/abi/icwbReader/icwbReader/Masks.cpp
    src/abi/icwbReader/icwbReader/PointDomain.cpp
    src/abi/icwbReader/icwbReader/Polygon.cpp
    src/abi/icwbReader/icwbReader/Segment1D.cpp
    src/abi/icwbReader/icwbReader/Segment2D.cpp
    src/abi/icwbReader/icwbReader/Stretch.cpp)


# =============================================================================
# rc_run —— RCFX 独立程序
# =============================================================================
# 产品入口层：main、版本信息、RCFX 命令注册，以及只有独立程序才提供本地
# 定义的进程级全局量（LocalGlobals）。Hook 侧这些全局量保持动态未定义，
# 直接绑定 vendor 存储，因此两条链路不能共用同一批 TU。
add_executable(rc_run
    # RCFX 0x11bd3f0..0x11bd5c0 的全局 new/delete 与此 TU 一致。
    # 复用已核对的实现，直接进入可执行文件，避免静态库未抽取全局重载。
    src/abi/sprocess/sprocess/SProcessAllocator.cpp
    src/abi/rcfx/rcfx/RCFXMain.cpp
    src/abi/rcfx/rcfx/RCFXVersionInfo.cpp
    src/abi/rcfx/rcfx/RcfxCmdUtil.cpp
    src/abi/sinterconnect/RampCmd.cpp
    src/abi/rcfx/rcfx/RegionSizeCmd.cpp
    src/abi/sinterconnect/SupplyCmd.cpp
    src/abi/rcfx/rcfx/LocalGlobals.cpp
    src/abi/floops/floops/IcwbInterface.cpp
    src/abi/gds2tcad/GdsStream.cpp
    src/abi/gdsLBB/record.cpp
    src/abi/gdsLBB/gdsLayLoader.cpp
    src/abi/bop/ciBopAnd.cpp
    src/abi/bop/ciBopNot.cpp
    src/abi/bop/ciBopOr.cpp
    src/abi/bop/bias.cpp
    src/abi/bop/bopLayer.cpp
    src/abi/bop/bopLayerSave.cpp
    src/abi/bop/extractBopPl.cpp
    src/abi/bop/bopPolygon.cpp
    src/abi/bop/listSearchIndex.cpp
    src/abi/bop/lw/lw.cpp
    src/abi/bop/lw/pool.cpp
    src/abi/bop/RcnetLocalGlobals.cpp
    src/abi/bop/tclBopLayer.cpp
    src/abi/layout/ciCellActive.cpp
    src/abi/layout/ciCellBBox.cpp
    src/abi/layout/ciCellEditState.cpp
    src/abi/layout/ciCellObjectAdd.cpp
    src/abi/layout/ciCellOpen.cpp
    src/abi/layout/ciFindInit.cpp
    src/abi/layout/ciLayerAdd.cpp
    src/abi/layout/ciLayerBBox.cpp
    src/abi/layout/ciLayerDelete.cpp
    src/abi/layout/ciLayerName.cpp
    src/abi/layout/ciLayoutClose.cpp
    src/abi/layout/ciLayoutDbu.cpp
    src/abi/layout/ciLayoutFigCommand.cpp
    src/abi/layout/ciLayoutLayers.cpp
    src/abi/layout/ciLayoutOpen.cpp
    src/abi/layout/ciLayoutSave.cpp
    src/abi/layout/ciPolygon.cpp
    src/abi/layout/ciRectangle.cpp
    src/abi/layout/saveWrap.cpp
    src/abi/layout/extractProducer.cpp
    src/abi/layout/layoutFile_impl.cpp
    src/abi/geom/geomFig.cpp
    src/abi/geom/bulkLoadGeomCell.cpp
    src/abi/geom/cell.cpp
    src/abi/geom/eText.cpp
    src/abi/geom/leaf.cpp
    src/abi/geom/layer.cpp
    src/abi/geom/node.cpp
    src/abi/geom/poly.cpp
    src/abi/geom/polygon.cpp
    src/abi/geom/rectangle.cpp
    src/abi/geom/rtree.cpp
    src/abi/geom/text.cpp
    src/abi/geom/vNode.cpp
    src/abi/ilayout/iContainer.cpp
    src/abi/ilayout/iLayer.cpp
    src/abi/ilayout/iObj.cpp
    src/abi/lop/bin.cpp
    src/abi/lop/adrc.cpp
    src/abi/lop/errno_stack.cpp
    src/abi/lop/ho_vm.cpp
    src/abi/lop/host_mem.cpp
    src/abi/lop/libtrb.cpp
    src/abi/lop/lop.cpp
    src/abi/lop/pl_boolean.cpp
    src/abi/lop/pl_helpers.cpp
    src/abi/lop/pl_pnts2trps.cpp
    src/abi/lop/pl_and.cpp
    src/abi/lop/pl_boundary.cpp
    src/abi/lop/pl_relation.cpp
    src/abi/lop/pl_split.cpp
    src/abi/lop/pl_merge.cpp
    src/abi/lop/pl_not.cpp
    src/abi/lop/pl_clean.cpp
    src/abi/lop/pl_trps.cpp
    src/abi/lop/size_vect.cpp
    src/abi/lop/trb_thr.cpp
    src/abi/lop/vmem.cpp
    src/abi/oasis/oasis_stream_t.cpp
    src/abi/oasisLBB/oasisSave.cpp
    src/abi/oasisLBB/layoutMT.cpp
    src/abi/oasisLBB/saveRecord.cpp
    src/abi/rcfx/rcfx/RcnetLayoutEngine.cpp
    src/abi/sinterconnect/BoundaryCmd.cpp
    src/abi/sinterconnect/SI_ContactCmd.cpp
    src/abi/floops/floops/Current_Ramp.cpp
    src/abi/floops/floops/Power_Ramp.cpp
    src/abi/floops/floops/Voltage_Ramp.cpp
    src/abi/floops/floops/SpxParams.cpp
    src/abi/mpiRcExtraction/mpiRcExtraction/Utility.cpp
    ${RCFX_STANDALONE_ICWBREADER_SOURCES})

target_include_directories(rc_run PRIVATE
    ${RCFX_TOOLCHAIN_INCLUDE_DIRS}
    ${CMAKE_CURRENT_BINARY_DIR})

target_compile_options(rc_run PRIVATE
    $<$<COMPILE_LANGUAGE:CXX>:-fno-rtti>
    -ffunction-sections -fdata-sections)
target_compile_definitions(rc_run PRIVATE
    ${RCFX_STANDALONE_DEFINITIONS}
    DISABLE_RTTI=1
    GEO_TCL_LIBRARY_DIR="${RCFX_TCL_SCRIPT_DIR}")

if(BUILD_TESTING)
    target_sources(rc_run PRIVATE
        ${RCFX_STANDALONE_TEST_SUPPORT_DIR}/FieldServerSnapshot.cpp
        ${RCFX_STANDALONE_TEST_SUPPORT_DIR}/StructureManagerSnapshot.cpp
        ${RCFX_STANDALONE_TEST_SUPPORT_DIR}/TriGridSnapshot.cpp)
    target_include_directories(rc_run PRIVATE
        ${RCFX_STANDALONE_TEST_SUPPORT_DIR})
    target_compile_definitions(rc_run PRIVATE
        GEO3D_ENABLE_FIELD_SERVER_SNAPSHOT=1)
endif()

target_link_directories(rc_run PRIVATE ${RCFX_TOOLCHAIN_LINK_DIRS})

# C++ 运行时保持动态链接，不用 -static-libstdc++/-static-libgcc。
#
# 理由：Rocky 8 的 binutils 2.30 读不了 Synopsys GCC 静态 archive 的压缩调试段，
# -static-libstdc++ 在那台构建机上会直接链接失败。本工程需要同时支持
# Rocky 8.10 与 Ubuntu 24.04 两套构建环境。
#
# 第二条理由（TBB 换回动态包后重新成立）：third_party/tbb-2019_U9 的
# libtbb.so.2 自己 DT_NEEDED libstdc++.so.6，静态化 rc_run 会造出两套 C++
# 运行时和两个异常展开器。该 .so 与 rc_run 由同一个 third_party/gcc-12.4.0
# 编出，动态解析到同一份 libstdc++ 才是正确形态。
#
# 运行时定位 libstdc++.so.6 由根 CMakeLists.txt 末尾的 BUILD_RPATH 循环统一
# 补上 GEO3D_GCC_RUNTIME_DIR：libstdc++ 来自编译器的隐式链接目录，CMake 不会
# 把隐式目录写进 RPATH，必须显式补。
target_link_options(rc_run PRIVATE -Wl,--gc-sections)
target_link_options(rc_run PRIVATE "$<$<CONFIG:Release>:-Wl,--strip-all>")

# 模块之间互相引用（floops ↔ geometry ↔ ts4mesh …），统一放进一个
# --start-group，不用假的线性依赖顺序去凑。
target_link_libraries(rc_run PRIVATE
    -Wl,--start-group
    rcfx_standalone_product
    rcfx_standalone_floops
    rcfx_standalone_kmc
    rcfx_standalone_solver
    rcfx_standalone_ts4mesh
    rcfx_standalone_geometry
    rcfx_standalone_pdb
    rcfx_standalone_tdr
    rcfx_standalone_base
    metis_long
    metis
    -Wl,--end-group
    rcnet_zlib
    ${RCFX_HDF5_LIB}
    z
    dl
    ${RCFX_TCL_LIB}
    ${RCFX_OPENSSL_CRYPTO_LIB})

if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU"
   AND CMAKE_CXX_COMPILER_VERSION VERSION_LESS 9)
    target_link_libraries(rc_run PRIVATE stdc++fs)
endif()

target_link_options(rc_run PRIVATE -Wl,--disable-new-dtags)

# libimf / libintlc 必须排在 libm 之前，transcendental 才会解析到 Intel 实现。
target_link_libraries(rc_run PRIVATE
    Intel::iomp5
    Intel::imf
    TBB::tbb
    TBB::tbbmalloc
    MKL::MKL)

set_target_properties(rc_run PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}
    BUILD_RPATH "${RCFX_TOOLCHAIN_RPATH}")
