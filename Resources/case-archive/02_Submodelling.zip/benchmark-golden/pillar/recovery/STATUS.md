# Recovery completed — 2026-10-11

Release sinterconnect_run now completes the original copper-pillar global solve and local submodel using its own global displacement. Essential point constraints are retained. Point displacement and face-point penalty assembly were recovered against vendor evidence; nonzero nodal-rate and anchored face regressions pass.

All three formal repetitions completed for StressThermal and Golden tool - S (12 native stages); all 12 full field datasets and own-global mapping hashes passed audit. Existing Golden tool - A provides three completed own-global pipelines with equivalent regionwise stress recovery.

StressThermal peak Mises: global 887.6781968741105 MPa; local 703.7011053179518 MPa. Median native solve: global 16.69 s; local 43.02 s. Performance observations retain swap/load and timing-scope qualifications; no unconditional speedup claim.

Case 2 Accuracy and Performance values are published in the current seven-slide HTML/draw.io/PPTX/SVG exports. The latest two-row performance layout and all other current pages are preserved. Future Plan changed independently during final checking; its latest content was retained and re-exported. 38 completion checks passed in recovery/completion-audit.json.

Evidence: pillar-benchmark.json; pillar-benchmark-report.md; vm/formal-pillar-recovered-a/all-repetitions-field-audit.json; recovery/source-provenance.json; recovery/point-recovery-final.patch; recovery/build-5.log; recovery/node-rate-verification.json; recovery/face-cursor-verification.json. Source files remain in /home/mozztcad/geo3d; no commit was requested or created.
