from pathlib import Path
import h5py,numpy as np,json
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011')
output={}
for stage in ('global','unit-fine'):
 paths=[root/'point-recovery/global-check-a'/(stage+'_sis.tdr'),root/'formal-pillar-a/r1-vendor'/(stage+'_sis.tdr')]
 if not paths[0].exists():continue
 fields=[]
 for p in paths:
  with h5py.File(p) as f:
   fields.append({(int(d.attrs['region']),d.attrs['name']):d['values'][:] for d in f['collection/geometry_0/state_0'].values() if d.attrs.get('name') in (b'MisesStress',b'StepDisplacement',b'Stress',b'StressEL')})
 a,b=fields;row={}
 for name in (b'MisesStress',b'StepDisplacement',b'Stress',b'StressEL'):
  keys=[k for k in a if k[1]==name]
  row[name.decode()]={'local_peak':max(float(np.max(abs(a[k]))) for k in keys),'vendor_peak':max(float(np.max(abs(b[k]))) for k in keys),'max_abs_difference':max(float(np.max(abs(a[k]-b[k]))) for k in keys)}
 output[stage]=row
(root/'point-recovery/field-comparison-a.json').write_text(json.dumps(output,indent=2));print(json.dumps(output,indent=2))
