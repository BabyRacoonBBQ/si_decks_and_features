// SPDX-License-Identifier: 0BSD
#pragma once

/**
 * @file GeneralBoundary.h
 * @brief 力学求解的边界条件集合：识别、校验并施加各类力学边界条件。
 *
 * IDA 来源: sprocess W-2024.09-SP1 linux64 的 floops::GeneralBoundary。
 */

#include <array>
#include <cstddef>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "abi/TcadBase/TcadBase/Iter.h"
#include "abi/TcadGeom/TcadGeom/Location.h"
#include "abi/TcadMath/TcadMath/P2.h"
#include "abi/TcadMath/TcadMath/P3.h"

namespace FE {
class FiniteElement;
class IsoparametricElement;
}

namespace floops {

class Element;
class FieldServer;
class Matrix;
class MechState;
class Mesh;
class Node;
class VelocitySolution;
class Vector;
enum GrowthType : int;

/**
 * @brief 按原始网格拓扑收集指定编号的外边界元素。
 *
 * 原始实现地址为 W-2024.09-SP1 sinterconnect `0x18a2600`：遍历全维、
 * 非 Gas mesh 的 Borders/lower/Matches 链，只保留唯一邻接到实体 mesh 且
 * `WhichBorder()` 等于 boundary 的 lower element。
 */
void get_boundary_elements(int boundary, std::vector<Element*>& elements);

/**
 * @brief 收集迭代器当前所指的 default/contact mesh 匹配到的实体面。
 *
 * @param contactMesh 指向当前 contact mesh 的迭代器
 * @param elements    输出，匹配到的面单元
 */
void get_contact_elements(TcadBase::Iter<Mesh>& contactMesh,
                          std::vector<Element*>& elements);

/**
 * @brief 收集结构顶面上的单元。
 *
 * @param elements 输出，顶面单元
 */
void get_top_elements(std::vector<Element*>& elements);

/**
 * @brief 一次力学求解用到的全部边界条件。
 *
 * 由求解器在建方程时按速度解与力学状态建出。生命周期分三段：先 identifyBCs 从 pdb
 * 与结构里认出本步生效的边条并归类，再 validate_defined_bc 校验，最后由各 apply_*
 * 把位移、力、压力、应力、周期与耦合条件压进全局矩阵与右端项；Dirichlet 类另走
 * LoadDirichlet 一路按方程号写进解向量。
 */
class GeneralBoundary {
public:
    /**
     * @brief 按速度解与力学状态建一套边界条件。
     *
     * @param velocity 速度解
     * @param growth   生长类型
     * @param state    力学状态
     */
    GeneralBoundary(VelocitySolution& velocity, GrowthType growth, MechState& state);

    /** @brief 析构：释放各表与各单元向量的堆存储。 */
    virtual ~GeneralBoundary();

    /**
     * @brief 统计某类面边条的个数并登记代表单元。
     *
     * @param kind     边条类别
     * @param elements 参与的单元表
     * @param faces    输出，编号到代表单元
     * @return 命中的个数
     */
    virtual int countFaceBCs(int kind, std::vector<Element*>& elements, std::map<int, Element*>& faces);

    /** @brief 施加点力边条。 */
    virtual void apply_point_force();

    /** @brief 施加点位移边条。 */
    virtual void apply_point_disp();

    /** @brief 施加体力边条。 */
    virtual void apply_body_force();

    /**
     * @brief 逐高斯点积分形函数，得到体力分配到各单元 DOF 的权重。
     *
     * 返回向量固定保留二十个槽，线性／二次 hex 分别消耗前 8／20 个。
     *
     * @param finiteElement 提供形函数、积分方案与材料的有限元
     * @return 各自由度上的积分权重
     */
    std::vector<double> apply_body_force_helper1(FE::FiniteElement* finiteElement);

    /** @brief 施加边界面上的边条。 */
    virtual void apply_boundary_bc();

    /**
     * @brief 按定值施加位移边条。
     *
     * @param elements 参与的单元表
     * @param axis     作用分量
     * @param value    位移值
     */
    virtual void apply_displacement(std::vector<Element*>& elements, int axis, double value);

    /**
     * @brief 按定值施加集中力边条。
     *
     * @param elements 参与的单元表
     * @param axis     作用分量
     * @param value    力值
     */
    virtual void apply_force(std::vector<Element*>& elements, int axis, double value);

    /**
     * @brief 按定值施加应力边条。
     *
     * @param elements 参与的单元表
     * @param axis     作用分量
     * @param value    应力值
     */
    virtual void apply_stress(std::vector<Element*>& elements, int axis, double value);

    /**
     * @brief 按刚体运动给一组单元的节点施加位移边条。
     *
     * @param elements    参与的单元表
     * @param axis        作用分量，同时用作取位移分量的下标
     * @param rotation    绕参考点的转动矢量，三个分量
     * @param translation 平移量，三个分量
     * @param center      转动参考点，三个分量
     */
    virtual void apply_displacement_mpc(std::vector<Element*>& elements, int axis, double* rotation,
                                        double* translation, double* center);

    /**
     * @brief 按表达式串施加位移边条。
     *
     * @param elements 参与的单元表
     * @param axis     作用分量
     * @param value    位移表达式
     */
    virtual void apply_displacement(std::vector<Element*>& elements, int axis, char* value);

    /**
     * @brief 把作用在梁截面上的力与力矩按截面惯性矩摊到各节点。
     *
     * @param elements 参与的单元表
     * @param moment   截面上的力矩矢量，三个分量
     * @param force    截面上的合力矢量，三个分量
     * @param reserved 第三个矢量形参，本 build 的 floops 实现整支未读取
     */
    virtual void apply_force_mpc(std::vector<Element*>& elements, double* moment, double* force, double* reserved);

    /**
     * @brief 按表达式串施加集中力边条。
     *
     * @param elements 参与的单元表
     * @param axis     作用分量
     * @param value    力表达式
     */
    virtual void apply_force(std::vector<Element*>& elements, int axis, char* value);

    /**
     * @brief 按表达式串施加应力边条。
     *
     * @param elements 参与的单元表
     * @param axis     作用分量
     * @param value    应力表达式
     */
    virtual void apply_stress(std::vector<Element*>& elements, int axis, char* value);

    /**
     * @brief 逐 3x3 高斯点积分形函数，得到面应力分配到各单元 DOF 的权重。
     *
     * @param nodes   面单元的节点坐标，按等参编号排列
     * @param element 等参单元，提供形函数与其等参导数
     * @return 八个自由度上的积分权重
     */
    std::vector<double> apply_stress_helper1(const TcadGeom::Location* nodes,
                                             FE::IsoparametricElement& element);

    /**
     * @brief 施加均布压力。
     *
     * @param elements 参与的单元表
     * @param value    压力值
     */
    virtual void apply_pressure(std::vector<Element*>& elements, double value);

    /**
     * @brief 施加逐单元给定的压力。
     *
     * @param elements 参与的单元表
     * @param values   逐单元压力值
     * @param scale    整体缩放
     */
    virtual void apply_pressure(std::vector<Element*>& elements, std::vector<double>& values, double scale);

    /** @brief 施加盒状区域内的压力。 */
    virtual void apply_box_pressure();

    /** @brief 施加流体表面张力。 */
    virtual void apply_fluid_tension();

    /** @brief 施加流体压力。 */
    virtual void apply_fluid_pressure();

    /** @brief 施加回流驱动力。 */
    virtual void apply_reflow_force();

    /**
     * @brief 施加线载荷：按线段长度的一半把每段载荷摊到它的两个节点，并累进 TensionForce 场。
     *
     * @param elements 参与的线段单元表
     * @param forces   与 elements 并行，逐线段的三个载荷分量；按值传入
     */
    virtual void apply_line_force(std::vector<Element*>& elements, std::vector<std::vector<double>> forces);

    /** @brief 施加拉链式闭合力。 */
    virtual void apply_zipping_force();

    /**
     * @brief 把点位移边条压进矩阵与右端项；本类为空实现，实际动作在派生类里。
     *
     * @param matrix 全局矩阵，本函数不使用
     * @param rhs    全局右端项，本函数不使用
     */
    virtual void processPointDispBCs(Matrix* matrix, Vector* rhs) {}

    /**
     * @brief 从 pdb 与结构里认出本步生效的边条并归类。
     *
     * @param fieldServer 场服务器，维度由它给出
     * @param flag        为真时只复位边界开关与线性位移参数，随即返回，不识别任何边条
     */
    void identifyBCs(const std::shared_ptr<FieldServer>& fieldServer, bool flag);

    /**
     * @brief 认出各命名边界上的单元。
     *
     * @param fieldServer 场服务器
     */
    void identifyBoundaryElements(const std::shared_ptr<FieldServer>& fieldServer);

    /**
     * @brief 建立各命名边界：依次识别边条、认出边界单元、定出底面边条。
     *
     * @param fieldServer 场服务器，原样转给前两步
     * @param flag        转给 identifyBCs 的同名开关；为真时不识别边条，只复位
     */
    void Boundary(const std::shared_ptr<FieldServer>& fieldServer, bool flag);

    /** @brief 收集 deck 里已定义的边条。 */
    void collect_defined_bc();

    /** @brief 校验已定义的边条彼此不冲突。 */
    void validate_defined_bc();

    /**
     * @brief 校验一对周期边界是否配得上。
     *
     * @param name 边界名
     * @param axis 周期方向
     */
    void validate_pbc_pair(const char* name, int axis);

    /**
     * @brief 打印某个已定义边条。
     *
     * @param name 边界名
     */
    void print_defined_bc(const char* name);

    /**
     * @brief 取某个边条的合法编号。
     *
     * @param name 边条名
     * @return 编号
     */
    int get_valid_bc_number(const char* name);

    /**
     * @brief 某个命名边界是否被约束。
     *
     * @param name 边界名
     * @return 约束级别
     */
    int is_constrained(const char* name);

    /**
     * @brief 本次求解是否走子模型。
     *
     * @return 走则真
     */
    bool is_submodel();

    /** @brief 施加子模型边条。 */
    void apply_submodel();

    /**
     * @brief 施加增强边界条件。
     *
     * @param pairs  接触对表
     * @param values 数值表
     * @param nodes  节点表
     */
    void apply_enhanced_bc(std::vector<int>& pairs, std::vector<double>& values, std::vector<Node*>& nodes);

    /**
     * @brief 统计 Dirichlet 类边条的方程数。
     *
     * @return 方程数
     */
    int countDirichletBCs();

    /**
     * @brief 把 Dirichlet 边条按方程号写进解向量。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param values 方程号到取值
     */
    void LoadDirichlet(Vector& rhs, Vector* sol, std::map<int, double>& values);

    /**
     * @brief 把某一类 Dirichlet 边条写进解向量。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param kind   边条类别
     * @param faces  编号到代表单元
     * @param values 方程号到取值
     */
    void loadDirichletBoundary(Vector& rhs, Vector* sol, int kind, std::map<int, Element*>& faces,
                               std::map<int, double>& values);

    /**
     * @brief 把空洞侧的 Dirichlet 边条写进解向量。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param values 方程号到取值
     * @param nodes  空洞侧节点表
     */
    void loadDirichletVoid(Vector& rhs, Vector* sol, std::map<int, double>& values, std::vector<Node*> nodes);

    /**
     * @brief 把边条整体压进右端项。
     *
     * @param rhs    全局右端项
     * @param values 方程号到取值
     * @param sol    解向量，可为空
     * @param nodes  参与的节点表
     */
    void Load(Vector& rhs, std::map<int, double>& values, Vector* sol, std::vector<Node*> nodes);

    /**
     * @brief 把预置值累加进右端项。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param values 方程号到取值
     */
    void add_rhs(Vector& rhs, Vector* sol, std::map<int, double>& values);

    /**
     * @brief 把指定自由度固定住。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param values 方程号到取值
     */
    void fix_dof(Vector& rhs, Vector* sol, std::map<int, double>& values);

    /**
     * @brief 修正翻转的结构。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param values 方程号到取值
     */
    void fixFlippedStructure(Vector& rhs, Vector* sol, std::map<int, double>& values);

    /**
     * @brief 固定顶面。
     *
     * @param rhs    全局右端项
     * @param sol    解向量，可为空
     * @param values 方程号到取值
     */
    void fixTop(Vector& rhs, Vector* sol, std::map<int, double>& values);

    /** @brief 把衬底标成翻转态。 */
    void setFlippedSubstrate();

    /** @brief 取底面边界。 */
    void bottomBoundary();

    /**
     * @brief 施加周期边界。
     *
     * @param first  一侧单元表
     * @param second 另一侧单元表
     * @param axis   周期方向
     * @param mode   施加方式
     * @param value  周期偏移
     */
    void enforce_periodic(std::vector<Element*>& first, std::vector<Element*>& second, int axis, int mode,
                          double value);

    /**
     * @brief 施加自由度耦合。
     *
     * @param elements 参与的单元表
     * @param axis     耦合分量
     * @param value    耦合系数
     */
    void enforce_coupling(std::vector<Element*>& elements, int axis, double value);

    /**
     * @brief 二维回流力：沿界面网格每个节点的两条入射边方向摊出节点力。
     *
     * @param interfaceMesh 界面网格，遍历它的节点
     * @param materialMesh  承力的体网格，节点力记到它那一侧的单元上
     * @param force         回流力大小
     */
    void apply_reflow2D(Mesh* interfaceMesh, Mesh* materialMesh, double force);

    /**
     * @brief 三维回流力：与二维同源，但要求节点恰好匹配三个单元，且三个分量都入表。
     *
     * @param interfaceMesh 界面网格，遍历它的节点
     * @param materialMesh  承力的体网格，节点力记到它那一侧的单元上
     * @param force         回流力大小
     */
    void apply_reflow3D(Mesh* interfaceMesh, Mesh* materialMesh, double force);

    /** @brief 施加位错驱动的牵引力。 */
    void apply_DDD_traction();

    /** @brief 按位移插值。 */
    void interpolate_displacement();

    /** @brief 按应力插值。 */
    void interpolate_stress();

    /** @brief 按温度插值。 */
    void interpolate_temperature();

    /**
     * @brief 按名字做全局插值。
     *
     * @param name 场名
     */
    void interpolate_global(const char* name);

    /**
     * @brief 按本步速度把各点力作用点的坐标向前挪一个时间步。
     *
     * @param dt 时间步长
     */
    void move_pointforce_node(double dt);

    /** @brief 把本步终了时刻刷进边界对象。 */
    void updateStepEndTime();

    /**
     * @brief 取当前时刻。
     *
     * @return 时刻
     */
    double getTime() const;

    /**
     * @brief 取累计总时间。
     *
     * @return 总时间
     */
    double getTotalTime() const;

    /**
     * @brief 取时间步长。
     *
     * @return 步长
     */
    double getTimeStep() const;

    /**
     * @brief 取当前温度。
     *
     * @return 温度
     */
    double getCurTemp() const;

    /**
     * @brief 取上一步温度。
     *
     * @return 温度
     */
    double getPrevTemp() const;

    /**
     * @brief 求单元外法向。
     *
     * @param element 目标单元
     * @param normal  输出，外法向
     */
    void compute_elem_normal(Element* element, TcadGeom::Location& normal);

    /**
     * @brief 按两条截面主轴求一组单元的面积惯性矩。
     *
     * @param elements   参与的单元表
     * @param firstAxis  截面第一主轴方向
     * @param secondAxis 截面第二主轴方向
     * @param centroid   截面形心，各单元中心相对它取矩
     * @param inertia    输出，依次是绕第二主轴、绕第一主轴与极惯性矩；2D 只写第三项
     */
    void AreaMomentInertia(std::vector<Element*>& elements, TcadGeom::Location& firstAxis,
                           TcadGeom::Location& secondAxis, TcadGeom::Location& centroid,
                           std::array<double, 3>& inertia);

    /**
     * @brief 求一组单元的总面积，并可选地输出面积加权重心与单位平均法向。
     *
     * @param elements 参与的单元表
     * @param centroid 输出，按单元面积加权的重心；传空指针则不计算
     * @param normal   输出，各单元法向之和归一化后的单位法向；传空指针则不计算
     * @return 总面积（2D 为总长度）
     */
    double total_quantity(std::vector<Element*>& elements, TcadGeom::Location* centroid, TcadGeom::Location* normal);

    /**
     * @brief 求多边形分解后的面积。
     *
     * @param points 顶点表
     * @param count  顶点数
     * @return 面积
     */
    double DecomposedArea(TcadGeom::Location* points, int count);

    /**
     * @brief 求线段分解后的长度。
     *
     * @param points 两个端点
     * @return 长度
     */
    double DecomposedLength(TcadGeom::Location* points);

    /**
     * @brief 判点是否落在三角形内。
     *
     * @param x 待判点 x
     * @param y 待判点 y
     * @param a 三角形顶点 a 的坐标对
     * @param b 三角形顶点 b 的坐标对
     * @param c 三角形顶点 c 的坐标对
     * @return 在内则真
     */
    bool in_triangle(double x, double y, double* a, double* b, double* c);

    /**
     * @brief 为节点找主控单元。
     *
     * @param node     待定节点
     * @param elements 候选单元表
     * @param axis     作用分量
     * @param weights  输出，插值权重
     * @return 主控单元在 elements 里的下标，没找到为 -1
     */
    int get_master(Node& node, std::vector<Element*>& elements, int axis, double* weights);

    /**
     * @brief 二维下为节点找主控单元。
     *
     * @param node     待定节点
     * @param elements 候选单元表
     * @param axis     作用分量
     * @param weights  输出，插值权重
     * @return 主控单元在 elements 里的下标，没找到为 -1
     */
    int get_master_2d(Node& node, std::vector<Element*>& elements, int axis, double* weights);

    /**
     * @brief 三维下为节点找主控单元。
     *
     * @param node     待定节点
     * @param elements 候选单元表
     * @param axis     作用分量
     * @param weights  输出，插值权重
     * @return 主控单元在 elements 里的下标，没找到为 -1
     */
    int get_master_3d(Node& node, std::vector<Element*>& elements, int axis, double* weights);

    /**
     * @brief 二维盒与单元求交。
     *
     * @param elements 参与的单元表
     * @param values   输出，逐单元交量
     * @param lower    盒下角
     * @param upper    盒上角
     * @param first    材料名一
     * @param second   材料名二
     */
    void box_intersect2D(std::vector<Element*>& elements, std::vector<double>& values, TcadMath::P2<double> lower,
                         TcadMath::P2<double> upper, std::string first, std::string second);

    /**
     * @brief 三维盒与单元求交。
     *
     * @param elements 参与的单元表
     * @param values   输出，逐单元交量
     * @param lower    盒下角
     * @param upper    盒上角
     * @param first    材料名一
     * @param second   材料名二
     */
    void box_intersect3D(std::vector<Element*>& elements, std::vector<double>& values, TcadMath::P3<double> lower,
                         TcadMath::P3<double> upper, std::string first, std::string second);

    // === ABI 字段（顺序固定，禁止调整）=================================
    VelocitySolution* velocitySolution_{};  // 速度解，构造收下，不归本对象所有
    GrowthType growth_{};                   // 生长类型，构造收下
    bool boundaryActive_[4]{};              // 四个命名边界是否参与，构造清零
    bool bottomAutoFree_{};  // 底面自动放开已生效（四面有约束且 pdb Bottom.Automatic.Free 为真）
    bool noLateralConstraint_{};   // 四个命名边界都没被约束；构造置 1
    int bottomBoundaryKind_{};     // 底面边界的类型码，bottomBoundary 按四面的约束组合定出
    double boundaryDisp_[5][3];    // 各命名边界的线性位移参数 {截距, 倾角, 参考坐标}；构造不写
    double dirichletValue_{};      // Dirichlet 罚因子，构造置 1e12；越界（<1e10 或 >1e18）时钳回 1e12
    int dirichletMethod_{};        // Dirichlet 施加方式：0 罚函数 / 1 矩阵消元 / 2 保对角
    alignas(8) std::byte reserved168_[24]{};  // type TBD: 构造清零后再无访问。类内 82 支、
                                   // 类外 13 支持有方、派生类（无）三处均不碰
    std::byte reserved192_[120];    // type TBD: 构造不写且全程无访问。注意「构造不写」
                                    // 不等于死字段——boundaryDisp_ 同样不由构造写，而是
                                    // identifyBCs 填的；本区大小与 boundaryDisp_ 同为
                                    // 120 字节，但全二进制查无填充方，元素类型无从推定
    std::vector<Element*> boundaryElements_[5]{};  // 各命名边界上的单元，identifyBoundaryElements 填，本对象所有
    std::map<int, Element*> boundaryFaces_[5]{};  // 各命名边界的编号到代表单元，与上表一一配对，本对象所有
    int solverVelocityType_{};                    // 求解器建边界时抄进来的速度解类型
    int equationCount_{};                         // 边条方程数
    Element* bottomElement_{};                    // 底面的代表单元，不归本对象所有
    std::vector<Element*> pointForceElements_{};  // 点力作用单元表，move_pointforce_node 遍历它换算力分量
    bool enhancedBC_{};                           // 是否走增强 BC
    bool submodel_{};                             // 本次求解是否走子模型，is_submodel 算出后缓存在此
    bool flag714_{};                        // type TBD: 构造与 enhancedBC_/submodel_ 一同清零，无读取方
    std::vector<Element*> bcElements_{};    // 已定义边条作用的单元，本对象所有
    std::vector<int> bcKinds_{};            // 与上表并行：边条分量码，3/4/5 依次对应 x/y/z
    std::vector<double> bcValues_{};        // 与上表并行：边条取值
    std::vector<int>* enhancedBCPairs_{};       // apply_enhanced_bc 的接触对输出，不归本对象所有
    std::vector<double>* enhancedBCValues_{};   // apply_enhanced_bc 的数值输出，不归本对象所有
    std::vector<Node*>* enhancedBCNodes_{};     // apply_enhanced_bc 的节点输出，不归本对象所有
    int feOrder_;                           // 有限元阶次，构造从场服务器的 feSimulationOrder_ 抄入
    bool useFELibrary_{};                   // 走 FE 库路径；构造取 pdb Mechanics Use.FE.Library
    MechState* mechState_{};                // 力学状态，构造收下，不归本对象所有
    double bcScale_{};                      // 边条取值的整体缩放，构造置 1.0
    int dimension_;                         // 模拟维度 1/2/3，取自场服务器；非这三者归 0
    double stepEndTime_{};                  // 本步终了时刻，updateStepEndTime 刷新
    // Product point displacement face constraints, sinterconnect @0x12a50f0.
    std::vector<Element*> elementsJ_{};                 // +0x358: skeletal faces
    std::vector<TcadGeom::Location> elementsK_{};        // +0x370: physical points
    std::vector<double> elementsL_{};                   // +0x388: prescribed values
    std::vector<int> elementsM_{};                      // +0x3a0: component indices

};

static_assert(sizeof(GeneralBoundary) == 952, "GeneralBoundary layout must match sprocess");
static_assert(offsetof(GeneralBoundary, velocitySolution_) == 0x008,
              "GeneralBoundary::velocitySolution_ offset mismatch");
static_assert(offsetof(GeneralBoundary, growth_) == 0x010, "GeneralBoundary::growth_ offset mismatch");
static_assert(offsetof(GeneralBoundary, boundaryDisp_) == 0x020, "GeneralBoundary::boundaryDisp_ offset mismatch");
static_assert(offsetof(GeneralBoundary, dirichletValue_) == 0x098, "GeneralBoundary::dirichletValue_ offset mismatch");
static_assert(offsetof(GeneralBoundary, dirichletMethod_) == 0x0A0,
              "GeneralBoundary::dirichletMethod_ offset mismatch");
static_assert(offsetof(GeneralBoundary, bottomBoundaryKind_) == 0x01C,
              "GeneralBoundary::bottomBoundaryKind_ offset mismatch");
static_assert(offsetof(GeneralBoundary, boundaryActive_) == 0x014, "GeneralBoundary::boundaryActive_ offset mismatch");
static_assert(offsetof(GeneralBoundary, boundaryElements_) == 0x138,
              "GeneralBoundary::boundaryElements_ offset mismatch");
static_assert(offsetof(GeneralBoundary, boundaryFaces_) == 0x1B0, "GeneralBoundary::boundaryFaces_ offset mismatch");
static_assert(offsetof(GeneralBoundary, solverVelocityType_) == 0x2A0,
              "GeneralBoundary::solverVelocityType_ offset mismatch");
static_assert(offsetof(GeneralBoundary, equationCount_) == 0x2A4, "GeneralBoundary::equationCount_ offset mismatch");
static_assert(offsetof(GeneralBoundary, bottomElement_) == 0x2A8, "GeneralBoundary::bottomElement_ offset mismatch");
static_assert(offsetof(GeneralBoundary, pointForceElements_) == 0x2B0, "GeneralBoundary::elementsF_ offset mismatch");
static_assert(offsetof(GeneralBoundary, enhancedBC_) == 0x2C8, "GeneralBoundary::enhancedBC_ offset mismatch");
static_assert(offsetof(GeneralBoundary, bcElements_) == 0x2D0, "GeneralBoundary::bcElements_ offset mismatch");
static_assert(offsetof(GeneralBoundary, bcKinds_) == 0x2E8, "GeneralBoundary::bcKinds_ offset mismatch");
static_assert(offsetof(GeneralBoundary, bcValues_) == 0x300, "GeneralBoundary::bcValues_ offset mismatch");
static_assert(offsetof(GeneralBoundary, bcScale_) == 0x340, "GeneralBoundary::bcScale_ offset mismatch");
static_assert(offsetof(GeneralBoundary, enhancedBCPairs_) == 0x318,
              "GeneralBoundary::enhancedBCPairs_ offset mismatch");
static_assert(offsetof(GeneralBoundary, enhancedBCValues_) == 0x320,
              "GeneralBoundary::enhancedBCValues_ offset mismatch");
static_assert(offsetof(GeneralBoundary, enhancedBCNodes_) == 0x328,
              "GeneralBoundary::enhancedBCNodes_ offset mismatch");
static_assert(offsetof(GeneralBoundary, feOrder_) == 0x330, "GeneralBoundary::feOrder_ offset mismatch");
static_assert(offsetof(GeneralBoundary, mechState_) == 0x338, "GeneralBoundary::mechState_ offset mismatch");
static_assert(offsetof(GeneralBoundary, dimension_) == 0x348, "GeneralBoundary::dimension_ offset mismatch");
static_assert(offsetof(GeneralBoundary, stepEndTime_) == 0x350, "GeneralBoundary::stepEndTime_ offset mismatch");
static_assert(offsetof(GeneralBoundary, elementsJ_) == 0x358, "GeneralBoundary::elementsJ_ offset mismatch");
static_assert(offsetof(GeneralBoundary, elementsK_) == 0x370);
static_assert(offsetof(GeneralBoundary, elementsL_) == 0x388);
static_assert(offsetof(GeneralBoundary, elementsM_) == 0x3a0);

}  // namespace floops

namespace sinterconnect {

class siGeneralBoundary final : public floops::GeneralBoundary {
public:
    /**
     * @brief Sinterconnect product boundary, W-2024.09-SP1 @0x12a0f40.
     *
     * The derived type adds no state; product-specific virtual overrides use
     * the base ABI tables at their native offsets.
     */
    siGeneralBoundary(floops::VelocitySolution& velocity,
                      floops::GrowthType growth,
                      floops::MechState& state);
    ~siGeneralBoundary() override;

    int countFaceBCs(int kind, std::vector<floops::Element*>& elements,
                     std::map<int, floops::Element*>& faces) override;
    void apply_point_force() override;
    void apply_point_disp() override;
    /** @brief Product body-force scan, native @0x12a2890. */
    void apply_body_force() override;
    /** @brief Product gravity branch, native @0x12a2380. */
    void apply_gravity();
    /** @brief Product per-element body-force assembly, native @0x12a17d0. */
    void apply_bforce(floops::Element* element, double value, int axis);
    void apply_displacement(std::vector<floops::Element*>& elements, int axis,
                            char* value) override;
    void apply_displacement(std::vector<floops::Element*>& elements, int axis,
                            double value) override;
    void apply_stress(std::vector<floops::Element*>& elements, int axis,
                      double value) override;
    void apply_pressure(std::vector<floops::Element*>& elements,
                        double value) override;
    void apply_pressure(std::vector<floops::Element*>& elements,
                        std::vector<double>& values, double scale) override;
    void apply_zipping_force() override;
    void processPointDispBCs(floops::Matrix* matrix,
                             floops::Vector* rhs) override;
};

static_assert(sizeof(siGeneralBoundary) == 0x3B8,
              "siGeneralBoundary adds no state to GeneralBoundary");

}  // namespace sinterconnect
