from pathlib import Path
import numpy as np,h5py,json,sys
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011/point-recovery')
def fields(p):
 with h5py.File(p) as f:
  return {(int(d.attrs['region']),d.attrs['name']):d['values'][:] for d in f['collection/geometry_0/state_0'].values() if d.attrs.get('name') in (b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress')}
a=fields(root/'rate-regression-c/face-vendor/global_sis.tdr');b=fields(root/'face-cursor-fixed/global_sis.tdr');assert a.keys()==b.keys()
report={}
for name in (b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress'):
 keys=[k for k in a if k[1]==name];err=max(float(np.max(abs(a[k]-b[k]))) for k in keys);scale=max(float(np.max(abs(a[k]))) for k in keys);report[name.decode()]=dict(error=err,relative_error=err/scale)
report['passed']=all(row['relative_error']<1e-8 for row in report.values());(root/'face-cursor-verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
