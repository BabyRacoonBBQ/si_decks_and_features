init tdr=mesh.tdr
pdbSetDouble solid Mechanics BulkModulus 1e12
pdbSetDouble solid Mechanics ShearModulus 5e11
stressdata bc.location=P0 point.coord= {0 0 0} bc.value= {pdx=2<um> pdy=-3<um> pdz=4<um>}
stressdata bc.location=P1 point.coord= {1000 0 0} bc.value= {pdx=2<um> pdy=-3<um> pdz=4<um>}
stressdata bc.location=P2 point.coord= {0 1000 0} bc.value= {pdx=2<um> pdy=-3<um> pdz=4<um>}
stressdata bc.location=P3 point.coord= {0 0 1000} bc.value= {pdx=2<um> pdy=-3<um> pdz=4<um>}
solve time=1<s>
