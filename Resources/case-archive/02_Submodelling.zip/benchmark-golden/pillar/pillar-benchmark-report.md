# Copper-pillar three-tool benchmark

Global flip-chip package and corner-pillar submodel, cooled from 180 to 25 °C. Temperature is prescribed: this case has no solved maximum-temperature accuracy score. Global mesh: 43,994 vertices / 246,681 tetrahedra; local mesh: 75,969 vertices / 422,904 tetrahedra. All three tools map their own global displacement to the local exterior; no golden-tool displacement substitutes for a StressThermal or MAPDL global result.

## Accuracy and support

Current von Mises is computed after volume-weighted recovery of the element stress tensor within each original region; interface sides remain separate. This is verified against native Vendor StressEL, Stress and MisesStress. MAPDL uses the same recovery of exported components. Silicon uses the independently verified default rotated cubic stiffness. The explicitly declared high-viscosity source materials use the documented elastic limit; this is not a general viscoelastic benchmark.

| Stage | StressThermal, MPa | Golden tool - S, MPa | Golden tool - A, MPa | A minus S, % |
|---|---:|---:|---:|---:|
| global | 887.678196874 | 887.678196874 | 887.678179921 | -0.000001910 |
| unit-fine | 703.701105318 | 703.701105318 | 703.700411396 | -0.000098610 |

StressThermal (Release sinterconnect_run) now completes the original global and local models after recovery of point displacement constraints. All original essential constraints remain. Nonzero nodal-rate and face-point regressions reproduce vendor fields; see recovery/implementation-notes.md and recovery/face-cursor-verification.json. The prior failed probe remains historical evidence and is excluded from successful timing scores.

All 12 Vendor/StressThermal native stage results pass full-field comparisons against the corresponding first Vendor run; all six local stages have verified own-global SHA256 provenance. See vm/formal-pillar-recovered-a/all-repetitions-field-audit.json. Formal repetitions retain scalar peaks for every completed run. The first formal Vendor full fields are checked against the audited calibration, and every MAPDL repetition is recovered from native stress exports. Nodal displacement agreement from calibration is retained in the JSON; peak agreement does not establish continuum accuracy or mesh convergence.

## Performance

Medians and ranges of three completed runs. Native total includes native startup/read/solve/postprocessing; Vendor and StressThermal local runs also include displacement mapping, whereas MAPDL mapping and CMD-to-CDB conversion occur outside its native process. Therefore full external stage wall time is shown separately. MAPDL diagnostic exports affect total time; native inclusive solve / computing-solution labels are tool-specific scopes. Do not sum nested module timers or infer an unconditional speedup.

| Tool | Stage | Native total median [range], s | Native solve median [range], s | Full external stage median [range], s |
|---|---|---:|---:|---:|
| vendor | global | 64.000 [61.000, 64.000] | 16.450 [14.890, 16.690] | 65.835 [61.506, 66.069] |
| vendor | unit-fine | 91.000 [90.000, 104.000] | 39.100 [38.230, 50.470] | 92.840 [90.534, 105.649] |
| stressthermal | global | 29.000 [23.000, 31.000] | 16.690 [12.920, 17.720] | 29.815 [24.588, 32.207] |
| stressthermal | unit-fine | 62.000 [53.000, 67.000] | 43.020 [36.840, 48.990] | 63.974 [54.679, 68.618] |
| mapdl | global | 69.188 [69.108, 72.340] | 38.600 [37.400, 40.100] | 74.942 [74.642, 79.372] |
| mapdl | unit-fine | 122.881 [117.263, 124.982] | 77.500 [74.200, 79.800] | 137.323 [132.252, 139.679] |

## Recorded load and machine

Windows 11 Home Chinese 10.0.26200 host, i7-13700F (16 cores / 24 logical processors), 16 GiB RAM; VMware Rocky Linux 8.10 guest, 10 vCPU / 12.4 GiB RAM. Vendor and StressThermal use guest CPU 4, one thread; MAPDL 2026 R1 / 26.1 uses host SMP, one requested thread. Host and guest are distinct environments. VM and MAPDL benchmark solves run sequentially. Full guest inventory and solver hashes are in the JSON.

Each VM solve starts after idle/no-swap samples. Any swap activity during a solve remains in the evidence and qualifies that observation; no runs are silently discarded.

| Tool / rep | Stage | Host mean / peak CPU, % | Min available GiB | VM swap-in / out pages |
|---|---|---:|---:|---:|
| vendor / 1 | global | 8.94 / 25.85 | 0.80 | 0 / 0 |
| vendor / 1 | unit-fine | 14.07 / 50.39 | 0.13 | 43 / 0 |
| stressthermal / 1 | global | 8.42 / 14.02 | 0.35 | 0 / 0 |
| stressthermal / 1 | unit-fine | 9.20 / 26.00 | 0.41 | 0 / 421 |
| vendor / 2 | global | 13.50 / 54.23 | 0.00 | 8 / 0 |
| vendor / 2 | unit-fine | 8.38 / 20.41 | 0.38 | 0 / 0 |
| stressthermal / 2 | global | 10.13 / 25.63 | 0.10 | 0 / 0 |
| stressthermal / 2 | unit-fine | 18.58 / 64.34 | 0.07 | 0 / 1650 |
| vendor / 3 | global | 8.56 / 28.17 | 1.41 | 18 / 0 |
| vendor / 3 | unit-fine | 13.73 / 45.75 | 0.09 | 0 / 0 |
| stressthermal / 3 | global | 17.51 / 28.75 | 1.10 | 0 / 0 |
| stressthermal / 3 | unit-fine | 14.52 / 32.62 | 0.25 | 0 / 0 |
| mapdl / 1 | global | 18.63 / 47.66 | 0.18 | Host run |
| mapdl / 1 | unit-fine | 17.43 / 50.90 | 0.28 | Host run |
| mapdl / 2 | global | 17.50 / 35.71 | 0.99 | Host run |
| mapdl / 2 | unit-fine | 17.14 / 51.58 | 0.35 | Host run |
| mapdl / 3 | global | 13.72 / 23.89 | 2.26 | Host run |
| mapdl / 3 | unit-fine | 11.41 / 28.71 | 0.97 | Host run |

## MAPDL preparation

| Rep | Stage | Measured preparation intervals, s |
|---|---|---|
| 1 | global | conversion_seconds: 1.912; archive_and_driver_preparation_seconds: 3.149 |
| 1 | unit-fine | transfer_container_seconds: 0.244; conversion_including_mapping_seconds: 8.408; archive_and_driver_preparation_seconds: 5.138 |
| 2 | global | conversion_seconds: 1.838; archive_and_driver_preparation_seconds: 4.592 |
| 2 | unit-fine | transfer_container_seconds: 0.225; conversion_including_mapping_seconds: 8.338; archive_and_driver_preparation_seconds: 5.148 |
| 3 | global | conversion_seconds: 1.854; archive_and_driver_preparation_seconds: 3.012 |
| 3 | unit-fine | transfer_container_seconds: 0.258; conversion_including_mapping_seconds: 8.742; archive_and_driver_preparation_seconds: 5.219 |

## Native module timings

CPU and elapsed tables remain separate; medians below retain native labels.

### vendor: global, module_cpu

| Native label | Median seconds |
|---|---:|
| Mechanics assembly (serial mode) | 3.560 |
| Mechanics preassembly | 0.290 |
| Mechanics step | 4.180 |
| Other Program Parts | 1.340 |
| Solver(Mechanics) | 6.910 |
| init command | 3.480 |
| solve command | 0.790 |
| struct command | 6.770 |

### vendor: global, module_elapsed

| Native label | Median seconds |
|---|---:|
| Mechanics assembly (serial mode) | 3.670 |
| Mechanics preassembly | 0.300 |
| Mechanics step | 4.310 |
| Other Program Parts | 1.390 |
| Solver(Mechanics) | 7.140 |
| init command | 3.570 |
| solve command | 0.820 |
| struct command | 6.950 |

### vendor: unit-fine, module_cpu

| Native label | Median seconds |
|---|---:|
| Bulk Interpolation | 3.030 |
| Mechanics assembly (serial mode) | 8.430 |
| Mechanics preassembly | 0.315 |
| Mechanics step | 12.550 |
| Other Program Parts | 1.230 |
| Solver(Mechanics) | 12.850 |
| init command | 3.550 |
| solve command | 0.990 |
| struct command | 11.020 |

### vendor: unit-fine, module_elapsed

| Native label | Median seconds |
|---|---:|
| Bulk Interpolation | 3.120 |
| Mechanics assembly (serial mode) | 8.660 |
| Mechanics preassembly | 0.325 |
| Mechanics step | 12.920 |
| Other Program Parts | 1.280 |
| Solver(Mechanics) | 13.220 |
| init command | 3.650 |
| solve command | 1.020 |
| struct command | 11.320 |

### stressthermal: global, module_cpu

| Native label | Median seconds |
|---|---:|
| Mechanics assembly (serial mode) | 3.080 |
| Mechanics preassembly | 0.360 |
| Mechanics step | 4.820 |
| Other Program Parts | 1.660 |
| Solver(Mechanics) | 6.220 |
| init command | 3.010 |
| solve command | 0.690 |
| struct command | 6.970 |

### stressthermal: global, module_elapsed

| Native label | Median seconds |
|---|---:|
| Mechanics assembly (serial mode) | 3.160 |
| Mechanics preassembly | 0.370 |
| Mechanics step | 4.950 |
| Other Program Parts | 1.730 |
| Solver(Mechanics) | 6.400 |
| init command | 3.090 |
| solve command | 0.710 |
| struct command | 7.170 |

### stressthermal: unit-fine, module_cpu

| Native label | Median seconds |
|---|---:|
| Bulk Interpolation | 2.980 |
| Mechanics assembly (serial mode) | 8.180 |
| Mechanics preassembly | 1.480 |
| Mechanics step | 11.990 |
| Other Program Parts | 1.340 |
| Solver(Mechanics) | 16.310 |
| init command | 3.820 |
| solve command | 0.880 |
| struct command | 12.340 |

### stressthermal: unit-fine, module_elapsed

| Native label | Median seconds |
|---|---:|
| Bulk Interpolation | 3.060 |
| Mechanics assembly (serial mode) | 8.420 |
| Mechanics preassembly | 1.520 |
| Mechanics step | 12.350 |
| Other Program Parts | 1.400 |
| Solver(Mechanics) | 16.770 |
| init command | 3.940 |
| solve command | 0.900 |
| struct command | 12.700 |

### mapdl: global, native_stages

| Native label | Median seconds |
|---|---:|
| Elapsed time in element formation & assembly | 8.700 |
| Elapsed time in element result calculations | 18.700 |
| Elapsed time in equation solver | 10.800 |
| Elapsed time spent computing solution | 38.600 |
| Elapsed time spent obtaining a license | 1.400 |
| Elapsed time spent post-processing model (/POST1) | 12.300 |
| Elapsed time spent pre-processing model (/PREP7) | 1.300 |
| Elapsed time spent solution - postprocessing | 0.000 |
| Elapsed time spent solution - preprocessing | 1.300 |
| Total CPU time for main thread | 49.200 |
| Total CPU time summed for all threads | 49.200 |

### mapdl: unit-fine, native_stages

| Native label | Median seconds |
|---|---:|
| Elapsed time in element formation & assembly | 15.600 |
| Elapsed time in element result calculations | 32.200 |
| Elapsed time in equation solver | 27.700 |
| Elapsed time spent computing solution | 77.500 |
| Elapsed time spent obtaining a license | 1.400 |
| Elapsed time spent post-processing model (/POST1) | 20.400 |
| Elapsed time spent pre-processing model (/PREP7) | 4.000 |
| Elapsed time spent solution - postprocessing | 0.000 |
| Elapsed time spent solution - preprocessing | 2.200 |
| Total CPU time for main thread | 97.400 |
| Total CPU time summed for all threads | 97.400 |

## Evidence and reproduction

- `pillar-benchmark.json`: complete measured results, machine identities, repeatability, source-field and stress-recovery audits.
- `prepared/*.cmd` and frozen meshes: original physical source semantics; converter creates CDB.
- `run_recovered_vm.py`, `run_formal_mapdl.py`, parent `monitor_vm_run.py`: sequential runners with load recording.
- `run_mapdl_global.py`, `run_mapdl_local.py`: source conversion, explicit MAPDL-owned displacement transfer container, native solve.
- `mapdl/*/mechanics/` and `mapdl/*/local/mechanics/`: native decks, logs, results, exported stress components and regional recovery.
- `vm/formal-pillar-recovered-a/` and `host-vm/formal-pillar-recovered-a/`: native Vendor/StressThermal logs, hashes, full first-run fields, system swap and host-load records.
- `host-mapdl/`: repeated host-load samples. Conversion/mapping time is not hidden in a native-only speedup.
- `summarize_recovered.py`, parent `recover_mapdl_calibration.py`: offline regeneration and checks.
