"""Native analytic verification of CMD point displacements through CDB.

Prescribe a rigid translation of all four tetrahedron vertices. The exact
answer is that translation at every vertex, with zero strain and stress.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,time
import numpy as np
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from tests.test_cmd_init_mesh import snapshot
from converter_core.conversion.deserialize import CmdToIxDeserializer
from converter_core.conversion.serialize import IxDataSerializer
root=Path(__file__).parent/(sys.argv[1] if len(sys.argv)>1 else 'point-spc-native')
root.mkdir(exist_ok=False)
snapshot(root/'mesh.tdr')
lines=['init tdr=mesh.tdr','pdbSetDouble solid Mechanics BulkModulus 1e12',
       'pdbSetDouble solid Mechanics ShearModulus 5e11']
for i,xyz in enumerate(((0,0,0),(1000,0,0),(0,1000,0),(0,0,1000))):
    lines.append('stressdata bc.location=P%d point.coord= {%s} bc.value= {pdx=2<um> pdy=-3<um> pdz=4<um>}'%(i,' '.join(map(str,xyz))))
lines.append('solve time=1<s>')
cmd=root/'model.cmd';cmd.write_text('\n'.join(lines)+'\n')
ix=CmdToIxDeserializer().deserialize(cmd)
IxDataSerializer.write(ix,root/'model.cdb')
(root/'solve.inp').write_text('''/BATCH
/CLEAR,NOSTART
CDREAD,DB,model,cdb
/SOLU
ANTYPE,STATIC
EQSLV,SPARSE
OUTRES,ALL,ALL
SOLVE
FINISH
/POST1
SET,LAST
*DIM,dispx,ARRAY,4
*DIM,dispy,ARRAY,4
*DIM,dispz,ARRAY,4
*VGET,dispx(1),NODE,1,U,X
*VGET,dispy(1),NODE,1,U,Y
*VGET,dispz(1),NODE,1,U,Z
*CFOPEN,displacement,txt
*VWRITE,dispx(1),dispy(1),dispz(1)
(3E26.17)
*CFCLOS
ETABLE,sx,S,X
ETABLE,sy,S,Y
ETABLE,sz,S,Z
ETABLE,sxy,S,XY
ETABLE,syz,S,YZ
ETABLE,sxz,S,XZ
*GET,vx,ELEM,1,ETAB,sx
*GET,vy,ELEM,1,ETAB,sy
*GET,vz,ELEM,1,ETAB,sz
*GET,vxy,ELEM,1,ETAB,sxy
*GET,vyz,ELEM,1,ETAB,syz
*GET,vxz,ELEM,1,ETAB,sxz
*CFOPEN,stress,txt
*VWRITE,vx,vy,vz,vxy,vyz,vxz
(6E26.17)
*CFCLOS
FINISH
/EXIT,NOSAVE
''')
exe=Path(r'D:/Program Files/ANSYS Inc/v261/ansys/bin/winx64/ANSYS261.exe')
start=time.time()
with (root/'launcher.log').open('wb') as launcher:
    p=subprocess.run([str(exe),'-b','-smp','-np','1','-j','verify','-i','solve.inp','-o','solve.out'],cwd=root,
        stdout=launcher,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,timeout=180)
report={'exit':p.returncode,'wall_s':time.time()-start,'cdb_sha256':hashlib.sha256((root/'model.cdb').read_bytes()).hexdigest()}
(root/'run.json').write_text(json.dumps(report,indent=2))
log=(root/'solve.out').read_text(errors='replace')
assert p.returncode==0 and '*** ERROR ***' not in log and '*** FATAL ***' not in log
u=np.loadtxt(root/'displacement.txt');stress=np.loadtxt(root/'stress.txt')
assert u.shape==(4,3) and stress.shape==(6,)
error=float(np.max(np.abs(u-np.array([.002,-.003,.004]))))
smax=float(np.max(np.abs(stress)))
assert error<1e-13 and smax<1e-6
report.update(expected_translation_mm=[.002,-.003,.004],maximum_displacement_error_mm=error,
              maximum_absolute_stress_MPa=smax,status='passed')
(root/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
