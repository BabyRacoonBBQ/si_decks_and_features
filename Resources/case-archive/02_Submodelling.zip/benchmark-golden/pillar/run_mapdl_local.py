"""Local native solve driven exclusively by MAPDL's own global displacement.

The derived TDR is a transfer container, explicitly marked with MAPDL provenance;
it is not a vendor result. Uses the existing CMD global.model reader/mapper.
"""
from pathlib import Path
import hashlib,json,sys,shutil,time
import h5py,numpy as np
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent));sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from run_mapdl import run
from converter_core.conversion.deserialize import CmdToIxDeserializer
from converter_core.tdr_displacement import read_step_displacement

tag=sys.argv[1]
global_run=root/'mapdl'/tag/'mechanics'
if json.loads((global_run/'run.json').read_text())['exit']!=0:raise ValueError('Global solve failed')
out=root/'mapdl'/tag/(sys.argv[2] if len(sys.argv)>2 else 'local');out.mkdir(exist_ok=False)
source=root/'prepared/global-mesh_sis.tdr'
transfer_started=time.perf_counter()
field=out/'mapdl-global-displacement.tdr'
shutil.copyfile(source,field)
raw=np.loadtxt(global_run/'displacement.txt')
u={int(row[0]):row[1:] for row in raw}
provenance={'producer':'ANSYS MAPDL','global_run':str(global_run),
    'source_mesh_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'displacement_sha256':hashlib.sha256((global_run/'displacement.txt').read_bytes()).hexdigest(),
    'conversion':'MAPDL displacement mm / 10 -> TDR cm; original frozen mesh and vertex IDs retained',
    'vendor_displacements_used':False}
with h5py.File(field,'r+') as f:
    f.attrs['benchmark_transfer_provenance']=json.dumps(provenance)
    g=f['collection/geometry_0'];state=g['state_0']
    for key in list(state):del state[key]
    count=0
    for name,r in g.items():
        if not name.startswith('region_') or int(r.attrs.get('type',-1))!=0 or r.attrs.get('material')==b'Gas':continue
        c=r['elements_0'][:].reshape(-1,5)
        if not np.all(c[:,0]==5):raise ValueError('Non-tetrahedral transfer source')
        ids=np.unique(c[:,1:]);values=np.array([u[int(n)+1] for n in ids])/10
        if not np.isfinite(values).all():raise ValueError('Missing/nonfinite displacement')
        d=state.create_group(f'dataset_{count}')
        d.attrs.update({'name':np.bytes_('StepDisplacement'),'region':int(name[7:]),
            'location type':0,'structure type':1,'number of rows':3,
            'unit:name':np.bytes_('cm'),'conversion factor':1e4})
        d.create_dataset('values',data=values.reshape(-1));count+=1
    state.attrs['number of datasets']=count
read_step_displacement(field)
(out/'transfer-provenance.json').write_text(json.dumps(provenance,indent=2))
deck=(root/'prepared/unit-fine.cmd').read_text()
deck=deck.replace('tdr=unit-fine-mesh_sis.tdr','"tdr='+(root/'prepared/unit-fine-mesh_sis.tdr').as_posix()+'"')
deck=deck.replace('global.model=global_sis.tdr','"global.model='+field.as_posix()+'"')
(out/'local.cmd').write_text(deck)
transfer_container_seconds=time.perf_counter()-transfer_started
reader=CmdToIxDeserializer();mapping_started=time.perf_counter();ix=reader.deserialize(out/'local.cmd')
(out/'conversion.json').write_text(json.dumps({'warnings':reader.warnings,
    'transfer_container_seconds':transfer_container_seconds,
    'conversion_including_mapping_seconds':time.perf_counter()-mapping_started,
    'scope':'Own-global-to-local preparation; native timing recorded separately'},indent=2))
run('mechanics',ix,out)
