"""Replace meshing with the audited pre-solve snapshot; retain source physics."""
from pathlib import Path
import shutil
root=Path(__file__).parent
out=root/'prepared';out.mkdir(exist_ok=True)
for stage in ('global','unit-fine'):
    text=(root/'inputs'/(stage+'.cmd')).read_text()
    prefix=text.split('sde on',1)[0]
    suffix=text.split('grid remesh',1)[1]
    assert suffix.rstrip().endswith('exit')
    suffix=suffix.rstrip()[:-len('exit')]
    deck='math numThreads=1\n'+prefix
    deck+=f'init tdr={stage}-mesh_sis.tdr !load.commands !pdb\n'+suffix
    (out/(stage+'.cmd')).write_text(deck)
    shutil.copy2(root/'freeze'/(stage+'-mesh_sis.tdr'),out/(stage+'-mesh_sis.tdr'))
print(out)
