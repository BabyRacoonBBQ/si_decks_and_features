# Recovery completed — 2026-10-11

Release sinterconnect_run now completes the original copper-pillar global solve and local submodel using its own global displacement. Essential point constraints are retained. Point displacement and face-point penalty assembly were recovered against vendor evidence; nonzero nodal-rate and anchored face regressions pass.

All three formal repetitions completed for StressThermal and Golden tool - S (12 native stages); all 12 full field datasets and own-global mapping hashes passed audit. Existing Golden tool - A provides three completed own-global pipelines with equivalent regionwise stress recovery.

StressThermal peak Mises: global 887.6781968741105 MPa; local 703.7011053179518 MPa. Median native solve: global 16.69 s; local 43.02 s. Performance observations retain swap/load and timing-scope qualifications; no unconditional speedup claim.

Case 2 Accuracy and Performance values are published in the current seven-slide HTML/draw.io/PPTX/SVG exports. The latest two-row performance layout and all other current pages are preserved. Future Plan changed independently during final checking; its latest content was retained and re-exported. 38 completion checks passed in recovery/completion-audit.json.

Evidence: pillar-benchmark.json; pillar-benchmark-report.md; vm/formal-pillar-recovered-a/all-repetitions-field-audit.json; recovery/source-provenance.json; recovery/point-recovery-final.patch; recovery/build-5.log; recovery/node-rate-verification.json; recovery/face-cursor-verification.json. Source files remain in /home/mozztcad/geo3d; no commit was requested or created.

---

## Historical work log (superseded where it reports unsupported recovery)

# Copper-pillar benchmark evidence and remaining work

The deliverable remains the new left/right Benchmark slide, not a replacement
for Application cases. The right comparison is incomplete.

## Verified preparation

`inputs/` preserves the original global and fine local decks and solved TDRs.
`freeze_meshes.py` runs their original mesh recipes and stops before mapping,
temperature assignment or solution. Both preparation runs exited zero.
`audit_meshes.py` verifies exact coordinates and connectivity against the
meshes used by the current Application cases slide. `mesh-audit.json` records
hashes: 43,994 vertices / 246,681 global tetrahedra and 75,969 vertices /
422,904 local tetrahedra. The only initial physical dataset is DelVorWeight;
the local refinement overlay is mesh metadata, not a result dataset.

`prepare_decks.py` replaces geometry meshing with those frozen snapshots and
retains the physical source commands. `!load.commands !pdb` makes the explicit
deck authoritative. The terminal `exit` command is omitted at end of file.

## Actual calibration outcome

`run_calibration.py` ran vendor global then local, followed by StressThermal
global. All processes are terminal; remote `calibration-a/exit.json` is 1.

- Vendor global and fine local exited zero. At every regional node,
  MisesStress and StepDisplacement reproduce archived results exactly.
  Maximum current Mises: 887.6781968741105 MPa global;
  703.7011053176738 MPa local. See `calibration-summary.json`.
- StressThermal Release global exited 1:
  `sinterconnect::siGeneralBoundary::apply_point_disp is not recovered for standalone execution`.
  The native point displacement boundary is required to constrain the quarter
  package. Do not remove it merely to obtain a passing run. Its own global to
  local pipeline has not completed; no local result or performance is claimed.
- No calibration time is used as a formal performance score. Raw stdout,
  stderr, vmstat samples and binary/deck hashes are in `calibration-a/`.
- Temperature is prescribed cooling from 180 to 25 C, not a heat solution.

## Converter work

`probe_converter.py` records actual CDB conversion failures. Currently both
decks fail at unsupported Mechanics.MaxIterations before the rest of their
semantics can be validated. Do not interpret this as the only missing feature.
Global-model displacement import is now integrated into the existing
stressdata handler, with a verified neutral boundary path. The full decks
still stop at earlier unsupported controls/material semantics.

A separate real bug was repaired in the converter repository: point
displacement pdx/pdy/pdz was previously silently lost in the point-load branch.
It now uses existing IxDirichletBoundary semantics, preserves zero and nonzero
values, handles units and declaration order, and serializes explicit CDB D
records. Unknown point values fail explicitly. ILS, like PARDISO, is recorded
as a source execution choice with a warning; target driver selection remains
separate. Evidence: `converter-work/point-spc-tests.xml` (38 passing tests) and
`converter-work/point-spc-ils-tests.xml` (8 passing targeted tests).
Native MAPDL point-constraint verification now passes. The four-vertex rigid
translation test reports exactly the prescribed displacement at every node
and zero stress (`point-spc-host-verified/verification.json`). Earlier attempts
are retained: `point-spc-native` failed at sandbox license startup and its
wrapper was explicitly stopped after the solver terminated; `point-spc-host`
failed because the diagnostic driver used reserved APDL variable names.

Braced point coordinates such as `{$xmin 0 0}` now resolve Tcl variables in
the safe child interpreter, without nested command substitution. The combined
point/mesh/import/mapping regression suite passed 49 tests, recorded in
`converter-work/point-mapping-regression.xml`.
After source-adapter integration, the combined converter/CDB/thermal/mapping
regression passed 109 tests and 12 subtests; evidence is
`converter-work/converter-submodel-regression.xml`.

The converter now has a target-neutral linear-tetrahedron nodal-field mapper,
`converter_core/tetrahedral_mapping.py`. Seven component tests verify affine
exactness, orientation, unit rescaling, tree traversal and fail-closed behavior.
An independent audit against actual vendor global/local results covered all
10,754 local boundary nodes: maximum displacement-vector error
1.0868011426688115e-17 mm, relative maximum error 5.034923428649011e-16.
See `converter-mapping-audit.json`.

The CMD global.model adapter and neutral boundary materialization are now
integrated. `submodel-adapter-audit.json` verifies all 10,754 real boundary
nodes / 32,262 components against the independently audited mapping, with
zero difference. The source profile requires one static solve, a cuboid local
mesh, explicit Submodel.Add.Global.Stress=0 and continuous nodal displacement.
Global stress addition, cutting geometry, additional contacts and unsupported
state histories remain rejected. Missing source values cannot become zero.

An additional native MAPDL affine patch test leaves an interior vertex free
and constrains only the mapped exterior. It reproduces displacement to
2.6020852139652106e-18 mm and all six stress components over four elements to
2.8610229518832853e-08 MPa. See
`mapped-boundary-native-verified/verification.json`. The preceding
`mapped-boundary-native/` attempt was rejected by the CDB writer for an
inverted synthetic tetrahedron; the test then normalized element ordering.

`conversion-gap-inventory.json` records the earlier unsupported source declarations
by executing each registered parser handler diagnostically. It never emits Ix
or CDB and is not a claim of complete target validation. Its numerical controls,
inactive mesh preprocessing, constant high-viscosity elastic limit and one-step
delNT profile are now implemented and covered by 12 focused tests; other
viscous laws and active remeshing remain rejected. Global stress addition remains unsupported; the explicit
zero option required by this case is now supported.

Material semantics reference for the next extension: local Sentaurus User Guide
chapter_02_computing_mechanical_stress/txt/sinterconnect_ug.md in
D:/my_repos/fem_rag/data/sinterconnect_manual. Lines 178–218 establish oxide and
nitride default Maxwell viscoelastic behavior, tau=eta/G, stress-dependent
viscosity and the high-viscosity elastic limit. The current original decks use
Viscosity0=1e40, ViscosityW=0, Vcrit0=1e-30 and VcritW=0. Do not silently discard
those declarations merely to get the converter to serialize a model.

## Completed benchmark

See pillar-benchmark.json and pillar-benchmark-report.md for all three measured
repetitions of Golden tool - S and Golden tool - A global/local pipelines.
MAPDL maps its own global displacement. StressThermal's actual point-constraint
failure is shown explicitly; it has no local accuracy or performance score.

The new Benchmark slide and editable exports contain final measured results.
Timing comparisons remain qualified by VM swap activity, host/VM differences,
and the different inclusion of mapping/conversion in native timers. Full-stage
wall times are retained in the report. The completion audit passed all 31 checks.
