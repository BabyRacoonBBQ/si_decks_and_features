"""Formal native timing, accuracy repetition, load, and provenance summary."""
from pathlib import Path
import sys,json,statistics,re,hashlib
import numpy as np,h5py
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent))
from native_timers import sentaurus,mapdl
from stress_recovery import recover_region,von_mises
vm_tag=sys.argv[1];mapdl_tag=sys.argv[2]
vm=root/'vm'/vm_tag;md=root/'mapdl'/mapdl_tag
vm_exit=json.loads((vm/'exit.json').read_text());md_exit=json.loads((md/'exit.json').read_text())
if vm_exit['exit'] or md_exit['exit']:raise ValueError('Measurement collection incomplete')
samples={k:[json.loads(line) for line in (p/'host-load.jsonl').read_text().splitlines()]
    for k,p in [('vm',root/'host-vm'/vm_tag),('mapdl',root/'host-mapdl'/mapdl_tag)]}
def host_load(kind,meta):
    rows=[s for s in samples[kind] if meta['start_epoch']<=s['epoch']<=meta['start_epoch']+meta['wall_seconds']]
    if not rows:raise ValueError('Missing host load evidence')
    return dict(samples=len(rows),mean_cpu_percent=statistics.mean(s['cpu_percent'] for s in rows),
        peak_cpu_percent=max(s['cpu_percent'] for s in rows),minimum_available_GiB=min(s['available_memory']/2**30 for s in rows))
rows=[];failures=[]
for meta in vm_exit['runs']:
    d=vm/f"r{meta['rep']}-{meta['tool']}";stage=meta['stage']
    log=(d/f'{stage}-stdout.log').read_text(errors='replace')
    row=dict(tool=meta['tool'],stage=stage,rep=meta['rep'],meta=meta,host_load=host_load('vm',meta),
        swap_pages={k:meta['swap_after'][k]-meta['swap_before'][k] for k in meta['swap_before']},
        log_sha256=hashlib.sha256((d/f'{stage}-stdout.log').read_bytes()).hexdigest())
    if meta['exit']:
        errors=log+'\n'+(d/f'{stage}-stderr.log').read_text(errors='replace')
        row['failure']='Point displacement constraint not implemented' if 'apply_point_disp' in errors else 'Native solve failed; inspect logs'
        failures.append(row);continue
    timers=sentaurus(log)
    peak=re.findall(r'^BENCH_MISES_CURRENT\s+([\d.eE+\-]+)',log,re.M)
    if len(peak)!=1:raise ValueError('Missing native current Mises peak')
    row.update(native_timers=timers,maximum_mises_MPa=float(peak[0])*1e-7,
        native_total_s=timers['totals']['elapsed'],native_solve_s=sum(timers['solve_elapsed']),
        pipeline_stage_wall_s=meta['wall_seconds'])
    rows.append(row)
for meta in md_exit['runs']:
    base=root/'mapdl'/meta['tag'];stage=meta['stage']
    if stage=='unit-fine':base=base/'local'
    d=base/'mechanics';native_meta=json.loads((d/'run.json').read_text())
    if native_meta['exit']:raise ValueError('MAPDL native failure')
    timers=mapdl((d/'solve.out').read_text(errors='replace'),(d/'stage_timers.txt').read_text())
    if not timers['completed']:raise ValueError('MAPDL completion not verified')
    rec=json.loads((d/'regionwise-recovery.json').read_text())
    conversion=json.loads((base/'conversion.json').read_text())
    prep={k:v for k,v in conversion.items() if k.endswith('_seconds')}
    prep['archive_and_driver_preparation_seconds']=native_meta['archive_and_driver_preparation_seconds']
    rows.append(dict(tool='mapdl',stage=stage,rep=meta['rep'],meta=meta,native_meta=native_meta,
        host_load=host_load('mapdl',meta),native_timers=timers,preparation=prep,
        maximum_mises_MPa=rec['maximum']['maximum_mises_MPa'],
        native_total_s=timers['totals']['elapsed'],
        native_solve_s=next(t['seconds'] for t in timers['native_stages'] if t['label']=='Elapsed time spent computing solution'),
        pipeline_stage_wall_s=meta['wall_seconds']))
summary=[]
for tool in ('vendor','stressthermal','mapdl'):
    for stage in ('global','unit-fine'):
        group=[r for r in rows if r['tool']==tool and r['stage']==stage]
        if len(group)!=3:raise ValueError('Need three completed runs for each supported stage')
        s=dict(tool=tool,stage=stage,runs=3,maximum_mises_MPa=[r['maximum_mises_MPa'] for r in group])
        s['identical_peaks']=len(set(s['maximum_mises_MPa']))==1
        for metric in ('native_total_s','native_solve_s','pipeline_stage_wall_s'):
            values=[r[metric] for r in group];s[metric]=dict(median=statistics.median(values),min=min(values),max=max(values))
        if tool in ('vendor','stressthermal'):s['strict_no_vm_swap_runs']=sum(r['meta']['timing_no_vm_swap'] for r in group)
        summary.append(s)
# Formal r1 native fields must reproduce the fully audited calibration, not
# merely share a rounded peak value.
field_audits=[]
for stage in ('global','unit-fine'):
    a=vm/'r1-vendor'/(stage+'_sis.tdr');b=root/'calibration-a/vendor'/(stage+'_sis.tdr')
    def fields(path):
        with h5py.File(path) as f:
            return {(int(d.attrs['region']),d.attrs['name']):d['values'][:] for d in f['collection/geometry_0/state_0'].values()
                if d.attrs.get('name') in (b'MisesStress',b'StepDisplacement',b'Stress',b'StressEL')}
    x,y=fields(a),fields(b)
    if x.keys()!=y.keys():raise ValueError('Formal/calibration fields differ')
    error=max(float(np.max(abs(x[k]-y[k]))) for k in x)
    if error!=0:raise ValueError('Formal/calibration native field mismatch')
    recovery_audit=[]
    with h5py.File(a) as f:
        g=f['collection/geometry_0'];v=g['vertex'][:];xyz=np.column_stack([v[k] for k in ('x','y','z')])
        for key,r in g.items():
            if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0 or r.attrs.get('material')==b'Gas':continue
            rid=int(key[7:]);conn=r['elements_0'][:].reshape(-1,5)[:,1:]
            el=x[rid,b'StressEL'].reshape(-1,6)*1e-7
            ids,tensor=recover_region(xyz,conn,el)
            nodal=x[rid,b'Stress'].reshape(-1,6)*1e-7
            native=x[rid,b'MisesStress']*1e-7
            invariant=von_mises(tensor[:,[0,3,5,1,4,2]])
            if not np.allclose(tensor,nodal,rtol=1e-10,atol=1e-7):raise ValueError('Source regional tensor recovery differs')
            if not np.allclose(invariant,native,rtol=1e-10,atol=1e-7):raise ValueError('Source current Mises invariant differs')
            recovery_audit.append(dict(region=key,maximum_component_error_MPa=float(np.max(abs(tensor-nodal))),maximum_invariant_error_MPa=float(np.max(abs(invariant-native)))))
    field_audits.append(dict(stage=stage,maximum_native_field_difference=error,regional_recovery=recovery_audit,sha256=hashlib.sha256(a.read_bytes()).hexdigest()))
# Every local run must consume its own immediately preceding global result.
for tool in ('vendor','stressthermal'):
    for rep in (1,2,3):
        global_meta=next(r['meta'] for r in rows if r['tool']==tool and r['rep']==rep and r['stage']=='global')
        local_meta=next(r['meta'] for r in rows if r['tool']==tool and r['rep']==rep and r['stage']=='unit-fine')
        if not global_meta['result_sha256'] or local_meta['global_input_sha256']!=global_meta['result_sha256']:
            raise ValueError('Local stage did not consume own global result')
# Compare complete source fields, retaining material-interface sides.
for stage in ('global','unit-fine'):
    a=fields(vm/'r1-stressthermal'/(stage+'_sis.tdr'))
    b=fields(vm/'r1-vendor'/(stage+'_sis.tdr'))
    if a.keys()!=b.keys():raise ValueError('Recovered field inventory differs')
    diffs={}
    for name in (b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress'):
        keys=[k for k in a if k[1]==name]
        error=max(float(np.max(abs(a[k]-b[k]))) for k in keys)
        scale=max(float(np.max(abs(b[k]))) for k in keys)
        if error>1e-8*max(scale,1e-12):raise ValueError('Recovered field mismatch: '+str((stage,name,error,scale)))
        diffs[name.decode()]=dict(maximum_absolute_error_native_units=error,relative_to_peak=error/max(scale,1e-300))
    field_audits.append(dict(stage=stage,tool='stressthermal',comparison_to='vendor',fields=diffs))
report=dict(case='Copper-pillar global-to-local submodelling',temperature='Prescribed 180 to 25 C; not a solved-temperature accuracy test',
    summary=summary,runs=rows,failures=failures,field_audits=field_audits,
    accuracy_calibration=json.loads((root/'calibration-summary.json').read_text()),
    vm_environment=json.loads((vm/'environment.json').read_text()),mapdl_identity=json.loads((md/'identity.json').read_text()),
    limitations=['Different host and guest environments on the same physical machine.',
        'Some VM runs may have nonzero system swap counters; all measured runs retained with their load evidence.',
        'Native local totals differ in scope: vendor includes displacement mapping; MAPDL mapping/conversion occurs before its native solver. Full external stage wall time is separately reported.',
        'MAPDL native total includes diagnostic stress/displacement exports. Native solve scopes are tool-specific; do not sum nested timers.',
        'StressThermal point displacement recovery verified with nonzero rate and own-global local mapping; original failed probe retained as historical evidence.'])
(root/'pillar-benchmark.json').write_text(json.dumps(report,indent=2))
print(json.dumps(summary,indent=2))
