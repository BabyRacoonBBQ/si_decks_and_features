"""Record real conversion support/errors; no manual APDL physics substitutions."""
from pathlib import Path
import json, sys, traceback
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from converter_core.conversion.deserialize import CmdToIxDeserializer
from converter_core.conversion.serialize import IxDataSerializer
root=Path(__file__).parent
results=[]
for stage in ('global','unit-fine'):
    reader=CmdToIxDeserializer()
    row={'stage':stage}
    try:
        ix=reader.deserialize(root/'prepared'/(stage+'.cmd'))
        IxDataSerializer.write(ix,root/'prepared'/(stage+'.cdb'))
        row.update(status='CDB serialized; not yet solver verified',warnings=reader.warnings)
    except Exception as e:
        row.update(status='conversion rejected',error=str(e),traceback=traceback.format_exc())
    results.append(row)
(root/'conversion-probe.json').write_text(json.dumps(results,indent=2))
for r in results: print(r['stage'],r['status'],r.get('error',''))
