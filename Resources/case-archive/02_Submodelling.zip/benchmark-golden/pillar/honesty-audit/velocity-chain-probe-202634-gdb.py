import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT'];events=[];counts={'setup':0,'apply':0}
def reg(n):
 try:return int(gdb.parse_and_eval('$'+n))
 except:return 0
def u64(a):
 try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return 0
def d(a):
 try:return struct.unpack('<d',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return None
def vec(field):
 slots=u64(field+0x68+8*0) if field else 0; seg=u64(slots+8*85) if slots else 0; data=u64(seg) if seg else 0
 return {'field':hex(field) if field else None,'node_slots':hex(slots) if slots else None,'segment':hex(seg) if seg else None,'data':hex(data) if data else None,'value':[d(data+24*1020+8*i) for i in range(3)] if data else [None]*3}
def boundary(gb):
 vs=u64(gb+0x8) if gb else 0; field=u64(vs+0x110) if vs else 0
 return {'general_boundary':hex(gb) if gb else None,'velocity_solution':hex(vs) if vs else None,'velocity_field':hex(field) if field else None,**vec(field)}
def solver(obj):
 vs=u64(obj+0x748) if obj else 0; field=u64(vs+0x110) if vs else 0; gb=u64(obj+0x730) if obj else 0
 return {'solver':hex(obj) if obj else None,'solver_velocity_solution':hex(vs) if vs else None,'solver_velocity_field':hex(field) if field else None,'general_boundary':hex(gb) if gb else None,**boundary(gb)}
class SetupRet(gdb.FinishBreakpoint):
 def __init__(self,obj):self.obj=obj;super().__init__(internal=True)
 def stop(self):events.append({'phase':'setup-return',**solver(self.obj)});return False
class ApplyRet(gdb.FinishBreakpoint):
 def __init__(self,obj):self.obj=obj;super().__init__(internal=True)
 def stop(self):events.append({'phase':'apply-return',**boundary(self.obj)});return False
class SetupBP(gdb.Breakpoint):
 def __init__(self):super().__init__('*'+os.environ['SETUP_PC'],internal=False)
 def stop(self):
  counts['setup']+=1;obj=reg('rdi')
  if counts['setup']==1:events.append({'phase':'setup-entry',**solver(obj)});SetupRet(obj)
  return False
class ApplyBP(gdb.Breakpoint):
 def __init__(self):super().__init__('*'+os.environ['APPLY_PC'],internal=False)
 def stop(self):
  counts['apply']+=1;obj=reg('rdi')
  if counts['apply']==1:events.append({'phase':'apply-entry',**boundary(obj)});ApplyRet(obj)
  return False
SetupBP();ApplyBP()
def exited(e):Path(OUT).write_text(json.dumps({'exit':getattr(e,'exit_code',None),'counts':counts,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')
