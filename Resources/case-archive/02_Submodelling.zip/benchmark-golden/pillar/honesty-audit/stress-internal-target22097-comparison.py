import json
import math
import struct
from pathlib import Path


BASE = Path(__file__).resolve().parent / "honesty-audit-stress-internal-target22097-202615"
PHASES = (
    "calc_euler_strain-entry",
    "calc_euler_strain-return",
    "calc_stress-entry",
    "calc_stress-return",
)


def bits(x):
    return f"0x{struct.unpack('<Q', struct.pack('<d', x))[0]:016x}"


def load(side):
    doc = json.loads((BASE / side / "events.json").read_text())
    return {event["phase"]: event for event in doc["events"] if event["phase"] in PHASES}, doc


def compare_arrays(a, b):
    deltas = [x - y for x, y in zip(a, b)]
    return {
        "vendor": a,
        "local_repair": b,
        "max_abs": max((abs(delta) for delta in deltas), default=0.0),
        "different": sum(x != y for x, y in zip(a, b)),
        "vendor_bits": [bits(x) for x in a],
        "local_repair_bits": [bits(x) for x in b],
        "deltas": deltas,
    }


vendor, vendor_doc = load("vendor")
local, local_doc = load("local-repair")
out = {
    "target_call": 22097,
    "vendor_stress_hits": vendor_doc.get("stress_hits"),
    "local_repair_stress_hits": local_doc.get("stress_hits"),
    "phases": sorted(set(vendor) | set(local)),
    "comparisons": {},
}

for phase in PHASES:
    ve = vendor[phase]
    le = local[phase]
    out["comparisons"][phase] = {}
    for key in ("displacement", "strain", "stress"):
        if key in ve and key in le and ve[key] is not None and le[key] is not None:
            out["comparisons"][phase][key] = compare_arrays(ve[key], le[key])

(BASE.parent / "stress-internal-target22097-comparison.json").write_text(
    json.dumps(out, indent=2) + "\n"
)
print(json.dumps(out, indent=2))
