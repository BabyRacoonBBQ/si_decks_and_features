from __future__ import annotations

import sys
from pathlib import Path

import h5py
import numpy as np


def main():
    path = Path(sys.argv[1])
    with h5py.File(path, "r") as f:
        for name in sys.argv[2:]:
            d = f[name]
            parent = f[name.rsplit("/", 1)[0]]
            print({
                "path": name,
                "name": parent.attrs.get("name"),
                "shape": d.shape,
                "dtype": str(d.dtype),
                "chunks": d.chunks,
                "compression": d.compression,
                "offset": d.id.get_offset(),
                "storage_size": d.id.get_storage_size(),
            })
            if d.chunks:
                try:
                    print("chunk0", d.id.get_chunk_info_by_coord(tuple(0 for _ in d.shape)))
                except Exception as exc:
                    print("chunk0_error", repr(exc))


if __name__ == "__main__":
    main()
