from __future__ import annotations
import hashlib, json, os, shutil, subprocess, time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-repair-20261011b'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
import fcntl
fcntl.flock(LOCK, fcntl.LOCK_EX)

binary = Path('/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run')
env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSERSITE='1', TDR_VERSION='16')
env.update(
    STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1',
    STRELEASE='W-2024.09-SP1',
    TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1',
)
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

work = OUT / 'local-repair'
shutil.copytree(ROOT / 'prepared', work)
records = []
for stage in ('global', 'unit-fine'):
    start = time.time()
    command = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', str(binary), f'{stage}.cmd']
    with (work / f'{stage}.stdout').open('w') as stdout, (work / f'{stage}.stderr').open('w') as stderr:
        result = subprocess.run(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
    output = work / f'{stage}_sis.tdr'
    record = {
        'stage': stage,
        'exit': result.returncode,
        'wall_seconds': time.time() - start,
        'binary_sha256': sha(binary),
        'deck_sha256': sha(work / f'{stage}.cmd'),
        'output_sha256': sha(output) if output.exists() else None,
        'output_size': output.stat().st_size if output.exists() else None,
    }
    records.append(record)
    if result.returncode != 0:
        raise SystemExit(json.dumps(record))
(OUT / 'repair-regression.json').write_text(json.dumps(records, indent=2))
print(json.dumps(records, indent=2))
