import gdb, hashlib, json, os, struct
from pathlib import Path

out = os.environ['AUDIT_OUT']
events = []

def read(inf, addr, n):
    return inf.read_memory(addr, n).tobytes()

class Probe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::BasicSingleStiff::ssScatter(floops::Vector&, floops::Vector*)', internal=False)
        self.count = 0
    def stop(self):
        self.count += 1
        stiff = int(gdb.parse_and_eval('$rdi'))
        inf = gdb.selected_inferior()
        row_count = struct.unpack('<i', read(inf, stiff + 0xc, 4))[0]
        n = max(0, min(row_count, 300))
        row_raw = read(inf, stiff + 0x1c, n * 4)
        # VectorStatic::data_ already points at its inline buffer.
        ss_data = struct.unpack('<Q', read(inf, stiff + 0x990, 8))[0]
        ss_raw = read(inf, ss_data, n * 8)
        events.append({'count': self.count, 'row_count': row_count,
                       'row_sha256': hashlib.sha256(row_raw).hexdigest(),
                       'ss_sha256': hashlib.sha256(ss_raw).hexdigest()})
        if self.count >= int(os.environ.get('AUDIT_LIMIT', '32768')):
            self.enabled = False
        return False

probe = Probe()
exit_code = None
def exited(event):
    global exit_code
    exit_code = getattr(event, 'exit_code', None)
    Path(out).write_text(json.dumps({'exit': exit_code, 'counts': {'ssScatter': probe.count}, 'events': events}, indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
