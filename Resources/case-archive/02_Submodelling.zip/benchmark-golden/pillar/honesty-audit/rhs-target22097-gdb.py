import gdb,json,os,struct,hashlib
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097')); count=0; events=[]
def read(inf,a,n): return inf.read_memory(a,n).tobytes()
def snap(stiff,label):
 inf=gdb.selected_inferior(); n=struct.unpack('<i',read(inf,stiff+0xc,4))[0]; m=max(0,min(n,64)); rows=list(struct.unpack('<{}i'.format(m),read(inf,stiff+0x1c,m*4))) if m else []; ptr=struct.unpack('<Q',read(inf,stiff+0x990,8))[0]; raw=read(inf,ptr,m*8) if m else b''; vals=list(struct.unpack('<{}d'.format(m),raw)) if m else []; return {'phase':label,'stiff_ptr':hex(stiff),'row_count':n,'row_ids':rows,'ss_values':vals,'ss_sha256':hashlib.sha256(raw).hexdigest()}
class R(gdb.FinishBreakpoint):
 def __init__(self,stiff): self.stiff=stiff; super().__init__(gdb.newest_frame(),internal=True)
 def stop(self): events.append(snap(self.stiff,'return')); return False
class P(gdb.Breakpoint):
 def __init__(self): super().__init__('sinterconnect::siMechPDE::computeElemRHSHOE(floops::Element*, floops::SingleStiff&)',internal=False)
 def stop(self):
  global count; count+=1
  if count==TARGET:
   p_rsi=int(gdb.parse_and_eval('$rsi')); p_rdx=int(gdb.parse_and_eval('$rdx')); e=snap(p_rdx,'entry'); e['count']=count; e['regs']={'rdi':hex(int(gdb.parse_and_eval('$rdi'))),'rsi':hex(p_rsi),'rdx':hex(p_rdx),'rcx':hex(int(gdb.parse_and_eval('$rcx')))}; e['rsi_candidate']=snap(p_rsi,'rsi-candidate'); e['stack']=gdb.execute('bt 10',to_string=True); events.append(e)
   try:R(p_rdx)
   except Exception as exc: events.append({'phase':'finish-error','error':str(exc)})
   self.enabled=False
  return False
P(); exit_code=None
def exited(event):
 global exit_code; exit_code=getattr(event,'exit_code',None); Path(OUT).write_text(json.dumps({'exit':exit_code,'target':TARGET,'rhs_hits':count,'events':events},indent=2))
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
