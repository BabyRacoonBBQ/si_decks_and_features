import gdb,json,os,struct,hashlib
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097')); counts={}; events=[]
def read(inf,a,n): return inf.read_memory(a,n).tobytes()
def snap(stiff,label):
 inf=gdb.selected_inferior(); n=struct.unpack('<i',read(inf,stiff+0xc,4))[0]; m=max(0,min(n,64)); rows=list(struct.unpack('<{}i'.format(m),read(inf,stiff+0x1c,m*4))) if m else []; ptr=struct.unpack('<Q',read(inf,stiff+0x990,8))[0]; raw=read(inf,ptr,m*8) if m else b''; vals=list(struct.unpack('<{}d'.format(m),raw)) if m else []; return {'phase':label,'stiff_ptr':hex(stiff),'row_count':n,'row_ids':rows,'ss_values':vals,'ss_sha256':hashlib.sha256(raw).hexdigest()}
class R(gdb.FinishBreakpoint):
 def __init__(self,name,stiff): self.name=name; self.stiff=stiff; super().__init__(gdb.newest_frame(),internal=True)
 def stop(self): e=snap(self.stiff,'return'); e['name']=self.name; events.append(e); return False
class P(gdb.Breakpoint):
 def __init__(self,name): self.name=name; counts[name]=0; super().__init__(name,internal=False)
 def stop(self):
  counts[self.name]+=1
  if counts[self.name]==TARGET:
   stiff=int(gdb.parse_and_eval('$rsi')); e=snap(stiff,'entry'); e['name']=self.name; e['count']=counts[self.name]; e['stack']=gdb.execute('bt 10',to_string=True); events.append(e)
   try:R(self.name,stiff)
   except Exception as exc: events.append({'phase':'finish-error','name':self.name,'error':str(exc)})
   self.enabled=False
  return False
names=['FE::MechanicsAssembler::calc_rhs(floops::SingleStiff&, floops::SingleDense*)','FE::CompositeSolidShell::calc_rhs(floops::SingleStiff&, floops::SingleDense*)']
for n in names:
 try:P(n)
 except Exception as exc: events.append({'phase':'breakpoint-error','name':n,'error':str(exc)})
exit_code=None
def exited(event):
 global exit_code; exit_code=getattr(event,'exit_code',None); Path(OUT).write_text(json.dumps({'exit':exit_code,'target':TARGET,'counts':counts,'events':events},indent=2))
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
