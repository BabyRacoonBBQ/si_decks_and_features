from __future__ import annotations

import hashlib
import sys
from pathlib import Path


def ranges(a: bytes, b: bytes):
    n = min(len(a), len(b))
    out = []
    i = 0
    while i < n:
        if a[i] == b[i]:
            i += 1
            continue
        start = i
        while i < n and a[i] != b[i]:
            i += 1
        out.append((start, i))
    return out


def main():
    vendor_path, local_path = map(Path, sys.argv[1:3])
    vendor = vendor_path.read_bytes()
    local = local_path.read_bytes()
    diffs = ranges(vendor, local)
    matched = []
    unmatched = []
    for start, end in diffs:
        # HDF5 v1 object-header message 0x0012, length 8: the final four
        # payload bytes are the object-modification seconds after epoch.
        message_start = start - 12
        is_mtime_payload = (
            message_start >= 0
            and vendor[message_start:message_start + 4] == bytes.fromhex("12000800")
            and vendor[message_start + 4:message_start + 8] == b"\x00\x00\x00\x00"
            and vendor[message_start + 8:message_start + 12] == b"\x01\x00\x00\x00"
            and local[message_start:message_start + 12] == vendor[message_start:message_start + 12]
            and start == message_start + 12
            and end == start + 2
        )
        row = {
            "start": start,
            "end": end,
            "vendor": vendor[start:end].hex(),
            "local": local[start:end].hex(),
            "vendor_seconds": int.from_bytes(vendor[start:start + 4], "little"),
            "local_seconds": int.from_bytes(local[start:start + 4], "little"),
        }
        (matched if is_mtime_payload else unmatched).append(row)
    print(f"vendor_sha256={hashlib.sha256(vendor).hexdigest()}")
    print(f"local_sha256={hashlib.sha256(local).hexdigest()}")
    print(f"vendor_bytes={len(vendor)} local_bytes={len(local)}")
    print(f"raw_diff_ranges={len(diffs)}")
    print(f"mtime_payload_ranges={len(matched)}")
    print(f"unmatched_ranges={len(unmatched)}")
    if matched:
        print(f"mtime_vendor_min={min(x['vendor_seconds'] for x in matched)}")
        print(f"mtime_vendor_max={max(x['vendor_seconds'] for x in matched)}")
        print(f"mtime_local_min={min(x['local_seconds'] for x in matched)}")
        print(f"mtime_local_max={max(x['local_seconds'] for x in matched)}")
        print(f"mtime_delta_values={sorted(set(x['local_seconds'] - x['vendor_seconds'] for x in matched))}")
        print("first_mtime_rows:")
        for row in matched[:20]:
            print(row)
    if unmatched:
        print("unmatched_rows:")
        for row in unmatched[:20]:
            print(row)


if __name__ == "__main__":
    main()
