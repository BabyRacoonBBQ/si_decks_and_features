import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; MAT=int(os.environ.get('AUDIT_MATERIAL_INDEX','85')); IDX=int(os.environ.get('AUDIT_DATA_INDEX','1020'))
events=[]
def reg(n):
 try:return int(gdb.parse_and_eval('$'+n))
 except:return 0
def u64(a):
 try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return 0
def d(a):
 try:return struct.unpack('<d',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return None
def vals(a):return [d(a+8*i) for i in range(3)] if a else [None]*3
def snap(gb):
 vs=u64(gb+0x8) if gb else 0; field=u64(vs+0x110) if vs else 0; slots=u64(field+0x68) if field else 0; seg=u64(slots+8*MAT) if slots else 0; data=u64(seg) if seg else 0
 return {'general_boundary':hex(gb) if gb else None,'velocity_solution':hex(vs) if vs else None,'velocity_field':hex(field) if field else None,'node_slots':hex(slots) if slots else None,'segment':hex(seg) if seg else None,'data':hex(data) if data else None,'value':vals(data+24*IDX) if data else [None,None,None],'stack':gdb.execute('bt 10',to_string=True)}
class Ret(gdb.FinishBreakpoint):
 def __init__(self,gb):self.gb=gb;super().__init__(internal=True)
 def stop(self):events.append({'phase':'return',**snap(self.gb)});return False
class BP(gdb.Breakpoint):
 def __init__(self):super().__init__('*'+os.environ['APPLY_SUBMODEL_PC'],internal=False)
 def stop(self):gb=reg('rdi');events.append({'phase':'entry',**snap(gb)});Ret(gb);return False
bp=BP()
def exited(e):Path(OUT).write_text(json.dumps({'exit':getattr(e,'exit_code',None),'hits':sum(1 for x in events if x['phase']=='entry'),'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')