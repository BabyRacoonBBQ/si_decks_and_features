from pathlib import Path
import os,json,subprocess,shutil,hashlib,time,fcntl
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011');out=root/'honesty-audit-b';out.mkdir(exist_ok=False)
lock=open('/tmp/geo3d-sinterconnect-heavy.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bins={'vendor':'/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect','local':'/home/mozztcad/geo3d/build/sinterconnect_run'}
names=['sinterconnect::siGeneralBoundary::apply_point_disp()','sinterconnect::siGeneralBoundary::processPointDispBCs(floops::Matrix*, floops::Vector*)','floops::GeneralBoundary::apply_submodel()','floops::GeneralBoundary::interpolate_global(char const*)','floops::MechController::performMechanics(char const*, bool)','floops::MechanicsSolver::pLoadBulk(floops::Matrix&, floops::Vector&, floops::Vector*, double, int)']
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONNOUSERSITE='1',TDR_VERSION='16')
for k in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(k,None)
identity={};records=[]
for tool,binary in bins.items():
 symbols=subprocess.check_output(['nm']+(['-D'] if tool=='vendor' else [])+['-C','--defined-only',binary],universal_newlines=True)
 probes=[]
 for name in names:
  matches=[line.split(' ',2) for line in symbols.splitlines() if line.endswith(' T '+name)]
  assert len(matches)==1,(tool,name,matches)
  probes.append({'name':name,'address':'0x'+matches[0][0]})
 identity[tool]={'path':binary,'sha256':sha(binary),'size':Path(binary).stat().st_size,'mtime':Path(binary).stat().st_mtime,'file':subprocess.check_output(['file',binary],universal_newlines=True),'elf_notes':subprocess.check_output(['readelf','-n',binary],universal_newlines=True),'ldd':subprocess.check_output(['ldd',binary],universal_newlines=True)}
 d=out/tool;shutil.copytree(root/'prepared',d);(d/'probes.json').write_text(json.dumps(probes))
 for stage in ('global','unit-fine'):
  env.update(AUDIT_OUT=str(d/(stage+'-events.json')),AUDIT_PROBES=str(d/'probes.json'))
  argv=['timeout','-k','10','900','taskset','-c','4','gdb','-q','-nx','-batch','-ex','source /tmp/honesty-probe.py','--args',binary]+(['--noSyntaxCheck'] if tool=='vendor' else [])+[stage+'.cmd']
  start=time.time();print('BEGIN',tool,stage,flush=True)
  with (d/(stage+'-gdb.log')).open('w') as log:p=subprocess.run(argv,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
  result=json.loads((d/(stage+'-events.json')).read_text()) if (d/(stage+'-events.json')).exists() else {}
  record={'tool':tool,'stage':stage,'observer_exit':p.returncode,'inferior_exit':result.get('exit'),'start':start,'wall':time.time()-start,'binary_sha256':sha(binary),'deck_sha256':sha(d/(stage+'.cmd')),'output_sha256':sha(d/(stage+'_sis.tdr')) if (d/(stage+'_sis.tdr')).exists() else None,'global_input_sha256':sha(d/'global_sis.tdr') if stage=='unit-fine' else None}
  records.append(record);(out/'progress.json').write_text(json.dumps(records,indent=2));print('END',json.dumps(record),flush=True)
  if p.returncode or result.get('exit')!=0:raise RuntimeError('Diagnostic run failed; retain evidence')
(out/'identity.json').write_text(json.dumps(identity,indent=2));(out/'exit.json').write_text(json.dumps({'exit':0,'runs':records},indent=2))

