import gdb,json,os,struct,hashlib
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; events=[]; calls=0
def reg(name):
    try:return int(gdb.parse_and_eval('$'+name))
    except Exception:return 0
def read_u64(addr):
    try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
    except Exception:return 0
def vec(obj):
    if not obj:return {'object':None,'length':None,'data':None,'sha256':None,'first':[]}
    n=int(read_u64(obj+8)); data=read_u64(obj+16); ncap=min(n,200000); raw=b''
    try:
        if data and ncap:raw=gdb.selected_inferior().read_memory(data,8*ncap).tobytes()
    except Exception:raw=b''
    first=list(struct.unpack('<%dd'%min(ncap,128),raw[:8*min(ncap,128)])) if raw else []
    return {'object':hex(obj),'length':n,'data':hex(data) if data else None,'sha256':hashlib.sha256(raw).hexdigest() if raw else None,'first':first}
class Ret(gdb.FinishBreakpoint):
    def __init__(self,call,rhs,sol):self.call=call;self.rhs=rhs;self.sol=sol;super().__init__(internal=True)
    def stop(self):events.append({'phase':'return','call':self.call,'rhs':vec(self.rhs),'solution':vec(self.sol),'xmm0':float(gdb.parse_and_eval('$xmm0')) if False else None,'stack':gdb.execute('bt 8',to_string=True)});return False
class BP(gdb.Breakpoint):
    def __init__(self):super().__init__('*'+os.environ['SOLVE_PC'],internal=False)
    def stop(self):
        global calls
        calls+=1; rhs=reg('rcx'); sol=reg('r8'); events.append({'phase':'entry','call':calls,'rhs':vec(rhs),'solution':vec(sol),'stack':gdb.execute('bt 8',to_string=True)}); Ret(calls,rhs,sol); return False
BP()
def exited(event):Path(OUT).write_text(json.dumps({'exit':getattr(event,'exit_code',None),'calls':calls,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')
