from pathlib import Path
import json,hashlib,numpy as np,h5py
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011'); base=root/'honesty-audit-b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={}
for stage in ['global','unit-fine']:
 a=base/'vendor'/(stage+'_sis.tdr'); b=base/'local'/(stage+'_sis.tdr');x=a.read_bytes();y=b.read_bytes();n=min(len(x),len(y));diff=np.flatnonzero(np.frombuffer(x[:n],dtype=np.uint8)!=np.frombuffer(y[:n],dtype=np.uint8))
 r={'raw_byte_exact':x==y,'vendor_bytes':len(x),'local_bytes':len(y),'vendor_sha256':sha(a),'local_sha256':sha(b),'first_differing_byte':int(diff[0]) if len(diff) else (n if len(x)!=len(y) else None),'differing_byte_count':len(diff)+abs(len(x)-len(y)),'fields':{}}
 with h5py.File(a) as fa,h5py.File(b) as fb:
  def fields(f):
   return {(int(d.attrs['region']),d.attrs['name']):d['values'][:] for d in f['collection/geometry_0/state_0'].values() if d.attrs.get('name') in (b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress')}
  aa,bb=fields(fa),fields(fb); assert aa.keys()==bb.keys()
  for name in [b'StepDisplacement',b'Stress',b'StressEL',b'MisesStress']:
   keys=[k for k in aa if k[1]==name];err=max(float(np.max(np.abs(aa[k]-bb[k]))) for k in keys);scale=max(float(np.max(np.abs(aa[k]))) for k in keys);assert err<=1e-8*max(scale,1e-12)
   r['fields'][name.decode()]={'max_absolute_difference_native_units':err,'relative_to_peak':err/max(scale,1e-300)}
  topology=[]
  def visit(name,obj):
   if isinstance(obj,h5py.Dataset) and (name.endswith('/vertex') or '/elements_' in name):
    assert name in fb and np.array_equal(obj[:],fb[name][:]),name
    topology.append(name)
  fa.visititems(visit);r['exact_topology_datasets']=topology
  attrs=[]
  def visitattrs(name,obj):
   if name not in fb:attrs.append({'path':name,'difference':'missing object'});return
   other=fb[name]
   for k in set(obj.attrs)|set(other.attrs):
    if k not in obj.attrs or k not in other.attrs or not np.array_equal(obj.attrs.get(k),other.attrs.get(k)):
     attrs.append({'path':name,'attribute':k,'vendor':repr(obj.attrs.get(k))[:250],'local':repr(other.attrs.get(k))[:250]})
  visitattrs('/',fa);fa.visititems(visitattrs);r['attribute_differences']=attrs
 report[stage]=r
mesh={}
for p in (root/'prepared').glob('*.tdr'):
 with h5py.File(p) as f:
  names=[]
  f.visititems(lambda n,o:names.append(str(o.attrs['name'])) if 'name' in o.attrs and '/state_' in n else None)
  assert not any(k in n for n in names for k in ['Stress','Displacement','Temperature'])
  mesh[p.name]={'sha256':sha(p),'state_dataset_names':names,'no_solution_fields':True}
report['input_meshes']=mesh
(base/'tdr-audit.json').write_text(json.dumps(report,indent=2)); print(json.dumps({k: {a:b for a,b in v.items() if a in ('raw_byte_exact','fields','first_differing_byte')} for k,v in report.items() if k!='input_meshes'},indent=2))
