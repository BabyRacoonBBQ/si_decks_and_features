import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097'))
rhs_count=0; b_count=0; events=[]
def u64(name):
 try: return int(gdb.parse_and_eval('$'+name))
 except Exception: return 0
def mem_u64(addr):
 try: return int.from_bytes(gdb.selected_inferior().read_memory(addr,8).tobytes(),'little')
 except Exception: return 0
def mem_i32(addr):
 try: return int.from_bytes(gdb.selected_inferior().read_memory(addr,4).tobytes(),'little',signed=True)
 except Exception: return 0
def memd(addr):
 try: return struct.unpack('<d',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
 except Exception: return None
def capture_this(this):
 bvec=mem_u64(this+0x18); mat=bvec; data=mem_u64(mat); rows=mem_i32(mat+0x18); cols=mem_i32(mat+0x1c)
 n=max(0,min(rows*cols,64))
 return {'this':hex(this),'bvec':hex(bvec),'mat':hex(mat),'data':hex(data),'rows':rows,'cols':cols,'b_values':[memd(data+8*i) for i in range(n)]}
class B(gdb.Breakpoint):
 def __init__(self): super().__init__('FE::MechanicsAssembler::calc_B(double const (*) [3])',internal=False)
 def stop(self):
  global b_count
  b_count+=1
  if b_count==TARGET:
   this=u64('rdi'); disp=u64('rsi')
   events.append({'phase':'calc_B_entry','count':b_count,'displacement_ptr':hex(disp),'displacement':[memd(disp+8*i) for i in range(12)],'b_before':capture_this(this)})
   self.enabled=False
  return False
class R(gdb.Breakpoint):
 def __init__(self): super().__init__('FE::MechanicsAssembler::calc_rhs(floops::SingleStiff&, floops::SingleDense*)',internal=False)
 def stop(self):
  global rhs_count
  rhs_count+=1
  if rhs_count==TARGET:
   events.append({'phase':'calc_rhs_entry','count':rhs_count,'calc_B_count':b_count,'capture':capture_this(u64('rdi'))})
   self.enabled=False
  return False
B(); R()
def exited(event):
 Path(OUT).write_text(json.dumps({'exit':getattr(event,'exit_code',None),'target':TARGET,'calc_B_hits':b_count,'calc_rhs_hits':rhs_count,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
