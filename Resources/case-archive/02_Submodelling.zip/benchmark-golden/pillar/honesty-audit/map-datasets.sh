#!/usr/bin/env bash
set -eu
V=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64
F=/home/mozztcad/si-bench/golden-pillar-20261011/honesty-audit-b/vendor/unit-fine_sis.tdr
L="$V/lib:$V/lib/gds2tcadLib"
for i in $(seq 0 172); do
  o=$(LD_LIBRARY_PATH="$L" "$V/bin/h5dump" -A -g "/collection/geometry_0/state_0/dataset_$i" "$F" 2>/dev/null || true)
  name=$(printf '%s\n' "$o" | awk '/ATTRIBUTE "name"/{a=1;next} a&&/\(0\):/{gsub(/"/,"",$2);print $2;exit}')
  quantity=$(printf '%s\n' "$o" | awk '/ATTRIBUTE "quantity"/{a=1;next} a&&/\(0\):/{gsub(/"/,"",$2);print $2;exit}')
  region=$(printf '%s\n' "$o" | awk '/ATTRIBUTE "region"/{a=1;next} a&&/\(0\):/{print $2;exit}')
  location=$(printf '%s\n' "$o" | awk '/ATTRIBUTE "location type"/{a=1;next} a&&/\(0\):/{print $2;exit}')
  if [ -n "$name" ]; then echo "$i|$name|$quantity|$region|$location"; fi
done
