import gdb, json, os, struct

out = os.environ['AUDIT_OUT']
records = []
pending = None
hits = 0
limit = 20

def read_u64(addr):
    try:
        return struct.unpack('<Q', gdb.selected_inferior().read_memory(addr, 8).tobytes())[0]
    except Exception:
        return 0

def vals(addr, count=6):
    if not addr:
        return None
    try:
        p = gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p + i).dereference()) for i in range(count)]
    except Exception as exc:
        return ['ERROR:' + str(exc)]

def snapshot(phase, pde, element):
    base = read_u64(pde + 0x400)
    ptr = read_u64(base) if base else 0
    rows = []
    if base:
        for i in range(8):
            rowptr = read_u64(base + 8 * i)
            rows.append({'index': i, 'ptr': hex(rowptr) if rowptr else None, 'values': vals(rowptr)})
    return {'phase': phase, 'pde': hex(pde), 'element': hex(element) if element else None,
            'gpStressArray': hex(base) if base else None, 'row0_ptr': hex(ptr) if ptr else None,
            'row0': vals(ptr), 'rows': rows, 'stack': gdb.execute('bt 12', to_string=True)}

class CallSite(gdb.Breakpoint):
    def __init__(self):
        super(CallSite, self).__init__('*' + os.environ['POSTPROCESS_CALL_PC'], internal=False)
    def stop(self):
        global pending
        if pending is None and hits < limit:
            pde = int(gdb.parse_and_eval('$rdi'))
            element = int(gdb.parse_and_eval('$rsi'))
            pending = {'pde': pde, 'element': element}
            records.append(snapshot('pre-call', pde, element))
        return False

class ReturnSite(gdb.Breakpoint):
    def __init__(self):
        super(ReturnSite, self).__init__('*' + os.environ['POSTPROCESS_RETURN_PC'], internal=False)
    def stop(self):
        global pending, hits
        if pending is not None:
            records.append(snapshot('post-call', pending['pde'], pending['element']))
            hits += 1
            pending = None
            if hits >= limit:
                call_bp.enabled = False
                self.enabled = False
        return False

call_bp = CallSite()
return_bp = ReturnSite()
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
exitcode = None
def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)
gdb.events.exited.connect(exited)
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records}, open(out, 'w'), indent=2)
