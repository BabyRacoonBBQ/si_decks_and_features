from __future__ import annotations
import hashlib, json, os, shutil, subprocess
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-scatter-all-hash-20261011-corrected2'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
import fcntl
fcntl.flock(LOCK, fcntl.LOCK_EX)
BINARIES = {'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect', 'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run'}
ENV = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSITE='1', TDR_VERSION='16')
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    ENV.pop(key, None)
V = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'
ENV['LD_LIBRARY_PATH'] = ':'.join([V + '/lib', V + '/lib/gds2tcadLib', V + '/lib/gds2tcadLib/tbcload1.7', V + '/lib/python3.11/site-packages/sinterconnect', V + '/lib/python3.11/site-packages/floops', V + '/lib/python3.11/site-packages/sdevice', V + '/tcad_mpi_mpich_ifort/lib', V + '/tcad_mpi_intel/lib'])
ENV['STROOT'] = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1'; ENV['STRELEASE'] = 'W-2024.09-SP1'; ENV['TCADPATH'] = ENV['STROOT']
records = []
for tool, binary in BINARIES.items():
    run_dir = OUT / tool
    shutil.copytree(ROOT / 'prepared', run_dir)
    shutil.copy2(ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr', run_dir / 'global_sis.tdr')
    env = dict(ENV, AUDIT_OUT=str(run_dir / 'scatter-all-hash-events.json'), AUDIT_LIMIT='32768')
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch', '-ex', 'source /tmp/scatter-all-hash-gdb.py', '--args', binary]
    if tool == 'vendor': argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    with (run_dir / 'scatter-all-hash-gdb.log').open('w') as log:
        proc = subprocess.run(argv, cwd=run_dir, env=env, stdout=log, stderr=subprocess.STDOUT)
    event_path = run_dir / 'scatter-all-hash-events.json'
    obj = json.loads(event_path.read_text()) if event_path.exists() else {}
    rec = {'tool': tool, 'observer_exit': proc.returncode, 'inferior_exit': obj.get('exit'), 'counts': obj.get('counts'), 'event_count': len(obj.get('events', []))}
    records.append(rec)
    if proc.returncode != 0 or obj.get('exit') != 0: raise RuntimeError(rec)
(OUT / 'exit.json').write_text(json.dumps({'exit': 0, 'runs': records}, indent=2))
print(json.dumps(records, indent=2))
