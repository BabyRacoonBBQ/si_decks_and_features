import gdb, json, os

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
hits = {}
observations = []

class First(gdb.Breakpoint):
    def __init__(self, p):
        self.name = p['name']
        self.total = 0
        super().__init__('*' + p['address'], internal=False)

    def stop(self):
        self.total += 1
        hits[self.name] = self.total
        observations.append({
            'name': self.name,
            'pc': str(gdb.parse_and_eval('$pc')),
            'symbol': gdb.execute('info symbol $pc', to_string=True),
            'stack': gdb.execute('bt 12', to_string=True),
        })
        self.enabled = False
        return False

for probe in probes:
    First(probe)

exitcode = None
def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)

gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exitcode, 'hits': hits, 'observations': observations, 'probes': probes}, open(out, 'w'), indent=2)
