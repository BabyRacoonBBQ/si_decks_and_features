import gdb, json, os

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
records = []
exitcode = None

def array_at(addr, count=6):
    if not addr:
        return None
    t = gdb.lookup_type('double').pointer()
    p = gdb.Value(addr).cast(t)
    return [float((p + i).dereference()) for i in range(count)]

def double_row_from_double_ptr(addr):
    if not addr:
        return None
    t = gdb.lookup_type('double').pointer()
    pp = gdb.Value(addr).cast(t.pointer())
    row = pp.dereference()
    return [float((row + i).dereference()) for i in range(6)] if int(row) else None

class ReturnProbe(gdb.FinishBreakpoint):
    def __init__(self, entry, strain_ptr, stress_ptr, flag):
        super().__init__(internal=True)
        self.entry = entry
        self.strain_ptr = strain_ptr
        self.stress_ptr = stress_ptr
        self.flag = flag
    def stop(self):
        records.append({
            'phase': 'return',
            'entry': self.entry,
            'flag': self.flag,
            'strain_row0': double_row_from_double_ptr(self.strain_ptr),
            'stress_row0': double_row_from_double_ptr(self.stress_ptr),
            'pc': str(gdb.parse_and_eval('$pc')),
            'stack': gdb.execute('bt 12', to_string=True),
        })
        return False

class EntryProbe(gdb.Breakpoint):
    def __init__(self, p):
        self.name = p['name']
        self.seen = False
        super().__init__('*' + p['address'], internal=False)
    def stop(self):
        if self.seen:
            return False
        self.seen = True
        rsp = int(gdb.parse_and_eval('$rsp'))
        # `this` occupies RDI, so the first three stack arguments are pde,
        # strain, stress; the bool flag is the fourth stack argument.
        strain_ptr = int(gdb.parse_and_eval('*(void**)($rsp+16)'))
        stress_ptr = int(gdb.parse_and_eval('*(void**)($rsp+24)'))
        flag = int(gdb.parse_and_eval('*(unsigned char*)($rsp+32)'))
        records.append({
            'phase': 'entry',
            'entry': self.name,
            'flag': flag,
            'strain_ptr': hex(strain_ptr),
            'stress_ptr': hex(stress_ptr),
            'strain_row0': double_row_from_double_ptr(strain_ptr),
            'stress_row0': double_row_from_double_ptr(stress_ptr),
            'pc': str(gdb.parse_and_eval('$pc')),
            'stack': gdb.execute('bt 12', to_string=True),
        })
        ReturnProbe(self.name, strain_ptr, stress_ptr, flag)
        self.enabled = False
        return False

for p in probes:
    EntryProbe(p)

def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)

gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records, 'probes': probes}, open(out, 'w'), indent=2)
