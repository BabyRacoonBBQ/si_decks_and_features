from pathlib import Path
import os, json, subprocess, shutil, hashlib, time, fcntl

root = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
out = root / 'honesty-audit-g'
out.mkdir(exist_ok=False)
lock = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
binary = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect'
probes = [
    ('siGeneralBoundary::ctor', '0x129e1c0'),
    ('siGeneralBoundary::dtor_D2', '0x129a890'),
    ('siGeneralBoundary::dtor_D0', '0x129b110'),
    ('GeneralBoundary::ctor', '0x1895ab0'),
    ('GeneralBoundary::dtor', '0x1891f20'),
    ('GeneralBoundary::shared_ptr_dispose', '0x129a910'),
    ('MechController::ctor_state', '0x18cced0'),
    ('MechController::ctor', '0x18cd370'),
    ('MechController::dtor', '0x18cd5a0'),
    ('MechanicsSolver::ctor', '0x1998210'),
    ('MechanicsSolver::dtor', '0x19986e0'),
    ('Tdr_writer::ctor', '0x14fb500'),
    ('Tdr_writer::populate', '0x1506c20'),
    ('Tdr_writer::dtor', '0x14eeb90'),
    ('StructureWriter::ctor', '0x1c83a90'),
    ('StructureWriter::processAndWriteTdr', '0x1c846f0'),
    ('StructureWriter::dtor', '0x1c7e990'),
]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSERSITE='1', TDR_VERSION='16')
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)
src = root / 'prepared'
d = out / 'vendor'
shutil.copytree(src, d)
(d / 'probes.json').write_text(json.dumps([{'name': n, 'address': a} for n, a in probes]))
records = []
for stage in ('global', 'unit-fine'):
    env.update(AUDIT_OUT=str(d / (stage + '-events.json')), AUDIT_PROBES=str(d / 'probes.json'))
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch',
            '-ex', 'source /tmp/honesty-probe.py', '--args', binary, '--noSyntaxCheck', stage + '.cmd']
    start = time.time()
    with (d / (stage + '-gdb.log')).open('w') as log:
        p = subprocess.run(argv, cwd=d, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = json.loads((d / (stage + '-events.json')).read_text())
    output = d / (stage + '_sis.tdr')
    record = {'tool': 'vendor', 'stage': stage, 'observer_exit': p.returncode,
              'inferior_exit': result.get('exit'), 'start': start, 'wall': time.time() - start,
              'binary_sha256': sha(binary), 'deck_sha256': sha(d / (stage + '.cmd')),
              'output_sha256': sha(output) if output.exists() else None,
              'global_input_sha256': sha(d / 'global_sis.tdr') if stage == 'unit-fine' else None}
    records.append(record)
    (out / 'progress.json').write_text(json.dumps(records, indent=2))
    print('END', json.dumps(record), flush=True)
    if p.returncode or result.get('exit') != 0:
        raise RuntimeError('vendor lifecycle follow-up failed')
(out / 'exit.json').write_text(json.dumps({'exit': 0, 'runs': records}, indent=2))
