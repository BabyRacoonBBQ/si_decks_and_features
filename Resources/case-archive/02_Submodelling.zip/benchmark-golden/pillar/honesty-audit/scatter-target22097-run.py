from __future__ import annotations
import json, os, shutil, subprocess, time
from pathlib import Path
ROOT=Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT=ROOT/'honesty-audit-scatter-target22097-20261011'
OUT.mkdir(exist_ok=False)
LOCK=open('/tmp/geo3d-sinterconnect-heavy.lock','w')
import fcntl
fcntl.flock(LOCK, fcntl.LOCK_EX)
BINARIES={'vendor':'/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect','local-repair':'/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run'}
ENV=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONNOUSITE='1',TDR_VERSION='16')
for key in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'): ENV.pop(key,None)
V='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'
ENV['LD_LIBRARY_PATH']=':'.join([V+'/lib',V+'/lib/gds2tcadLib',V+'/lib/gds2tcadLib/tbcload1.7',V+'/lib/python3.11/site-packages/sinterconnect',V+'/lib/python3.11/site-packages/floops',V+'/lib/python3.11/site-packages/sdevice',V+'/tcad_mpi_mpich_ifort/lib',V+'/tcad_mpi_intel/lib'])
ENV['STROOT']='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1'; ENV['STRELEASE']='W-2024.09-SP1'; ENV['TCADPATH']=ENV['STROOT']
records=[]
for tool,binary in BINARIES.items():
    d=OUT/tool; shutil.copytree(ROOT/'prepared',d); shutil.copy2(ROOT/'honesty-audit-b'/('vendor' if tool=='vendor' else 'local')/'global_sis.tdr',d/'global_sis.tdr')
    env=dict(ENV,AUDIT_OUT=str(d/'scatter-target22097-events.json'),AUDIT_TARGET='22097')
    argv=['timeout','-k','10','900','taskset','-c','4','gdb','-q','-nx','-batch','-ex','source /tmp/scatter-target22097-gdb.py','--args',binary]
    if tool=='vendor': argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    with (d/'scatter-target22097-gdb.log').open('w') as log: proc=subprocess.run(argv,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
    p=d/'scatter-target22097-events.json'; obj=json.loads(p.read_text()) if p.exists() else {}
    records.append({'tool':tool,'observer_exit':proc.returncode,'inferior_exit':obj.get('exit'),'hits':obj.get('hits'),'events':len(obj.get('events',[]))})
    if proc.returncode!=0 or obj.get('exit')!=0: raise RuntimeError(records[-1])
(OUT/'exit.json').write_text(json.dumps({'exit':0,'runs':records},indent=2)); print(json.dumps(records,indent=2))
