import gdb, json, os, struct
from pathlib import Path
OUT = os.environ['AUDIT_OUT']
TARGET = int(os.environ.get('AUDIT_TARGET', '22097'))
count = 0
events = []

def read(inf, addr, n):
    return inf.read_memory(addr, n).tobytes()

def Probe():
    class P(gdb.Breakpoint):
        def __init__(self):
            super().__init__('floops::BasicSingleStiff::ssScatter(floops::Vector&, floops::Vector*)', internal=False)
        def stop(self):
            global count
            count += 1
            if count != TARGET:
                return False
            inf = gdb.selected_inferior()
            stiff = int(gdb.parse_and_eval('$rdi'))
            row_count = struct.unpack('<i', read(inf, stiff + 0xc, 4))[0]
            n = max(0, min(row_count, 64))
            row_ids = list(struct.unpack('<{}i'.format(n), read(inf, stiff + 0x1c, n * 4))) if n else []
            ss_data = struct.unpack('<Q', read(inf, stiff + 0x990, 8))[0]
            ss_vals = list(struct.unpack('<{}d'.format(n), read(inf, ss_data, n * 8))) if n else []
            ret_addr = struct.unpack('<Q', read(inf, int(gdb.parse_and_eval('$rsp')), 8))[0]
            events.append({'count': count, 'row_count': row_count, 'row_ids': row_ids, 'ss_values': ss_vals, 'pc': hex(int(gdb.parse_and_eval('$pc'))), 'return_address': hex(ret_addr), 'stiff_ptr': hex(stiff), 'ss_data': hex(ss_data), 'stack': gdb.execute('bt 12', to_string=True)})
            self.enabled = False
            return False
    P()
Probe()
exit_code = None
def exited(event):
    global exit_code
    exit_code = getattr(event, 'exit_code', None)
gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
Path(OUT).write_text(json.dumps({'exit': exit_code, 'target': TARGET, 'hits': count, 'events': events}, indent=2))
