import gdb, json, os

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
records = []
exitcode = None

def mem_int(addr, off, fmt):
    return int(gdb.parse_and_eval(f'*({fmt})({hex(addr + off)})'))

def rows(stiff):
    if not stiff: return None
    rows_ptr = mem_int(stiff, 0, 'void**')
    count = mem_int(stiff, 0x0c, 'int*')
    if not rows_ptr or count <= 0 or count > 64: return {'count': count, 'rows': None}
    result = []
    row_size = 2424
    for i in range(min(count, 8)):
        row = rows_ptr + i * row_size
        size = mem_int(row, 0x08, 'int*')
        data = mem_int(row, 0x10, 'void**')
        vals = []
        if data and 0 < size <= 64:
            for j in range(min(size, 12)):
                vals.append(float(gdb.parse_and_eval(f'*((double*){hex(data)} + {j})')))
        result.append({'size': size, 'values': vals})
    return {'count': count, 'rows': result}

class ReturnProbe(gdb.FinishBreakpoint):
    def __init__(self, entry, stiff):
        super().__init__(internal=True); self.entry = entry; self.stiff = stiff
    def stop(self):
        records.append({'phase':'return','entry':self.entry,'stiff_ptr':hex(self.stiff),
                        'matrix':rows(self.stiff),'pc':str(gdb.parse_and_eval('$pc')),
                        'stack':gdb.execute('bt 10',to_string=True)})
        return False

class EntryProbe(gdb.Breakpoint):
    def __init__(self,p): self.name=p['name']; self.seen=False; super().__init__('*'+p['address'],internal=False)
    def stop(self):
        if self.seen: return False
        self.seen=True
        stiff=int(gdb.parse_and_eval('$rsi'))
        records.append({'phase':'entry','entry':self.name,'stiff_ptr':hex(stiff),
                        'matrix':rows(stiff),'pc':str(gdb.parse_and_eval('$pc')),
                        'stack':gdb.execute('bt 10',to_string=True)})
        ReturnProbe(self.name,stiff); self.enabled=False; return False

for p in probes: EntryProbe(p)
def exited(event):
    global exitcode; exitcode=getattr(event,'exit_code',None)
gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
json.dump({'exit':exitcode,'records':records,'probes':probes},open(out,'w'),indent=2)
