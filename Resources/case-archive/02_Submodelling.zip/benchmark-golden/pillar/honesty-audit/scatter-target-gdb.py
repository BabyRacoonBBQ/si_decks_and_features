import gdb, hashlib, json, os, struct
from pathlib import Path

out = os.environ['AUDIT_OUT']
events = []
counts = {}
returns = {}
limit = int(os.environ.get('AUDIT_LIMIT', '64'))


def scalar(expr):
    try:
        return str(gdb.parse_and_eval(expr))
    except Exception as exc:
        return 'ERROR:' + str(exc)


def read_u64(inf, address):
    return struct.unpack('<Q', inf.read_memory(address, 8).tobytes())[0]


def read_i64(inf, address):
    return struct.unpack('<q', inf.read_memory(address, 8).tobytes())[0]


def vector_snapshot(address, label):
    row = {'label': label, 'object': hex(address) if address else None}
    if not address:
        return row
    try:
        inf = gdb.selected_inferior()
        size = read_i64(inf, address + 8)
        data = read_u64(inf, address + 16)
        row['size'] = size
        row['data'] = hex(data) if data else None
        if data and 0 < size <= 20_000_000:
            raw = inf.read_memory(data, size * 8).tobytes()
            dump_dir = os.environ.get('AUDIT_DUMP_DIR')
            if dump_dir and (label in ('increment-at-updateSolution', 'rhs-at-PreCondOnly-entry') or label.startswith('rhs-trace-') or label.startswith('scatter-rhs-')):
                Path(dump_dir).mkdir(parents=True, exist_ok=True)
                if label == 'increment-at-updateSolution':
                    filename = 'increment-at-updateSolution.bin'
                elif label == 'rhs-at-PreCondOnly-entry':
                    filename = 'rhs-at-PreCondOnly-entry.bin'
                else:
                    filename = label + '.bin'
                Path(dump_dir, filename).write_bytes(raw)
            row['sha256'] = hashlib.sha256(raw).hexdigest()
            vals = struct.unpack('<{}d'.format(min(size, 8)), raw[:min(size, 8) * 8]) if size else ()
            tail_count = min(size, 8)
            tail = struct.unpack('<{}d'.format(tail_count), raw[-tail_count * 8:]) if tail_count else ()
            row['head'] = list(vals)
            row['tail'] = list(tail)
            row['max_abs'] = max((abs(v) for v in struct.unpack('<{}d'.format(size), raw)), default=0.0)
        else:
            row['read_error'] = 'invalid size or data pointer'
    except Exception as exc:
        row['read_error'] = str(exc)
    return row


def record(name, extra=None):
    count = counts.get(name, 0) + 1
    counts[name] = count
    if count > limit:
        return
    row = {'name': name, 'count': count, 'pc': scalar('$pc')}
    if extra:
        row.update(extra)
    try:
        row['stack'] = gdb.execute('bt 10', to_string=True)
        row['symbol'] = gdb.execute('info symbol $pc', to_string=True)
    except Exception as exc:
        row['stack_error'] = str(exc)
    events.append(row)


class ReturnProbe(gdb.FinishBreakpoint):
    def __init__(self, frame, name, payload):
        self.name = name
        self.payload = payload
        super().__init__(frame, internal=True)

    def stop(self):
        payload = dict(self.payload)
        payload['rax'] = scalar('$rax')
        payload['xmm0'] = scalar('$xmm0.v2_double[0]')
        if self.name.endswith('Solve-return') or self.name == 'ILS::solve-return':
            payload['rhs_after'] = vector_snapshot(payload.pop('rhs_ptr'), 'rhs-after')
            payload['solution_after'] = vector_snapshot(payload.pop('solution_ptr'), 'solution-after')
        elif 'after_label' in payload:
            payload['rhs_after'] = vector_snapshot(payload.pop('rhs_ptr'), payload.pop('after_label'))
        returns.setdefault(self.name, []).append(payload)
        return False


class SolveProbe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::Iterate::Solve(floops::Matrix&, floops::Preconditioner&, floops::Vector&, floops::Vector&, int)', internal=False)

    def stop(self):
        rhs = int(gdb.parse_and_eval('$rcx'))
        solution = int(gdb.parse_and_eval('$r8'))
        payload = {
            'this_ptr': scalar('$rdi'),
            'matrix_ptr': scalar('$rsi'),
            'preconditioner_ptr': scalar('$rdx'),
            'rhs_ptr': rhs,
            'solution_ptr': solution,
            'rhs_before': vector_snapshot(rhs, 'rhs-before'),
            'solution_before': vector_snapshot(solution, 'solution-before'),
        }
        record('Iterate::Solve', payload)
        try:
            ReturnProbe(gdb.newest_frame(), 'Iterate::Solve-return', payload)
        except Exception:
            pass
        return False


class UpdateProbe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::MechSolver::updateSolution(floops::Vector&)', internal=False)

    def stop(self):
        vector = int(gdb.parse_and_eval('$rsi'))
        record('MechSolver::updateSolution', {
            'this_ptr': scalar('$rdi'),
            'vector_ptr': vector,
            'vector': vector_snapshot(vector, 'increment-at-updateSolution'),
        })
        return False


class PreCondOnlyProbe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::PreCondOnly::Solve(floops::Matrix&, floops::Preconditioner&, floops::Vector&, floops::Vector&, int)', internal=False)

    def stop(self):
        rhs = int(gdb.parse_and_eval('$rcx'))
        solution = int(gdb.parse_and_eval('$r8'))
        payload = {
            'matrix_ptr': scalar('$rsi'),
            'preconditioner_ptr': scalar('$rdx'),
            'rhs_ptr': rhs,
            'solution_ptr': solution,
            'rhs_before': vector_snapshot(rhs, 'rhs-at-PreCondOnly-entry'),
            'solution_before': vector_snapshot(solution, 'solution-at-PreCondOnly-entry'),
        }
        record('PreCondOnly::Solve', payload)
        try:
            ReturnProbe(gdb.newest_frame(), 'PreCondOnly::Solve-return', payload)
        except Exception:
            pass
        return False


class ILSProbe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::ILS::solve(floops::Vector&, floops::Vector&, int)', internal=False)

    def stop(self):
        solution = int(gdb.parse_and_eval('$rsi'))
        rhs = int(gdb.parse_and_eval('$rdx'))
        payload = {
            'solution_ptr': solution,
            'rhs_ptr': rhs,
            'rhs_before': vector_snapshot(rhs, 'rhs-at-ILS-entry'),
            'solution_before': vector_snapshot(solution, 'solution-at-ILS-entry'),
        }
        record('ILS::solve', payload)
        try:
            ReturnProbe(gdb.newest_frame(), 'ILS::solve-return', payload)
        except Exception:
            pass
        return False


class RhsBoundaryProbe(gdb.Breakpoint):
    SPECS = {
        'MechanicsSolver::pLoadBulk': ('floops::MechanicsSolver::pLoadBulk(floops::Matrix&, floops::Vector&, floops::Vector*, double, int)', '$rdx'),
        'MechanicsSolver::LoadBoundaryAndInterface': ('floops::MechanicsSolver::LoadBoundaryAndInterface(floops::Vector&, floops::Vector*, int)', '$rsi'),
    }

    def __init__(self, name, spec, register):
        self.name = name
        self.register = register
        super().__init__(spec, internal=False)

    def stop(self):
        count = counts.get(self.name, 0) + 1
        counts[self.name] = count
        rhs = int(gdb.parse_and_eval(self.register))
        payload = {
            'rhs_ptr': rhs,
            'rhs_entry': vector_snapshot(rhs, 'rhs-trace-' + self.name.replace('::', '-') + '-entry-' + str(count)),
            'after_label': 'rhs-trace-' + self.name.replace('::', '-') + '-return-' + str(count),
        }
        if count <= limit:
            record(self.name + '-entry', payload)
        try:
            ReturnProbe(gdb.newest_frame(), self.name + '-return', payload)
        except Exception:
            pass
        return False


class ExitProbe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::MechController::mechanicsPostProcess(floops::MechParams*)', internal=False)

    def stop(self):
        record('mechanicsPostProcess-entry', {'this_ptr': scalar('$rdi'), 'params_ptr': scalar('$rsi')})
        return False



SCATTER_TARGETS = {8192,9000,10000,11000,12000,13000,14000,15000,16000}

class ScatterProbe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::BasicSingleStiff::ssScatter(floops::Vector&, floops::Vector*)', internal=False)
        self.enabled = True

    def stop(self):
        count = counts.get('BasicSingleStiff::ssScatter', 0) + 1
        counts['BasicSingleStiff::ssScatter'] = count
        if count > 16000:
            self.enabled = False
            return False
        if count not in SCATTER_TARGETS:
            return False
        rhs = int(gdb.parse_and_eval('$rsi'))
        abs_ptr = int(gdb.parse_and_eval('$rdx'))
        payload = {
            'stiff_ptr': scalar('$rdi'),
            'rhs_ptr': rhs,
            'abs_ptr': abs_ptr,
            'after_label': f'scatter-rhs-return-{count}',
            'rhs_entry': vector_snapshot(rhs, f'scatter-rhs-entry-{count}'),
            'stiff_bytes': gdb.selected_inferior().read_memory(int(gdb.parse_and_eval('$rdi')), 256).tobytes().hex(),
        }
        record('BasicSingleStiff::ssScatter-entry', payload)
        if count >= 16000:
            self.enabled = False
        try:
            ReturnProbe(gdb.newest_frame(), 'BasicSingleStiff::ssScatter-return', payload)
        except Exception:
            pass
        return False


ScatterProbe()
SolveProbe()
UpdateProbe()
PreCondOnlyProbe()
ILSProbe()
for _name, (_spec, _register) in RhsBoundaryProbe.SPECS.items():
    RhsBoundaryProbe(_name, _spec, _register)
ExitProbe()
exit_code = None


def exited(event):
    global exit_code
    exit_code = getattr(event, 'exit_code', None)


gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exit_code, 'counts': counts, 'returns': returns, 'events': events}, open(out, 'w'), indent=2)
