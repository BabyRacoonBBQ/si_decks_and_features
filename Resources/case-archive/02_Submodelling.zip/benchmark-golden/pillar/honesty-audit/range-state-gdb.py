import gdb,json,os,struct
out=os.environ['AUDIT_OUT']; probes=json.load(open(os.environ['AUDIT_PROBES'])); counts={}; observations=[]
def read_state():
 inf=gdb.selected_inferior(); this=int(gdb.parse_and_eval('$rdi')); rp=int(gdb.parse_and_eval('$rsi')); b=inf.read_memory(rp,8).tobytes(); start,end=struct.unpack('<ii',b); raw=inf.read_memory(this+0x7e8,20).tobytes(); dt,mode=struct.unpack_from('<di',raw,0); skip=raw[12]; pde=struct.unpack_from('<i',raw,16)[0]
 mesh=struct.unpack('<Q',inf.read_memory(this+0x1670,8).tobytes())[0]
 return {'this':hex(this),'range_ptr':hex(rp),'range_begin':start,'range_end':end,'assemblyDt':dt,'assembleMode':mode,'skipGrowthVelocity':skip,'pdePerSolution':pde,'meshParams':hex(mesh)}
class Probe(gdb.Breakpoint):
 def __init__(self,p): self.name=p['name']; super(Probe,self).__init__('*'+p['address'],internal=False)
 def stop(self):
  n=self.name; counts[n]=counts.get(n,0)+1
  row={'name':n,'count':counts[n]}
  try: row.update(read_state())
  except Exception as e: row['read_error']=str(e)
  if counts[n]==1: row['stack']=gdb.execute('bt 10',to_string=True); row['symbol']=gdb.execute('info symbol $pc',to_string=True)
  observations.append(row); return False
for p in probes: Probe(p)
exitcode=None
def exited(e):
 global exitcode; exitcode=getattr(e,'exit_code',None)
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run'); json.dump({'exit':exitcode,'counts':counts,'observations':observations,'probes':probes},open(out,'w'),indent=2)