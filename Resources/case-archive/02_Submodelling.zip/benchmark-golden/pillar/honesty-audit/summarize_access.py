from pathlib import Path
import re,json
base=Path('/home/mozztcad/si-bench/golden-pillar-20261011/honesty-files-a')
assert json.loads((base/'exit.json').read_text())['exit']==0
summary={}
for stage in ['global','unit-fine']:
 lines=[line for p in base.glob(stage+'-syscalls*') for line in p.read_text().splitlines()]
 execs=[l for l in lines if l.startswith(('execve(', 'execveat('))]
 tdr=[l for l in lines if '.tdr' in l and l.startswith(('open(', 'openat('))]
 vendor=[l for l in lines if '/synopsys/' in l]
 libs=[l for l in lines if '.so' in l and re.search(r'= [0-9]+$',l)]
 connections=[l for l in lines if l.startswith('connect(')]
 summary[stage]={'execs':execs,'tdr_opens':tdr,'synopsys_path_accesses':vendor,'successful_library_opens':libs,'connections':connections}
(base/'access-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({s:{k:v for k,v in d.items() if k!='successful_library_opens'} for s,d in summary.items()},indent=2))
