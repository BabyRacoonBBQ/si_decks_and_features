set breakpoint pending on
break 'sinterconnect::siMechPDE::getDisplacements(floops::Element*, floops::ElementIter&)'
info breakpoints