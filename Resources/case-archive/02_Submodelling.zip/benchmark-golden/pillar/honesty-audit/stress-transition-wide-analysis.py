from __future__ import annotations

import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "stress-transition-wide-20261011"
STRESS = "computeStressHOE"
ELASTIC = "computeElasticStrainHOE"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def short_name(name: str) -> str:
    return STRESS if STRESS in name else ELASTIC if ELASTIC in name else name


def classify(record):
    stack = record.get("stack", "")
    if "MechanicsSolver::updateStress" in stack:
        return "postprocess"
    if "RunAssemble" in stack or "computeElemStiffHOE" in stack:
        return "assembly"
    return "other"


def finite_max_abs(a, b):
    diffs = []
    for x, y in zip(a or [], b or []):
        try:
            if math.isfinite(float(x)) and math.isfinite(float(y)):
                diffs.append(abs(float(x) - float(y)))
        except (TypeError, ValueError):
            pass
    return max(diffs, default=0.0)


def classify_events(events):
    result = {"counts": {}, "by_kind": {"stress": [], "elastic": []}}
    for record in events.get("records", []):
        key = (short_name(record.get("entry", "")), record.get("phase"), classify(record))
        result["counts"]["|".join(key)] = result["counts"].get("|".join(key), 0) + 1
        kind = "stress" if short_name(record.get("entry", "")) == STRESS else "elastic" if short_name(record.get("entry", "")) == ELASTIC else None
        if kind and record.get("phase") in ("entry", "return"):
            result["by_kind"][kind].append(record)
    return result


def sequence(events, kind, phase, bucket):
    return [r for r in events.get("records", []) if short_name(r.get("entry", "")) == kind and r.get("phase") == phase and classify(r) == bucket]


def compare(vendor, local, kind, phase, bucket):
    v = sequence(vendor, kind, phase, bucket)
    l = sequence(local, kind, phase, bucket)
    n = min(len(v), len(l))
    first = None
    max_diff = 0.0
    for i in range(n):
        diff = finite_max_abs(v[i].get("row0"), l[i].get("row0"))
        max_diff = max(max_diff, diff)
        if first is None and diff != 0.0:
            first = {
                "index": i,
                "vendor_hit": v[i].get("hit"),
                "local_hit": l[i].get("hit"),
                "vendor_row0": v[i].get("row0"),
                "local_row0": l[i].get("row0"),
                "max_abs_diff": diff,
            }
    return {
        "vendor_count": len(v),
        "local_count": len(l),
        "paired_count": n,
        "first_nonzero_row0_diff": first,
        "max_row0_abs_diff": max_diff,
    }


def main():
    vendor = load(ROOT / "vendor" / "events.json")
    local = load(ROOT / "local-repair" / "events.json")
    summary = {
        "vendor_exit": vendor.get("exit"),
        "local_exit": local.get("exit"),
        "vendor": classify_events(vendor),
        "local": classify_events(local),
        "comparisons": {},
    }
    for kind in (STRESS, ELASTIC):
        for phase in ("entry", "return"):
            for bucket in ("assembly", "postprocess", "other"):
                summary["comparisons"][f"{kind}|{phase}|{bucket}"] = compare(vendor, local, kind, phase, bucket)
    (ROOT / "analysis.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
