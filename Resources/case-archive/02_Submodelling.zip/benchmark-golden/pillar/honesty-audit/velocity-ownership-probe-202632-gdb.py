import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; events=[]; hits=0
def u64(a):
    try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
    except Exception:return 0
def reg(n):
    try:return int(gdb.parse_and_eval('$'+n))
    except Exception:return 0
def snap(phase,obj):
    if not obj:return {'phase':phase,'this':None}
    vel=u64(obj+0x748); gb=u64(obj+0x730); gbobj=gb
    # libstdc++ shared_ptr stores the managed pointer at object start.
    gbvel=u64(gbobj+0x8) if gbobj else 0
    return {'phase':phase,'this':hex(obj),'solver_velocity_solution':hex(vel) if vel else None,'solver_velocity_field':hex(u64(vel+0x110)) if vel else None,'general_boundary_shared_ptr':hex(gb) if gb else None,'general_boundary_object':hex(gbobj) if gbobj else None,'boundary_velocity_solution':hex(gbvel) if gbvel else None,'boundary_velocity_field':hex(u64(gbvel+0x110)) if gbvel else None}
class Ret(gdb.FinishBreakpoint):
    def __init__(self,obj):self.obj=obj;super().__init__(internal=True)
    def stop(self):events.append(snap('return',self.obj));return False
class BP(gdb.Breakpoint):
    def __init__(self):super().__init__('*'+os.environ['INIT_PC'],internal=False)
    def stop(self):
        global hits
        hits+=1; obj=reg('rdi'); events.append(snap('entry',obj)); Ret(obj); return False
BP()
def exited(e):Path(OUT).write_text(json.dumps({'exit':getattr(e,'exit_code',None),'hits':hits,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')
