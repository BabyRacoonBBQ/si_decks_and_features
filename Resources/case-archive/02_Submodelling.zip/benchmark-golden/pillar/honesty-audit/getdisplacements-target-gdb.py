import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097')); count=0; events=[]
def reg(n):
 try:return int(gdb.parse_and_eval('$'+n))
 except:return 0
def u64(a):
 try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return 0
def d(a):
 try:return struct.unpack('<d',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return None
def vals(a,n=3):return [d(a+8*i) for i in range(n)] if a else [None]*n
def field_value(pde):
 vs=u64(pde+0x710) if pde else 0; field=u64(vs+0x110) if vs else 0; slots=u64(field+0x68) if field else 0; seg=u64(slots+8*85) if slots else 0; data=u64(seg) if seg else 0
 return {'velocity_solution':hex(vs) if vs else None,'velocity_field':hex(field) if field else None,'data':hex(data) if data else None,'velocity_value':vals(data+24*1020) if data else [None]*3}
def snap(phase,pde,element):return {'phase':phase,'pde':hex(pde) if pde else None,'element':hex(element) if element else None,'pde_displacement':vals(pde+0x218,30) if pde else [],**field_value(pde),'stack':gdb.execute('bt 10',to_string=True)}
class Ret(gdb.FinishBreakpoint):
 def __init__(self,pde,element):self.pde=pde;self.element=element;super().__init__(internal=True)
 def stop(self):events.append(snap('return',self.pde,self.element));return False
class BP(gdb.Breakpoint):
 def __init__(self):super().__init__('*'+os.environ['GETDISP_PC'],internal=False)
 def stop(self):
  global count
  count+=1
  if count==TARGET:
   pde=reg('rdi');element=reg('rsi');events.append(snap('entry',pde,element));Ret(pde,element);self.enabled=False
  return False
bp=BP()
def exited(e):Path(OUT).write_text(json.dumps({'exit':getattr(e,'exit_code',None),'target':TARGET,'hits':count,'events':events},indent=2))
gdb.events.exited.connect(exited);gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')