import gdb, hashlib, json, os, struct
from pathlib import Path

out = os.environ['AUDIT_OUT']
events=[]
counts={}
TARGETS={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12000,14000,16000,16384,18000,20000,24000,32000,40000,50000}
LIMIT=int(os.environ.get('AUDIT_LIMIT','50000'))

def read_int(inf, addr): return struct.unpack('<i', inf.read_memory(addr,4).tobytes())[0]
def read_doubles(inf, addr, n): return list(struct.unpack('<{}d'.format(n), inf.read_memory(addr,n*8).tobytes()))
def snap(stiff, label):
    row={'label':label,'stiff_ptr':hex(stiff)}
    try:
        inf=gdb.selected_inferior()
        n=read_int(inf, stiff+0xc)
        rowids=struct.unpack('<{}i'.format(max(0,min(n,300))), inf.read_memory(stiff+0x18+4, max(0,min(n,300))*4).tobytes()) if n>0 else ()
        row['row_count']=n; row['row_ids']=list(rowids)
        sn=min(max(n,0),300)
        ss_ptr = struct.unpack('<Q', inf.read_memory(stiff + 0x990, 8).tobytes())[0]
        row['ss_ptr'] = hex(ss_ptr)
        ss=read_doubles(inf, ss_ptr, sn) if sn and ss_ptr else []
        row['ss_rhs']=ss; row['ss_sha256']=hashlib.sha256(struct.pack('<{}d'.format(sn),*ss)).hexdigest() if sn else hashlib.sha256(b'').hexdigest()
        row['ss_max_abs']=max((abs(x) for x in ss),default=0.0)
    except Exception as e: row['read_error']=str(e)
    return row
class Ret(gdb.FinishBreakpoint):
    def __init__(self, count, stiff, entry):
        self.count=count; self.stiff=stiff; self.entry=entry; super().__init__(gdb.newest_frame(),internal=True)
    def stop(self):
        events.append({'phase':'return','count':self.count,'entry':self.entry,'return_state':snap(self.stiff,'return')})
        return False
class Assemble(gdb.Breakpoint):
    def __init__(self): super().__init__('floops::MechPDE::AssembleElem(floops::Element&, floops::SingleStiff&, double, int, bool)',internal=False); self.count=0
    def stop(self):
        self.count+=1
        if self.count>LIMIT: self.enabled=False; return False
        if self.count in TARGETS:
            stiff=int(gdb.parse_and_eval('$rdx'))
            entry=snap(stiff,'entry')
            events.append({'phase':'entry','count':self.count,'stiff_ptr':hex(stiff),'entry_state':entry,'stack':gdb.execute('bt 8',to_string=True)})
            try: Ret(self.count,stiff,entry)
            except Exception as e: events.append({'phase':'finish-error','count':self.count,'error':str(e)})
        return False
asm = Assemble()

def exited(event):
    Path(out).write_text(json.dumps({'exit':int(event.exit_code),'counts':{'AssembleElem':asm.count},'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('run')

