import gdb,json,os
out=os.environ['AUDIT_OUT']; probes=json.load(open(os.environ['AUDIT_PROBES'])); events=[]; counts={}; returns={}; return_values={}
class Ret(gdb.FinishBreakpoint):
 def __init__(self,frame,name): self.name=name; super(Ret,self).__init__(frame,internal=True)
 def stop(self):
  returns[self.name]=returns.get(self.name,0)+1
  try: return_values.setdefault(self.name,[]).append(str(gdb.parse_and_eval('$rax')))
  except Exception as e: return_values.setdefault(self.name,[]).append('ERROR:'+str(e))
  return False
class Probe(gdb.Breakpoint):
 def __init__(self,p): self.name=p['name']; super(Probe,self).__init__('*'+p['address'],internal=False)
 def stop(self):
  n=self.name; counts[n]=counts.get(n,0)+1
  if counts[n]==1: events.append({'name':n,'pc':str(gdb.parse_and_eval('$pc')),'stack':gdb.execute('bt 12',to_string=True),'symbol':gdb.execute('info symbol $pc',to_string=True)})
  try: Ret(gdb.newest_frame(),n)
  except Exception as e: events.append({'name':n,'return_probe_error':str(e)})
  return False
for p in probes: Probe(p)
exitcode=None
def exited(e):
 global exitcode; exitcode=getattr(e,'exit_code',None)
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run'); json.dump({'exit':exitcode,'counts':counts,'returns':returns,'return_values':return_values,'events':events,'probes':probes},open(out,'w'),indent=2)