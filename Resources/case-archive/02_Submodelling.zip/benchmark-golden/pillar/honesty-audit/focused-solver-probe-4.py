from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path


ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-solver-focus-4'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
import fcntl
fcntl.flock(LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)

BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local': '/home/mozztcad/geo3d/build/sinterconnect_run',
}

NAMES = [
    'floops::Newton::Solve(floops::Vector&, int)',
    'floops::MechSolver::pLoadBulk(floops::Matrix&, floops::Vector&, floops::Vector*, double, int)',
    'floops::MechSolver::setupEquations()',
    'floops::MechSolver::calculateDisplacement()',
    'floops::MechanicsSolver::calculateDisplacement()',
    'floops::MechanicsSolver::pLoadBulk(floops::Matrix&, floops::Vector&, floops::Vector*, double, int)',
    'floops::MechanicsSolver::updateStress(floops::MechParams*)',
    'floops::MechanicsSolver::LoadBulk(floops::Matrix&, floops::Vector&, floops::Vector*, floops::MechParams*, double, int)',
    'floops::MechanicsSolver::setupEquations()',
    'floops::MechanicsSolver::bulkEquations(floops::Mesh&, int)',
    'floops::MechanicsSolver::RunAssemble(tbb::blocked_range<int> const&)',
    'floops::MechController::performMechanicsStep(double, double, double, bool)',
    'floops::MechController::computeCnvgAndCheck(int, bool, int, int, int, int, double, floops::Vector&, floops::Vector&, floops::MechParams*)',
    'floops::MechController::mechanicsPostProcess(floops::MechParams*)',
    'sinterconnect::siMechanicsSolver::setupBCs(bool)',
    'sinterconnect::siMechanicsSolver::calculateDisplacement()',
]


def sha(path: Path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def resolve(binary: str):
    symbols = subprocess.check_output(['nm'] + (['-D'] if binary == BINARIES['vendor'] else []) + ['-C', '--defined-only', binary], text=True)
    probes = []
    missing = []
    for name in NAMES:
        matches = [line.split(' ', 2) for line in symbols.splitlines() if line.endswith(' T ' + name)]
        if len(matches) == 1:
            probes.append({'name': name, 'address': '0x' + matches[0][0]})
        else:
            missing.append({'name': name, 'matches': matches})
    return probes, missing


env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSERSITE='1', TDR_VERSION='16')
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)

records = []
for tool, binary in BINARIES.items():
    probes, missing = resolve(binary)
    tool_dir = OUT / tool
    shutil.copytree(ROOT / 'prepared', tool_dir)
    shutil.copy2(ROOT / 'honesty-audit-b' / tool / 'global_sis.tdr', tool_dir / 'global_sis.tdr')
    (tool_dir / 'probes.json').write_text(json.dumps(probes, indent=2))
    env.update(AUDIT_OUT=str(tool_dir / 'unit-fine-focus-events.json'), AUDIT_PROBES=str(tool_dir / 'probes.json'))
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch', '-ex', 'source /tmp/honesty-probe.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    start = time.time()
    with (tool_dir / 'unit-fine-focus-gdb.log').open('w') as log:
        process = subprocess.run(argv, cwd=tool_dir, env=env, stdout=log, stderr=subprocess.STDOUT)
    events = json.loads((tool_dir / 'unit-fine-focus-events.json').read_text()) if (tool_dir / 'unit-fine-focus-events.json').exists() else {}
    record = {
        'tool': tool,
        'observer_exit': process.returncode,
        'inferior_exit': events.get('exit'),
        'wall': time.time() - start,
        'binary_sha256': sha(Path(binary)),
        'missing_common_probes': missing,
        'counts': events.get('counts'),
        'returns': events.get('returns'),
        'output_sha256': sha(tool_dir / 'unit-fine_sis.tdr') if (tool_dir / 'unit-fine_sis.tdr').exists() else None,
    }
    records.append(record)
    (OUT / 'progress.json').write_text(json.dumps(records, indent=2))
    if process.returncode or events.get('exit') != 0:
        raise RuntimeError(record)

(OUT / 'exit.json').write_text(json.dumps({'exit': 0, 'runs': records}, indent=2))
print(json.dumps(records, indent=2))
