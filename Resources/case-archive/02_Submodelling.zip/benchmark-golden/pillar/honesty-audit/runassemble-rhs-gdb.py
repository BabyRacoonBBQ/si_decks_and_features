import gdb, hashlib, json, os, struct
from pathlib import Path

out = os.environ['AUDIT_OUT']
dump_dir = Path(os.environ.get('AUDIT_DUMP_DIR', '.'))
events = []
counts = {}
limit = int(os.environ.get('AUDIT_LIMIT', '8'))

def read_u64(inf, address):
    return struct.unpack('<Q', inf.read_memory(address, 8).tobytes())[0]

def vector_snapshot(address, label, dump=False):
    row = {'label': label, 'object': hex(address) if address else None}
    if not address:
        return row
    try:
        inf = gdb.selected_inferior()
        size = struct.unpack('<q', inf.read_memory(address + 8, 8).tobytes())[0]
        data = read_u64(inf, address + 16)
        row.update({'size': size, 'data': hex(data) if data else None})
        if data and 0 < size <= 20000000:
            raw = inf.read_memory(data, size * 8).tobytes()
            row['sha256'] = hashlib.sha256(raw).hexdigest()
            vals = struct.unpack('<{}d'.format(size), raw)
            row['head'] = list(vals[:8])
            row['tail'] = list(vals[-8:])
            row['index_13495'] = vals[13495] if size > 13495 else None
            row['max_abs'] = max((abs(value) for value in vals), default=0.0)
            if dump:
                dump_dir.mkdir(parents=True, exist_ok=True)
                (dump_dir / (label + '.bin')).write_bytes(raw)
        else:
            row['read_error'] = 'invalid size or data pointer'
    except Exception as exc:
        row['read_error'] = str(exc)
    return row

class ReturnProbe(gdb.FinishBreakpoint):
    def __init__(self, frame, count, solver, entry):
        self.count = count
        self.solver = solver
        self.entry = entry
        super().__init__(frame, internal=True)
    def stop(self):
        rhs_obj = read_u64(gdb.selected_inferior(), self.solver + 0x210)
        events.append({'phase': 'return', 'count': self.count, 'entry': self.entry,
                       'rhs': vector_snapshot(rhs_obj, 'runassemble-rhs-return-%d' % self.count, True),
                       'pc': str(gdb.parse_and_eval('$pc'))})
        return False

class RunAssemble(gdb.Breakpoint):
    def __init__(self):
        exe = gdb.current_progspace().filename or ''
        # The repair's active optimized clone is not selected by the public
        # symbol breakpoint; bind each probe to the verified binary-specific
        # entry from nm/disassembly.
        address = '*0xe73b20' if 'honesty-repair' in exe else '*0x1999ad0'
        super().__init__(address, internal=False)
        self.count = 0
    def stop(self):
        self.count += 1
        if self.count > limit:
            return False
        solver = int(gdb.parse_and_eval('$rdi'))
        rhs_obj = read_u64(gdb.selected_inferior(), solver + 0x210)
        entry = {'phase': 'entry', 'count': self.count,
                 'solver': hex(solver), 'rhs': vector_snapshot(rhs_obj, 'runassemble-rhs-entry-%d' % self.count, True),
                 'stack': gdb.execute('bt 8', to_string=True)}
        events.append(entry)
        try:
            ReturnProbe(gdb.newest_frame(), self.count, solver, entry)
        except Exception as exc:
            events.append({'phase': 'finish-error', 'count': self.count, 'error': str(exc)})
        return False

probe = RunAssemble()
exit_code = None
def exited(event):
    global exit_code
    exit_code = getattr(event, 'exit_code', None)
    Path(out).write_text(json.dumps({'exit': exit_code, 'counts': {'RunAssemble': probe.count}, 'events': events}, indent=2))

gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
