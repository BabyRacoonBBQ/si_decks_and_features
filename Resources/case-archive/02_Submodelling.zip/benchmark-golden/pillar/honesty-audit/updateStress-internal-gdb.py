import gdb, json, os, struct

records = []
stress_hits = 0
stress_limit = 20
active = None

def read_u64(addr):
    try:
        return struct.unpack('<Q', gdb.selected_inferior().read_memory(addr, 8).tobytes())[0]
    except Exception:
        return 0

def vals(addr, count=6):
    if not addr:
        return None
    try:
        p = gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p + i).dereference()) for i in range(count)]
    except Exception as exc:
        return ['ERROR:' + str(exc)]

def array_snapshot(pde, offset):
    base = read_u64(pde + offset)
    rows = []
    if base:
        for i in range(8):
            rowptr = read_u64(base + 8 * i)
            rows.append({'index': i, 'ptr': hex(rowptr) if rowptr else None,
                         'values': vals(rowptr)})
    return {'array': hex(base) if base else None, 'rows': rows}

def snap(phase, pde, element=None, material=None):
    return {
        'phase': phase,
        'pde': hex(pde) if pde else None,
        'element': hex(element) if element else None,
        'material': hex(material) if material else None,
        'gpStrain': array_snapshot(pde, 0x3f8) if pde else None,
        'gpStress': array_snapshot(pde, 0x400) if pde else None,
        'stack': gdb.execute('bt 14', to_string=True),
    }

def raw_snap(phase, pde, element, material, strain_ptr, stress_ptr):
    out = snap(phase, pde, element, material)
    out['strain_arg'] = vals(strain_ptr)
    out['stress_arg'] = vals(stress_ptr)
    return out

class StageReturn(gdb.FinishBreakpoint):
    def __init__(self, phase, pde, element, material=None):
        self.phase = phase
        self.pde = pde
        self.element = element
        self.material = material
        super(StageReturn, self).__init__(internal=True)
    def stop(self):
        records.append(snap(self.phase + '-return', self.pde, self.element, self.material))
        return False

class StrainsBP(gdb.Breakpoint):
    def __init__(self):
        super(StrainsBP, self).__init__('*' + os.environ['COMPUTE_STRAINS_PC'], internal=False)
        self.enabled = False
    def stop(self):
        if active is None:
            return False
        try:
            pde = int(gdb.parse_and_eval('$rdi'))
            element = int(gdb.parse_and_eval('$rsi'))
            records.append(snap('computeStrains-entry', pde, element))
            StageReturn('computeStrains', active['pde'], active['element'])
            euler_bp.enabled = True
        except Exception:
            pass
        self.enabled = False
        return False

class EulerReturn(gdb.FinishBreakpoint):
    def __init__(self, pde, element, displacement, output):
        self.pde = pde
        self.element = element
        self.displacement = displacement
        self.output = output
        super(EulerReturn, self).__init__(internal=True)
    def stop(self):
        records.append({
            **snap('calc_euler_strain-return', self.pde, self.element),
            'displacement_arg': vals(self.displacement, 6),
            'strain_output': vals(self.output, 6),
        })
        return False

class EulerBP(gdb.Breakpoint):
    def __init__(self):
        super(EulerBP, self).__init__('*' + os.environ['EULER_STRAIN_PC'], internal=False)
        self.enabled = False
    def stop(self):
        if active is None or active.get('euler_seen'):
            return False
        active['euler_seen'] = True
        try:
            displacement = int(gdb.parse_and_eval('$rdx'))
            output = int(gdb.parse_and_eval('$rcx'))
            records.append({
                **snap('calc_euler_strain-entry', active['pde'], active['element']),
                'displacement_arg': vals(displacement, 6),
                'strain_output': vals(output, 6),
            })
            EulerReturn(active['pde'], active['element'], displacement, output)
        except Exception:
            pass
        self.enabled = False
        return False

class MaterialBP(gdb.Breakpoint):
    def __init__(self):
        super(MaterialBP, self).__init__('*' + os.environ['MATERIAL_PC'], internal=False)
        self.enabled = False
    def stop(self):
        if active is None:
            return False
        try:
            material = int(gdb.parse_and_eval('$rdi'))
            records.append(snap('calculate_D_and_Stress-entry', active['pde'], active['element'], material))
            StageReturn('calculate_D_and_Stress', active['pde'], active['element'], material)
            calc_stresses_bp.enabled = True
        except Exception:
            pass
        self.enabled = False
        return False

class CalculateStressesReturn(gdb.FinishBreakpoint):
    def __init__(self, pde, element, material):
        self.pde = pde
        self.element = element
        self.material = material
        super(CalculateStressesReturn, self).__init__(internal=True)
    def stop(self):
        records.append(snap('calculate_stresses-return', self.pde, self.element, self.material))
        calc_stress_bp.enabled = False
        euler_bp.enabled = False
        return False

class CalculateStressesBP(gdb.Breakpoint):
    def __init__(self):
        super(CalculateStressesBP, self).__init__('*' + os.environ['CALCULATE_STRESSES_PC'], internal=False)
        self.enabled = False
    def stop(self):
        if active is None:
            return False
        try:
            material = int(gdb.parse_and_eval('$rdi'))
            records.append(snap('calculate_stresses-entry', active['pde'], active['element'], material))
            CalculateStressesReturn(active['pde'], active['element'], material)
            calc_stress_bp.enabled = True
        except Exception:
            pass
        self.enabled = False
        return False

class CalcStressReturn(gdb.FinishBreakpoint):
    def __init__(self, pde, element, material, strain_ptr, stress_ptr):
        self.pde = pde
        self.element = element
        self.material = material
        self.strain_ptr = strain_ptr
        self.stress_ptr = stress_ptr
        super(CalcStressReturn, self).__init__(internal=True)
    def stop(self):
        records.append(raw_snap('calc_stress-return', self.pde, self.element, self.material, self.strain_ptr, self.stress_ptr))
        return False

class CalcStressBP(gdb.Breakpoint):
    def __init__(self):
        super(CalcStressBP, self).__init__('*' + os.environ['CALC_STRESS_PC'], internal=False)
        self.enabled = False
    def stop(self):
        if active is None or active.get('calc_seen'):
            return False
        active['calc_seen'] = True
        try:
            material = int(gdb.parse_and_eval('$rdi'))
            strain_ptr = int(gdb.parse_and_eval('$rsi'))
            stress_ptr = int(gdb.parse_and_eval('$rdx'))
            records.append(raw_snap('calc_stress-entry', active['pde'], active['element'], material, strain_ptr, stress_ptr))
            CalcStressReturn(active['pde'], active['element'], material, strain_ptr, stress_ptr)
        except Exception:
            pass
        self.enabled = False
        return False

class StressReturn(gdb.FinishBreakpoint):
    def __init__(self, pde, element):
        self.pde = pde
        self.element = element
        super(StressReturn, self).__init__(internal=True)
    def stop(self):
        global active
        records.append(snap('computeStressHOE-return', self.pde, self.element))
        strains_bp.enabled = False
        material_bp.enabled = False
        calc_stresses_bp.enabled = False
        calc_stress_bp.enabled = False
        euler_bp.enabled = False
        active = None
        return False

class StressBP(gdb.Breakpoint):
    def __init__(self):
        super(StressBP, self).__init__('*' + os.environ['COMPUTE_STRESS_PC'], internal=False)
        self.enabled = False
    def stop(self):
        global stress_hits, active
        if stress_hits >= stress_limit:
            return False
        stress_hits += 1
        pde = int(gdb.parse_and_eval('$rdi'))
        element = int(gdb.parse_and_eval('$rsi'))
        active = {'pde': pde, 'element': element}
        records.append(snap('computeStressHOE-entry', pde, element))
        strains_bp.enabled = True
        material_bp.enabled = True
        calc_stresses_bp.enabled = False
        calc_stress_bp.enabled = False
        try:
            StressReturn(pde, element)
        except Exception:
            pass
        if stress_hits >= stress_limit:
            self.enabled = False
        return False

class UpdateReturn(gdb.FinishBreakpoint):
    def __init__(self):
        super(UpdateReturn, self).__init__(internal=True)
    def stop(self):
        stress_bp.enabled = False
        strains_bp.enabled = False
        material_bp.enabled = False
        calc_stresses_bp.enabled = False
        return False

class UpdateBP(gdb.Breakpoint):
    def __init__(self):
        super(UpdateBP, self).__init__('*' + os.environ['UPDATE_STRESS_PC'], internal=False)
    def stop(self):
        if stress_hits < stress_limit:
            stress_bp.enabled = True
        try:
            UpdateReturn()
        except Exception:
            pass
        return False

strains_bp = StrainsBP()
material_bp = MaterialBP()
calc_stresses_bp = CalculateStressesBP()
calc_stress_bp = CalcStressBP()
euler_bp = EulerBP()
stress_bp = StressBP()
update_bp = UpdateBP()
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
exitcode = None
def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)
gdb.events.exited.connect(exited)
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records, 'stress_hits': stress_hits},
          open(os.environ['AUDIT_OUT'], 'w'), indent=2)
