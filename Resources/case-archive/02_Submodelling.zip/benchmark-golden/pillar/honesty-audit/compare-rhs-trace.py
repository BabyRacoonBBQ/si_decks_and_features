import hashlib, json, struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V = ROOT / 'linear-e-vendor-'
L = ROOT / 'linear-e-local-'
rows = {}
for path in sorted(V.glob('*.bin')):
    name = path.name
    raw_v = path.read_bytes()
    raw_l = (L / name).read_bytes()
    assert len(raw_v) == len(raw_l) and len(raw_v) % 8 == 0
    vals_v = struct.unpack('<{}d'.format(len(raw_v) // 8), raw_v)
    vals_l = struct.unpack('<{}d'.format(len(raw_l) // 8), raw_l)
    diffs = [(i, a, b, abs(a - b)) for i, (a, b) in enumerate(zip(vals_v, vals_l)) if a != b]
    rows[name] = {
        'length': len(vals_v),
        'vendor_sha256': hashlib.sha256(raw_v).hexdigest(),
        'local_sha256': hashlib.sha256(raw_l).hexdigest(),
        'different_entries': len(diffs),
        'first_difference': ({'index': diffs[0][0], 'vendor': diffs[0][1], 'local': diffs[0][2], 'abs_diff': diffs[0][3]} if diffs else None),
        'max_abs_difference': max((d[3] for d in diffs), default=0.0),
    }
(ROOT / 'rhs-trace-comparison.json').write_text(json.dumps(rows, indent=2))
print(json.dumps(rows, indent=2))
