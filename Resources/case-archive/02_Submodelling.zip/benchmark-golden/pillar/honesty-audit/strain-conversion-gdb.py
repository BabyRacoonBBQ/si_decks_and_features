import gdb, json, os

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
records = []
exitcode = None

def vals(addr, count=6):
    if not addr:
        return None
    try:
        p = gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p + i).dereference()) for i in range(count)]
    except Exception as e:
        return ['ERROR:' + str(e)]

class Ret(gdb.FinishBreakpoint):
    def __init__(self, input_ptr, output_ptr):
        super(Ret, self).__init__(internal=True)
        self.input_ptr = input_ptr; self.output_ptr = output_ptr
    def stop(self):
        records.append({'phase': 'return', 'input': vals(self.input_ptr),
                        'output': vals(self.output_ptr),
                        'pc': str(gdb.parse_and_eval('$pc')), 'stack': gdb.execute('bt 12', to_string=True)})
        return False

class Probe(gdb.Breakpoint):
    def __init__(self, p):
        self.name = p['name']; self.seen = False
        super(Probe, self).__init__('*' + p['address'], internal=False)
    def stop(self):
        if self.seen:
            return False
        self.seen = True
        input_ptr = int(gdb.parse_and_eval('$rsi'))
        output_ptr = int(gdb.parse_and_eval('$rcx'))
        records.append({'phase': 'entry', 'entry': self.name,
                        'this': hex(int(gdb.parse_and_eval('$rdi'))),
                        'input_ptr': hex(input_ptr), 'output_ptr': hex(output_ptr),
                        'input': vals(input_ptr), 'output': vals(output_ptr),
                        'order': int(gdb.parse_and_eval('$rdx')),
                        'pc': str(gdb.parse_and_eval('$pc')), 'stack': gdb.execute('bt 12', to_string=True)})
        try:
            Ret(input_ptr, output_ptr)
        except Exception:
            pass
        self.enabled = False
        return False

for p in probes:
    Probe(p)

def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)

gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off')
gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records, 'probes': probes}, open(out, 'w'), indent=2)
