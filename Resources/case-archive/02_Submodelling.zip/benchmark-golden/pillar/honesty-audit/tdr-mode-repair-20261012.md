# TDR mode repair and final recovery evidence (2026-10-12)

## Recovered source change

The isolated repair worktree is `/home/mozztcad/geo3d-worktrees/honesty-repair`.
`Tdr_reader::read` now preserves the requested `dfise` mode while inspecting
restart tags. A reader created for the global `stressdata` path has
`dfise=false` and therefore follows the ordinary region-element reconstruction
path, even when `readRestartData=true`; the initialization reader has
`dfise=true` and retains the restart-data path. This matches the vendor call
sequence observed in GDB. `Interpolator::sub_1BEC940` also now passes the
single seven-material bulk set observed at the vendor boundary; interface-pair
grouping remains in `sub_1BEDBD0`.

The repaired Release target was rebuilt with:

```text
cmake --build build --target sinterconnect_run -j2
```

Final repaired binary SHA-256:

```text
381ed20dd3287bf184246629e5f75ff4078506d17fda0fe556afdbbec38f3f56
```

## TDR parity

Vendor reference directory: `/tmp/honesty-load-boundary-20261011`.
Final recovery run directories: `/tmp/honesty-tdrfix-local` and the clean
`execve` run `/tmp/honesty-tdrfix-strace`.

The shared inputs are byte-identical. The generated global result and prepared
mesh are also byte-identical:

```text
global_sis.tdr          0d1fc26f4c853a3d518b37071aaea0e3f8ff853d95674eef8d56ea8ed9f12749
unit-fine-mesh_sis.tdr  21dec9300824e71f747089272068d780b977b13d3cc18f94b6532a857313b88e
```

`h5diff -q` reports zero difference lines for vendor versus recovery
`unit-fine_sis.tdr` in both post-fix runs. The unit-fine files are the same
size (158,117,101 bytes); their raw SHA-256 values differ because 582 raw
bytes are HDF5 metadata time fields. The logical HDF5 structure, attributes,
labels, topology, fields, and numeric values compare equal. The global and
prepared-mesh outputs are raw-byte identical.

## Execution-boundary evidence

The clean final run exits `0`, writes `unit-fine_sis.tdr`, and reports a
nonzero Mechanics solve and Bulk Interpolation step. Its `strace -f -e
trace=execve` record contains exactly one application `execve`, the recovered
binary:

```text
/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run unit-fine.cmd
```

No vendor `sinterconnect` executable is present in that exec trace. The local
run consumes the local `global_sis.tdr`; the mapped first source element after
the TDR fix matches the vendor trace exactly (element/data/mesh-cell IDs and
all four node coordinates).

## Conclusion

The original missing submodeling behavior was recovered by correcting the TDR
reader mode gate and the material grouping at the actual mapping boundary.
The copper-pillar case now runs through the recovered Release binary, performs
its own global-to-local interpolation and local mechanics solve, and produces
HDF5-semantic results equal to the vendor result. No vendor delegation,
result injection, hard-coded case result, or silent fallback was observed in
the final run.
