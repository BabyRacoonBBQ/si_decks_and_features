import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097'))
stress_count=0; active=False; events=[]; nested={'strains':False,'euler':False,'calc_stress':False}
def addr_env(name): return int(os.environ[name],16)
def reg(name):
 try: return int(gdb.parse_and_eval('$'+name))
 except Exception: return 0
def read_u64(addr):
 try: return struct.unpack('<Q',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
 except Exception: return 0
def vals(addr,count=6):
 if not addr:return []
 out=[]
 for i in range(count):
  try: out.append(struct.unpack('<d',gdb.selected_inferior().read_memory(addr+8*i,8).tobytes())[0])
  except Exception: out.append(None)
 return out
def rows(base,count=8):
 return [{'index':i,'ptr':hex(read_u64(base+8*i)) if read_u64(base+8*i) else None,'values':vals(read_u64(base+8*i))} for i in range(count)] if base else []
def pde_snapshot(phase,pde,element):
 base=read_u64(pde+0x400)
 return {'phase':phase,'pde':hex(pde),'element':hex(element),'gpStressArray':hex(base) if base else None,'rows':rows(base),'stack':gdb.execute('bt 14',to_string=True)}
def finish_outer():
 global active
 active=False; strains_bp.enabled=False; euler_bp.enabled=False; calcstress_bp.enabled=False
class OuterReturn(gdb.FinishBreakpoint):
 def __init__(self,pde,element): self.pde=pde; self.element=element; super().__init__(internal=True)
 def stop(self): events.append(pde_snapshot('computeStressHOE-return',self.pde,self.element)); finish_outer(); return False
class EulerReturn(gdb.FinishBreakpoint):
 def __init__(self,disp,out,pde,element): self.disp=disp; self.out=out; self.pde=pde; self.element=element; super().__init__(internal=True)
 def stop(self): events.append({'phase':'calc_euler_strain-return','pde':hex(self.pde),'element':hex(self.element),'displacement':vals(self.disp,6),'strain':vals(self.out,6),'stack':gdb.execute('bt 12',to_string=True)}); return False
class CalcStressReturn(gdb.FinishBreakpoint):
 def __init__(self,strain,stress,pde,element): self.strain=strain; self.stress=stress; self.pde=pde; self.element=element; super().__init__(internal=True)
 def stop(self): events.append({'phase':'calc_stress-return','pde':hex(self.pde),'element':hex(self.element),'strain':vals(self.strain,6),'stress':vals(self.stress,6),'stack':gdb.execute('bt 12',to_string=True)}); return False
class StrainsBP(gdb.Breakpoint):
 def __init__(self): super().__init__('*'+os.environ['COMPUTE_STRAINS_PC'],internal=False); self.enabled=False
 def stop(self):
  if not active or nested['strains']: return False
  nested['strains']=True; pde=reg('rdi'); element=reg('rsi'); events.append({'phase':'computeStrains-entry','pde':hex(pde),'element':hex(element),'stack':gdb.execute('bt 12',to_string=True)}); return False
class EulerBP(gdb.Breakpoint):
 def __init__(self): super().__init__('*'+os.environ['EULER_PC'],internal=False); self.enabled=False
 def stop(self):
  if not active or nested['euler']: return False
  nested['euler']=True; disp=reg('rdx'); out=reg('rcx'); pde=reg('rdi'); element=reg('rsi'); events.append({'phase':'calc_euler_strain-entry','pde':hex(pde),'element':hex(element),'displacement':vals(disp,6),'strain':vals(out,6),'stack':gdb.execute('bt 12',to_string=True)}); EulerReturn(disp,out,pde,element); self.enabled=False; return False
class CalcStressBP(gdb.Breakpoint):
 def __init__(self): super().__init__('*'+os.environ['CALC_STRESS_PC'],internal=False); self.enabled=False
 def stop(self):
  if not active or nested['calc_stress']: return False
  nested['calc_stress']=True; pde=reg('rdi'); strain=reg('rsi'); stress=reg('rdx'); element=0; events.append({'phase':'calc_stress-entry','pde':hex(pde),'strain':vals(strain,6),'stress':vals(stress,6),'stack':gdb.execute('bt 12',to_string=True)}); CalcStressReturn(strain,stress,pde,element); self.enabled=False; return False
class StressBP(gdb.Breakpoint):
 def __init__(self): super().__init__('*'+os.environ['COMPUTE_STRESS_PC'],internal=False)
 def stop(self):
  global stress_count,active,nested
  stress_count+=1
  if stress_count==TARGET:
   active=True; nested={'strains':False,'euler':False,'calc_stress':False}; pde=reg('rdi'); element=reg('rsi'); events.append(pde_snapshot('computeStressHOE-entry',pde,element)); strains_bp.enabled=True; euler_bp.enabled=True; calcstress_bp.enabled=True; OuterReturn(pde,element); self.enabled=False
  return False
strains_bp=StrainsBP(); euler_bp=EulerBP(); calcstress_bp=CalcStressBP(); stress_bp=StressBP()
def exited(event): Path(OUT).write_text(json.dumps({'exit':getattr(event,'exit_code',None),'target':TARGET,'stress_hits':stress_count,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
