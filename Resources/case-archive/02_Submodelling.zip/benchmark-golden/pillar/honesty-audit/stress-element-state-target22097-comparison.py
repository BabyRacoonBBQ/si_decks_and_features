import json
import struct
from pathlib import Path


BASE = Path(__file__).resolve().parent / "honesty-audit-stress-element-state-target22097-202619"
PHASES = ("computeStressHOE-entry", "computeStressHOE-return")


def bits(x):
    return f"0x{struct.unpack('<Q', struct.pack('<d', x))[0]:016x}"


def compare(a, b):
    deltas = [x - y for x, y in zip(a, b)]
    return {
        "vendor": a,
        "local_repair": b,
        "vendor_bits": [bits(x) for x in a],
        "local_repair_bits": [bits(x) for x in b],
        "different": sum(x != y for x, y in zip(a, b)),
        "max_abs": max((abs(x) for x in deltas), default=0.0),
        "deltas": deltas,
    }


def load(side):
    doc = json.loads((BASE / side / "events.json").read_text())
    return {event["phase"]: event for event in doc["events"] if event["phase"] in PHASES}, doc


vendor, vendor_doc = load("vendor")
local, local_doc = load("local-repair")
out = {
    "target_call": 22097,
    "vendor_stress_hits": vendor_doc.get("stress_hits"),
    "local_repair_stress_hits": local_doc.get("stress_hits"),
    "phases": sorted(set(vendor) | set(local)),
    "comparisons": {},
}

for phase in PHASES:
    ve, le = vendor[phase], local[phase]
    out["comparisons"][phase] = {
        "pde_displacement": compare(ve["pde_displacement"], le["pde_displacement"]),
        "pde_shape_gradient": compare(ve["pde_shape_gradient"], le["pde_shape_gradient"]),
        "pde_coords": compare(ve["pde_coords"], le["pde_coords"]),
        "pde_element_weight": compare([ve["pde_element_weight"]], [le["pde_element_weight"]]),
        "velocity_node_values": {
            "vendor": ve["velocity_node_values"],
            "local_repair": le["velocity_node_values"],
        },
        "growth_node_values": {
            "vendor": ve["growth_node_values"],
            "local_repair": le["growth_node_values"],
        },
        "velocity_solution": {"vendor": ve["velocity_solution"], "local_repair": le["velocity_solution"]},
        "velocity_field": {"vendor": ve["velocity_field"], "local_repair": le["velocity_field"]},
        "growth_field": {"vendor": ve["growth_field"], "local_repair": le["growth_field"]},
        "element_state": {
            "vendor": ve["element_state"],
            "local_repair": le["element_state"],
        },
    }

(BASE.parent / "stress-element-state-target22097-comparison.json").write_text(
    json.dumps(out, indent=2) + "\n"
)
print(json.dumps(out, indent=2))
