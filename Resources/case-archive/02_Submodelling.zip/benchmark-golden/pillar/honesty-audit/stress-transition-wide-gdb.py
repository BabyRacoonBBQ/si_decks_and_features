import gdb, json, os, struct

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
records = []
exitcode = None

def read_u64(addr):
    try:
        return struct.unpack('<Q', gdb.selected_inferior().read_memory(addr, 8).tobytes())[0]
    except Exception:
        return 0

def vals(addr, count=6):
    if not addr:
        return None
    try:
        p = gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p + i).dereference()) for i in range(count)]
    except Exception as e:
        return ['ERROR:' + str(e)]

def rows(base, count=8):
    if not base:
        return []
    out_rows = []
    for i in range(count):
        ptr = read_u64(base + 8 * i)
        out_rows.append({'index': i, 'ptr': hex(ptr) if ptr else None, 'values': vals(ptr)})
    return out_rows

def snap(phase, name, this, element=0):
    base = read_u64(this + 0x400)
    ptr = read_u64(base) if base else 0
    return {
        'phase': phase,
        'entry': name,
        'this': hex(this),
        'element': hex(element) if element else None,
        'gpStressArray': hex(base) if base else None,
        'row0_ptr': hex(ptr) if ptr else None,
        'row0': vals(ptr),
        'rows': rows(base),
        'stack': gdb.execute('bt 12', to_string=True),
    }

class Ret(gdb.FinishBreakpoint):
    def __init__(self, name, this, element):
        self.name = name
        self.this = this
        self.element = element
        super(Ret, self).__init__(internal=True)

    def stop(self):
        records.append(snap('return', self.name, self.this, self.element))
        return False

class Probe(gdb.Breakpoint):
    def __init__(self, probe):
        self.name = probe['name']
        self.seen = 0
        super(Probe, self).__init__('*' + probe['address'], internal=False)

    def stop(self):
        if self.seen >= 100:
            return False
        self.seen += 1
        this = int(gdb.parse_and_eval('$rdi'))
        element = int(gdb.parse_and_eval('$rsi'))
        rec = snap('entry', self.name, this, element)
        rec['hit'] = self.seen
        rec['r8'] = int(gdb.parse_and_eval('$r8'))
        rec['r9'] = int(gdb.parse_and_eval('$r9'))
        records.append(rec)
        try:
            Ret(self.name, this, element)
        except Exception:
            pass
        if self.seen >= 100:
            self.enabled = False
        return False

for probe in probes:
    Probe(probe)

def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)

gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records, 'probes': probes}, open(out, 'w'), indent=2)
