import hashlib, json, math, struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def compare(stem):
    raw_v = (ROOT / f'linear-solve-vendor-{stem}.bin').read_bytes()
    raw_l = (ROOT / f'linear-solve-local-repair-{stem}.bin').read_bytes()
    assert len(raw_v) == len(raw_l) and len(raw_v) % 8 == 0
    vals_v = struct.unpack('<{}d'.format(len(raw_v) // 8), raw_v)
    vals_l = struct.unpack('<{}d'.format(len(raw_l) // 8), raw_l)
    diffs = []
    for i, (a, b) in enumerate(zip(vals_v, vals_l)):
        if a != b:
            diffs.append({'index': i, 'vendor': a, 'local': b, 'abs_diff': abs(a - b),
                          'rel_diff': abs(a - b) / max(abs(a), abs(b), 1e-300)})
    return {
        'length': len(vals_v),
        'vendor_sha256': hashlib.sha256(raw_v).hexdigest(),
        'local_sha256': hashlib.sha256(raw_l).hexdigest(),
        'different_entries': len(diffs),
        'first_difference': diffs[0] if diffs else None,
        'max_abs_difference': max((d['abs_diff'] for d in diffs), default=0.0),
        'max_relative_difference': max((d['rel_diff'] for d in diffs), default=0.0),
        'largest_abs_difference': max(diffs, key=lambda d: d['abs_diff']) if diffs else None,
        'first_20_differences': diffs[:20],
    }


result = {'increment': compare('increment'), 'rhs': compare('rhs')}
(ROOT / 'linear-solve-vector-comparison.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
