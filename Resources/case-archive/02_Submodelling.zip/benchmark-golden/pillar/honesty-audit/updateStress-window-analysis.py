from __future__ import annotations
import json, math
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'updateStress-window-20261011'

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def seq(data, phase):
    return [r for r in data.get('records', []) if r.get('phase') == phase]

def diff(a,b):
    out=[]
    for x,y in zip(a or [],b or []):
        try:
            if math.isfinite(float(x)) and math.isfinite(float(y)):
                out.append(abs(float(x)-float(y)))
        except (TypeError, ValueError):
            pass
    return max(out, default=0.0)

def compare(v,l,phase):
    vv,ll=seq(v,phase),seq(l,phase)
    n=min(len(vv),len(ll)); first=None; maxd=0.0
    for i in range(n):
        d=diff(vv[i].get('row0'),ll[i].get('row0')); maxd=max(maxd,d)
        if first is None and d != 0.0:
            first={'index':i,'vendor_row0':vv[i].get('row0'),'local_row0':ll[i].get('row0'),'max_abs_diff':d,
                   'vendor_stack':vv[i].get('stack','').splitlines()[:4], 'local_stack':ll[i].get('stack','').splitlines()[:4]}
    return {'vendor_count':len(vv),'local_count':len(ll),'paired_count':n,'first_nonzero_row0_diff':first,'max_row0_abs_diff':maxd}

def main():
    v=load(ROOT/'vendor/events.json'); l=load(ROOT/'local-repair/events.json')
    out={'vendor_exit':v.get('exit'),'local_exit':l.get('exit'),'comparisons':{p:compare(v,l,p) for p in ('stress-entry','stress-return')},
         'vendor_first_stacks':[r.get('stack','').splitlines()[:4] for r in seq(v,'stress-entry')[:2]],
         'local_first_stacks':[r.get('stack','').splitlines()[:4] for r in seq(l,'stress-entry')[:2]]}
    (ROOT/'analysis.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
