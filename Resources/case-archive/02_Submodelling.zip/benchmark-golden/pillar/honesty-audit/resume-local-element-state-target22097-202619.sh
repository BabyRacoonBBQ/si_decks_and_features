#!/usr/bin/env bash
set -euo pipefail
cd /home/mozztcad/si-bench/golden-pillar-20261011/honesty-audit-stress-element-state-target22097-202619/local-repair

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONNOUSITE=1
export TDR_VERSION=16
export STROOT=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1
export STRELEASE=W-2024.09-SP1
export TCADPATH=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1
export LD_LIBRARY_PATH=/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/gds2tcadLib:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/gds2tcadLib/tbcload1.7:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/python3.11/site-packages/sinterconnect:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/python3.11/site-packages/floops:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/python3.11/site-packages/sdevice:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/tcad_mpi_mpich_ifort/lib:/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/tcad_mpi_intel/lib
export AUDIT_OUT=/home/mozztcad/si-bench/golden-pillar-20261011/honesty-audit-stress-element-state-target22097-202619/local-repair/events.json
export AUDIT_TARGET=22097
export COMPUTE_STRESS_PC=0xe87300
export COMPUTE_STRAINS_PC=0xe85200
export CALC_STRESS_PC=0x1544d90
export EULER_PC=0x1a443c0

flock -x /tmp/geo3d-sinterconnect-heavy.lock -c 'timeout -k 10 900 taskset -c 4 gdb -q -nx -batch -ex "source /tmp/stress-element-state-target22097-gdb.py" --args /home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run unit-fine.cmd'
