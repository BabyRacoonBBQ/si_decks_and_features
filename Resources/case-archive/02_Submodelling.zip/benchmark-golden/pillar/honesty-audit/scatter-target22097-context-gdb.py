import gdb, json, os, struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097')); scatter_count=0; assemble_count=0; events=[]
def read(inf,addr,n): return inf.read_memory(addr,n).tobytes()
class A(gdb.Breakpoint):
 def __init__(self): super().__init__('floops::MechPDE::AssembleElem(floops::Element&, floops::SingleStiff&, double, int, bool)',internal=False)
 def stop(self):
  global assemble_count; assemble_count += 1; return False
class S(gdb.Breakpoint):
 def __init__(self): super().__init__('floops::BasicSingleStiff::ssScatter(floops::Vector&, floops::Vector*)',internal=False)
 def stop(self):
  global scatter_count; scatter_count += 1
  if scatter_count != TARGET: return False
  inf=gdb.selected_inferior(); stiff=int(gdb.parse_and_eval('$rdi')); n=struct.unpack('<i',read(inf,stiff+0xc,4))[0]; m=max(0,min(n,64)); rows=list(struct.unpack('<{}i'.format(m),read(inf,stiff+0x1c,m*4))) if m else []; ptr=struct.unpack('<Q',read(inf,stiff+0x990,8))[0]; vals=list(struct.unpack('<{}d'.format(m),read(inf,ptr,m*8))) if m else []
  events.append({'scatter_count':scatter_count,'assemble_count_at_scatter':assemble_count,'row_count':n,'row_ids':rows,'ss_values':vals,'scatter_pc':hex(int(gdb.parse_and_eval('$pc'))),'return_address':hex(struct.unpack('<Q',read(inf,int(gdb.parse_and_eval('$rsp')),8))[0]),'stack':gdb.execute('bt 12',to_string=True)})
  self.enabled=False; return False
A(); S()
exit_code=None
def exited(event):
 global exit_code; exit_code=getattr(event,'exit_code',None); Path(OUT).write_text(json.dumps({'exit':exit_code,'scatter_hits':scatter_count,'assemble_hits':assemble_count,'events':events},indent=2))
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
