from __future__ import annotations
import json, math
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'postprocess-stress-20261011'

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def maxdiff(a, b):
    ds=[]
    for x,y in zip(a or [], b or []):
        try:
            if math.isfinite(float(x)) and math.isfinite(float(y)):
                ds.append(abs(float(x)-float(y)))
        except (TypeError, ValueError):
            pass
    return max(ds, default=0.0)

def seq(data, phase):
    return [r for r in data.get('records', []) if r.get('phase') == phase]

def compare(v, l, phase):
    vv, ll = seq(v, phase), seq(l, phase)
    n=min(len(vv),len(ll)); first=None; md=0.0
    for i in range(n):
        d=maxdiff(vv[i].get('row0'), ll[i].get('row0')); md=max(md,d)
        if first is None and d != 0.0:
            first={'index':i,'vendor_row0':vv[i].get('row0'),'local_row0':ll[i].get('row0'),'max_abs_diff':d}
    return {'vendor_count':len(vv),'local_count':len(ll),'paired_count':n,'first_nonzero_row0_diff':first,'max_row0_abs_diff':md,
            'vendor_callers':sorted(set(r.get('stack','').splitlines()[1] if len(r.get('stack','').splitlines())>1 else '' for r in vv)),
            'local_callers':sorted(set(r.get('stack','').splitlines()[1] if len(r.get('stack','').splitlines())>1 else '' for r in ll))}

def main():
    v=load(ROOT/'vendor/events.json'); l=load(ROOT/'local-repair/events.json')
    out={'vendor_exit':v.get('exit'),'local_exit':l.get('exit'),'comparisons':{p:compare(v,l,p) for p in ('entry','return')}}
    (ROOT/'analysis.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
