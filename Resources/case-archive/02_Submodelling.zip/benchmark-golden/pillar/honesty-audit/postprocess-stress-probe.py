from __future__ import annotations
import fcntl, hashlib, json, os, shutil, subprocess, time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-postprocess-stress-20261011'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(LOCK, fcntl.LOCK_EX)
BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run',
}
NAME = 'sinterconnect::siMechPDE::computeStressHOE(floops::Element*, TcadBase::Iter<floops::Node>&, floops::ElementIter&, double, bool, int, bool)'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def resolve(binary):
    cmd = ['nm'] + (['-D'] if binary == BINARIES['vendor'] else []) + ['-C', '--defined-only', binary]
    rows = subprocess.check_output(cmd, text=True).splitlines()
    matches = [row.split() for row in rows if row.endswith(' T ' + NAME)]
    if len(matches) != 1:
        raise RuntimeError({'binary': binary, 'matches': matches})
    return {'name': NAME, 'address': '0x' + matches[0][0]}

env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSITE='1', TDR_VERSION='16')
env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1', STRELEASE='W-2024.09-SP1', TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1')
V = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'
env['LD_LIBRARY_PATH'] = ':'.join([V + '/lib', V + '/lib/gds2tcadLib', V + '/lib/gds2tcadLib/tbcload1.7', V + '/lib/python3.11/site-packages/sinterconnect', V + '/lib/python3.11/site-packages/floops', V + '/lib/python3.11/site-packages/sdevice', V + '/tcad_mpi_mpich_ifort/lib', V + '/tcad_mpi_intel/lib'])
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)
caller = {'vendor': '0x199e5c1', 'local-repair': '0xe6cc95'}
results = []
for tool, binary in BINARIES.items():
    directory = OUT / tool
    shutil.copytree(ROOT / 'prepared', directory)
    source = ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr'
    shutil.copy2(source, directory / 'global_sis.tdr')
    (directory / 'probes.json').write_text(json.dumps([resolve(binary)], indent=2))
    env.update(AUDIT_OUT=str(directory / 'events.json'), AUDIT_PROBES=str(directory / 'probes.json'), POSTPROCESS_CALLER_PC=caller[tool])
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch', '-ex', 'source /tmp/postprocess-stress-gdb.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    started = time.time()
    with (directory / 'gdb.log').open('w') as log:
        process = subprocess.run(argv, cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT)
    event = json.loads((directory / 'events.json').read_text()) if (directory / 'events.json').exists() else {}
    results.append({'tool': tool, 'observer_exit': process.returncode, 'inferior_exit': event.get('exit'), 'wall_seconds': time.time() - started, 'binary_sha256': sha(Path(binary)), 'records': event.get('records'), 'output_sha256': sha(directory / 'unit-fine_sis.tdr')})
    if process.returncode or event.get('exit') != 0:
        raise RuntimeError(results[-1])
(OUT / 'exit.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
