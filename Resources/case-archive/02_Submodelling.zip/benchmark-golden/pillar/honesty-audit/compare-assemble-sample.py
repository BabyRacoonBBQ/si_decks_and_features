import json
import pathlib

root = pathlib.Path(r"C:\Users\Yuanyuan\Desktop\si\benchmark-golden\pillar\honesty-audit\assemble-sample-20261011-corrected")


def load(name):
    obj = json.loads((root / name / "assemble-events.json").read_text())
    return {(event["phase"], event["count"]): event for event in obj["events"]}, obj


vendor, vendor_obj = load("vendor")
local, local_obj = load("local-repair")
rows = []
for key in sorted(set(vendor) & set(local), key=lambda value: (value[1], value[0])):
    vendor_event = vendor[key]
    local_event = local[key]
    vendor_state = vendor_event.get("entry_state") or vendor_event.get("return_state")
    local_state = local_event.get("entry_state") or local_event.get("return_state")
    vendor_rhs = vendor_state.get("ss_rhs", [])
    local_rhs = local_state.get("ss_rhs", [])
    differences = [
        (index, left, right, abs(left - right))
        for index, (left, right) in enumerate(zip(vendor_rhs, local_rhs))
        if left != right
    ]
    rows.append(
        {
            "phase": key[0],
            "count": key[1],
            "row_ids_equal": vendor_state.get("row_ids") == local_state.get("row_ids"),
            "ss_equal": not differences,
            "first_diff": differences[0][:4] if differences else None,
            "max_abs": max((item[3] for item in differences), default=0.0),
            "ss_sha_vendor": vendor_state.get("ss_sha256"),
            "ss_sha_local": local_state.get("ss_sha256"),
        }
    )

comparison = {
    "vendor_assemble_count": vendor_obj["counts"],
    "local_assemble_count": local_obj["counts"],
    "sample_count": len(rows),
    "rows": rows,
}
(root / "assemble-sample-comparison.json").write_text(json.dumps(comparison, indent=2))
print(json.dumps(comparison, indent=2))
