import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; hits=0; events=[]
def reg(name):
    try:return int(gdb.parse_and_eval('$'+name))
    except Exception:return 0
def u64(addr):
    try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
    except Exception:return 0
def symbol(addr):
    try:return gdb.execute('info symbol 0x%x'%addr,to_string=True).strip()
    except Exception:return ''
class BP(gdb.Breakpoint):
    def __init__(self):super().__init__('*'+os.environ['NEWTON_PC'],internal=False)
    def stop(self):
        global hits
        hits+=1; obj=reg('rdi'); iterate=u64(obj+0x40) if obj else 0; vt=u64(iterate) if iterate else 0
        slots=[]
        for i in range(6):
            addr=u64(vt+8*i) if vt else 0; slots.append({'index':i,'address':hex(addr) if addr else None,'symbol':symbol(addr) if addr else ''})
        events.append({'hit':hits,'newton':hex(obj) if obj else None,'solver':hex(u64(obj+0x18)) if obj else None,'iterate':hex(iterate) if iterate else None,'vtable':hex(vt) if vt else None,'slots':slots,'stack':gdb.execute('bt 8',to_string=True)})
        return hits>=int(os.environ.get('MAX_HITS','1'))
BP()
def exited(event):Path(OUT).write_text(json.dumps({'exit':getattr(event,'exit_code',None),'hits':hits,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')
