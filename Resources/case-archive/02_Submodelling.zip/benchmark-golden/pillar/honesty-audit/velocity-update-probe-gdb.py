import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; MATERIAL_INDEX=int(os.environ.get('AUDIT_MATERIAL_INDEX','85')); DATA_INDEX=int(os.environ.get('AUDIT_DATA_INDEX','1020'))
updates=0; events=[]
def reg(name):
 try:return int(gdb.parse_and_eval('$'+name))
 except Exception:return 0
def read_u64(addr):
 try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
 except Exception:return 0
def read_i32(addr):
 try:return struct.unpack('<i',gdb.selected_inferior().read_memory(addr,4).tobytes())[0]
 except Exception:return 0
def memd(addr):
 try:return struct.unpack('<d',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
 except Exception:return None
def vals(addr,n=3):return [memd(addr+8*i) for i in range(n)] if addr else [None]*n
def velocity_value(obj):
 field=read_u64(obj+0x110) if obj else 0
 node_slots=read_u64(field+0x68) if field else 0
 segment=read_u64(node_slots+8*MATERIAL_INDEX) if node_slots else 0
 data=read_u64(segment) if segment else 0
 return {'velocity_solution':hex(obj) if obj else None,'velocity_field':hex(field) if field else None,'node_slots':hex(node_slots) if node_slots else None,'segment':hex(segment) if segment else None,'data':hex(data) if data else None,'value':vals(data+24*DATA_INDEX,3) if data else [None,None,None]}
class Ret(gdb.FinishBreakpoint):
 def __init__(self, obj, count):self.obj=obj;self.count=count;super().__init__(internal=True)
 def stop(self):events.append({'phase':'return','count':self.count,**velocity_value(self.obj),'rax':reg('rax'),'stack':gdb.execute('bt 8',to_string=True)});return False
class UpdateBP(gdb.Breakpoint):
 def __init__(self):super().__init__('*'+os.environ['UPDATE_PC'],internal=False)
 def stop(self):
  global updates
  updates+=1; obj=reg('rsi'); events.append({'phase':'entry','count':updates,**velocity_value(obj),'stack':gdb.execute('bt 8',to_string=True)}); Ret(obj,updates); return False
bp=UpdateBP()
def exited(event):Path(OUT).write_text(json.dumps({'exit':getattr(event,'exit_code',None),'updates':updates,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')
