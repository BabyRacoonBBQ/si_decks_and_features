from __future__ import annotations

import sys
from pathlib import Path


PATTERN = bytes.fromhex("120008000000000001000000")


def scan(blob: bytes):
    result = []
    pos = 0
    while True:
        pos = blob.find(PATTERN, pos)
        if pos < 0:
            return result
        result.append((pos, int.from_bytes(blob[pos + 12:pos + 16], "little")))
        pos += 1


def main():
    vendor = Path(sys.argv[1]).read_bytes()
    local = Path(sys.argv[2]).read_bytes()
    vm = dict(scan(vendor))
    lm = dict(scan(local))
    same_offsets = sorted(set(vm) & set(lm))
    timestamp_diffs = [(p, vm[p], lm[p]) for p in same_offsets if vm[p] != lm[p]]
    print(f"vendor_messages={len(vm)} local_messages={len(lm)} same_offsets={len(same_offsets)}")
    print(f"timestamp_differences_at_same_offsets={len(timestamp_diffs)}")
    if timestamp_diffs:
        print(f"timestamp_delta_values={sorted(set(local - vendor for _, vendor, local in timestamp_diffs))}")
        print("first_timestamp_differences:")
        for row in timestamp_diffs[:40]:
            print(row)
    print(f"vendor_only_offsets={len(set(vm) - set(lm))} local_only_offsets={len(set(lm) - set(vm))}")


if __name__ == "__main__":
    main()
