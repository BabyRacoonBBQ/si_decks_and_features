from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import h5py
import numpy as np
from h5py import h5o


def attrs_equal(a, b):
    try:
        return np.array_equal(a, b)
    except Exception:
        return repr(a) == repr(b)


def attribute_differences(vendor_path: Path, local_path: Path):
    diffs = []
    with h5py.File(vendor_path, "r") as vendor, h5py.File(local_path, "r") as local:
        paths = set()

        def collect(name, obj):
            paths.add(name)

        vendor.visititems(collect)
        local.visititems(collect)
        for path in sorted(paths):
            if path not in vendor or path not in local:
                diffs.append((path, "<object>", "missing", "present"))
                continue
            va = vendor[path].attrs
            la = local[path].attrs
            for key in sorted(set(va.keys()) | set(la.keys())):
                if key not in va or key not in la or not attrs_equal(va.get(key), la.get(key)):
                    diffs.append((path, key, repr(va.get(key)), repr(la.get(key))))
    return diffs


def raw_diff(vendor_path: Path, local_path: Path):
    vendor = vendor_path.read_bytes()
    local = local_path.read_bytes()
    n = min(len(vendor), len(local))
    ranges = []
    i = 0
    while i < n:
        if vendor[i] == local[i]:
            i += 1
            continue
        start = i
        while i < n and vendor[i] != local[i]:
            i += 1
        ranges.append((start, i, vendor[start:i].hex(), local[start:i].hex()))
    return vendor, local, ranges


def main():
    vendor_path, local_path = map(Path, sys.argv[1:3])
    vendor, local, ranges = raw_diff(vendor_path, local_path)
    print(f"vendor_sha256={hashlib.sha256(vendor).hexdigest()}")
    print(f"local_sha256={hashlib.sha256(local).hexdigest()}")
    print(f"vendor_bytes={len(vendor)} local_bytes={len(local)} ranges={len(ranges)}")
    print("raw_ranges_first_40:")
    for row in ranges[:40]:
        print(row)
    diffs = attribute_differences(vendor_path, local_path)
    print(f"attribute_differences={len(diffs)}")
    for row in diffs[:120]:
        print("ATTR", row)
    print("objects_near_first_raw_difference:")
    with h5py.File(vendor_path, "r") as vfile:
        objects = []
        def collect(name, obj):
            try:
                info = h5o.get_info(obj.id)
                objects.append((int(info.addr), name, type(obj).__name__, int(info.rc), int(info.type)))
            except Exception as exc:
                objects.append((-1, name, type(obj).__name__, repr(exc), ""))
        vfile.visititems(collect)
        for row in sorted(objects):
            if 0 <= row[0] <= 3164 + 8192:
                print("OBJ", row)
    for offset in [0, 3164, 292300, 293004, 2132148]:
        print(f"window_{offset}_vendor={bytes(vendor[offset-32:offset+64]).hex()}")
        print(f"window_{offset}_local={bytes(local[offset-32:offset+64]).hex()}")
    for offset in [2944, 4096, 5016]:
        print(f"object_header_{offset}_vendor={vendor[offset:offset+512].hex()}")
        print(f"object_header_{offset}_local={local[offset:offset+512].hex()}")


if __name__ == "__main__":
    main()
