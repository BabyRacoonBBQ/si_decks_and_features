from pathlib import Path

source = Path(__file__).with_name("convergence-probe-10.py")
text = source.read_text()
text = text.replace("honesty-audit-solver-focus-10", "honesty-audit-solver-focus-11")
Path(__file__).with_name("_convergence_probe_11_generated.py").write_text(text)
print(Path(__file__).with_name("_convergence_probe_11_generated.py"))
