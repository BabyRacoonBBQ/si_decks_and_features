set breakpoint pending on
break 'floops::MechPDE::getDisplacements(floops::Element*, bool)'
info breakpoints