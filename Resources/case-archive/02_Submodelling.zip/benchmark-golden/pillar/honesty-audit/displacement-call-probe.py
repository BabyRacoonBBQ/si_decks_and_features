from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-displacement-path-3'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
import fcntl
fcntl.flock(LOCK, fcntl.LOCK_EX)

BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run',
}

NAMES = [
    'sinterconnect::siMechanicsSolver::calculateDisplacement()',
    'floops::MechanicsSolver::calculateDisplacement()',
    'floops::MechData::SetDisplacement(TcadGeom::Location&, floops::Node&, bool, bool)',
    'floops::MechData::SetDisplacement2(TcadGeom::Location&, floops::Node2&, bool, bool)',
    'floops::FieldServer::VectorFindMatch(char const*) const',
    'floops::Mesh::FullDimensional() const',
    'floops::Mesh::nodes2()',
    'sinterconnect::siMechanicsSolver::computeTauInv(double*, double, double)',
    'sinterconnect::siMechData::SetPseudoDisp(TcadGeom::Location&, floops::Node&, bool, bool, double)',
    'sinterconnect::siMechData::SetPseudoDisp2(TcadGeom::Location&, floops::Node2&, bool, bool, double)',
]

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def resolve(binary: str):
    args = ['nm']
    if binary == BINARIES['vendor']:
        args.append('-D')
    args += ['-C', '--defined-only', binary]
    lines = subprocess.check_output(args, text=True).splitlines()
    probes, missing = [], []
    for name in NAMES:
        matches = [line.split() for line in lines if line.endswith(' T ' + name)]
        if len(matches) == 1:
            probes.append({'name': name, 'address': '0x' + matches[0][0]})
        else:
            missing.append({'name': name, 'matches': matches})
    return probes, missing

env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSERSITE='1', TDR_VERSION='16')
env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1', STRELEASE='W-2024.09-SP1',
           TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1',
           SENTAROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1',
           STROOT_ARCH_OS='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64')
env['LD_LIBRARY_PATH'] = ':'.join([
    '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib',
    '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/gds2tcadLib',
    '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/gds2tcadLib/tbcload1.7',
    '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/lib/python3.11/site-packages/sprocess',
    '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64/tcad_mpi_mpich_ifort/lib',
])
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)

records = []
for tool, binary in BINARIES.items():
    probes, missing = resolve(binary)
    tool_dir = OUT / tool
    shutil.copytree(ROOT / 'prepared', tool_dir)
    shutil.copy2(ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr', tool_dir / 'global_sis.tdr')
    (tool_dir / 'probes.json').write_text(json.dumps(probes, indent=2))
    env.update(AUDIT_OUT=str(tool_dir / 'unit-fine-displacement-events.json'), AUDIT_PROBES=str(tool_dir / 'probes.json'))
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch',
            '-ex', 'source /tmp/honesty-displacement-gdb.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    start = time.time()
    with (tool_dir / 'unit-fine-displacement-gdb.log').open('w') as log:
        process = subprocess.run(argv, cwd=tool_dir, env=env, stdout=log, stderr=subprocess.STDOUT)
    events = json.loads((tool_dir / 'unit-fine-displacement-events.json').read_text()) if (tool_dir / 'unit-fine-displacement-events.json').exists() else {}
    records.append({
        'tool': tool, 'observer_exit': process.returncode, 'inferior_exit': events.get('exit'),
        'wall_seconds': time.time() - start, 'binary_sha256': sha(Path(binary)),
        'missing_probes': missing, 'hits': events.get('hits'),
        'output_sha256': sha(tool_dir / 'unit-fine_sis.tdr') if (tool_dir / 'unit-fine_sis.tdr').exists() else None,
    })
    if process.returncode or events.get('exit') != 0:
        raise RuntimeError(records[-1])

(OUT / 'exit.json').write_text(json.dumps({'runs': records}, indent=2))
print(json.dumps(records, indent=2))
