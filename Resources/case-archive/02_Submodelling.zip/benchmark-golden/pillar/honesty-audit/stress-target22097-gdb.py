import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097'))
stress_count=0; rhs_count=0; events=[]
def u64reg(name):
 try: return int(gdb.parse_and_eval('$'+name))
 except Exception: return 0
def read_u64(addr):
 try: return struct.unpack('<Q',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
 except Exception: return 0
def vals(addr,count=6):
 if not addr:return []
 return [struct.unpack('<d',gdb.selected_inferior().read_memory(addr+8*i,8).tobytes())[0] for i in range(count)]
def rows(base,count=8):
 out=[]
 for i in range(count):
  ptr=read_u64(base+8*i); out.append({'index':i,'ptr':hex(ptr) if ptr else None,'values':vals(ptr)})
 return out
def pde_snap(phase,this,element):
 base=read_u64(this+0x400)
 return {'phase':phase,'target':'computeStressHOE','this':hex(this),'element':hex(element),'gpStressArray':hex(base),'rows':rows(base),'stack':gdb.execute('bt 12',to_string=True)}
def rhs_snap(this):
 fe=read_u64(this+0x8); base=read_u64(fe+0x80); ptr=read_u64(base)
 return {'assembler':hex(this),'fe':hex(fe),'gpStressArray':hex(base),'row0':vals(ptr),'rows':rows(base),'stack':gdb.execute('bt 12',to_string=True)}
class StressReturn(gdb.FinishBreakpoint):
 def __init__(self,this,element): self.this=this; self.element=element; super().__init__(internal=True)
 def stop(self): events.append(pde_snap('computeStressHOE-return',self.this,self.element)); return False
class Stress(gdb.Breakpoint):
 def __init__(self): super().__init__('sinterconnect::siMechPDE::computeStressHOE(floops::Element*, TcadBase::Iter<floops::Node>&, floops::ElementIter&, double, bool, int, bool)',internal=False)
 def stop(self):
  global stress_count
  stress_count+=1
  if stress_count==TARGET:
   this=u64reg('rdi'); element=u64reg('rsi'); events.append(pde_snap('computeStressHOE-entry',this,element)); StressReturn(this,element); self.enabled=False
  return False
class RHS(gdb.Breakpoint):
 def __init__(self): super().__init__('FE::MechanicsAssembler::calc_rhs(floops::SingleStiff&, floops::SingleDense*)',internal=False)
 def stop(self):
  global rhs_count
  rhs_count+=1
  if rhs_count==TARGET:
   events.append({'phase':'calc_rhs-entry','count':rhs_count,'stress_count':stress_count,'capture':rhs_snap(u64reg('rdi'))}); self.enabled=False
  return False
Stress(); RHS()
def exited(event):
 Path(OUT).write_text(json.dumps({'exit':getattr(event,'exit_code',None),'target':TARGET,'stress_hits':stress_count,'rhs_hits':rhs_count,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
