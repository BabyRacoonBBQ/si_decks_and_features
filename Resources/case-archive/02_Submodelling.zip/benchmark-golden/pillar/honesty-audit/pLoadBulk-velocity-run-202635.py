from __future__ import annotations
import fcntl,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/home/mozztcad/si-bench/golden-pillar-20261011');OUT=ROOT/'honesty-audit-pLoadBulk-velocity-202635';OUT.mkdir(exist_ok=False)
LOCK=open('/tmp/geo3d-sinterconnect-heavy.lock','w');fcntl.flock(LOCK,fcntl.LOCK_EX)
B={'vendor':'/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect','local-repair':'/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run'};P={'vendor':'0x19a00b0','local-repair':'0xe766c0'}
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONNOUSITE='1',TDR_VERSION='16',MAX_HITS='4',AUDIT_MATERIAL_INDEX='85',AUDIT_DATA_INDEX='1020');env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1',STRELEASE='W-2024.09-SP1',TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1')
V='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1';env['LD_LIBRARY_PATH']=':'.join([V+'/linux64/lib',V+'/linux64/lib/gds2tcadLib',V+'/linux64/lib/gds2tcadLib/tbcload1.7',V+'/linux64/lib/python3.11/site-packages/sinterconnect',V+'/linux64/lib/python3.11/site-packages/floops',V+'/linux64/lib/python3.11/site-packages/sdevice',V+'/linux64/tcad_mpi_mpich_ifort/lib',V+'/linux64/tcad_mpi_intel/lib'])
for k in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(k,None)
res=[]
for tool,binary in B.items():
 d=OUT/tool;shutil.copytree(ROOT/'prepared',d);shutil.copy2(ROOT/'honesty-audit-b'/('vendor' if tool=='vendor' else 'local')/'global_sis.tdr',d/'global_sis.tdr');env.update(AUDIT_OUT=str(d/'events.json'),PLOAD_PC=P[tool]);argv=['timeout','-k','10','900','taskset','-c','4','gdb','-q','-nx','-batch','-ex','source /tmp/pLoadBulk-velocity-probe-202635-gdb.py','--args',binary]
 if tool=='vendor':argv.append('--noSyntaxCheck')
 argv.append('unit-fine.cmd');t=time.time()
 with (d/'gdb.log').open('w') as log:p=subprocess.run(argv,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 e=json.loads((d/'events.json').read_text()) if (d/'events.json').exists() else {};res.append({'tool':tool,'observer_exit':p.returncode,'inferior_exit':e.get('exit'),'hits':e.get('hits'),'wall_seconds':time.time()-t})
 if p.returncode or e.get('exit')!=0:raise RuntimeError(res[-1])
(OUT/'exit.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
