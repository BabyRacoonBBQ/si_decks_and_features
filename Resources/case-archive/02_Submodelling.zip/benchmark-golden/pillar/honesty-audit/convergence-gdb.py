import gdb,json,os,struct
out=os.environ['AUDIT_OUT']; probes=json.load(open(os.environ['AUDIT_PROBES'])); counts={}; observations=[]; returns={}
def scalar(expr):
 try: return str(gdb.parse_and_eval(expr))
 except Exception as e: return 'ERROR:'+str(e)
def snapshot(n):
 vals={'name':n,'rdi_this':scalar('$rdi'),'rsi_arg1':scalar('$rsi'),'rdx_arg2':scalar('$rdx'),'rcx_arg3':scalar('$rcx'),'r8_arg4':scalar('$r8'),'r9_arg5':scalar('$r9'),'xmm0':scalar('$xmm0.v2_double[0]')}
 try:
  rsp=int(gdb.parse_and_eval('$rsp')); b=gdb.selected_inferior().read_memory(rsp+8,40).tobytes(); vals['stack_args_qwords']=[hex(x) for x in struct.unpack('<5Q',b)]
 except Exception as e: vals['stack_read_error']=str(e)
 if n == 'sinterconnect::siMechanicsSolver::calculateDisplacement()':
  try:
   this=int(gdb.parse_and_eval('$rdi')); inf=gdb.selected_inferior(); data_ptr=struct.unpack('<Q',inf.read_memory(this+0x1818,8).tobytes())[0]; state_ptr=struct.unpack('<Q',inf.read_memory(this+0x1810,8).tobytes())[0]
   vals['productMechData']=hex(data_ptr); vals['reservedAfterViscoElastic']=int(inf.read_memory(data_ptr+0x654,1).tobytes()[0]) if data_ptr else None; vals['productMechState']=hex(state_ptr)
   vals['state_dt']=struct.unpack('<d',inf.read_memory(state_ptr+0x18,8).tobytes())[0] if state_ptr else None; vals['state_curTemperature']=struct.unpack('<d',inf.read_memory(state_ptr+0x28,8).tobytes())[0] if state_ptr else None; vals['state_prevTemperature']=struct.unpack('<d',inf.read_memory(state_ptr+0x30,8).tobytes())[0] if state_ptr else None
  except Exception as e: vals['product_state_read_error']=str(e)
 return vals
class Ret(gdb.FinishBreakpoint):
 def __init__(self,frame,name): self.name=name; super(Ret,self).__init__(frame,internal=True)
 def stop(self): returns.setdefault(self.name,[]).append({'rax':scalar('$rax'),'xmm0':scalar('$xmm0.v2_double[0]')}); return False
class Probe(gdb.Breakpoint):
 def __init__(self,p): self.name=p['name']; super(Probe,self).__init__('*'+p['address'],internal=False)
 def stop(self):
  n=self.name; counts[n]=counts.get(n,0)+1
  if counts[n]==1:
   row=snapshot(n); row['stack']=gdb.execute('bt 10',to_string=True); row['symbol']=gdb.execute('info symbol $pc',to_string=True); observations.append(row)
  try: Ret(gdb.newest_frame(),n)
  except Exception as e: pass
  return False
for p in probes: Probe(p)
exitcode=None
def exited(e):
 global exitcode; exitcode=getattr(e,'exit_code',None)
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run'); json.dump({'exit':exitcode,'counts':counts,'returns':returns,'observations':observations,'probes':probes},open(out,'w'),indent=2)
