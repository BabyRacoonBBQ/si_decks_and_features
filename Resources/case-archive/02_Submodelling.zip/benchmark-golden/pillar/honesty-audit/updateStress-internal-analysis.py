from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNS = {
    'b': ROOT / 'updateStress-internal-20261011b',
    'c': ROOT / 'updateStress-internal-20261011c',
    'd': ROOT / 'updateStress-internal-20261011d',
    'e': ROOT / 'updateStress-internal-20261011e',
}

def load(run, side):
    flat = RUNS[run] / ('vendor-events.json' if side == 'vendor' else 'local-repair-events.json')
    nested = RUNS[run] / ('vendor' if side == 'vendor' else 'local-repair') / 'events.json'
    path = flat if flat.exists() else nested
    return json.loads(path.read_text())

def phase_rows(data, phase):
    return [record for record in data['records'] if record['phase'] == phase]

def max_array_diff(a, b, array):
    maximum = 0.0
    location = None
    for i, (left, right) in enumerate(zip(a, b)):
        for row_left, row_right in zip(left[array]['rows'], right[array]['rows']):
            for component, (x, y) in enumerate(zip(row_left['values'], row_right['values'])):
                difference = abs(x - y)
                if difference > maximum:
                    maximum = difference
                    location = [i, row_left['index'], component, x, y]
    return {'max_abs': maximum, 'location': location}

def max_field_diff(a, b, field):
    maximum = 0.0
    location = None
    for i, (left, right) in enumerate(zip(a, b)):
        for component, (x, y) in enumerate(zip(left[field], right[field])):
            difference = abs(x - y)
            if difference > maximum:
                maximum = difference
                location = [i, component, x, y]
    return {'max_abs': maximum, 'location': location}

out = {}
for run in ('b', 'c', 'd', 'e'):
    vendor = load(run, 'vendor')
    local = load(run, 'local')
    phases = sorted({record['phase'] for record in vendor['records']} | {record['phase'] for record in local['records']})
    entry = {'vendor_exit': vendor['exit'], 'local_exit': local['exit'], 'phase_counts': {}, 'comparisons': {}}
    for phase in phases:
        left = phase_rows(vendor, phase)
        right = phase_rows(local, phase)
        entry['phase_counts'][phase] = {'vendor': len(left), 'local': len(right)}
        if len(left) != len(right) or not left:
            continue
        comparison = {}
        for array in ('gpStrain', 'gpStress'):
            comparison[array] = max_array_diff(left, right, array)
        for field in ('displacement_arg', 'strain_output', 'strain_arg', 'stress_arg'):
            if field in left[0] and field in right[0]:
                comparison[field] = max_field_diff(left, right, field)
        entry['comparisons'][phase] = comparison
    out[run] = entry
(ROOT / 'updateStress-internal-analysis.json').write_text(json.dumps(out, indent=2))
print(json.dumps(out, indent=2))
