from __future__ import annotations
import json,os,shutil,subprocess
from pathlib import Path
ROOT=Path('/home/mozztcad/si-bench/golden-pillar-20261011'); OUT=ROOT/'honesty-audit-calc-rhs-operands22097-202612'; OUT.mkdir(exist_ok=False)
LOCK=open('/tmp/geo3d-sinterconnect-heavy.lock','w'); import fcntl; fcntl.flock(LOCK,fcntl.LOCK_EX)
B={'vendor':'/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect','local-repair':'/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run'}
E=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONNOUSITE='1',TDR_VERSION='16')
for k in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'): E.pop(k,None)
V='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'; E['LD_LIBRARY_PATH']=':'.join([V+'/lib',V+'/lib/gds2tcadLib',V+'/lib/gds2tcadLib/tbcload1.7',V+'/lib/python3.11/site-packages/sinterconnect',V+'/lib/python3.11/site-packages/floops',V+'/lib/python3.11/site-packages/sdevice',V+'/tcad_mpi_mpich_ifort/lib',V+'/tcad_mpi_intel/lib']); E['STROOT']='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1'; E['STRELEASE']='W-2024.09-SP1'; E['TCADPATH']=E['STROOT']
R=[]
for t,b in B.items():
 d=OUT/t; shutil.copytree(ROOT/'prepared',d); shutil.copy2(ROOT/'honesty-audit-b'/('vendor' if t=='vendor' else 'local')/'global_sis.tdr',d/'global_sis.tdr'); env=dict(E,AUDIT_OUT=str(d/'events.json'),AUDIT_TARGET='22097'); a=['timeout','-k','10','900','taskset','-c','4','gdb','-q','-nx','-batch','-ex','source /tmp/calc-rhs-operands22097-gdb.py','--args',b];
 if t=='vendor': a.append('--noSyntaxCheck')
 a.append('unit-fine.cmd')
 with (d/'gdb.log').open('w') as log:p=subprocess.run(a,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 o=json.loads((d/'events.json').read_text()) if (d/'events.json').exists() else {}; R.append({'tool':t,'observer_exit':p.returncode,'inferior_exit':o.get('exit'),'calc_rhs_hits':o.get('calc_rhs_hits'),'events':len(o.get('events',[]))})
 if p.returncode!=0 or o.get('exit')!=0: raise RuntimeError(R[-1])
(OUT/'exit.json').write_text(json.dumps({'exit':0,'runs':R},indent=2)); print(json.dumps(R,indent=2))
