import gdb, json, os, struct

records = []
stress_hits = 0
stress_limit = 20

def read_u64(addr):
    try:
        return struct.unpack('<Q', gdb.selected_inferior().read_memory(addr, 8).tobytes())[0]
    except Exception:
        return 0

def vals(addr, count=6):
    if not addr:
        return None
    try:
        p = gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p + i).dereference()) for i in range(count)]
    except Exception as exc:
        return ['ERROR:' + str(exc)]

def snap(phase, this, element):
    base = read_u64(this + 0x400)
    ptr = read_u64(base) if base else 0
    rows = []
    if base:
        for i in range(8):
            rowptr = read_u64(base + 8 * i)
            rows.append({'index': i, 'ptr': hex(rowptr) if rowptr else None, 'values': vals(rowptr)})
    return {'phase': phase, 'this': hex(this), 'element': hex(element) if element else None,
            'gpStressArray': hex(base) if base else None, 'row0_ptr': hex(ptr) if ptr else None,
            'row0': vals(ptr), 'rows': rows, 'stack': gdb.execute('bt 12', to_string=True)}

class StressReturn(gdb.FinishBreakpoint):
    def __init__(self, this, element):
        self.this = this
        self.element = element
        super(StressReturn, self).__init__(internal=True)
    def stop(self):
        records.append(snap('stress-return', self.this, self.element))
        return False

class StressBP(gdb.Breakpoint):
    def __init__(self):
        super(StressBP, self).__init__('*' + os.environ['COMPUTE_STRESS_PC'], internal=False)
        self.enabled = False
    def stop(self):
        global stress_hits
        if stress_hits >= stress_limit:
            return False
        stress_hits += 1
        this = int(gdb.parse_and_eval('$rdi'))
        element = int(gdb.parse_and_eval('$rsi'))
        records.append(snap('stress-entry', this, element))
        try:
            StressReturn(this, element)
        except Exception:
            pass
        if stress_hits >= stress_limit:
            self.enabled = False
        return False

class UpdateReturn(gdb.FinishBreakpoint):
    def __init__(self):
        super(UpdateReturn, self).__init__(internal=True)
    def stop(self):
        stress_bp.enabled = False
        return False

class UpdateBP(gdb.Breakpoint):
    def __init__(self):
        super(UpdateBP, self).__init__('*' + os.environ['UPDATE_STRESS_PC'], internal=False)
    def stop(self):
        if stress_hits < stress_limit:
            stress_bp.enabled = True
        try:
            UpdateReturn()
        except Exception:
            pass
        return False

stress_bp = StressBP()
update_bp = UpdateBP()
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
exitcode = None
def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)
gdb.events.exited.connect(exited)
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records, 'stress_hits': stress_hits}, open(os.environ['AUDIT_OUT'], 'w'), indent=2)
