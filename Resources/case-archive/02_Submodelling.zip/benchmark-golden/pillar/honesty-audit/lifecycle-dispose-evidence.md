# Boundary ownership/dispose evidence

The focused global runs used vendor SHA `6b5f30b801b08012dd846b339c4e4275502c5d1ee526420c4be315623d178464` and local SHA `6b14da5293db45767f9026e5599cc164e7ab654c8a091661610d8f76304f1781`.

- Vendor `std::_Sp_counted_ptr_inplace<sinterconnect::siGeneralBoundary>::_M_dispose` at `0x129a910` writes the derived vtable and jumps to `floops::GeneralBoundary::~GeneralBoundary()` at `0x1891f20`.
- Local `std::_Sp_counted_ptr_inplace<sinterconnect::siGeneralBoundary>::_M_dispose` at `0x0e82370` jumps to `sinterconnect::siGeneralBoundary::~siGeneralBoundary()` at `0x15e0b50`; that destructor writes the same derived vtable and jumps to `floops::GeneralBoundary::~GeneralBoundary()` at `0x15e0990`.
- The recovered source declares `siGeneralBoundary::~siGeneralBoundary() = default` and `static_assert(sizeof(siGeneralBoundary) == 0x3B8)`, documenting that the derived type adds no state.

The focused GDB counts are equal for `GeneralBoundary` construction/destruction, `shared_ptr` dispose, mechanics-solver destruction, and controller destruction. The vendor/local difference is therefore an explained compiler/ABI representation of an equivalent defaulted derived destructor, not an observed ownership leak or skipped state cleanup.
