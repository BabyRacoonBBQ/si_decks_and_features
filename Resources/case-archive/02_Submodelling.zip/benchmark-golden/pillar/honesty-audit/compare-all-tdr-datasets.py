from __future__ import annotations

import json
import sys
from pathlib import Path

import h5py
import numpy as np


def attr_value(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return repr(value)


def dataset_row(vendor, local, path):
    if path not in local:
        return {"path": path, "status": "missing_local"}
    a = vendor[path]
    b = local[path]
    row = {
        "path": path,
        "status": "present",
        "shape_vendor": list(a.shape),
        "shape_local": list(b.shape),
        "dtype_vendor": str(a.dtype),
        "dtype_local": str(b.dtype),
        "size_vendor": int(a.size),
        "size_local": int(b.size),
        "exact": False,
    }
    parent = vendor[path.rsplit("/", 1)[0]] if "/" in path else vendor[path]
    for key in ("name", "region", "type"):
        source = a.attrs if key in a.attrs else parent.attrs
        if key in source:
            value = source[key]
            if isinstance(value, bytes):
                value = value.decode("utf-8", errors="replace")
            elif isinstance(value, np.ndarray):
                value = value.tolist()
            elif isinstance(value, np.generic):
                value = value.item()
            row[f"attr_{key}"] = value
    if a.shape != b.shape or a.dtype != b.dtype:
        row["status"] = "shape_or_dtype_difference"
        return row
    av = a[...]
    bv = b[...]
    try:
        row["exact"] = bool(np.array_equal(av, bv))
        if np.issubdtype(a.dtype, np.number):
            delta = np.asarray(av, dtype=np.float64) - np.asarray(bv, dtype=np.float64)
            abs_delta = np.abs(delta)
            peak = float(np.max(np.abs(np.asarray(av, dtype=np.float64)))) if av.size else 0.0
            row["different_elements"] = int(np.count_nonzero(delta))
            row["max_absolute_difference"] = float(np.max(abs_delta)) if av.size else 0.0
            row["relative_to_vendor_peak"] = row["max_absolute_difference"] / max(peak, 1e-300)
            row["allclose_1e-12"] = bool(np.allclose(av, bv, rtol=1e-12, atol=1e-12))
        else:
            row["different_elements"] = int(np.count_nonzero(av != bv))
    except Exception as exc:
        row["comparison_error"] = repr(exc)
    return row


def main():
    vendor_path, local_path, output_path = map(Path, sys.argv[1:4])
    report = {"vendor": str(vendor_path), "local": str(local_path), "datasets": [], "attributes": []}
    with h5py.File(vendor_path, "r") as vendor, h5py.File(local_path, "r") as local:
        paths = set()
        vendor.visititems(lambda name, obj: paths.add(name) if isinstance(obj, h5py.Dataset) else None)
        local.visititems(lambda name, obj: paths.add(name) if isinstance(obj, h5py.Dataset) else None)
        for path in sorted(paths):
            if path in vendor and isinstance(vendor[path], h5py.Dataset):
                report["datasets"].append(dataset_row(vendor, local, path))
            else:
                report["datasets"].append({"path": path, "status": "missing_vendor"})

        object_paths = set()
        vendor.visititems(lambda name, obj: object_paths.add(name))
        local.visititems(lambda name, obj: object_paths.add(name))
        for path in sorted(object_paths):
            if path not in vendor or path not in local:
                report["attributes"].append({"path": path, "status": "missing_object"})
                continue
            va = vendor[path].attrs
            la = local[path].attrs
            for key in sorted(set(va.keys()) | set(la.keys())):
                if key not in va or key not in la or not np.array_equal(va.get(key), la.get(key)):
                    report["attributes"].append({
                        "path": path,
                        "key": key,
                        "vendor": attr_value(va.get(key)),
                        "local": attr_value(la.get(key)),
                    })
    report["summary"] = {
        "dataset_count": len(report["datasets"]),
        "dataset_exact": sum(1 for row in report["datasets"] if row.get("exact") is True),
        "dataset_missing_or_shape_difference": sum(1 for row in report["datasets"] if row.get("status") != "present"),
        "dataset_nonexact": sum(1 for row in report["datasets"] if row.get("status") == "present" and row.get("exact") is False),
        "attribute_difference_count": len(report["attributes"]),
    }
    output_path.write_text(json.dumps(report, indent=2))
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
