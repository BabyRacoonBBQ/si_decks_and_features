import gdb, hashlib, json, os, struct
from pathlib import Path

out = os.environ['AUDIT_OUT']
events = []
counts = 0
targets = set(range(1, 17))

def bytes_at(inf, addr, n):
    return inf.read_memory(addr, n).tobytes()

def vectorstatic(inf, addr, n):
    size = struct.unpack('<q', bytes_at(inf, addr + 8, 8))[0]
    data = struct.unpack('<Q', bytes_at(inf, addr + 16, 8))[0]
    size = max(0, min(size, n))
    raw = bytes_at(inf, data, size * 8) if data and size else b''
    values = struct.unpack('<{}d'.format(size), raw) if raw else ()
    return {'size': size, 'sha256': hashlib.sha256(raw).hexdigest(), 'values': list(values)}

def snap(stiff, label):
    inf = gdb.selected_inferior()
    row_count = struct.unpack('<i', bytes_at(inf, stiff + 0xc, 4))[0]
    rows = list(struct.unpack('<{}i'.format(max(0, min(row_count, 300))), bytes_at(inf, stiff + 0x1c, max(0, min(row_count, 300)) * 4))) if row_count > 0 else []
    ss = vectorstatic(inf, stiff + 0x980, max(0, min(row_count, 300)))
    return {'label': label, 'row_count': row_count, 'row_ids': rows, 'ss_rhs': ss}

class Ret(gdb.FinishBreakpoint):
    def __init__(self, frame, count, stiff, entry):
        self.count, self.stiff, self.entry = count, stiff, entry
        super().__init__(frame, internal=True)
    def stop(self):
        events.append({'phase': 'return', 'count': self.count, 'entry': self.entry, 'state': snap(self.stiff, 'return')})
        return False

class Probe(gdb.Breakpoint):
    def __init__(self):
        super().__init__('floops::BasicSingleStiff::ssScatter(floops::Vector&, floops::Vector*)', internal=False)
        self.count = 0
    def stop(self):
        self.count += 1
        if self.count > 16:
            self.enabled = False
            return False
        stiff = int(gdb.parse_and_eval('$rdi'))
        entry = snap(stiff, 'entry')
        events.append({'phase': 'entry', 'count': self.count, 'state': entry})
        Ret(gdb.newest_frame(), self.count, stiff, entry)
        return False

probe = Probe()
exit_code = None
def exited(event):
    global exit_code
    exit_code = getattr(event, 'exit_code', None)
    Path(out).write_text(json.dumps({'exit': exit_code, 'counts': {'ssScatter': probe.count}, 'events': events}, indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
