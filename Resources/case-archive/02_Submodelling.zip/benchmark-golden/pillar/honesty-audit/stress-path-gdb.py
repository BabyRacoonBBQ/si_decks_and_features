import gdb,json,os
out=os.environ['AUDIT_OUT']; probes=json.load(open(os.environ['AUDIT_PROBES'])); hits={}; observations=[]
class First(gdb.Breakpoint):
 def __init__(self,p): self.name=p['name']; super(First,self).__init__('*'+p['address'],internal=False)
 def stop(self):
  self.enabled=False
  hits[self.name]=hits.get(self.name,0)+1
  observations.append({'name':self.name,'pc':str(gdb.parse_and_eval('$pc')),'stack':gdb.execute('bt 8',to_string=True),'symbol':gdb.execute('info symbol $pc',to_string=True)})
  return False
for p in probes: First(p)
exitcode=None
def exited(e):
 global exitcode; exitcode=getattr(e,'exit_code',None)
gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
json.dump({'exit':exitcode,'hits':hits,'observations':observations,'probes':probes},open(out,'w'),indent=2)
