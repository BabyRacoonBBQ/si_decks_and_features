import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT'];events=[];hits=0;MAX_HITS=int(os.environ.get('MAX_HITS','4'))
def reg(n):
 try:return int(gdb.parse_and_eval('$'+n))
 except:return 0
def u64(a):
 try:return struct.unpack('<Q',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return 0
def d(a):
 try:return struct.unpack('<d',gdb.selected_inferior().read_memory(a,8).tobytes())[0]
 except:return None
def field_values(obj):
 vs=u64(obj+0x748) if obj else 0
 field=u64(vs+0x110) if vs else 0
 slots=u64(field+0x68+8*0) if field else 0
 seg=u64(slots+8*85) if slots else 0
 data=u64(seg) if seg else 0
 return {'solver_velocity_solution':hex(vs) if vs else None,'velocity_field':hex(field) if field else None,'data':hex(data) if data else None,'target1020':[d(data+24*1020+8*i) for i in range(3)] if data else [None]*3}
class Ret(gdb.FinishBreakpoint):
 def __init__(self,call,obj):self.call=call;self.obj=obj;super().__init__(internal=True)
 def stop(self):
  events.append({'phase':'return','call':self.call,**field_values(self.obj),'stack':gdb.execute('bt 8',to_string=True)});return False
class BP(gdb.Breakpoint):
 def __init__(self):super().__init__('*'+os.environ['LOAD_PC'],internal=False)
 def stop(self):
  global hits
  hits+=1
  if hits<=MAX_HITS:
   obj=reg('rdi');events.append({'phase':'entry','call':hits,**field_values(obj),'stack':gdb.execute('bt 8',to_string=True)});Ret(hits,obj)
  return False
BP()
def exited(e):Path(OUT).write_text(json.dumps({'exit':getattr(e,'exit_code',None),'hits':hits,'events':events},indent=2))
gdb.events.exited.connect(exited)
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set follow-fork-mode parent');gdb.execute('run')
