from __future__ import annotations
import hashlib, json, os, shutil, subprocess, time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-runassemble-rhs-20261011-corrected'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
import fcntl
fcntl.flock(LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)

BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run',
}
ENV = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSITE='1', TDR_VERSION='16')
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    ENV.pop(key, None)
V = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'
ENV['LD_LIBRARY_PATH'] = ':'.join([V + '/lib', V + '/lib/gds2tcadLib', V + '/lib/gds2tcadLib/tbcload1.7', V + '/lib/python3.11/site-packages/sinterconnect', V + '/lib/python3.11/site-packages/floops', V + '/lib/python3.11/site-packages/sdevice', V + '/tcad_mpi_mpich_ifort/lib', V + '/tcad_mpi_intel/lib'])
ENV['STROOT'] = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1'
ENV['STRELEASE'] = 'W-2024.09-SP1'
ENV['TCADPATH'] = ENV['STROOT']

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

records = []
for tool, binary in BINARIES.items():
    run_dir = OUT / tool
    shutil.copytree(ROOT / 'prepared', run_dir)
    shutil.copy2(ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr', run_dir / 'global_sis.tdr')
    env = dict(ENV, AUDIT_OUT=str(run_dir / 'runassemble-rhs-events.json'), AUDIT_DUMP_DIR=str(run_dir), AUDIT_LIMIT='8')
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch', '-ex', 'source /tmp/runassemble-rhs-gdb.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    started = time.time()
    with (run_dir / 'runassemble-rhs-gdb.log').open('w') as log:
        proc = subprocess.run(argv, cwd=run_dir, env=env, stdout=log, stderr=subprocess.STDOUT)
    events_path = run_dir / 'runassemble-rhs-events.json'
    events = json.loads(events_path.read_text()) if events_path.exists() else {}
    rec = {'tool': tool, 'observer_exit': proc.returncode, 'inferior_exit': events.get('exit'), 'wall': time.time() - started, 'binary_sha256': sha(Path(binary)), 'counts': events.get('counts'), 'event_count': len(events.get('events', []))}
    records.append(rec)
    (OUT / 'progress.json').write_text(json.dumps(records, indent=2))
    if proc.returncode != 0 or events.get('exit') != 0:
        raise RuntimeError(rec)

(OUT / 'exit.json').write_text(json.dumps({'exit': 0, 'runs': records}, indent=2))
print(json.dumps(records, indent=2))
