from pathlib import Path
import os,json,subprocess,shutil,hashlib,time,fcntl
root=Path('/home/mozztcad/si-bench/golden-pillar-20261011'); out=root/'honesty-files-a'
assert json.loads((root/'honesty-audit-b/exit.json').read_text())['exit']==0,'Wait for GDB pipeline completion'
lock=open('/tmp/geo3d-sinterconnect-heavy.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
shutil.copytree(root/'prepared',out)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
binary='/home/mozztcad/geo3d/build/sinterconnect_run'
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TDR_VERSION='16',PYTHONNOUSERSITE='1')
for k in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(k,None)
records=[]
for stage in ('global','unit-fine'):
 args=['timeout','-k','10','900','taskset','-c','4','strace','-ff','-s','1024','-e','trace=execve,execveat,open,openat,creat,connect','-o',str(out/(stage+'-syscalls')),binary,stage+'.cmd']
 before={p.name:sha(p) for p in out.glob('*.tdr')}; start=time.time();print('BEGIN',stage,flush=True)
 with (out/(stage+'-stdout.log')).open('w') as stdout,(out/(stage+'-stderr.log')).open('w') as stderr:
  result=subprocess.run(args,cwd=out,env=env,stdout=stdout,stderr=stderr)
 record={'stage':stage,'exit':result.returncode,'binary_sha256':sha(binary),'deck_sha256':sha(out/(stage+'.cmd')),'inputs_before':before,'output_sha256':sha(out/(stage+'_sis.tdr')) if (out/(stage+'_sis.tdr')).exists() else None,'wall':time.time()-start}
 records.append(record);(out/'progress.json').write_text(json.dumps(records,indent=2));print('END',json.dumps(record),flush=True)
 if result.returncode:raise RuntimeError('Tracing failed')
(out/'exit.json').write_text(json.dumps({'exit':0,'runs':records},indent=2))
