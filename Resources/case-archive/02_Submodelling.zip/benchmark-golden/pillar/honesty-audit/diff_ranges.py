from pathlib import Path
x=Path('/home/mozztcad/si-bench/golden-pillar-20261011/honesty-audit-b/vendor/global_sis.tdr').read_bytes(); y=Path('/home/mozztcad/si-bench/golden-pillar-20261011/honesty-audit-b/local/global_sis.tdr').read_bytes()
r=[]; i=0
while i<min(len(x),len(y)):
 if x[i]==y[i]: i+=1; continue
 j=i
 while j<min(len(x),len(y)) and x[j]!=y[j]: j+=1
 r.append((i,j-1,j-i,x[i:j].hex(),y[i:j].hex())); i=j
print('ranges',len(r),'diffbytes',sum(z[2] for z in r))
for z in r[:50]: print(z)
