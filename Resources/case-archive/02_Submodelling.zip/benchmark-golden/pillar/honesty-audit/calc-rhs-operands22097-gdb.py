import gdb,json,os,struct
from pathlib import Path
OUT=os.environ['AUDIT_OUT']; TARGET=int(os.environ.get('AUDIT_TARGET','22097')); count=0; events=[]; inner=None
def dreg(name):
 try:return float(gdb.parse_and_eval(f'${name}.v2_double[0]'))
 except Exception:return None
def u64(name):
 try:return int(gdb.parse_and_eval(f'${name}'))
 except Exception:return 0
def memd(addr):
 try:return struct.unpack('<d',gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
 except Exception:return None
class Inner(gdb.Breakpoint):
 def __init__(self,addr,style): self.style=style; super().__init__(f'*{addr:#x}',internal=False)
 def stop(self):
  inf=gdb.selected_inferior(); e={'phase':'inner','style':self.style,'pc':hex(int(gdb.parse_and_eval('$pc'))),'xmm0':dreg('xmm0'),'xmm1':dreg('xmm1'),'xmm2':dreg('xmm2'),'xmm3':dreg('xmm3'),'xmm4':dreg('xmm4'),'xmm5':dreg('xmm5'),'xmm6':dreg('xmm6'),'xmm7':dreg('xmm7'),'xmm8':dreg('xmm8'),'xmm9':dreg('xmm9')}
  if self.style=='vendor': e.update({'rhs_ptr':hex(u64('r8')),'b_ptr':hex(u64('r9')),'detJ_ptr':hex(u64('rdi')),'weight_ptr':hex(u64('rsi')),'b':memd(u64('r9')),'detJ':memd(u64('rdi')),'weight':memd(u64('rsi'))})
  else: e.update({'rhs_ptr':hex(u64('r13')),'b_ptr':hex(u64('rdx')),'detJ_ptr':hex(u64('rdx')+0),'weight_ptr':hex(u64('r15')),'b':memd(u64('rdx')),'weight':dreg('xmm1'),'detJ':dreg('xmm2')})
  events.append(e); self.enabled=False; return False
class P(gdb.Breakpoint):
 def __init__(self): super().__init__('FE::MechanicsAssembler::calc_rhs(floops::SingleStiff&, floops::SingleDense*)',internal=False)
 def stop(self):
  global count,inner; count+=1
  if count==TARGET:
   base=int(gdb.parse_and_eval('$pc')); style='vendor' if base < 0x1900000 else 'local'; off=0x148 if style=='vendor' else 0x160; inner=Inner(base+off,style); events.append({'phase':'entry','count':count,'style':style,'base':hex(base),'inner':hex(base+off)})
   self.enabled=False
  return False
P(); exit_code=None
def exited(event):
 global exit_code; exit_code=getattr(event,'exit_code',None); Path(OUT).write_text(json.dumps({'exit':exit_code,'target':TARGET,'calc_rhs_hits':count,'events':events},indent=2))
gdb.events.exited.connect(exited); gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
