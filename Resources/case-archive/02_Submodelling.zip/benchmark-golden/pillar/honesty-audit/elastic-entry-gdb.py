import gdb, json, os, struct

out = os.environ['AUDIT_OUT']; probes = json.load(open(os.environ['AUDIT_PROBES']))
records=[]; exitcode=None

def read_u64(addr):
    try: return struct.unpack('<Q', gdb.selected_inferior().read_memory(addr,8).tobytes())[0]
    except Exception: return 0

def vals(addr, count=6):
    if not addr: return None
    try:
        p=gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p+i).dereference()) for i in range(count)]
    except Exception as e: return ['ERROR:'+str(e)]

class Probe(gdb.Breakpoint):
    def __init__(self,p): self.name=p['name']; self.seen=False; super(Probe,self).__init__('*'+p['address'],internal=False)
    def stop(self):
        if self.seen: return False
        self.seen=True
        this=int(gdb.parse_and_eval('$rdi')); element=int(gdb.parse_and_eval('$rsi'))
        base=read_u64(this+0x400); rows=[]
        for i in range(8):
            ptr=read_u64(base+8*i) if base else 0
            rows.append({'index':i,'ptr':hex(ptr) if ptr else None,'values':vals(ptr)})
        records.append({'phase':'entry','entry':self.name,'this':hex(this),'element':hex(element),'gpStressArray':hex(base) if base else None,'rows':rows,'stack':gdb.execute('bt 12',to_string=True)})
        self.enabled=False; return False

for p in probes: Probe(p)
def exited(e):
    global exitcode; exitcode=getattr(e,'exit_code',None)
gdb.events.exited.connect(exited)
gdb.execute('set pagination off'); gdb.execute('set confirm off'); gdb.execute('set print thread-events off'); gdb.execute('set follow-fork-mode parent'); gdb.execute('run')
json.dump({'exit':exitcode,'records':records,'probes':probes},open(out,'w'),indent=2)
