from pathlib import Path
import os, json, subprocess, shutil, hashlib, time, fcntl

root = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
out = root / 'honesty-audit-f'
out.mkdir(exist_ok=False)
lock = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
bins = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local': '/home/mozztcad/geo3d/build/sinterconnect_run',
}

# Addresses are bound to the separately recorded vendor/local executable SHAs.
probes = {
    'vendor': [
        ('siGeneralBoundary::ctor', '0x129e1c0'),
        ('siGeneralBoundary::dtor', '0x129a890'),
        ('GeneralBoundary::ctor', '0x1895ab0'),
        ('GeneralBoundary::dtor', '0x1891f20'),
        ('GeneralBoundary::shared_ptr_dispose', '0x129a910'),
        ('MechController::ctor_state', '0x18cced0'),
        ('MechController::ctor', '0x18cd370'),
        ('MechController::dtor', '0x18cd5a0'),
        ('MechanicsSolver::ctor', '0x1998210'),
        ('MechanicsSolver::dtor', '0x19986e0'),
        ('Tdr_writer::ctor', '0x14fb500'),
        ('Tdr_writer::populate', '0x1506c20'),
        ('Tdr_writer::dtor', '0x14eeb90'),
        ('StructureWriter::ctor', '0x1c83a90'),
        ('StructureWriter::processAndWriteTdr', '0x1c846f0'),
        ('StructureWriter::dtor', '0x1c7e990'),
    ],
    'local': [
        ('siGeneralBoundary::ctor', '0x15eef20'),
        ('siGeneralBoundary::dtor', '0x15e0b50'),
        ('GeneralBoundary::shared_ptr_dispose', '0x0e82370'),
        ('siMechanicsSolver::dtor', '0x0e80970'),
        ('GeneralBoundary::ctor', '0x15e21b0'),
        ('GeneralBoundary::dtor', '0x15e0990'),
        ('MechController::ctor_state', '0x0d05880'),
        ('MechController::ctor', '0x0d05660'),
        ('MechController::dtor', '0x0d06280'),
        ('MechanicsSolver::ctor', '0x0e65b40'),
        ('MechanicsSolver::dtor', '0x0e64a70'),
        ('Tdr_writer::ctor', '0x0fbe000'),
        ('Tdr_writer::populate', '0x0fc0000'),
        ('Tdr_writer::dtor', '0x0fbf000'),
        ('StructureWriter::ctor', '0x10f5b00'),
        ('StructureWriter::processAndWriteTdr', '0x10f6250'),
        ('StructureWriter::dtor', '0x10f5db0'),
    ],
}

# Local Tdr_writer addresses are resolved from the current binary before launch.
nm = subprocess.check_output(['nm', '-C', '--defined-only', bins['local']], universal_newlines=True)
for label, suffix in [
    ('Tdr_writer::ctor', 'floops::Tdr_writer::Tdr_writer(std::shared_ptr<floops::FieldServer> const&, floops::StructSpec const&, std::shared_ptr<Tdr_collection>&)'),
    ('Tdr_writer::populate', 'floops::Tdr_writer::populate()'),
    ('Tdr_writer::dtor', 'floops::Tdr_writer::~Tdr_writer()'),
]:
    matches = [line.split(' ', 2)[0] for line in nm.splitlines() if line.endswith(' T ' + suffix)]
    if not matches:
        raise RuntimeError('missing local symbol: ' + suffix)
    for i, (name, _) in enumerate(probes['local']):
        if name == label:
            probes['local'][i] = (name, '0x' + matches[0])

env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSERSITE='1', TDR_VERSION='16')
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)

records = []
for tool, binary in bins.items():
    d = out / tool
    shutil.copytree(root / 'prepared', d)
    probe_path = d / 'probes.json'
    probe_path.write_text(json.dumps([{'name': n, 'address': a} for n, a in probes[tool]]))
    for stage in ('global', 'unit-fine'):
        env.update(AUDIT_OUT=str(d / (stage + '-events.json')), AUDIT_PROBES=str(probe_path))
        argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch',
                '-ex', 'source /tmp/honesty-probe.py', '--args', binary]
        if tool == 'vendor':
            argv.append('--noSyntaxCheck')
        argv.append(stage + '.cmd')
        start = time.time()
        with (d / (stage + '-gdb.log')).open('w') as log:
            p = subprocess.run(argv, cwd=d, env=env, stdout=log, stderr=subprocess.STDOUT)
        result = json.loads((d / (stage + '-events.json')).read_text()) if (d / (stage + '-events.json')).exists() else {}
        output = d / (stage + '_sis.tdr')
        record = {
            'tool': tool, 'stage': stage, 'observer_exit': p.returncode,
            'inferior_exit': result.get('exit'), 'start': start,
            'wall': time.time() - start, 'binary_sha256': sha(binary),
            'deck_sha256': sha(d / (stage + '.cmd')),
            'output_sha256': sha(output) if output.exists() else None,
            'global_input_sha256': sha(d / 'global_sis.tdr') if stage == 'unit-fine' else None,
        }
        records.append(record)
        (out / 'progress.json').write_text(json.dumps(records, indent=2))
        print('END', json.dumps(record), flush=True)
        if p.returncode or result.get('exit') != 0:
            raise RuntimeError('lifecycle diagnostic run failed; retain evidence')

(out / 'exit.json').write_text(json.dumps({'exit': 0, 'runs': records}, indent=2))
