import gdb, json, os

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
events, counts, returns = [], {}, {}

class Ret(gdb.FinishBreakpoint):
    def __init__(self, frame, name):
        self.name = name
        super(Ret, self).__init__(frame, internal=True)
    def stop(self):
        returns[self.name] = returns.get(self.name, 0) + 1
        return False

class Probe(gdb.Breakpoint):
    def __init__(self, item):
        self.name = item['name']
        super(Probe, self).__init__('*' + item['address'], internal=False)
    def stop(self):
        n = self.name
        counts[n] = counts.get(n, 0) + 1
        if counts[n] <= 3:
            events.append({
                'name': n,
                'hit': counts[n],
                'pc': str(gdb.parse_and_eval('$pc')),
                'stack': gdb.execute('bt 18', to_string=True),
                'symbol': gdb.execute('info symbol $pc', to_string=True),
            })
        try:
            Ret(gdb.newest_frame(), n)
        except Exception as exc:
            events.append({'name': n, 'hit': counts[n], 'return_probe_error': str(exc)})
        return False

for item in probes:
    Probe(item)

exitcode = None
def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)
gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exitcode, 'counts': counts, 'returns': returns, 'events': events,
           'probes': probes}, open(out, 'w'), indent=2)
