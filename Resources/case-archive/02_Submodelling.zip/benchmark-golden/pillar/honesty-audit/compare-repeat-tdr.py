from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import h5py
import numpy as np


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def compare(a_path: Path, b_path: Path):
    result = {"a": str(a_path), "b": str(b_path), "a_sha256": sha(a_path), "b_sha256": sha(b_path), "datasets": []}
    with h5py.File(a_path, "r") as a, h5py.File(b_path, "r") as b:
        paths = set()
        a.visititems(lambda name, obj: paths.add(name) if isinstance(obj, h5py.Dataset) else None)
        b.visititems(lambda name, obj: paths.add(name) if isinstance(obj, h5py.Dataset) else None)
        for path in sorted(paths):
            if path not in a or path not in b:
                result["datasets"].append({"path": path, "status": "missing"})
                continue
            av, bv = a[path][...], b[path][...]
            row = {"path": path, "shape": list(av.shape), "dtype": str(av.dtype), "exact": bool(np.array_equal(av, bv))}
            if np.issubdtype(av.dtype, np.number) and av.shape == bv.shape:
                delta = np.asarray(av, dtype=np.float64) - np.asarray(bv, dtype=np.float64)
                row["different_elements"] = int(np.count_nonzero(delta))
                row["max_absolute_difference"] = float(np.max(np.abs(delta))) if av.size else 0.0
                peak = float(np.max(np.abs(np.asarray(av, dtype=np.float64)))) if av.size else 0.0
                row["relative_to_a_peak"] = row["max_absolute_difference"] / max(peak, 1e-300)
            result["datasets"].append(row)
    result["summary"] = {
        "dataset_count": len(result["datasets"]),
        "exact": sum(1 for row in result["datasets"] if row.get("exact") is True),
        "nonexact": sum(1 for row in result["datasets"] if row.get("exact") is False),
        "max_relative": max((row.get("relative_to_a_peak", 0.0) for row in result["datasets"]), default=0.0),
    }
    return result


def main():
    out = Path(sys.argv[1])
    pairs = list(zip(sys.argv[2::2], sys.argv[3::2]))
    result = [compare(Path(a), Path(b)) for a, b in pairs]
    out.write_text(json.dumps(result, indent=2))
    print(json.dumps([r["summary"] for r in result], indent=2))


if __name__ == "__main__":
    main()
