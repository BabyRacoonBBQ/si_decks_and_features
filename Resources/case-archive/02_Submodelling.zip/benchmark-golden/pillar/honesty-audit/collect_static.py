from pathlib import Path
import subprocess,json,hashlib
out=Path('benchmark-golden/pillar/honesty-audit');host='mozztcad@192.168.43.128'
commands={
'worktree':'cd /home/mozztcad/geo3d && git rev-parse HEAD && git branch --show-current && git status --short',
'link':'cat /home/mozztcad/geo3d/build/CMakeFiles/sinterconnect_run.dir/link.txt',
'case_literal_scan':'cd /home/mozztcad/geo3d && rg -n "887\\.678|703\\.701|golden-pillar|unit-fine_sis|global_sis\\.tdr|calibration-a|formal-pillar" src cmake',
'core_forwarding_scan':'cd /home/mozztcad/geo3d && rg -n "dlopen|dlsym|execve|popen|std::system|::system\\(" src/abi/sinterconnect src/abi/floops/floops/GeneralBoundary.cpp src/abi/floops/floops/MechController.cpp src/abi/FE/FE/MechanicsAssembler.cpp src/abi/floops/floops/Interpolator.cpp',
'current_source_hashes':'cd /home/mozztcad/geo3d && sha256sum src/abi/floops/floops/GeneralBoundary.cpp src/abi/floops/floops/GeneralBoundary.h cmake/geo_libraries.cmake cmake/rcfx_standalone.cmake build/sinterconnect_run',
'build_flags':'cd /home/mozztcad/geo3d && cat build/CMakeFiles/sinterconnect_run.dir/flags.make && rg "CMAKE_BUILD_TYPE:|BUILD_TESTING:" build/CMakeCache.txt'}
results={}
for name,cmd in commands.items():
 p=subprocess.run(['ssh',host,cmd],capture_output=True,text=True,encoding='utf-8')
 results[name]={'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(out/'static-evidence.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('Saved six read-only identity/source checks; no-match scan exit 1 retained.')
