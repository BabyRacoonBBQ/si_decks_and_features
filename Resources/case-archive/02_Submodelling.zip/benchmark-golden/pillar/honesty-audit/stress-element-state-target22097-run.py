from __future__ import annotations
import fcntl, hashlib, json, os, shutil, subprocess, time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-stress-element-state-target22097-202619'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(LOCK, fcntl.LOCK_EX)
BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run',
}
PC = {
    'vendor': {'stress': '0x126a2c0', 'strains': '0x1267fc0', 'calc_stress': '0x19e8ac0', 'euler': '0x188aab0'},
    'local-repair': {'stress': '0xe87300', 'strains': '0xe85200', 'calc_stress': '0x1544d90', 'euler': '0x1a443c0'},
}

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSITE='1', TDR_VERSION='16')
env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1', STRELEASE='W-2024.09-SP1', TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1')
V = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1'
env['LD_LIBRARY_PATH'] = ':'.join([V + '/linux64/lib', V + '/linux64/lib/gds2tcadLib', V + '/linux64/lib/gds2tcadLib/tbcload1.7', V + '/linux64/lib/python3.11/site-packages/sinterconnect', V + '/linux64/lib/python3.11/site-packages/floops', V + '/linux64/lib/python3.11/site-packages/sdevice', V + '/linux64/tcad_mpi_mpich_ifort/lib', V + '/linux64/tcad_mpi_intel/lib'])
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)
results = []
for tool, binary in BINARIES.items():
    directory = OUT / tool
    shutil.copytree(ROOT / 'prepared', directory)
    shutil.copy2(ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr', directory / 'global_sis.tdr')
    env.update(AUDIT_OUT=str(directory / 'events.json'), AUDIT_TARGET='22097', COMPUTE_STRESS_PC=PC[tool]['stress'], COMPUTE_STRAINS_PC=PC[tool]['strains'], CALC_STRESS_PC=PC[tool]['calc_stress'], EULER_PC=PC[tool]['euler'])
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch', '-ex', 'source /tmp/stress-element-state-target22097-gdb.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    started = time.time()
    with (directory / 'gdb.log').open('w') as log:
        process = subprocess.run(argv, cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT)
    event = json.loads((directory / 'events.json').read_text()) if (directory / 'events.json').exists() else {}
    results.append({'tool': tool, 'observer_exit': process.returncode, 'inferior_exit': event.get('exit'), 'wall_seconds': time.time() - started, 'binary_sha256': sha(Path(binary)), 'stress_hits': event.get('stress_hits'), 'record_count': len(event.get('events', [])), 'output_sha256': sha(directory / 'unit-fine_sis.tdr') if (directory / 'unit-fine_sis.tdr').exists() else None})
    if process.returncode or event.get('exit') != 0:
        raise RuntimeError(results[-1])
(OUT / 'exit.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
