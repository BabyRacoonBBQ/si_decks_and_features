import gdb, json, os

out = os.environ['AUDIT_OUT']
probes = json.load(open(os.environ['AUDIT_PROBES']))
records = []
exitcode = None

def dvals(addr, count=6):
    if not addr:
        return None
    try:
        p = gdb.Value(addr).cast(gdb.lookup_type('double').pointer())
        return [float((p + i).dereference()) for i in range(count)]
    except Exception as e:
        return ['ERROR:' + str(e)]

def scalar(expr):
    try:
        return float(gdb.parse_and_eval(expr))
    except Exception as e:
        return 'ERROR:' + str(e)

class ReturnProbe(gdb.FinishBreakpoint):
    def __init__(self, entry, ptr):
        super(ReturnProbe, self).__init__(internal=True)
        self.entry = entry
        self.ptr = ptr
    def stop(self):
        records.append({
            'phase': 'return', 'entry': self.entry,
            'ptr': hex(self.ptr) if self.ptr else None,
            'values': dvals(self.ptr),
            'xmm0': scalar('$xmm0.v2_double[0]'),
            'pc': str(gdb.parse_and_eval('$pc')),
            'stack': gdb.execute('bt 12', to_string=True),
        })
        return False

class ElasticSetter(gdb.Breakpoint):
    def __init__(self, p):
        self.name = p['name']; self.seen = False
        super(ElasticSetter, self).__init__('*' + p['address'], internal=False)
    def stop(self):
        if self.seen:
            return False
        self.seen = True
        # SysV member-function ABI: RDI=this, RSI=double*, RDX=Element&, RCX=bool.
        ptr = int(gdb.parse_and_eval('$rsi'))
        records.append({
            'phase': 'entry', 'entry': self.name, 'ptr': hex(ptr) if ptr else None,
            'values': dvals(ptr), 'this': hex(int(gdb.parse_and_eval('$rdi'))),
            'element': hex(int(gdb.parse_and_eval('$rdx'))),
            'flag': int(gdb.parse_and_eval('$rcx')),
            'xmm0': scalar('$xmm0.v2_double[0]'),
            'pc': str(gdb.parse_and_eval('$pc')),
            'stack': gdb.execute('bt 12', to_string=True),
        })
        try:
            ReturnProbe(self.name, ptr)
        except Exception:
            pass
        self.enabled = False
        return False

class EnergySetter(gdb.Breakpoint):
    def __init__(self, p):
        self.name = p['name']; self.seen = False
        super(EnergySetter, self).__init__('*' + p['address'], internal=False)
    def stop(self):
        if self.seen:
            return False
        self.seen = True
        records.append({
            'phase': 'entry', 'entry': self.name,
            'energy': scalar('$xmm0.v2_double[0]'),
            'this': hex(int(gdb.parse_and_eval('$rdi'))),
            'element': hex(int(gdb.parse_and_eval('$rsi'))),
            'flag': int(gdb.parse_and_eval('$rdx')),
            'pc': str(gdb.parse_and_eval('$pc')),
            'stack': gdb.execute('bt 12', to_string=True),
        })
        self.enabled = False
        return False

for p in probes:
    if p['name'] == 'floops::MechData::SetElasticStrain(double*, floops::Element&, bool)':
        ElasticSetter(p)
    elif p['name'] == 'floops::MechData::Set_enerDensel(double, floops::Element&, bool)':
        EnergySetter(p)

def exited(event):
    global exitcode
    exitcode = getattr(event, 'exit_code', None)

gdb.events.exited.connect(exited)
gdb.execute('set pagination off')
gdb.execute('set confirm off')
gdb.execute('set print thread-events off')
gdb.execute('set follow-fork-mode parent')
gdb.execute('run')
json.dump({'exit': exitcode, 'records': records, 'probes': probes}, open(out, 'w'), indent=2)
