from __future__ import annotations
import fcntl,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/home/mozztcad/si-bench/golden-pillar-20261011');OUT=ROOT/'honesty-audit-stress-transition-20261011b';OUT.mkdir(exist_ok=False)
LOCK=open('/tmp/geo3d-sinterconnect-heavy.lock','w');fcntl.flock(LOCK,fcntl.LOCK_EX)
BINARIES={'vendor':'/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect','local-repair':'/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run'}
NAMES=['sinterconnect::siMechPDE::computeStressHOE(floops::Element*, TcadBase::Iter<floops::Node>&, floops::ElementIter&, double, bool, int, bool)','sinterconnect::siMechPDE::computeElasticStrainHOE(floops::Element*)']
def sha(path):
 h=hashlib.sha256();
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def resolve(binary):
 lines=subprocess.check_output(['nm']+(['-D'] if binary==BINARIES['vendor'] else [])+['-C','--defined-only',binary],text=True).splitlines();ps=[];ms=[]
 for n in NAMES:
  m=[x.split() for x in lines if x.endswith(' T '+n)]
  if len(m)==1:ps.append({'name':n,'address':'0x'+m[0][0]})
  else:ms.append({'name':n,'matches':m})
 return ps,ms
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONNOUSITE='1',TDR_VERSION='16');env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1',STRELEASE='W-2024.09-SP1',TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1')
V='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64';env['LD_LIBRARY_PATH']=':'.join([V+'/lib',V+'/lib/gds2tcadLib',V+'/lib/gds2tcadLib/tbcload1.7',V+'/lib/python3.11/site-packages/sinterconnect',V+'/lib/python3.11/site-packages/floops',V+'/lib/python3.11/site-packages/sdevice',V+'/tcad_mpi_mpich_ifort/lib',V+'/tcad_mpi_intel/lib'])
for k in ('LD_PRELOAD','BREP_RECON_SO','HOOK_JS','EXTRA_HOOK_JS','HOOK_LIST','HOOK_SKIP','GEO_INIT_MODELS'):env.pop(k,None)
records=[]
for tool,binary in BINARIES.items():
 ps,ms=resolve(binary);d=OUT/tool;shutil.copytree(ROOT/'prepared',d);shutil.copy2(ROOT/'honesty-audit-b'/('vendor' if tool=='vendor' else 'local')/'global_sis.tdr',d/'global_sis.tdr');(d/'probes.json').write_text(json.dumps(ps,indent=2));env.update(AUDIT_OUT=str(d/'events.json'),AUDIT_PROBES=str(d/'probes.json'))
 argv=['timeout','-k','10','900','taskset','-c','4','gdb','-q','-nx','-batch','-ex','source /tmp/stress-transition-gdb.py','--args',binary]
 if tool=='vendor':argv.append('--noSyntaxCheck')
 argv.append('unit-fine.cmd');st=time.time()
 with (d/'gdb.log').open('w') as log:p=subprocess.run(argv,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 ev=json.loads((d/'events.json').read_text()) if (d/'events.json').exists() else {};records.append({'tool':tool,'observer_exit':p.returncode,'inferior_exit':ev.get('exit'),'wall_seconds':time.time()-st,'binary_sha256':sha(Path(binary)),'missing_probes':ms,'records':ev.get('records'),'output_sha256':sha(d/'unit-fine_sis.tdr')})
 if p.returncode or ev.get('exit')!=0:raise RuntimeError(records[-1])
(OUT/'exit.json').write_text(json.dumps(records,indent=2));print(json.dumps(records,indent=2))
