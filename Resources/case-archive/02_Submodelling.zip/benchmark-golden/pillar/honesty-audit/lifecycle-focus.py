from pathlib import Path
import os, json, subprocess, shutil, hashlib, time, fcntl

root = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
out = root / 'honesty-audit-h'
out.mkdir(exist_ok=False)
lock = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
bins = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local': '/home/mozztcad/geo3d/build/sinterconnect_run',
}
probes = {
    'vendor': [
        ('siGeneralBoundary::dtor_D2', '0x129a890'),
        ('siGeneralBoundary::dtor_D0', '0x129b110'),
        ('GeneralBoundary::dtor_D1', '0x1891f20'),
        ('GeneralBoundary::shared_ptr_dispose', '0x129a910'),
        ('MechanicsSolver::dtor_D1', '0x19986e0'),
        ('MechController::dtor_D1', '0x18cd5a0'),
    ],
    'local': [
        ('siGeneralBoundary::dtor_D1', '0x15e0b50'),
        ('siGeneralBoundary::dtor_D0', '0x15e0b60'),
        ('GeneralBoundary::dtor_D1', '0x15e0990'),
        ('GeneralBoundary::shared_ptr_dispose', '0x0e82370'),
        ('MechanicsSolver::dtor_D1', '0x0e64a70'),
        ('MechController::dtor_D1', '0x0d06280'),
    ],
}
env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSERSITE='1', TDR_VERSION='16')
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)
records = []
for tool, binary in bins.items():
    d = out / tool
    shutil.copytree(root / 'prepared', d)
    (d / 'probes.json').write_text(json.dumps([{'name': n, 'address': a} for n, a in probes[tool]]))
    env.update(AUDIT_OUT=str(d / 'global-events.json'), AUDIT_PROBES=str(d / 'probes.json'))
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch',
            '-ex', 'source /home/mozztcad/si-bench/probe-lifecycle.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('global.cmd')
    start = time.time()
    with (d / 'global-gdb.log').open('w') as log:
        p = subprocess.run(argv, cwd=d, env=env, stdout=log, stderr=subprocess.STDOUT)
    result = json.loads((d / 'global-events.json').read_text())
    output = d / 'global_sis.tdr'
    rec = {'tool': tool, 'stage': 'global', 'observer_exit': p.returncode,
           'inferior_exit': result.get('exit'), 'start': start, 'wall': time.time() - start,
           'binary_sha256': sha(binary), 'deck_sha256': sha(d / 'global.cmd'),
           'output_sha256': sha(output) if output.exists() else None}
    records.append(rec)
    (out / 'progress.json').write_text(json.dumps(records, indent=2))
    print('END', json.dumps(rec), flush=True)
    if p.returncode or result.get('exit') != 0:
        raise RuntimeError('lifecycle focus run failed')
(out / 'exit.json').write_text(json.dumps({'exit': 0, 'runs': records}, indent=2))
