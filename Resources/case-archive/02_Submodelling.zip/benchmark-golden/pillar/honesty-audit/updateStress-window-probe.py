from __future__ import annotations
import fcntl, hashlib, json, os, shutil, subprocess, time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-updateStress-window-20261011'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(LOCK, fcntl.LOCK_EX)
BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run',
}
PC = {
    'vendor': ('0x199d540', '0x126a2c0'),
    'local-repair': ('0xe6bd70', '0xe87300'),
}

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSITE='1', TDR_VERSION='16')
env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1', STRELEASE='W-2024.09-SP1', TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1')
V = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'
env['LD_LIBRARY_PATH'] = ':'.join([V + '/lib', V + '/lib/gds2tcadLib', V + '/lib/gds2tcadLib/tbcload1.7', V + '/lib/python3.11/site-packages/sinterconnect', V + '/lib/python3.11/site-packages/floops', V + '/lib/python3.11/site-packages/sdevice', V + '/tcad_mpi_mpich_ifort/lib', V + '/tcad_mpi_intel/lib'])
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)
results = []
for tool, binary in BINARIES.items():
    directory = OUT / tool
    shutil.copytree(ROOT / 'prepared', directory)
    shutil.copy2(ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr', directory / 'global_sis.tdr')
    env.update(AUDIT_OUT=str(directory / 'events.json'), UPDATE_STRESS_PC=PC[tool][0], COMPUTE_STRESS_PC=PC[tool][1])
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch', '-ex', 'source /tmp/updateStress-window-gdb.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    started = time.time()
    with (directory / 'gdb.log').open('w') as log:
        process = subprocess.run(argv, cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT)
    event = json.loads((directory / 'events.json').read_text()) if (directory / 'events.json').exists() else {}
    results.append({'tool': tool, 'observer_exit': process.returncode, 'inferior_exit': event.get('exit'), 'wall_seconds': time.time() - started, 'binary_sha256': sha(Path(binary)), 'records': event.get('records'), 'stress_hits': event.get('stress_hits'), 'output_sha256': sha(directory / 'unit-fine_sis.tdr') if (directory / 'unit-fine_sis.tdr').exists() else None})
    if process.returncode or event.get('exit') != 0:
        raise RuntimeError(results[-1])
(OUT / 'exit.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
