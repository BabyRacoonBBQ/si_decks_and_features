from __future__ import annotations

import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path('/home/mozztcad/si-bench/golden-pillar-20261011')
OUT = ROOT / 'honesty-audit-elastic-helper-20261011'
OUT.mkdir(exist_ok=False)
LOCK = open('/tmp/geo3d-sinterconnect-heavy.lock', 'w')
fcntl.flock(LOCK, fcntl.LOCK_EX)

BINARIES = {
    'vendor': '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/current/linux64/bin/sinterconnect',
    'local-repair': '/home/mozztcad/geo3d-worktrees/honesty-repair/build/sinterconnect_run',
}

NAMES = [
    'sinterconnect::siMechPDE::computeElasticStrainHOE(floops::Element*)',
    'sinterconnect::siMechPDE::computeElasticStrainEnergyDensityHOE(floops::Element*)',
    'floops::MechData::SetElasticStrain(double*, floops::Element&, bool)',
    'floops::MechData::SetEulerStrain(double*, floops::Element&, bool)',
    'floops::MechData::Set_enerDensel(double, floops::Element&, bool)',
    'FE::FiniteElement::calc_eulerian_strain(int, double*)',
    'FE::FiniteElement::calc_euler_strain(int, double const (*) [3], double*, floops::SingleDense*, bool)',
    'FE::FiniteElement::calc_euler_strain_CSSE(int, int, double const (*) [3], double*, floops::SingleDense*, bool)',
    'sinterconnect::siMechPDE::clearJB()',
]

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def resolve(binary: str):
    cmd = ['nm'] + (['-D'] if binary == BINARIES['vendor'] else []) + ['-C', '--defined-only', binary]
    lines = subprocess.check_output(cmd, text=True).splitlines()
    probes, missing = [], []
    for name in NAMES:
        matches = [line.split() for line in lines if line.endswith(' T ' + name)]
        if len(matches) == 1:
            probes.append({'name': name, 'address': '0x' + matches[0][0]})
        else:
            missing.append({'name': name, 'matches': matches})
    return probes, missing

env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONNOUSITE='1', TDR_VERSION='16')
env.update(STROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1', STRELEASE='W-2024.09-SP1',
           TCADPATH='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1',
           SENTAROOT='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1',
           STROOT_ARCH_OS='/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64')
V = '/home/mozztcad/synopsys/sentaurus/W-2024.09-SP1/tcad/W-2024.09-SP1/linux64'
env['LD_LIBRARY_PATH'] = ':'.join([V + '/lib', V + '/lib/gds2tcadLib', V + '/lib/gds2tcadLib/tbcload1.7',
                                   V + '/lib/python3.11/site-packages/sinterconnect', V + '/lib/python3.11/site-packages/floops',
                                   V + '/lib/python3.11/site-packages/sdevice', V + '/tcad_mpi_mpich_ifort/lib',
                                   V + '/tcad_mpi_intel/lib'])
for key in ('LD_PRELOAD', 'BREP_RECON_SO', 'HOOK_JS', 'EXTRA_HOOK_JS', 'HOOK_LIST', 'HOOK_SKIP', 'GEO_INIT_MODELS'):
    env.pop(key, None)

records = []
for tool, binary in BINARIES.items():
    probes, missing = resolve(binary)
    d = OUT / tool
    shutil.copytree(ROOT / 'prepared', d)
    shutil.copy2(ROOT / 'honesty-audit-b' / ('vendor' if tool == 'vendor' else 'local') / 'global_sis.tdr', d / 'global_sis.tdr')
    (d / 'probes.json').write_text(json.dumps(probes, indent=2))
    env.update(AUDIT_OUT=str(d / 'events.json'), AUDIT_PROBES=str(d / 'probes.json'))
    argv = ['timeout', '-k', '10', '900', 'taskset', '-c', '4', 'gdb', '-q', '-nx', '-batch',
            '-ex', 'source /tmp/honesty-displacement-gdb.py', '--args', binary]
    if tool == 'vendor':
        argv.append('--noSyntaxCheck')
    argv.append('unit-fine.cmd')
    start = time.time()
    with (d / 'gdb.log').open('w') as log:
        p = subprocess.run(argv, cwd=d, env=env, stdout=log, stderr=subprocess.STDOUT)
    events = json.loads((d / 'events.json').read_text()) if (d / 'events.json').exists() else {}
    rec = {'tool': tool, 'observer_exit': p.returncode, 'inferior_exit': events.get('exit'),
           'wall_seconds': time.time() - start, 'binary_sha256': sha(Path(binary)),
           'missing_probes': missing, 'hits': events.get('hits'), 'output_sha256': sha(d / 'unit-fine_sis.tdr')}
    records.append(rec)
    if p.returncode or events.get('exit') != 0:
        raise RuntimeError(rec)
(OUT / 'exit.json').write_text(json.dumps(records, indent=2))
print(json.dumps(records, indent=2))
