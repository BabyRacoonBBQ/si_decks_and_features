"""Compare the converter's interpolation to native vendor submodel boundaries."""
from pathlib import Path
import hashlib,json,sys,time
import h5py,numpy as np
sys.path.insert(0,r'D:/my_repos/si_to_ans_converter')
from converter_core.tetrahedral_mapping import TetrahedralFieldMapper
root=Path(__file__).parent
def read(path):
    with h5py.File(path) as f:
        g=f['collection/geometry_0']
        assert g.attrs['unit:name']==b'cm'
        vertices=g['vertex'][:]
        xyz=np.column_stack([vertices[a] for a in ('x','y','z')])*10 # mm
        fields={int(d.attrs['region']):d for d in g['state_0'].values()
                if d.attrs.get('name')==b'StepDisplacement'}
        values=np.full((len(xyz),3),np.nan);conn=[]
        for key,r in g.items():
            if not key.startswith('region_') or int(r.attrs.get('type',-1))!=0:continue
            elements=r['elements_0'][:].reshape(-1,5)
            assert np.all(elements[:,0]==5)
            c=elements[:,1:].astype(np.int64);ids=np.unique(c)
            data=fields[int(key[7:])]['values'][:].reshape(-1,3)*10
            assert data.shape==(len(ids),3)
            shared=np.isfinite(values[ids,0])
            np.testing.assert_allclose(values[ids[shared]],data[shared],rtol=1e-10,atol=1e-12)
            values[ids]=data;conn.append(c)
        conn=np.concatenate(conn)
        assert np.isfinite(values[np.unique(conn)]).all()
        values[np.isnan(values)]=0 # unused geometry vertices cannot be interpolated
        return xyz,conn,values
global_path=root/'calibration-a/vendor/global_sis.tdr'
local_path=root/'calibration-a/vendor/unit-fine_sis.tdr'
x,c,u=read(global_path);y,lc,lu=read(local_path)
active=np.unique(lc)
lo=y[active].min(axis=0);hi=y[active].max(axis=0)
boundary=active[np.any(np.isclose(y[active],lo,rtol=0,atol=1e-9)|np.isclose(y[active],hi,rtol=0,atol=1e-9),axis=1)]
start=time.perf_counter()
mapped=TetrahedralFieldMapper(x,c).interpolate(u,y[boundary])
error=np.linalg.norm(mapped-lu[boundary],axis=1)
norm=float(np.linalg.norm(mapped,axis=1).max())
report=dict(scope='Converter interpolation vs vendor local boundary StepDisplacement; not MAPDL solver accuracy or timing',
    global_sha256=hashlib.sha256(global_path.read_bytes()).hexdigest(),
    local_sha256=hashlib.sha256(local_path.read_bytes()).hexdigest(),boundary_vertices=len(boundary),
    maximum_vector_error_mm=float(error.max()),rms_vector_error_mm=float(np.sqrt(np.mean(error**2))),
    relative_maximum_error=float(error.max()/norm),mapping_preparation_seconds=time.perf_counter()-start)
assert report['relative_maximum_error']<1e-5
np.savez(root/'mapped-boundary-diagnostic.npz',node_ids=boundary+1,displacement_mm=mapped)
(root/'converter-mapping-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
