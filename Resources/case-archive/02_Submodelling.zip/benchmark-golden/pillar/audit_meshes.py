"""Check frozen mesh topology against the meshes actually used in the slide."""
from pathlib import Path
import hashlib, json
import h5py
import numpy as np
root=Path(__file__).parent
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def mesh(path):
    with h5py.File(path) as f:
        g=f['collection/geometry_0']
        unit=g.attrs['unit:name']
        if isinstance(unit,bytes):unit=unit.decode()
        scale={'cm':1e4,'um':1.}[unit]
        v=g['vertex'][:]
        xyz=np.column_stack([v[a] for a in ('x','y','z')])*scale
        regions={k:(dict(r.attrs),r['elements_0'][:]) for k,r in g.items()
                 if k.startswith('region_') and int(r.attrs.get('type',-1))==0}
        fields=[]
        for name,state in g.items():
            if name.startswith('state_'):
                for key,d in state.items():
                    if not key.startswith('dataset_'): continue
                    value=d.attrs.get('name','')
                    fields.append(value.decode() if isinstance(value,bytes) else str(value))
        return xyz,regions,sorted(set(fields))
results=[]
for stage in ('global','unit-fine'):
    frozen=root/'freeze'/(stage+'-mesh_sis.tdr')
    archive=root/'inputs'/(stage+'_sis.tdr')
    x,r,fields=mesh(frozen); y,s,_=mesh(archive)
    assert x.shape==y.shape
    assert np.allclose(x,y,rtol=0,atol=1e-8), 'Geometry differs'
    assert r.keys()==s.keys()
    for k in r:
        assert r[k][0]['material']==s[k][0]['material']
        assert np.array_equal(r[k][1],s[k][1]), 'Topology differs'
    # Presence of physical result fields would invalidate a stress-free start.
    assert set(fields)<= {'DelVorWeight'}, fields
    results.append(dict(stage=stage,vertices=len(x),tetrahedra=sum(len(v[1])//5 for v in r.values()),
                        maximum_coordinate_difference_um=float(np.max(np.abs(x-y))),
                        identical_connectivity=True,initial_fields=fields,
                        frozen_sha256=digest(frozen),archived_result_sha256=digest(archive)))
(root/'mesh-audit.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
