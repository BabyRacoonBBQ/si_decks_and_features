math numThreads=1
math pardiso
line x location=0 spacing=1 tag=top
line x location=50 spacing=1 tag=bottom
line y location=-2 spacing=0.5 tag=left
line y location=2 spacing=0.5 tag=right
line z location=-2 spacing=0.5 tag=back
line z location=2 spacing=0.5 tag=front
region Silicon xlo=top xhi=bottom ylo=left yhi=right zlo=back zhi=front
init !DelayFullD mixed.mesh
pdbSet Silicon Mechanics BulkModulus [Enu2K 1e10 0.2]
pdbSet Silicon Mechanics ShearModulus [Enu2G 1e10 0.2]
pdbSet Mechanics Save.Displacement.Field 1
pdbSet Mechanics Save.Total.Displacement 1
pdbSet Mechanics Save.Step.Displacement 1
stressdata bc.location=Bottom bc.value= {dx=0 dy=0 dz=0}
stressdata bc.location=pointend point.coord= {0 0 0} bc.value= {pfx=0 pfy=0 pfz=-1.5<dyn>}
mode mechanics
pdbSetBoolean Mechanics LargeDeformation 1
pdbSetBoolean Mechanics ArcLength 0
pdbSetBoolean Mechanics Adjust.Time.Step 0
pdbSet Mechanics MaxIterations 30
pdbSet Mechanics Convergence.Info 1
pdbSet Mechanics Convergence.Force.Check 1
pdbSet Mechanics Convergence.Energy.Check 0
pdbSet Mechanics Convergence.Force.Tolerance 1e-6
set frame 0
solve time=1<s> init=0.025<s> maxstep=0.025<s> info=2 movie= {incr frame; struct tdr=[format "frame-%03d" $frame] !Gas; puts "PAIR_FRAME $frame TIME $time"}
struct tdr=result !Gas
